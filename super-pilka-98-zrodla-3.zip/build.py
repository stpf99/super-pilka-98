#!/usr/bin/env python3
"""Build: skleja shell.html + vendor three.js + moduły js w JEDEN plik HTML.
   Technika jak w uno-com-escada (source/ + build.mjs -> index.html)."""
import pathlib, re, sys

SRC = pathlib.Path("/home/z/my-project/work/source")
OUT = pathlib.Path("/home/z/my-project/download")
NAME = "super-pilka-98.html"

shell = (SRC / "shell.html").read_text(encoding="utf-8")
three = (SRC / "vendor-three.min.js").read_text(encoding="utf-8")

js_files = sorted((SRC / "js").glob("*.js"))
game = "\n;\n".join(f.read_text(encoding="utf-8") for f in js_files)

for label, code in (("THREE", three), ("GAME", game)):
    if re.search(r"</script", code, re.I):
        sys.exit(f"BŁĄD: {label} zawiera </script — przerwij tag przez <\\/script>")

html = shell.replace("<!--THREE-->", "<script>\n" + three + "\n</script>")
html = html.replace("<!--GAME-->", "<script>\n" + game + "\n</script>")

OUT.mkdir(parents=True, exist_ok=True)
dest = OUT / NAME
dest.write_text(html, encoding="utf-8")
print(f"OK: {dest}  ({dest.stat().st_size/1024:.0f} KB, {len(game.splitlines())} linii kodu gry)")
