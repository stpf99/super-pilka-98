/* ============================================================
   SUPER PILKA '98 · 11-main.js — bootstrap, pętla, sterowanie
   ============================================================ */
var MAIN = {
  lastT: 0, fps: 60, fpsAcc: 0, fpsN: 0, fpsT: 0,
  chargeP: [0, 0], chargeS: [0, 0],
  paused: false, running: false,

  boot: function(){
    var canvas = document.getElementById("c");
    WORLD.init(canvas);
    SET_bindAll();
    SET_applyLang();
    INPUT.init();
    HUD.refreshTeams();
    this.bindUI();
    window.addEventListener("resize", function(){ WORLD.resize(); });
    document.getElementById("splash").style.display = "none";
    this.state = "menu";
    RULES.state = "menu";
    requestAnimationFrame(function(t){ MAIN.loop(t); });
  },

  bindUI: function(){
    var self = this;
    document.getElementById("btnPlay").addEventListener("click", function(){ self.startMatch(); });
    document.getElementById("btnHelp").addEventListener("click", function(){
      AUDIO.init(); AUDIO.resume(); AUDIO.ui();
      document.getElementById("ovMenu").classList.add("hide");
      document.getElementById("ovHelp").classList.remove("hide");
    });
    document.getElementById("btnHelpBack").addEventListener("click", function(){
      AUDIO.ui();
      document.getElementById("ovHelp").classList.add("hide");
      document.getElementById("ovMenu").classList.remove("hide");
    });
    document.getElementById("btnResume").addEventListener("click", function(){ self.togglePause(false); });
    document.getElementById("btnSet").addEventListener("click", function(){
      AUDIO.ui();
      document.getElementById("ovPause").classList.add("hide");
      document.getElementById("ovMenu").classList.remove("hide");
    });
    document.getElementById("btnRestart").addEventListener("click", function(){ self.startMatch(); });
    document.getElementById("btnQuit").addEventListener("click", function(){ self.toMenu(); });
    document.getElementById("btnRematch").addEventListener("click", function(){ self.startMatch(); });
    document.getElementById("btnEndMenu").addEventListener("click", function(){ self.toMenu(); });
  },

  startMatch: function(){
    AUDIO.init(); AUDIO.resume(); AUDIO.ui();
    document.getElementById("ovMenu").classList.add("hide");
    document.getElementById("ovHelp").classList.add("hide");
    document.getElementById("ovPause").classList.add("hide");
    HUD.hideEnd();
    RULES.newMatch();
    WORLD.refreshAds(SET.home, SET.away);
    HUD.refreshTeams();
    /* podpowiedź kick-offu zostaje — nie nadpisuj jej „ESC — pauza” */
    document.getElementById("hud").classList.add("show");
    this.paused = false;
    this.state = "match";
  },
  toMenu: function(){
    AUDIO.ui();
    document.getElementById("ovPause").classList.add("hide");
    HUD.hideEnd();
    document.getElementById("ovMenu").classList.remove("hide");
    document.getElementById("hud").classList.remove("show");
    WORLD.m1.visible = false; WORLD.m2.visible = false;
    WORLD.aimArrow.visible = false;
    RULES.state = "menu";
    this.state = "menu";
    this.paused = false;
  },
  togglePause: function(on){
    if(on === undefined) on = !this.paused;
    this.paused = on;
    document.getElementById("ovPause").classList.toggle("hide", !on);
    if(on){
      this.el2("pScore").textContent = SET.home + "  " + SIM.teams[0].score + " : " + SIM.teams[1].score + "  " + SET.away;
      AUDIO.ui();
    }
  },
  el2: function(id){ return document.getElementById(id); },

  /* ---------- sterowanie człowieka ---------- */
  humanControl: function(dt){
    for(var s=0; s<2; s++){
      /* tryb 1 gracza: drużyna 1 = komputer; tryb oglądania: obie drużyny AI */
      if(SET.mode===2 || (SET.mode===0 && s===1)){
        var tm = SIM.teams[s];
        if(tm && tm.user){ if(tm.user.isUser===s) tm.user.isUser = null; tm.user = null; }
        this.chargeP[s] = 0; this.chargeS[s] = 0;
        continue;
      }
      var inp = INPUT.slots[s];
      var team = SIM.teams[s];
      if(!team) continue;
      var b = SIM.ball;
      var user = team.user;
      if(user && user.off){ user = null; team.user = null; }

      /* automatyczna zmiana: gdy kolega z drużyny ma piłkę */
      if(b.owner && b.owner.team===s && b.owner.role!=="GK" && b.owner.isUser===null){
        if(user && user.isUser===s) user.isUser = null;
        user = b.owner; team.user = user; user.isUser = s;
        team.switchCd = 0.25;
      }
      /* przy obronie: zmiana gdy obecny znacznie daleko od piłki */
      if(user && (!b.owner || b.owner.team!==s)){
        var near = SIM.nearestToBall(s, true);
        if(near && near!==user){
          var du = Math.hypot(user.pos.x-b.x, user.pos.z-b.z);
          var dn = Math.hypot(near.pos.x-b.x, near.pos.z-b.z);
          if(dn < du - 7){ user.isUser = null; user = near; team.user = user; user.isUser = s; team.switchCd = 0.25; }
        }
      }
      if(!user){
        var near2 = SIM.nearestToBall(s, true);
        if(near2){ user = near2; team.user = user; user.isUser = s; }
        else continue;
      }
      team.switchCd -= dt;

      /* manualna zmiana */
      if(inp.switchP && team.switchCd <= 0){
        var cands = SIM.teamPlayers(s).filter(function(p){ return p.role!=="GK" && p!==user; });
        cands.sort(function(a,c){
          return Math.hypot(a.pos.x-b.x,a.pos.z-b.z) - Math.hypot(c.pos.x-b.x,c.pos.z-b.z);
        });
        if(cands[0]){ user.isUser = null; user = cands[0]; team.user = user; user.isUser = s; team.switchCd = 0.3; }
      }

      /* ruch */
      if(inp.moveLen > 0.15){
        user.moveTarget = { x: user.pos.x + inp.mx*6, z: user.pos.z + inp.mz*6, sprint: !!inp.sprint };
      } else {
        user.moveTarget = null;
      }

      /* z piłką */
      if(b.owner===user){
        if(inp.pass){
          this.chargeP[s] = Math.min(1, this.chargeP[s] + dt/0.85);
        } else if(this.chargeP[s] > 0){
          var pw = Math.max(0.18, this.chargeP[s]); this.chargeP[s] = 0;
          var mate = SIM.pickPassTarget(s, inp.mx, inp.mz, false, user);
          if(mate){
            SIM.kick(user, mate.pos.x + mate.vel.x*0.35 - user.pos.x,
                          mate.pos.z + mate.vel.z*0.35 - user.pos.z, pw, "pass");
            RULES.onPass(user, mate);
          } else {
            SIM.kick(user, inp.moveLen>0.2?inp.mx:Math.sin(user.face),
                          inp.moveLen>0.2?inp.mz:Math.cos(user.face), pw, "pass");
            RULES.onPass(user, null);
          }
        }
        if(inp.throughP){
          var mate2 = SIM.pickPassTarget(s, inp.mx||Math.sin(user.face), inp.mz||Math.cos(user.face), true, user);
          if(mate2){
            var dirX = SIM.teams[s].dir;
            SIM.kick(user, mate2.pos.x + dirX*6 + mate2.vel.x*0.45 - user.pos.x,
                          mate2.pos.z + mate2.vel.z*0.45 - user.pos.z, 0.8, "through");
            RULES.onPass(user, mate2);
          }
        }
        if(inp.shoot){
          this.chargeS[s] = Math.min(1, this.chargeS[s] + dt/0.9);
        } else if(this.chargeS[s] > 0){
          var pw2 = Math.max(0.25, this.chargeS[s]); this.chargeS[s] = 0;
          var dirX2 = SIM.teams[s].dir;
          var gvx = dirX2*HL - user.pos.x, gvz = 0 - user.pos.z;
          var gl = Math.hypot(gvx, gvz)||1;
          gvx/=gl; gvz/=gl;
          var ax = 0, az = 0;
          if(inp.moveLen > 0.3){ ax = inp.mx; az = inp.mz; var al = Math.hypot(ax,az)||1; ax/=al; az/=al; }
          else { ax = gvx; az = gvz; }
          var dx3 = gvx*0.55 + ax*0.45, dz3 = gvz*0.55 + az*0.45;
          var l3 = Math.hypot(dx3, dz3)||1;
          SIM.kick(user, dx3/l3, dz3/l3, pw2, "shot");
          RULES.onShot(user);
        }
        HUD.showPower(Math.max(this.chargeP[s], this.chargeS[s]) > 0 ? Math.max(this.chargeP[s], this.chargeS[s]) : null);
      } else {
        this.chargeP[s] = 0; this.chargeS[s] = 0;
        /* bez piłki: wślizg */
        if(inp.tackleP){ SIM.startSlide(user); }
        if(b.owner && b.owner.team!==s && inp.passP){
          /* presja na właściciela: bieg do piłki */
          user.moveTarget = { x: b.x, z: b.z, sprint: true };
        }
        HUD.showPower(null);
      }
    }
  },

  markers: function(){
    var m1 = WORLD.m1, m2 = WORLD.m2;
    if(RULES.state==="replay"){ m1.visible = false; m2.visible = false; return; }
    var u0 = SIM.teams[0] && SIM.teams[0].user, u1 = SIM.teams[1] && SIM.teams[1].user;
    if(this.state==="match" && u0 && !u0.off){
      m1.visible = true;
      m1.position.set(u0.pos.x, 0, u0.pos.z);
      m1.userData.arrow.position.y = 2.35 + Math.sin(performance.now()/300)*0.06;
    } else m1.visible = false;
    if(this.state==="match" && u1 && !u1.off){
      m2.visible = true;
      m2.position.set(u1.pos.x, 0, u1.pos.z);
      m2.userData.arrow.position.y = 2.35 + Math.cos(performance.now()/300)*0.06;
    } else m2.visible = false;
  },

  /* ---------- główna pętla ---------- */
  loop: function(tms){
    var self = this;
    requestAnimationFrame(function(t){ self.loop(t); });
    var rawDt = (tms - this.lastT)/1000;
    var dt = Math.min(0.1, Math.max(0.001, rawDt));
    this.lastT = tms;
    /* prawdziwy fps liczony z nieograniczonego odstępu */
    this.fpsAcc += rawDt; this.fpsN++;
    if(this.fpsAcc > 0.5){
      this.fps = Math.round(this.fpsN/this.fpsAcc);
      this.fpsAcc = 0; this.fpsN = 0;
      HUD.lagMeter(this.fps, INPUT.padSeen[0], INPUT.padSeen[1]);
    }

    INPUT.update();

    /* pauza / menu — klawisze */
    if(this.state==="match"){
      var s1 = INPUT.slots[0], s2 = INPUT.slots[1];
      if((s1.pauseP || s2.pauseP) && RULES.state!=="fulltime") this.togglePause();
      if(s1.camP){ CAM.setMode(SET.cam+1); AUDIO.ui(); }
      if(s2.camP){ CAM.setMode(SET.cam+1); AUDIO.ui(); }
    }

    if(this.state==="menu"){
      /* tryb attract: pusta arena */
      CAM.update(dt, "menu");
      WORLD.renderer.render(WORLD.scene, WORLD.cam);
      return;
    }
    if(this.paused){
      WORLD.renderer.render(WORLD.scene, WORLD.cam);
      return;
    }

    /* aktualizacja gry */
    RULES.update(dt);
    if(RULES.state==="replay"){
      /* REPLAY napędza siatkę i kamerę (przez RULES.update) — symulacja wstrzymana */
    } else {
      if(RULES.state==="play"){
        AI.update(dt);
        this.humanControl(dt);
      } else {
        AI.frozen = true;
        /* człowiek kieruje wykonawcą wznowienia przez RULES.update */
      }
      SIM.step(dt);
      SIM.syncMeshes(dt);
      if(RULES.state==="play") REC.push(dt);   /* bufor powtórek */
    }
    CAM.update(dt, RULES.state==="menu" ? "menu" : RULES.state);
    this.markers();
    HUD.update(dt);

    /* emocje tłumu */
    var b = SIM.ball;
    var prox = Math.max(0, 1 - Math.min(Math.abs(b.x-HL), Math.abs(b.x+HL))/40);
    AUDIO.excitementSet(0.12 + prox*0.3 + (b.owner?0.06:0.1));
    AUDIO.update(dt);
    /* trybuny: podskok tłumu przy golu, cichy szum w trakcie gry */
    if(RULES.state==="goal") WORLD.crowdPulse = 1;
    else if(RULES.state==="replay") WORLD.crowdPulse = 0.35;
    else WORLD.crowdPulse = Math.max(0, (WORLD.crowdPulse||0) - dt*0.5);
    WORLD.tick(dt);

    WORLD.renderer.render(WORLD.scene, WORLD.cam);
  }
};

/* przycisk pauzy = powrót do gry; ustawienia w pauzie pokazują menu */

window.addEventListener("load", function(){
  MAIN.boot();
  /* pad w menu = szybki start */
  var padWatch = setInterval(function(){
    if(MAIN.state==="menu" && document.getElementById("ovMenu") && !document.getElementById("ovMenu").classList.contains("hide")){
      if(INPUT.anyPadButton()){
        INPUT.update();
        MAIN.startMatch();
      }
    }
  }, 300);
});
