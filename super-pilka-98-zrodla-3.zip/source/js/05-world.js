/* ============================================================
   SUPER PILKA '98 · 05-world.js — scena Three.js, stadion, zawodnicy
   Współrzędne: X wzdłuż boiska (±52.5), Z szerokość (±34), Y w górę.
   ============================================================ */
var PL = 105, PW = 68, HL = 52.5, HW = 34;          // wymiary boiska
var GOAL_W = 7.32, GOAL_H = 2.44, GK_R = 0.06;      // bramka

var WORLD = {
  renderer: null, scene: null, cam: null,
  gPlayers: null, gBall: null, gFx: null, gLines: null,
  kit: null, ball: null, blob: null, aimArrow: null,
  marks: [], m1: null, m2: null,

  init: function(canvas){
    this.renderer = new THREE.WebGLRenderer({ canvas: canvas, antialias: true, powerPreference:"high-performance" });
    this.renderer.outputEncoding = THREE.sRGBEncoding;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.08;
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x0a1422);
    this.scene.fog = new THREE.Fog(0x0a1422, 150, 460);

    this.cam = new THREE.PerspectiveCamera(38, innerWidth/innerHeight, 0.5, 700);
    this.cam.position.set(0, 30, 52);

    this.gLines = new THREE.Group(); this.gPlayers = new THREE.Group();
    this.gBall = new THREE.Group(); this.gFx = new THREE.Group();
    this.scene.add(this.gLines, this.gPlayers, this.gBall, this.gFx);

    this._lights();
    this._sky();
    this._ground();
    this._fieldLines();
    this._goals();
    this._stands();
    this._masts();
    this._flags();
    this._ads();
    this._markers();
    this.setNight(!SET || SET.night !== 0);   /* domyślnie: noc pod reflektorami */
    this.kit = [
      { shirt:0xf5f5f2, shorts:0xd21f2b, socks:0xd21f2b, gk:0xe8a11c, gkShorts:0x20242c, tag:0xe8352a },
      { shirt:0x2456e0, shorts:0xf5f5f2, socks:0x2456e0, gk:0x23b85c, gkShorts:0x20242c, tag:0x2a6df0 }
    ];
    this.ball = this._makeBall();
    this.gBall.add(this.ball);
    this.quality();
  },

  quality: function(){
    var q = SET.q|0;
    var dpr = window.devicePixelRatio || 1;
    if(q===0){ this.renderer.setPixelRatio(Math.min(dpr,1)); this.renderer.shadowMap.enabled=false; }
    else if(q===1){ this.renderer.setPixelRatio(Math.min(dpr,1.5)); this.renderer.shadowMap.enabled=true;
      if(this._sun) this._sun.shadow.mapSize.set(1024,1024); }
    else { this.renderer.setPixelRatio(Math.min(dpr,2)); this.renderer.shadowMap.enabled=true;
      if(this._sun) this._sun.shadow.mapSize.set(2048,2048); }
    if(this._sun){ this._sun.castShadow = this.renderer.shadowMap.enabled;
      if(this._sun.shadow.map){ this._sun.shadow.map.dispose(); this._sun.shadow.map = null; } }
    /* publiczność: przy niskiej jakości rzadsza trybuna */
    if(this._crowdFull !== undefined && this.crowdMesh && this.crowdMesh.count !== undefined)
      this.crowdMesh.count = (q===0) ? Math.max(400, Math.floor(this._crowdFull*0.42)) : this._crowdFull;
    this.renderer.setSize(innerWidth, innerHeight, false);
    this.cam.aspect = innerWidth/innerHeight; this.cam.updateProjectionMatrix();
  },
  resize: function(){
    this.renderer.setSize(innerWidth, innerHeight, false);
    this.cam.aspect = innerWidth/innerHeight; this.cam.updateProjectionMatrix();
  },

  /* ---------- światła i niebo ---------- */
  _lights: function(){
    this.hemi = new THREE.HemisphereLight(0x9db4d6, 0x1c2a1a, 0.85);
    this.scene.add(this.hemi);
    var sun = new THREE.DirectionalLight(0xfff1d0, 1.15);
    sun.position.set(46, 84, 30);
    sun.castShadow = true;
    sun.shadow.mapSize.set(2048, 2048);
    sun.shadow.camera.left = -78; sun.shadow.camera.right = 78;
    sun.shadow.camera.top = 60; sun.shadow.camera.bottom = -60;
    sun.shadow.camera.near = 10; sun.shadow.camera.far = 220;
    sun.shadow.bias = -0.0006;
    this.scene.add(sun);
    this._sun = sun;
    /* 4 reflektory z masztów — realne światła sceny (cień liczy tylko jedno światło) */
    this.spots = [];
    for(var sx=-1; sx<=1; sx+=2) for(var sz=-1; sz<=1; sz+=2){
      var sp = new THREE.SpotLight(0xdfeaff, 0, 340, 0.64, 0.5, 1.1);
      sp.position.set(sx*66, 30.5, sz*48);
      sp.target.position.set(sx*24, 0, sz*16);
      sp.castShadow = false;
      this.scene.add(sp);
      this.scene.add(sp.target);
      this.spots.push(sp);
    }
  },
  _sky: function(){
    var n = 260, pos = new Float32Array(n*3);
    for(var i=0;i<n;i++){
      var a = Math.random()*Math.PI*2, r = 300 + Math.random()*60;
      var y = 30 + Math.random()*220;
      pos[i*3] = Math.cos(a)*r; pos[i*3+1] = y; pos[i*3+2] = Math.sin(a)*r;
    }
    var g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.BufferAttribute(pos,3));
    var m = new THREE.PointsMaterial({ color:0xcfe0ff, size:1.6, sizeAttenuation:false, transparent:true, opacity:0.8 });
    this.stars = new THREE.Points(g, m);
    this.scene.add(this.stars);
  },

  /* dzień / noc pod reflektorami */
  setNight: function(n){
    this.night = !!n;
    var bg = this.night ? 0x05080f : 0x4a7ab5;
    this.scene.background = new THREE.Color(bg);
    this.scene.fog = new THREE.Fog(this.night ? 0x05080f : 0x7fa3c8, this.night ? 130 : 170, this.night ? 430 : 560);
    if(this.hemi){
      this.hemi.intensity = this.night ? 0.34 : 0.78;
      this.hemi.color.setHex(this.night ? 0x33415e : 0x9db4d6);
      this.hemi.groundColor.setHex(this.night ? 0x0c1210 : 0x1c2a1a);
    }
    if(this._sun){
      this._sun.intensity = this.night ? 0.44 : 1.0;
      this._sun.color.setHex(this.night ? 0xaebfe0 : 0xfff1d0);
    }
    if(this.spots) for(var i=0;i<this.spots.length;i++) this.spots[i].intensity = this.night ? 0.95 : 0;
    if(this.cones) for(var c=0;c<this.cones.length;c++) this.cones[c].visible = this.night;
    if(this.glows) for(var g2=0;g2<this.glows.length;g2++) this.glows[g2].material.opacity = this.night ? 0.9 : 0.26;
    if(this.stars) this.stars.visible = this.night;
    this.renderer.toneMappingExposure = this.night ? 1.12 : 1.0;
  },

  /* ---------- płaszczyzny pomocnicze ---------- */
  _mkCanvas: function(w,h){ var c=document.createElement("canvas"); c.width=w; c.height=h; return c; },
  _tex: function(cv, rx, ry){
    var t = new THREE.CanvasTexture(cv);
    t.wrapS = t.wrapT = THREE.RepeatWrapping;
    if(rx) t.repeat.set(rx, ry||1);
    t.anisotropy = 8;
    return t;
  },
  _plane: function(w, h, mat, rx){
    var m = new THREE.Mesh(new THREE.PlaneGeometry(w, h), mat);
    m.rotation.x = rx!==undefined ? rx : -Math.PI/2;
    return m;
  },

  _ground: function(){
    /* murawa jak prawdziwa: pasy koszenia prostopadłe do kamery TV,
       ziarno trawy, ślady użytkowania przy bramkach i na środku */
    var cv = this._mkCanvas(1024, 512), g = cv.getContext("2d");
    var BANDS = 12, bw = 1024/BANDS;
    for(var i=0;i<BANDS;i++){
      g.fillStyle = (i%2===0) ? "#27702e" : "#1b5021";
      g.fillRect(Math.round(i*bw), 0, Math.ceil(bw)+1, 512);
    }
    for(var d=0; d<9000; d++){
      g.fillStyle = "rgba("+(16+Math.random()*40|0)+","+(80+Math.random()*60|0)+","+(30+Math.random()*30|0)+",0.16)";
      g.fillRect(Math.random()*1024, Math.random()*512, 2, 2);
    }
    function wear(x, y, rx, ry, a){
      var gr = g.createRadialGradient(x, y, 2, x, y, rx);
      gr.addColorStop(0, "rgba(124,112,62,"+a+")");
      gr.addColorStop(1, "rgba(124,112,62,0)");
      g.save(); g.translate(x, y); g.scale(1, ry/rx); g.translate(-x, -y);
      g.fillStyle = gr;
      g.beginPath(); g.arc(x, y, rx, 0, 6.29); g.fill();
      g.restore();
    }
    wear(512, 256, 62, 34, 0.10);        /* środek boiska */
    wear(512-317, 256, 36, 26, 0.10);    /* punkty karnego */
    wear(512+317, 256, 36, 26, 0.10);
    wear(512-470, 256, 30, 24, 0.09);    /* bramki */
    wear(512+470, 256, 30, 24, 0.09);
    var vg = g.createRadialGradient(512, 256, 280, 512, 256, 640);
    vg.addColorStop(0, "rgba(0,0,0,0)"); vg.addColorStop(1, "rgba(0,22,8,0.34)");
    g.fillStyle = vg; g.fillRect(0, 0, 1024, 512);
    var grass = new THREE.CanvasTexture(cv);
    grass.encoding = THREE.sRGBEncoding;      /* bez tego kolory canvasu są rozjaśniane */
    grass.anisotropy = 16;
    var pitch = this._plane(134, 96, new THREE.MeshLambertMaterial({ map: grass }));
    pitch.receiveShadow = true;
    this.scene.add(pitch);
    var outer = this._plane(420, 380, new THREE.MeshBasicMaterial({ color:0x070b11 }));
    outer.position.y = -0.06; outer.receiveShadow = false;
    this.scene.add(outer);
  },

  _line: function(w, l, x, z, rotY){
    var m = new THREE.Mesh(new THREE.PlaneGeometry(w, l),
      new THREE.MeshBasicMaterial({ color:0xf2f6ff }));
    m.rotation.x = -Math.PI/2;
    if(rotY) m.rotation.z = rotY;
    m.position.set(x, 0.02, z);
    this.gLines.add(m);
    return m;
  },
  _ring: function(rIn, rOut, x, z, tStart, tLen){
    var m = new THREE.Mesh(new THREE.RingGeometry(rIn, rOut, 48, 1, tStart||0, tLen||Math.PI*2),
      new THREE.MeshBasicMaterial({ color:0xf2f6ff, side:THREE.DoubleSide }));
    m.rotation.x = -Math.PI/2;
    m.position.set(x, 0.02, z);
    this.gLines.add(m);
    return m;
  },
  _spot: function(x, z){
    var m = new THREE.Mesh(new THREE.CircleGeometry(0.16, 16),
      new THREE.MeshBasicMaterial({ color:0xf2f6ff }));
    m.rotation.x = -Math.PI/2; m.position.set(x, 0.021, z);
    this.gLines.add(m);
  },
  _fieldLines: function(){
    var L = PL, W = PW;
    this._line(L+0.3, 0.13, 0,  HW); this._line(L+0.3, 0.13, 0, -HW);
    this._line(0.13, W+0.3,  HL, 0); this._line(0.13, W+0.3, -HL, 0);
    this._line(0.13, W, 0, 0);
    this._ring(9.09, 9.21, 0, 0);
    this._spot(0, 0);
    for(var s=-1; s<=1; s+=2){
      /* pole karne */
      this._line(0.13, 40.32, s*(HL-16.5), 0);
      this._line(16.5, 0.13, s*(HL-8.25),  20.16);
      this._line(16.5, 0.13, s*(HL-8.25), -20.16);
      /* pole bramkowe */
      this._line(0.13, 18.32, s*(HL-5.5), 0);
      this._line(5.5, 0.13, s*(HL-2.75),  9.16);
      this._line(5.5, 0.13, s*(HL-2.75), -9.16);
      /* punkty i łuki karne */
      this._spot(s*(HL-11), 0);
      var a = Math.acos(5.5/9.15);
      if(s<0) this._ring(9.09, 9.21, s*(HL-11), 0, -a, 2*a);
      else    this._ring(9.09, 9.21, s*(HL-11), 0, Math.PI-a, 2*a);
      /* łuki narożne */
      if(s>0){
        this._ring(0.92, 1.04,  HL,  HW, Math.PI, Math.PI/2);
        this._ring(0.92, 1.04,  HL, -HW, Math.PI/2, Math.PI/2);
        this._ring(0.92, 1.04, -HL,  HW, Math.PI*1.5, Math.PI/2);
        this._ring(0.92, 1.04, -HL, -HW, 0, Math.PI/2);
      }
    }
  },

  _goals: function(){
    var postMat = new THREE.MeshLambertMaterial({ color:0xf8f8f8 });
    var netCv = this._mkCanvas(128,128), ng = netCv.getContext("2d");
    ng.strokeStyle = "rgba(255,255,255,0.85)"; ng.lineWidth = 1.4;
    for(var i=0;i<=128;i+=9){
      ng.beginPath(); ng.moveTo(i,0); ng.lineTo(i,128); ng.stroke();
      ng.beginPath(); ng.moveTo(0,i); ng.lineTo(128,i); ng.stroke();
    }
    var netMat = new THREE.MeshBasicMaterial({ map:this._tex(netCv, 6, 3), transparent:true, opacity:0.34, side:THREE.DoubleSide, depthWrite:false });
    for(var s=-1; s<=1; s+=2){
      var gx = s*HL;
      var p1 = new THREE.Mesh(new THREE.CylinderGeometry(GK_R, GK_R, GOAL_H+0.1, 10), postMat);
      p1.position.set(gx, GOAL_H/2,  3.66);
      var p2 = p1.clone(); p2.position.z = -3.66;
      var bar = new THREE.Mesh(new THREE.CylinderGeometry(GK_R, GK_R, GOAL_W+0.24, 10), postMat);
      bar.rotation.x = Math.PI/2; bar.position.set(gx, GOAL_H, 0);
      p1.castShadow = p2.castShadow = bar.castShadow = true;
      this.scene.add(p1, p2, bar);
      /* siatka: tył, góra, boki */
      var back = new THREE.Mesh(new THREE.PlaneGeometry(GOAL_W+0.2, 2.0), netMat);
      back.position.set(s*(HL+1.5), 1.0, 0); back.rotation.y = Math.PI/2;
      var top = new THREE.Mesh(new THREE.PlaneGeometry(GOAL_W+0.2, 1.7), netMat);
      top.position.set(s*(HL+0.75), 2.2, 0); top.rotation.set(Math.PI/2, Math.PI/2*s, 0);
      var sideL = new THREE.Mesh(new THREE.PlaneGeometry(1.5, 2.0), netMat);
      sideL.position.set(s*(HL+0.75), 1.0, 3.66);
      var sideR = sideL.clone(); sideR.position.z = -3.66;
      this.scene.add(back, top, sideL, sideR);
    }
  },

  /* pomocnik: scalenie geometrii (sylwetka kibica = tułów + głowa) */
  _mergeGeoms: function(parts){
    var pos = [], nor = [];
    var v = new THREE.Vector3(), n = new THREE.Vector3(), nm = new THREE.Matrix3();
    for(var i=0;i<parts.length;i++){
      var g = parts[i].g.toNonIndexed();
      var p = g.attributes.position.array, q = g.attributes.normal.array;
      nm.getNormalMatrix(parts[i].m);
      for(var k=0;k<p.length;k+=3){
        v.set(p[k], p[k+1], p[k+2]).applyMatrix4(parts[i].m);
        pos.push(v.x, v.y, v.z);
        n.set(q[k], q[k+1], q[k+2]).applyMatrix3(nm).normalize();
        nor.push(n.x, n.y, n.z);
      }
    }
    var out = new THREE.BufferGeometry();
    out.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3));
    out.setAttribute("normal", new THREE.Float32BufferAttribute(nor, 3));
    return out;
  },
  _crowdGeo: function(){
    if(this._crowdGeoC) return this._crowdGeoC;
    var body = new THREE.BoxGeometry(0.34, 0.46, 0.26);
    var head = new THREE.SphereGeometry(0.13, 6, 5);
    var geo = this._mergeGeoms([
      { g: body, m: new THREE.Matrix4().makeTranslation(0, 0.40, 0) },
      { g: head, m: new THREE.Matrix4().makeTranslation(0, 0.78, 0.02) }
    ]);
    this._crowdGeoC = geo;
    return geo;
  },

  _stands: function(){
    var terraceMat = new THREE.MeshLambertMaterial({ color:0x2e3542 });
    var wallMat = new THREE.MeshLambertMaterial({ color:0x10151f });
    var roofMat = new THREE.MeshLambertMaterial({ color:0x272f3e });
    var steelMat = new THREE.MeshLambertMaterial({ color:0x39414f });
    /* jeden materiał tłumu — bujanie i skoki kibiców liczone w shaderze (0 kosztu CPU) */
    var uni = this.crowdUni = { uTime: { value: 0 }, uJump: { value: 0.16 } };
    var crowdMat = new THREE.MeshLambertMaterial({ color:0xffffff, emissive:0x11141c });
    var self = this;
    crowdMat.onBeforeCompile = function(sh){
      sh.uniforms.uTime = uni.uTime;
      sh.uniforms.uJump = uni.uJump;
      sh.vertexShader = "uniform float uTime;\nuniform float uJump;\nattribute float aPhase;\nattribute float aRand;\n" +
        sh.vertexShader.replace("#include <begin_vertex>",
          "#include <begin_vertex>\n" +
          "float bob = sin(uTime*(1.5+aRand*1.6)+aPhase);\n" +
          "transformed.y += 0.02 + bob*(0.035+uJump*0.30);\n");
    };
    var cgeo = this._crowdGeo();
    var dummy = new THREE.Object3D();
    var col = new THREE.Color();
    var items = [];
    var sinA = Math.sin(1.06), cosA = Math.cos(1.06);
    function seatItems(w, dist, rotY){
      for(var r=0; r<13; r++){
        var l = -11.5 + r*1.8;
        var rowZ = dist + 2 + l*sinA;
        var rowY = 11 + l*cosA + 0.42;
        var cols = Math.floor(w/0.85);
        for(var c=0; c<cols; c++){
          if(Math.random() < 0.14) continue;          /* puste miejsca */
          items.push({
            lx: -w/2 + (c+0.5)*0.85 + (Math.random()*0.24-0.12),
            y: rowY + Math.random()*0.05,
            z: rowZ + (Math.random()*0.22-0.11),
            ry: rotY, s: 0.82 + Math.random()*0.3
          });
        }
      }
    }
    seatItems(112, 46, 0);
    seatItems(112, 46, Math.PI);
    seatItems(64, 66, Math.PI/2);
    seatItems(64, 66, -Math.PI/2);
    var inst = new THREE.InstancedMesh(cgeo, crowdMat, items.length);
    var phases = new Float32Array(items.length);
    var rands = new Float32Array(items.length);
    var pal = [0xe8352a,0xe8352a,0x2456e0,0xf5f5f2,0xffcf3d,0x7893c9,0x20242c,0xc9542a,
               0x3c4757,0x8a94a6,0x5c3d2e,0x2f6b46,0x1d2740,0x9b6a3c];
    for(var i=0;i<items.length;i++){
      var it = items[i];
      var wx = it.lx*Math.cos(it.ry) + it.z*Math.sin(it.ry);
      var wz = -it.lx*Math.sin(it.ry) + it.z*Math.cos(it.ry);
      dummy.position.set(wx, it.y, wz);
      dummy.rotation.set(0, it.ry + Math.PI, 0);
      dummy.scale.set(it.s, it.s, it.s);
      dummy.updateMatrix();
      inst.setMatrixAt(i, dummy.matrix);
      col.setHex(pal[(Math.random()*pal.length)|0]);
      if(Math.random() < 0.3) col.offsetHSL(0, 0, (Math.random()-0.5)*0.16);
      inst.setColorAt(i, col);
      phases[i] = Math.random()*6.283;
      rands[i] = Math.random();
    }
    inst.instanceMatrix.needsUpdate = true;
    if(inst.instanceColor) inst.instanceColor.needsUpdate = true;
    inst.geometry.setAttribute("aPhase", new THREE.InstancedBufferAttribute(phases, 1));
    inst.geometry.setAttribute("aRand", new THREE.InstancedBufferAttribute(rands, 1));
    inst.frustumCulled = false;
    this.crowdMesh = inst;
    this._crowdFull = items.length;
    this.scene.add(inst);
    /* konstrukcja trybun: mur przy boisku, betonowy płat, dach na słupach */
    function stand(w, dist, rotY){
      var grp = new THREE.Group();
      var wall = new THREE.Mesh(new THREE.BoxGeometry(w, 2.9, 1.6), wallMat);
      wall.position.set(0, 1.45, dist - 3.2);
      var slab = new THREE.Mesh(new THREE.PlaneGeometry(w, 30), terraceMat);
      slab.position.set(0, 11, dist + 2);
      slab.rotation.x = 1.06;          /* +: górna krawędź DALEJ od boiska */
      slab.receiveShadow = true;
      var roof = new THREE.Mesh(new THREE.BoxGeometry(w, 0.6, 10), roofMat);
      roof.position.set(0, 21.6, dist + 7.5);
      roof.rotation.x = 0.09;
      grp.add(wall, slab, roof);
      for(var p=0; p<=2; p++){
        var pole = new THREE.Mesh(new THREE.BoxGeometry(0.55, 17.5, 0.55), steelMat);
        pole.position.set(-w/2 + p*(w/2), 12.9, dist + 11.4);
        grp.add(pole);
      }
      grp.rotation.y = rotY;
      self.scene.add(grp);
      return grp;
    }
    stand(112, 46, 0);
    stand(112, 46, Math.PI);
    stand(64, 66, Math.PI/2);
    stand(64, 66, -Math.PI/2);
  },

  _masts: function(){
    var poleMat = new THREE.MeshLambertMaterial({ color:0x1a2030 });
    var lampMat = new THREE.MeshBasicMaterial({ color:0xeaf2ff });
    /* poświata lampy */
    var glowCv = this._mkCanvas(128, 128), gg = glowCv.getContext("2d");
    var gr = gg.createRadialGradient(64, 64, 4, 64, 64, 62);
    gr.addColorStop(0, "rgba(235,244,255,0.95)");
    gr.addColorStop(0.28, "rgba(190,214,255,0.42)");
    gr.addColorStop(1, "rgba(160,190,255,0)");
    gg.fillStyle = gr; gg.fillRect(0, 0, 128, 128);
    var glowTex = new THREE.CanvasTexture(glowCv);
    /* stożek światła (alphaMap: jasno przy głowie, zanika przy murawie) */
    var coneCv = this._mkCanvas(16, 256), cg = coneCv.getContext("2d");
    var lg = cg.createLinearGradient(0, 0, 0, 256);
    lg.addColorStop(0, "rgb(255,255,255)");
    lg.addColorStop(1, "rgb(0,0,0)");
    cg.fillStyle = lg; cg.fillRect(0, 0, 16, 256);
    var coneMat = new THREE.MeshBasicMaterial({ color:0x9fbfe8, transparent:true, opacity:0.15,
      alphaMap:new THREE.CanvasTexture(coneCv), blending:THREE.AdditiveBlending,
      depthWrite:false, side:THREE.DoubleSide, fog:false });
    this.cones = []; this.glows = [];
    var up = new THREE.Vector3(0, 1, 0);
    for(var sx=-1; sx<=1; sx+=2) for(var sz=-1; sz<=1; sz+=2){
      var hx = sx*66, hz = sz*48;
      var pole = new THREE.Mesh(new THREE.CylinderGeometry(0.42, 0.62, 30, 8), poleMat);
      pole.position.set(hx, 15, hz);
      var head = new THREE.Mesh(new THREE.BoxGeometry(5.8, 2.2, 0.8), lampMat);
      head.position.set(hx, 30.5, hz);
      head.lookAt(0, 2, 0);
      this.scene.add(pole, head);
      var glow = new THREE.Sprite(new THREE.SpriteMaterial({ map:glowTex, color:0xffffff,
        blending:THREE.AdditiveBlending, depthWrite:false, transparent:true, opacity:0.9, fog:false }));
      glow.scale.set(11, 11, 1);
      glow.position.set(hx - sx*3.2, 30.4, hz - sz*2.4);
      this.scene.add(glow);
      this.glows.push(glow);
      /* stożek: od głowy masztu do ćwiartki boiska */
      var tp = new THREE.Vector3(sx*24, 0, sz*16);
      var hp = new THREE.Vector3(hx, 30.5, hz);
      var dir = tp.clone().sub(hp);          /* głowa -> murawa */
      var len = Math.max(20, dir.length());
      var cone = new THREE.Mesh(new THREE.CylinderGeometry(0.8, 13, 1, 20, 1, true), coneMat);
      cone.scale.y = len;
      cone.position.copy(hp).addScaledVector(dir, 0.5);
      cone.quaternion.setFromUnitVectors(up, dir.clone().negate().normalize());
      this.scene.add(cone);
      this.cones.push(cone);
    }
  },

  /* chorągiewki narożne */
  _flags: function(){
    this.flags = [];
    var poleMat = new THREE.MeshLambertMaterial({ color:0xdddddd });
    var flagMat = new THREE.MeshBasicMaterial({ color:0xffcf3d, side:THREE.DoubleSide });
    for(var sx=-1; sx<=1; sx+=2) for(var sz=-1; sz<=1; sz+=2){
      var pole = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.035, 1.6, 6), poleMat);
      pole.position.set(sx*HL, 0.8, sz*HW);
      var fg = new THREE.PlaneGeometry(0.55, 0.38);
      fg.translate(0.275, 0, 0);              /* kotwica na drzewcu */
      var flag = new THREE.Mesh(fg, flagMat);
      flag.position.set(sx*HL, 1.48, sz*HW);
      flag.userData.base = Math.random()*6.28;
      this.scene.add(pole, flag);
      this.flags.push(flag);
    }
  },

  _ads: function(){
    this.adMat = new THREE.MeshBasicMaterial({ color:0x10141c });
    var mk = function(w, x, z, ry){
      var m = new THREE.Mesh(new THREE.BoxGeometry(w, 1.0, 0.24), WORLD.adMat);
      m.position.set(x, 0.52, z); m.rotation.y = ry||0;
      m.castShadow = false;
      return m;
    };
    this.adBoards = [
      mk(104, 0,  37.4, 0), mk(104, 0, -37.4, 0),
      mk(46,  56.6, 0, Math.PI/2), mk(46, -56.6, 0, Math.PI/2)
    ];
    this.scene.add(this.adBoards[0], this.adBoards[1], this.adBoards[2], this.adBoards[3]);
  },
  refreshAds: function(home, away){
    var cv = this._mkCanvas(1024, 64), g = cv.getContext("2d");
    g.fillStyle = "#0e1420"; g.fillRect(0,0,1024,64);
    g.fillStyle = "#ffcf3d"; g.font = "bold 30px 'Segoe UI',Arial";
    var txt = ("  SUPER PILKA '98  ★  " + home + "  —  " + away + "  ★  JEDEN PLIK HTML  ★").repeat(2);
    g.fillText(txt.slice(0, 120), 8, 44);
    g.fillStyle = "#e8352a"; g.fillRect(0,0,1024,4); g.fillRect(0,60,1024,4);
    if(this.adMat.map) this.adMat.map.dispose();
    this.adMat.map = this._tex(cv, 4, 1);
    this.adMat.needsUpdate = true;
  },

  _markers: function(){
    /* wskaźnik gracza P1 / P2: pierścień + strzałka nad głową */
    function mkMark(color){
      var grp = new THREE.Group();
      var ring = new THREE.Mesh(new THREE.RingGeometry(0.46, 0.60, 28),
        new THREE.MeshBasicMaterial({ color: color, transparent:true, opacity:0.9, side:THREE.DoubleSide, depthWrite:false }));
      ring.rotation.x = -Math.PI/2; ring.position.y = 0.03;
      var arrow = new THREE.Mesh(new THREE.ConeGeometry(0.16, 0.34, 10),
        new THREE.MeshBasicMaterial({ color: color, depthWrite:false }));
      arrow.rotation.x = Math.PI; arrow.position.y = 2.35;
      grp.add(ring, arrow);
      grp.userData = { ring: ring, arrow: arrow };
      grp.visible = false;
      return grp;
    }
    this.m1 = mkMark(0xffd23d); this.m2 = mkMark(0x3ddcff);
    this.gFx.add(this.m1, this.m2);
    /* piłka: cień „kropelka” */
    var blobCv = this._mkCanvas(64,64), bg = blobCv.getContext("2d");
    var gr = bg.createRadialGradient(32,32,4,32,32,30);
    gr.addColorStop(0,"rgba(0,0,0,0.5)"); gr.addColorStop(1,"rgba(0,0,0,0)");
    bg.fillStyle = gr; bg.fillRect(0,0,64,64);
    this.blob = new THREE.Mesh(new THREE.PlaneGeometry(1,1),
      new THREE.MeshBasicMaterial({ map:new THREE.CanvasTexture(blobCv), transparent:true, depthWrite:false }));
    this.blob.rotation.x = -Math.PI/2;
    this.gFx.add(this.blob);
    /* strzałka namieru przy wznowieniach */
    this.aimArrow = new THREE.Mesh(new THREE.PlaneGeometry(3.2, 0.14),
      new THREE.MeshBasicMaterial({ color:0xffffff, transparent:true, opacity:0.55, depthWrite:false }));
    this.aimArrow.rotation.x = -Math.PI/2;
    this.aimArrow.geometry.translate(1.6, 0, 0);
    this.aimArrow.visible = false;
    this.gFx.add(this.aimArrow);
  },

  /* ---------- zawodnicy ---------- */
  _numTex: function(num, dark){
    var cv = this._mkCanvas(64, 80), g = cv.getContext("2d");
    g.fillStyle = dark ? "#1a1a22" : "#ffffff";
    g.font = "bold 58px 'Segoe UI',Arial";
    g.textAlign = "center"; g.textBaseline = "middle";
    g.fillText(String(num), 32, 42);
    return new THREE.CanvasTexture(cv);
  },
  makePlayer: function(team, isGk, num){
    var kit = this.kit[team];
    var shirt = isGk ? kit.gk : kit.shirt;
    var shorts = isGk ? kit.gkShorts : kit.shorts;
    var socks = isGk ? 0x20242c : kit.socks;
    var skins = [0xf0c8a0, 0xdca475, 0xa86a3d, 0x74462a];
    var hairs = [0x17120e, 0x3a2a18, 0x6e4f1f, 0xb08d5a, 0x0e0c0a];
    var skin = skins[(Math.random()*skins.length)|0];
    var hair = hairs[(Math.random()*hairs.length)|0];

    var grp = new THREE.Group();
    var shirtMat = new THREE.MeshLambertMaterial({ color: shirt });
    var shortsMat = new THREE.MeshLambertMaterial({ color: shorts });
    var sockMat = new THREE.MeshLambertMaterial({ color: socks });
    var skinMat = new THREE.MeshLambertMaterial({ color: skin });

    function leg(sx){
      var pivot = new THREE.Group();
      pivot.position.set(sx*0.095, 0.58, 0);
      var thigh = new THREE.Mesh(new THREE.CylinderGeometry(0.062, 0.05, 0.26, 8), skinMat);
      thigh.position.y = -0.14;
      var sock = new THREE.Mesh(new THREE.CylinderGeometry(0.055, 0.05, 0.24, 8), sockMat);
      sock.position.y = -0.38;
      var boot = new THREE.Mesh(new THREE.BoxGeometry(0.11, 0.07, 0.2), new THREE.MeshLambertMaterial({ color:0x14141a }));
      boot.position.set(0, -0.52, 0.04);
      pivot.add(thigh, sock, boot);
      return pivot;
    }
    var legL = leg(-1), legR = leg(1);
    var body = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.5, 0.24), shirtMat);
    body.position.y = 1.02;
    var hip = new THREE.Mesh(new THREE.BoxGeometry(0.36, 0.2, 0.22), shortsMat);
    hip.position.y = 0.68;
    var num = new THREE.Mesh(new THREE.PlaneGeometry(0.26, 0.32),
      new THREE.MeshBasicMaterial({ map: this._numTex(num, isGk), transparent:true }));
    num.position.set(0, 1.06, -0.125); num.rotation.y = Math.PI;
    function arm(sx){
      var pivot = new THREE.Group();
      pivot.position.set(sx*0.26, 1.2, 0);
      var a = new THREE.Mesh(new THREE.CylinderGeometry(0.048, 0.04, 0.4, 8), shirtMat);
      a.position.y = -0.18;
      var hand = new THREE.Mesh(new THREE.SphereGeometry(0.05, 6, 6), skinMat);
      hand.position.y = -0.4;
      pivot.add(a, hand);
      return pivot;
    }
    var armL = arm(-1), armR = arm(1);
    var head = new THREE.Mesh(new THREE.SphereGeometry(0.125, 10, 8), skinMat);
    head.position.y = 1.44;
    var hairMesh = new THREE.Mesh(new THREE.SphereGeometry(0.132, 10, 8, 0, Math.PI*2, 0, Math.PI/2.1),
      new THREE.MeshLambertMaterial({ color: hair }));
    hairMesh.position.y = 1.46;

    grp.add(legL, legR, body, hip, num, armL, armR, head, hairMesh);
    grp.traverse(function(o){ if(o.isMesh){ o.castShadow = true; } });
    grp.userData = { legL:legL, legR:legR, armL:armL, armR:armR, phase: Math.random()*6.28 };
    this.gPlayers.add(grp);
    return grp;
  },
  removePlayer: function(mesh){
    this.gPlayers.remove(mesh);
    mesh.traverse(function(o){ if(o.isMesh && o.geometry) o.geometry.dispose(); });
  },

  _makeBall: function(){
    var cv = this._mkCanvas(128, 64), g = cv.getContext("2d");
    g.fillStyle = "#fafafa"; g.fillRect(0,0,128,64);
    g.fillStyle = "#1c1c22";
    for(var i=0;i<10;i++){
      g.beginPath();
      g.arc(8+(i%5)*26, 14+(i/5|0)*32, 7, 0, 6.29); g.fill();
    }
    var tex = this._tex(cv, 2, 1);
    var m = new THREE.Mesh(new THREE.SphereGeometry(0.15, 14, 12),
      new THREE.MeshPhongMaterial({ map: tex, shininess: 40 }));
    m.castShadow = true;
    return m;
  },

  /* animacja biegu zawodnika — styl '98: szerokie wymachy, pochylenie, bujanie */
  animatePlayer: function(mesh, speed, dt, action, actionT){
    var u = mesh.userData;
    var rate = 4 + speed*1.9;
    u.phase += dt * rate * (speed > 0.3 ? 1 : 0.25);
    var s = Math.sin(u.phase) * Math.min(1, speed/4);
    var c = Math.cos(u.phase) * Math.min(1, speed/4);
    if(action === "slide"){
      mesh.rotation.x = -1.15;
      u.legL.rotation.x = -0.5; u.legR.rotation.x = -0.1;
      u.armL.rotation.x = 2.6; u.armR.rotation.x = 0.6;
    } else if(action === "kick"){
      /* dwie fazy: zamach, potem wybij nogi */
      mesh.rotation.x = 0.06;
      var t = actionT || 0;
      if(t > 0.12){
        u.legR.rotation.x = 0.85; u.legL.rotation.x = -0.18;
        u.armL.rotation.x = 0.35; u.armR.rotation.x = -0.45;
      } else {
        u.legR.rotation.x = -1.35; u.legL.rotation.x = 0.42;
        u.armL.rotation.x = -0.7; u.armR.rotation.x = 0.55;
      }
    } else if(action === "fallen"){
      mesh.rotation.x = -1.5;
      u.legL.rotation.x = 0.3; u.legR.rotation.x = -0.2;
      u.armL.rotation.x = 0.4; u.armR.rotation.x = -0.4;
    } else if(action === "celebrate"){
      mesh.rotation.x = 0;
      var wig = Math.sin(performance.now()/110)*0.2;
      u.legL.rotation.x = 0; u.legR.rotation.x = 0;
      u.armL.rotation.x = Math.PI*0.85 + wig; u.armR.rotation.x = -Math.PI*0.85 - wig;
    } else {
      mesh.rotation.x = -Math.min(0.11, speed*0.013);   /* pochylenie w biegu */
      u.legL.rotation.x = s*1.05; u.legR.rotation.x = -s*1.05;
      u.armL.rotation.x = -s*0.95; u.armR.rotation.x = s*0.95;
      if(speed <= 0.3){
        /* spokojny oddech na stojąco */
        var br = Math.sin(u.phase*0.8);
        u.armL.rotation.x = -0.14 + br*0.07; u.armR.rotation.x = 0.14 - br*0.07;
        u.legL.rotation.x = 0; u.legR.rotation.x = 0;
        mesh.position.y += br*0.012;
      }
      /* bujanie biegu */
      mesh.position.y += Math.abs(Math.sin(u.phase))*0.05*Math.min(1, speed/5);
    }
  },

  /* puls trybun: skoki przy golu / ekscytacji (shader) + flagi + drganie lamp */
  crowdPulse: 0,
  tick: function(dt){
    this._crowdT = (this._crowdT || 0) + dt;
    if(this.crowdUni){
      this.crowdUni.uTime.value = this._crowdT;
      var want = 0.14 + (this.crowdPulse || 0) * 0.95;
      this.crowdUni.uJump.value += (want - this.crowdUni.uJump.value) * Math.min(1, dt*3.5);
    }
    if(this.flags){
      var tt = this._crowdT;
      for(var i=0;i<this.flags.length;i++){
        var f = this.flags[i];
        f.rotation.y = f.userData.base + Math.sin(tt*2.4 + i*1.7)*0.30 + Math.sin(tt*7.1 + i)*0.06;
      }
    }
    if(this.glows && this.night){
      var fl = 0.88 + Math.sin(this._crowdT*37)*0.03 + Math.sin(this._crowdT*9.3)*0.04;
      for(var g=0; g<this.glows.length; g++) this.glows[g].material.opacity = 0.9*fl;
    }
  }
};
