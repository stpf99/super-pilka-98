/* ============================================================
   SUPER PILKA '98 · 10-hud.js — HUD, ekrany, pomoc sterowania
   ============================================================ */
var HUD = {
  el: function(id){ return document.getElementById(id); },
  bannerT: 0, commT: 0,

  refreshTeams: function(){
    this.el("tNameH").textContent = SET.home.slice(0, 12);
    this.el("tNameA").textContent = SET.away.slice(0, 12);
    this.setScore();
  },
  setScore: function(){
    this.el("gH").textContent = SIM.teams[0] ? SIM.teams[0].score : 0;
    this.el("gA").textContent = SIM.teams[1] ? SIM.teams[1].score : 0;
    this.updateCards();
  },
  updateClock: function(){
    var m = RULES.state==="fulltime" ? 90 : RULES.displayMin;
    this.el("clkMin").textContent = (m<10?"0":"") + m + "'";
    var tag = RULES.half===1 ? t("k1p") : t("k2p");
    if(RULES.state==="fulltime") tag = t("k1p_done");
    this.el("halfTag").textContent = tag;
  },
  updateCards: function(){
    var h = this.el("cardsH"), a = this.el("cardsA");
    h.innerHTML = ""; a.innerHTML = "";
    if(!SIM.players.length) return;
    var yell = [0,0], red = [0,0];
    for(var i=0;i<SIM.players.length;i++){
      var pl = SIM.players[i];
      if(pl.yellows>0 && !pl.off) yell[pl.team]++;
      if(pl.off && pl.yellows>0){ /* czerwona po dwóch żółtych */ }
      if(pl.off) red[pl.team]++;
    }
    for(var k=0;k<yell[0];k++){ var d1=document.createElement("span"); d1.className="cardDot"; h.appendChild(d1); }
    for(var k2=0;k2<red[0];k2++){ var d2=document.createElement("span"); d2.className="cardDot red"; h.appendChild(d2); }
    for(var k3=0;k3<yell[1];k3++){ var d3=document.createElement("span"); d3.className="cardDot"; a.appendChild(d3); }
    for(var k4=0;k4<red[1];k4++){ var d4=document.createElement("span"); d4.className="cardDot red"; a.appendChild(d4); }
  },
  cardFlash: function(pl, isRed){
    var col = isRed ? "#e8352a" : "#ffcf3d";
    var txt = isRed ? tPick("c_red") : tPick("c_yellow");
    this.banner(isRed ? t("b_red") : t("b_yellow"),
      "#" + pl.num + " · " + this.teamNameOf(pl.team), 1.8, col);
    this.commentary(txt);
    this.updateCards();
  },
  teamNameOf: function(team){ return team===0 ? SET.home : SET.away; },

  banner: function(main, sub, dur, color){
    var b = this.el("banner");
    b.innerHTML = main + (sub ? "<small>" + sub + "</small>" : "");
    b.style.color = color || "#fff";
    b.classList.add("show");
    this.bannerT = dur || 2.2;
  },
  commentary: function(txt){
    var el = this.el("comm");
    if(!txt){ el.style.visibility = "hidden"; return; }
    el.innerHTML = "<b>›</b> " + txt;
    el.style.visibility = "visible";
    this.commT = 3.6;
  },
  hint: function(txt){
    this.el("hintbar").textContent = txt || "";
  },
  restartTagShow: function(txt){ this.el("restartTag").textContent = txt; this.el("restartTag").classList.add("show"); },
  restartTagHide: function(){ this.el("restartTag").classList.remove("show"); },
  replayUI: function(on){
    var on2 = !!on;
    document.getElementById("lbT").classList.toggle("show", on2);
    document.getElementById("lbB").classList.toggle("show", on2);
    document.getElementById("repTag").classList.toggle("show", on2);
    this.el("hintbar").textContent = on2 ? t("rep_skip") : "";
  },
  showPower: function(v){
    var p = this.el("pwr");
    if(v===null || v===undefined){ p.classList.remove("show"); return; }
    p.classList.add("show");
    this.el("pwrFill").style.width = Math.round(v*100) + "%";
  },
  padChips: function(){
    var s1 = INPUT.slots[0], s2 = INPUT.slots[1];
    var c1 = this.el("chipP1"), c2 = this.el("chipP2");
    /* tryb 1 gracza / oglądania: CPU zamiast P2 */
    this.el("chipP1L").textContent = SET.mode===2 ? "CPU" : "P1";
    this.el("chipP2L").textContent = SET.mode===1 ? "P2" : "CPU";
    c1.querySelector("b").textContent = SET.mode===2 ? "AI" : (s1 ? s1.device : "—");
    c2.querySelector("b").textContent = SET.mode===1 ? (s2 ? s2.device : "—") : "AI";
    c1.classList.toggle("on", SET.mode!==2 && !!s1 && s1.device !== "—");
    c2.classList.toggle("on", SET.mode===1 && !!s2 && s2.device !== "—");
  },
  lagMeter: function(fps, pad1, pad2){
    var el = this.el("lag");
    if(el) el.textContent = t("lag").replace("{V}", fps).replace("{A}", pad1).replace("{B}", pad2);
  },

  update: function(dt){
    if(this.bannerT > 0){
      this.bannerT -= dt;
      if(this.bannerT <= 0) this.el("banner").classList.remove("show");
    }
    if(this.commT > 0){
      this.commT -= dt;
      if(this.commT <= 0) this.el("comm").style.visibility = "hidden";
    }
    this.updateClock();
    this.padChips();
  },

  showEnd: function(){
    var s0 = SIM.teams[0].score, s1 = SIM.teams[1].score;
    this.el("eH").textContent = s0;
    this.el("eA").textContent = s1;
    var win = "";
    if(s0 > s1) win = t("e_win") + " · " + SET.home;
    else if(s1 > s0) win = t("e_win") + " · " + SET.away;
    else win = t("e_draw");
    this.el("eWin").textContent = win;
    var st = SIM.teams[0].stats, st2 = SIM.teams[1].stats;
    var tot = st.poss + st2.poss || 1;
    var rows = [
      [t("st_poss"), Math.round(st.poss/tot*100) + "%", Math.round(st2.poss/tot*100) + "%"],
      [t("st_shots"), st.shots, st2.shots],
      [t("st_target"), st.onT, st2.onT],
      [t("st_pass"), st.pass, st2.pass],
      [t("st_corr"), st.corr, st2.corr],
      [t("st_fouls"), st.fouls, st2.fouls],
      [t("st_yel"), st.yel, st2.yel],
      [t("st_red"), st.red, st2.red]
    ];
    var tb = this.el("statTable");
    var html = "<tr><th>" + SET.home + "</th><th></th><th>" + SET.away + "</th></tr>";
    for(var i=0;i<rows.length;i++)
      html += "<tr><td>" + rows[i][1] + "</td><th style='text-align:center'>" + rows[i][0] + "</th><td>" + rows[i][2] + "</td></tr>";
    tb.innerHTML = html;
    document.getElementById("ovEnd").classList.remove("hide");
  },
  hideEnd: function(){ document.getElementById("ovEnd").classList.add("hide"); },

  /* pomoc sterowania — budowana z i18n */
  buildHelp: function(){
    var cols = document.getElementById("helpCols");
    if(!cols) return;
    function table(title, rows){
      var h = "<div><h2>" + title + "</h2><table class='keys'>";
      for(var i=0;i<rows.length;i++)
        h += "<tr><td>" + rows[i][0] + "</td><td>" + rows[i][1] + "</td></tr>";
      return h + "</table></div>";
    }
    var kk = function(k){ return "<span class='kbd'>" + k + "</span>"; };
    var padRows = [
      [kk("LS") + " / " + kk("D-PAD"), t("h_m_move")],
      [kk("A / ✕"), t("h_m_pass")],
      [kk("B / ◯"), t("h_m_shoot")],
      [kk("X / ▢"), t("h_m_tackle")],
      [kk("Y / △"), t("h_m_through")],
      [kk("RT/RB/R2/R1"), t("h_m_sprint")],
      [kk("LB / L1"), t("h_m_switch")],
      [kk("SELECT / SHARE"), t("h_m_cam")],
      [kk("START / OPTIONS"), t("h_m_pause")]
    ];
    var kb1 = [
      [kk("W") + kk("A") + kk("S") + kk("D"), t("h_m_move")],
      [kk("K"), t("h_m_pass")],
      [kk("L"), t("h_m_shoot")],
      [kk("J"), t("h_m_tackle")],
      [kk("I"), t("h_m_through")],
      [kk("SPACE") + " / " + kk("L-SHIFT"), t("h_m_sprint")],
      [kk("O"), t("h_m_switch")],
      [kk("C"), t("h_m_cam")],
      [kk("ESC") + " / " + kk("ENTER"), t("h_m_pause")]
    ];
    var kb2 = [
      [kk("←") + kk("↑") + kk("↓") + kk("→"), t("h_m_move")],
      [kk(","), t("h_m_pass")],
      [kk("."), t("h_m_shoot")],
      [kk("/"), t("h_m_tackle")],
      [kk("M"), t("h_m_through")],
      [kk("R-SHIFT"), t("h_m_sprint")],
      [kk("N"), t("h_m_switch")],
      ["—", t("h_m_cam") + " (C gr.1)"],
      [kk("ESC"), t("h_m_pause")]
    ];
    cols.innerHTML =
      table(t("h_pad"), padRows) +
      table(t("h_p1"), kb1) +
      table(t("h_p2"), kb2);
    document.getElementById("helpNote").textContent = t("h_note");
  }
};
