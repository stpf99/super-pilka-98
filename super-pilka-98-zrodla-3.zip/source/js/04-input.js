/* ============================================================
   SUPER PILKA '98 · 04-input.js — klawiatura + Gamepad API (2 pady)
   Krawędzie przycisków liczone jednolicie: poziom + porównanie
   z poprzednią klatką. P1: pad1 lub WASD+JKLI; P2: pad2 lub strzałki+,.M/
   ============================================================ */
var INPUT = {
  kb: {},                 // stan klawiszy (e.code)
  slots: [null, null],    // stany graczy P1, P2
  padIdx: [-1, -1],       // indeks gamepada przypisany do P1/P2
  padSeen: [false, false],
  _prev: [null, null],

  /* normalizacja: realne przeglądarki dają e.code, syntetyczne tylko e.key */
  _norm: function(e){
    if(e.code && e.code.length) return e.code;
    var k = e.key || "";
    var map = { " ": "Space", ",": "Comma", ".": "Period", "/": "Slash" };
    if(map[k]) return map[k];
    if(k.length === 1) return "Key" + k.toUpperCase();
    return k; /* Escape, Enter, ArrowUp... */
  },

  init: function(){
    var self = this;
    window.addEventListener("keydown", function(e){
      var c = self._norm(e);
      if(["ArrowUp","ArrowDown","ArrowLeft","ArrowRight","Space"].indexOf(c)>=0) e.preventDefault();
      self.kb[c] = true;
    });
    window.addEventListener("keyup", function(e){ self.kb[self._norm(e)] = false; });
    window.addEventListener("blur", function(){ self.kb = {}; });
    window.addEventListener("gamepadconnected", function(e){
      if(self.padIdx[0]<0) self.padIdx[0]=e.gamepad.index;
      else if(self.padIdx[1]<0 && e.gamepad.index!==self.padIdx[0]) self.padIdx[1]=e.gamepad.index;
      self._reassign();
    });
    window.addEventListener("gamepaddisconnected", function(e){
      if(self.padIdx[0]===e.gamepad.index) self.padIdx[0]=-1;
      if(self.padIdx[1]===e.gamepad.index) self.padIdx[1]=-1;
      self._reassign();
    });
  },

  _reassign: function(){
    var pads = (navigator.getGamepads && navigator.getGamepads()) || [];
    var used = [];
    /* zachowaj poprawne przydziały */
    if(this.padIdx[0]>=0 && pads[this.padIdx[0]]) used.push(this.padIdx[0]); else this.padIdx[0]=-1;
    if(this.padIdx[1]>=0 && pads[this.padIdx[1]] && used.indexOf(this.padIdx[1])<0) used.push(this.padIdx[1]);
    else if(this.padIdx[1]>=0 && (used.indexOf(this.padIdx[1])>=0 || !pads[this.padIdx[1]])) this.padIdx[1]=-1;
    if(this.padIdx[0]<0){
      for(var i=0;i<pads.length;i++) if(pads[i] && used.indexOf(i)<0){ this.padIdx[0]=i; used.push(i); break; }
    }
    if(this.padIdx[1]<0){
      for(var j=0;j<pads.length;j++) if(pads[j] && used.indexOf(j)<0){ this.padIdx[1]=j; used.push(j); break; }
    }
    this.padSeen[0] = this.padIdx[0]>=0;
    this.padSeen[1] = this.padIdx[1]>=0;
  },

  _empty: function(){
    return { mx:0, mz:0, moveLen:0,
      pass:false, shoot:false, tackle:false, through:false,
      switchL:false, camL:false, pauseL:false, sprint:false,
      passP:false, shootP:false, passR:false, shootR:false,
      tackleP:false, throughP:false, switchP:false, camP:false, pauseP:false,
      device:"—", pad:null };
  },

  _padState: function(gp){
    var s = this._empty(); if(!gp) return s;
    var b = function(i){ return !!(gp.buttons[i] && (gp.buttons[i].pressed || gp.buttons[i].value>0.5)); };
    var ax = gp.axes[0]||0, az = gp.axes[1]||0, dead = 0.2;
    var mag = Math.hypot(ax, az);
    if(mag > dead){ s.mx = ax; s.mz = az; s.moveLen = Math.min(1,(mag-dead)/(1-dead)); }
    if(b(12)) { s.mz = -1; s.moveLen = 1; }
    if(b(13)) { s.mz =  1; s.moveLen = 1; }
    if(b(14)) { s.mx = -1; s.moveLen = 1; }
    if(b(15)) { s.mx =  1; s.moveLen = 1; }
    s.pass=b(0); s.shoot=b(1); s.tackle=b(2); s.through=b(3);
    s.sprint = b(5)||b(7)||b(6);
    s.switchL = b(4); s.camL = b(8); s.pauseL = b(9);
    s.device = "PAD"; s.pad = gp;
    return s;
  },

  _kb1State: function(){
    var s = this._empty(), k = this.kb;
    var x = (k["KeyD"]?1:0) - (k["KeyA"]?1:0);
    var z = (k["KeyS"]?1:0) - (k["KeyW"]?1:0);
    if(x||z){ var l=Math.hypot(x,z); s.mx=x/l; s.mz=z/l; s.moveLen=1; }
    s.pass=!!k["KeyK"]; s.shoot=!!k["KeyL"]; s.tackle=!!k["KeyJ"]; s.through=!!k["KeyI"];
    s.sprint = !!(k["Space"]||k["ShiftLeft"]);
    s.switchL = !!k["KeyO"]; s.camL = !!k["KeyC"];
    s.device = "KLAW.1";
    return s;
  },
  _kb2State: function(){
    var s = this._empty(), k = this.kb;
    var x = (k["ArrowRight"]?1:0) - (k["ArrowLeft"]?1:0);
    var z = (k["ArrowDown"]?1:0) - (k["ArrowUp"]?1:0);
    if(x||z){ var l=Math.hypot(x,z); s.mx=x/l; s.mz=z/l; s.moveLen=1; }
    s.pass=!!k["Comma"]; s.shoot=!!k["Period"]; s.tackle=!!k["Slash"]; s.through=!!k["KeyM"];
    s.sprint = !!k["ShiftRight"];
    s.switchL = !!k["KeyN"];
    s.device = "KLAW.2";
    return s;
  },

  update: function(){
    this._reassign();
    var pads = (navigator.getGamepads && navigator.getGamepads()) || [];
    var s1 = this.padSeen[0] ? this._padState(pads[this.padIdx[0]]) : this._kb1State();
    var s2 = this.padSeen[1] ? this._padState(pads[this.padIdx[1]]) : this._kb2State();
    /* wspólne klawisze: ESC/Enter pauza, C kamera */
    s1.pauseL = s1.pauseL || !!this.kb["Escape"] || !!this.kb["Enter"];
    s2.pauseL = s2.pauseL || !!this.kb["Escape"] || !!this.kb["Enter"];
    s1.camL = s1.camL || !!this.kb["KeyC"];

    var levels = ["pass","shoot","tackle","through","switch","cam","pause"];
    for(var sl=0; sl<2; sl++){
      var cur = sl===0 ? s1 : s2, prev = this._prev[sl];
      var map = { switch:"switchL", cam:"camL", pause:"pauseL" };
      for(var c=0;c<levels.length;c++){
        var name = levels[c];
        var levelKey = map[name] || name;
        var held = !!cur[levelKey], was = prev ? !!prev[levelKey] : false;
        cur[name+"P"] = held && !was;
        if(name==="pass"){ cur.passR = !held && was; cur.passP = held && !was; }
        if(name==="shoot"){ cur.shootR = !held && was; cur.shootP = held && !was; }
        if(name==="switch"||name==="cam"||name==="pause") cur[name+"P"] = held && !was;
      }
      this._prev[sl] = cur;
    }
    this.slots[0] = s1; this.slots[1] = s2;
  },

  anyPadButton: function(){
    var pads = (navigator.getGamepads && navigator.getGamepads()) || [];
    for(var i=0;i<pads.length;i++){
      var gp = pads[i]; if(!gp) continue;
      for(var b=0;b<gp.buttons.length;b++) if(gp.buttons[b].pressed) return true;
    }
    return false;
  }
};
