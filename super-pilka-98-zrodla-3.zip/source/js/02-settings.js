/* ============================================================
   SUPER PILKA '98 · 02-settings.js — ustawienia zapisywane lokalnie
   ============================================================ */
var SET = {
  mode: 0,        // 0 = 1 gracz vs komputer, 1 = 2 graczy, 2 = oglądaj (AI vs AI)
  half: 120,      // sekundy na połowę: 60/120/180/300
  diff: 1,        // 0 łatwy, 1 normalny, 2 trudny
  ref:  1,        // 0 łagodny, 1 normalny, 2 surowy
  cam:  0,        // 0 TV, 1 góra, 2 za piłką
  night: 1,       // 1 = noc pod reflektorami, 0 = dzień
  q:    1,        // 0 niska, 1 średnia, 2 wysoka
  snd:  0.6,      // głośność 0..1
  lang:"pl",
  home:"KS SOKÓŁ", away:"TS ORZEŁ"
};
var SET_KEY = "sp98_v1";
try{
  var _saved = JSON.parse(localStorage.getItem(SET_KEY) || "{}");
  for(var sk in _saved) if(sk in SET) SET[sk] = _saved[sk];
}catch(e){ /* file:// bez localStorage — ignoruj */ }

function SET_save(){
  try{ localStorage.setItem(SET_KEY, JSON.stringify(SET)); }catch(e){}
}
function SET_applyLang(){ I18N_cur = SET.lang; applyI18n(); }

/* segment menu: klik + odczyt wartości */
function SET_bindSeg(id, key, parse, after){
  var seg = document.getElementById(id);
  function sync(){
    seg.querySelectorAll("button").forEach(function(b){
      b.classList.toggle("on", String(b.dataset.v) === String(SET[key]));
    });
  }
  seg.addEventListener("click", function(e){
    var b = e.target.closest("button"); if(!b) return;
    SET[key] = parse ? parse(b.dataset.v) : b.dataset.v;
    SET_save(); sync(); UI_click();
    if(after) after();
  });
  sync();
  return sync;
}
function SET_updateModeUI(){
  var tg = document.getElementById("tagAway");
  if(tg) tg.textContent = SET.mode===1 ? "P2" : "AI";
}
function SET_bindAll(){
  SET_bindSeg("segMode","mode", Number, function(){ SET_updateModeUI(); });
  SET_bindSeg("segHalf","half", Number);
  SET_bindSeg("segDiff","diff", Number);
  SET_bindSeg("segRef","ref", Number);
  SET_bindSeg("segCam","cam", Number);
  SET_bindSeg("segNight","night", Number, function(){ if(WORLD.setNight) WORLD.setNight(SET.night===1); });
  SET_bindSeg("segQ","q", Number, function(){ WORLD_quality(); });
  SET_bindSeg("segSnd","snd", Number, function(){ AUDIO_setVolume(); });
  SET_bindSeg("segLang","lang", String, function(){
    SET_applyLang(); UI_click();
  });
  var ih = document.getElementById("inHome"), ia = document.getElementById("inAway");
  ih.value = SET.home; ia.value = SET.away;
  ih.addEventListener("change", function(){ SET.home = ih.value.trim() || "KS SOKÓŁ"; SET_save(); });
  ia.addEventListener("change", function(){ SET.away = ia.value.trim() || "TS ORZEŁ"; SET_save(); });
  SET_updateModeUI();
}

/* parametry rozgrywki wynikające z ustawień */
var DIFF = [
  { react:0.50, passErr:2.3, shotErr:1.7, spd:0.93, press:15, mark:3.2, gk:0.55, aiIQ:0.55 },
  { react:0.34, passErr:1.4, shotErr:1.0, spd:1.00, press:20, mark:2.1, gk:0.70, aiIQ:0.75 },
  { react:0.21, passErr:0.8, shotErr:0.6, spd:1.06, press:25, mark:1.3, gk:0.82, aiIQ:0.92 }
];
var REFSTRICT = [0.7, 1.0, 1.45];
