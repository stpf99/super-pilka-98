/* ============================================================
   SUPER PILKA '98 · 06-sim.js — encje, fizyka piłki i zawodników
   ============================================================ */
var SIM = {
  players: [],
  ball: null,
  teams: [],
  events: [],          // zdarzenia dla modułu zasad
  G: 9.81, BR: 0.15,

  FORM: [
    { role:"GK", x:-49,  z:0 },
    { role:"DF", x:-34, z:-24 }, { role:"DF", x:-37, z:-8 },
    { role:"DF", x:-37, z:8 },   { role:"DF", x:-34, z:24 },
    { role:"MF", x:-12, z:-25 }, { role:"MF", x:-16, z:-8 },
    { role:"MF", x:-16, z:8 },   { role:"MF", x:-12, z:25 },
    { role:"FW", x:8,  z:-7 },   { role:"FW", x:8,  z:7 }
  ],

  resetMatch: function(){
    /* POPRAWKA: usuń meshy zawodników z POPRZEDNIEGO meczu —
       inaczej 11 (lub 22) „duchów” zostaje na boisku obok nowej jedenastki */
    for(var r=0;r<this.players.length;r++){
      if(this.players[r] && this.players[r].mesh) WORLD.removePlayer(this.players[r].mesh);
    }
    this.players.length = 0;
    if(WORLD.gPlayers) WORLD.gPlayers.children.length = 0;   /* gwint bezpieczeństwa */
    this.teams = [
      { id:0, dir:1, score:0, user:null, stats:{shots:0,onT:0,corr:0,fouls:0,yel:0,red:0,pass:0,poss:0}, switchCd:0 },
      { id:1, dir:-1, score:0, user:null, stats:{shots:0,onT:0,corr:0,fouls:0,yel:0,red:0,pass:0,poss:0}, switchCd:0 }
    ];
    for(var t=0;t<2;t++){
      for(var i=0;i<11;i++){
        var f = this.FORM[i];
        var num = i===0 ? 1 : i+1;
        var mesh = WORLD.makePlayer(t, i===0, num);
        var pace = (i===0 ? 6.3 : 6.8 + Math.random()*1.2);
        this.players.push({
          team:t, idx:i, role:f.role, num:num, mesh:mesh,
          home:{ x:f.x, z:f.z },
          pos:{ x:f.x, z:f.z }, vel:{ x:0, z:0 }, face:0,
          pace:pace, action:"run", actionT:0,
          isUser:null, moveTarget:null,
          yellows:0, off:false, aiTarget:null, decideCd:0, slideCd:0
        });
      }
    }
    this.ball = { x:0, y:this.BR, z:0, vx:0, vy:0, vz:0,
      owner:null, lastTouchTeam:-1, lastKicker:null, curve:0, curveDir:null, live:false };
    this.events.length = 0;
    this.syncMeshes(0);
  },

  dirX: function(team){ return this.teams[team].dir; },

  /* pozycja domowa formacji dla kierunku ataku teamu */
  formPos: function(team, slotX, slotZ){
    var d = this.teams[team].dir;
    return { x: slotX * d, z: slotZ * d };
  },

  /* ================= FIZYKA ================= */
  step: function(dt){
    var b = this.ball;
    /* --- piłka --- */
    if(b.owner){
      var o = b.owner, p = o.pos;
      var sprintBoost = o.isUser!==null && INPUT.slots[o.isUser].sprint ? 1 : 0;
      var tx = p.x + Math.sin(o.face)*(0.5 + sprintBoost*0.45);
      var tz = p.z + Math.cos(o.face)*(0.5 + sprintBoost*0.45);
      var dx = tx-b.x, dz = tz-b.z;
      var k = 12.5;
      b.vx = dx*k; b.vz = dz*k;
      b.x += b.vx*dt; b.z += b.vz*dt;
      b.y += (this.BR - b.y) * Math.min(1, dt*14);
      if(b.y > 0.5){ b.owner = null; }  /* wybicie w górę gubi posiadanie */
    } else {
      b.vy -= this.G*dt;
      var airborne = b.y > this.BR + 0.02;
      var drag = airborne ? 0.12 : 1.55;
      var f = Math.exp(-drag*dt);
      b.vx *= f; b.vz *= f;
      if(airborne && b.curve){
        /* lekki efekt Magnusa dla stałych fragmentów */
        var sp = Math.hypot(b.vx, b.vz);
        if(sp>0.5){
          var px = -b.vz/sp, pz = b.vx/sp;
          b.vx += px*b.curve*dt; b.vz += pz*b.curve*dt;
        }
      }
      b.x += b.vx*dt; b.y += b.vy*dt; b.z += b.vz*dt;
      if(b.y < this.BR){
        b.y = this.BR;
        if(b.vy < -1.4){
          b.vy = -b.vy*0.55;
          AUDIO.bounce(Math.abs(b.vy));
          if(b.vy < 1.6) b.vy = 0;
        } else b.vy = 0;
      }
      this._postCollision(b);
    }
    /* --- zawodnicy --- */
    for(var i=0;i<this.players.length;i++){
      var pl = this.players[i];
      if(pl.off) continue;
      this._stepPlayer(pl, dt);
    }
    this._separate();
    this._ballContacts(dt);
  },

  _stepPlayer: function(pl, dt){
    /* cel ruchu ustawiony przez AI (aiTarget) albo przez input człowieka (w module main) */
    var tgt = pl.moveTarget;    // {x, z, sprint}
    var dvx = 0, dvz = 0, maxs = pl.pace;
    if(tgt){
      var dx = tgt.x - pl.pos.x, dz = tgt.z - pl.pos.z;
      var d = Math.hypot(dx, dz);
      if(d > 0.06){
        dvx = dx/d; dvz = dz/d;
        var want = Math.min(d*4, maxs*(tgt.sprint ? 1.32 : 1));
        dvx *= want; dvz *= want;
      }
    }
    var acc = 26;
    pl.vel.x += Math.max(-acc*dt, Math.min(acc*dt, dvx - pl.vel.x));
    pl.vel.z += Math.max(-acc*dt, Math.min(acc*dt, dvz - pl.vel.z));
    var sp = Math.hypot(pl.vel.x, pl.vel.z);
    if(sp > maxs*1.36){ pl.vel.x *= maxs*1.36/sp; pl.vel.z *= maxs*1.36/sp; }
    pl.pos.x += pl.vel.x*dt; pl.pos.z += pl.vel.z*dt;

    /* orientacja: cel lub kierunek ruchu */
    if(tgt && (Math.abs(tgt.x-pl.pos.x)>0.4 || Math.abs(tgt.z-pl.pos.z)>0.4)){
      var ta = Math.atan2(tgt.x-pl.pos.x, tgt.z-pl.pos.z);
      pl.face += this._angDelta(pl.face, ta) * Math.min(1, dt*10);
    } else if(sp > 0.5){
      var va = Math.atan2(pl.vel.x, pl.vel.z);
      pl.face += this._angDelta(pl.face, va) * Math.min(1, dt*12);
    }
    /* granice: lekko poza boisko dozwolone */
    pl.pos.x = Math.max(-HL-4, Math.min(HL+4, pl.pos.x));
    pl.pos.z = Math.max(-HW-4, Math.min(HW+4, pl.pos.z));

    if(pl.actionT > 0){
      pl.actionT -= dt;
      if(pl.actionT <= 0){ pl.action = "run"; }
    }
    if(pl.slideCd > 0) pl.slideCd -= dt;
    if(pl.decideCd > 0) pl.decideCd -= dt;
  },
  _angDelta: function(a, b){
    var d = (b - a) % (Math.PI*2);
    if(d > Math.PI) d -= Math.PI*2;
    if(d < -Math.PI) d += Math.PI*2;
    return d;
  },
  _separate: function(){
    var ps = this.players;
    for(var i=0;i<ps.length;i++){
      if(ps[i].off) continue;
      for(var j=i+1;j<ps.length;j++){
        if(ps[j].off) continue;
        var dx = ps[j].pos.x-ps[i].pos.x, dz = ps[j].pos.z-ps[i].pos.z;
        var d2 = dx*dx+dz*dz;
        if(d2 < 0.72 && d2 > 0.0001){
          var d = Math.sqrt(d2), push = (0.85-d)/d*0.5;
          var mi = ps[j].role==="GK"?0:1, mj = ps[i].role==="GK"?0:1;
          ps[i].pos.x -= dx*push*mi; ps[i].pos.z -= dz*push*mi;
          ps[j].pos.x += dx*push*mj; ps[j].pos.z += dz*push*mj;
        }
      }
    }
  },

  _postCollision: function(b){
    var posts = [ [HL,3.66],[HL,-3.66],[-HL,3.66],[-HL,-3.66] ];
    for(var i=0;i<4;i++){
      var dx = b.x-posts[i][0], dz = b.z-posts[i][1];
      var d = Math.hypot(dx,dz);
      if(d < this.BR+GK_R && b.y < GOAL_H+0.1){
        var nx = dx/d, nz = dz/d;
        var vn = b.vx*nx + b.vz*nz;
        if(vn < 0){
          b.vx -= 2*vn*nx; b.vz -= 2*vn*nz;
          b.vx *= 0.6; b.vz *= 0.6;
          AUDIO.bounce(8);
          this.events.push({ type:"post" });
        }
        b.x = posts[i][0] + nx*(this.BR+GK_R+0.01);
        b.z = posts[i][1] + nz*(this.BR+GK_R+0.01);
      }
    }
    /* poprzeczki: cylinder wzdłuż osi Z na (x=±52.5, y=2.44) */
    for(var s=-1; s<=1; s+=2){
      var dxb = b.x - s*HL, dyb = b.y - GOAL_H;
      var db = Math.hypot(dxb, dyb);
      if(db < this.BR+GK_R && Math.abs(b.z) < GOAL_W/2+0.3){
        var nx = dxb/(db||0.01), ny = dyb/(db||0.01);
        var vn = b.vx*nx + b.vy*ny;
        if(vn < 0){
          b.vx -= 2*vn*nx; b.vy -= 2*vn*ny;
          b.vx *= 0.55; b.vy *= 0.55;
          AUDIO.bounce(8);
          this.events.push({ type:"post" });
        }
        b.x = s*HL + nx*(this.BR+GK_R+0.01);
        b.y = GOAL_H + ny*(this.BR+GK_R+0.01);
      }
    }
  },

  _ballContacts: function(dt){
    var b = this.ball, ps = this.players;
    if(b.owner){
      var o = b.owner;
      var d2 = (b.x-o.pos.x)*(b.x-o.pos.x)+(b.z-o.pos.z)*(b.z-o.pos.z);
      if(d2 > 4.6){ b.owner = null; }
      return;
    }
    var speed = Math.hypot(b.vx, b.vz);
    for(var i=0;i<ps.length;i++){
      var pl = ps[i];
      if(pl.off) continue;
      if(pl.action==="slide" && pl.actionT > 0.15) continue; /* wślizg ogarnia rules */
      var dx = b.x-pl.pos.x, dz = b.z-pl.pos.z;
      var d = Math.hypot(dx, dz);
      if(d < 0.55 && b.y < 1.25){
        if(speed < 9.5 || pl.role==="GK"){
          if(b.y < 0.9){
            b.owner = pl;
            b.curve = 0;
            this.events.push({ type:"touch", player:pl, first: b.lastTouchTeam!==pl.team });
            b.lastTouchTeam = pl.team; b.lastKicker = pl;
          }
        } else {
          /* odbicie od ciała */
          var nx = dx/(d||0.01), nz = dz/(d||0.01);
          var vn = b.vx*nx + b.vz*nz;
          if(vn < 0){
            b.vx -= 1.6*vn*nx; b.vz -= 1.6*vn*nz;
            b.vx *= 0.55; b.vz *= 0.55;
            this.events.push({ type:"touch", player:pl, first: b.lastTouchTeam!==pl.team });
            b.lastTouchTeam = pl.team; b.lastKicker = pl;
          }
        }
        break;
      }
    }
  },

  /* ================= UDERZENIA ================= */
  kick: function(pl, dx, dz, power, kind){
    var b = this.ball;
    var d = Math.hypot(dx, dz) || 1;
    dx /= d; dz /= d;
    var sp = 0, vy = 0, curve = 0;
    kind = kind || "pass";
    if(kind==="pass"){    sp = 11 + 13*power; vy = 0.4 + 2.2*power; }
    if(kind==="through"){ sp = 14 + 14*power; vy = 0.8 + 1.6*power; }
    if(kind==="shot"){    sp = 17 + 17*power; vy = 1.2 + 5.2*power; }
    if(kind==="clear"){   sp = 16 + 10*power; vy = 5.5 + 2*power; }
    if(kind==="throw"){   sp = 7 + 6*power;  vy = 3.3; }
    if(kind==="cross"){   sp = 12 + 6*power; vy = 5.6; curve = (Math.random()<0.5?-1:1)*(1.4+power); }
    if(kind==="gklong"){  sp = 21 + 7*power; vy = 7.2; }
    if(kind==="penclear"){sp = 18 + 8*power; vy = 3.0; }
    b.owner = null;
    b.vx = dx*sp; b.vz = dz*sp; b.vy = vy;
    b.curve = curve;
    b.lastTouchTeam = pl.team; b.lastKicker = pl;
    pl.action = "kick"; pl.actionT = 0.2;
    AUDIO.kick(power);
    return { speed: sp, kind: kind };
  },
  throwBall: function(pl, dx, dz, power){
    var b = this.ball;
    var d = Math.hypot(dx, dz) || 1;
    b.owner = null;
    b.x = pl.pos.x; b.z = pl.pos.z; b.y = 1.7;
    b.vx = dx/d*(6+7*power); b.vz = dz/d*(6+7*power); b.vy = 3.0;
    b.curve = 0;
    b.lastTouchTeam = pl.team; b.lastKicker = pl;
    AUDIO.kick(0.3);
  },

  /* ================= WŚLIZGI ================= */
  startSlide: function(pl){
    if(pl.action==="slide" || pl.action==="fallen" || pl.slideCd > 0) return false;
    pl.action = "slide"; pl.actionT = 0.72; pl.slideCd = 1.4;
    pl.vel.x = Math.sin(pl.face)*8.6;
    pl.vel.z = Math.cos(pl.face)*8.6;
    return true;
  },

  /* ================= SYNCHRONIZACJA GRAFIKI ================= */
  syncMeshes: function(dt){
    var b = this.ball;
    WORLD.ball.position.set(b.x, b.y, b.z);
    if(!b.owner){
      var roll = Math.hypot(b.vx, b.vz);
      if(roll > 0.4){
        WORLD.ball.rotation.x += (b.vz/0.15)*dt;
        WORLD.ball.rotation.z -= (b.vx/0.15)*dt;
      }
    }
    WORLD.blob.position.set(b.x, 0.022, b.z);
    var bs = 0.7 + Math.max(0, b.y-0.15)*0.55;
    WORLD.blob.scale.set(bs, bs, 1);
    WORLD.blob.material.opacity = Math.max(0.12, 0.5 - (b.y-0.15)*0.22);

    for(var i=0;i<this.players.length;i++){
      var pl = this.players[i];
      if(pl.off || !pl.mesh){ if(pl.mesh) pl.mesh.visible = false; continue; }
      pl.mesh.visible = true;
      pl.mesh.position.set(pl.pos.x,
        pl.action==="celebrate" ? Math.abs(Math.sin(performance.now()/140))*0.26 : 0,
        pl.pos.z);
      pl.mesh.rotation.y = pl.face;
      var speed = Math.hypot(pl.vel.x, pl.vel.z);
      WORLD.animatePlayer(pl.mesh, speed, dt, pl.action, pl.actionT);
    }
  },

  celebrateHops: function(){ /* obsługa w syncMeshes */ },

  nearestToBall: function(team, exclGK){
    var best = null, bd = 1e9, b = this.ball;
    for(var i=0;i<this.players.length;i++){
      var pl = this.players[i];
      if(pl.off || pl.team!==team) continue;
      if(exclGK && pl.role==="GK") continue;
      var d = (pl.pos.x-b.x)*(pl.pos.x-b.x)+(pl.pos.z-b.z)*(pl.pos.z-b.z);
      if(d < bd){ bd = d; best = pl; }
    }
    return best;
  },
  teamPlayers: function(team){
    var out = [];
    for(var i=0;i<this.players.length;i++)
      if(this.players[i].team===team && !this.players[i].off) out.push(this.players[i]);
    return out;
  },
  playersOf: function(team, role){
    var out = [];
    for(var i=0;i<this.players.length;i++)
      if(this.players[i].team===team && !this.players[i].off && (!role || this.players[i].role===role)) out.push(this.players[i]);
    return out;
  },

  /* pomocnik wyboru partnera do podania */
  pickPassTarget: function(team, mx, mz, through, self){
    var mates = this.teamPlayers(team), best = null, bs = -1e9;
    var ml = Math.hypot(mx, mz);
    if(ml < 0.25){ mx = Math.sin(self.face); mz = Math.cos(self.face); ml = 1; }
    mx /= ml; mz /= ml;
    var dirX = this.teams[team].dir;
    for(var i=0;i<mates.length;i++){
      var m = mates[i];
      if(m===self) continue;
      var dx = m.pos.x-self.pos.x, dz = m.pos.z-self.pos.z;
      var d = Math.hypot(dx, dz);
      if(d < 2 || d > 42) continue;
      var al = (dx*mx+dz*mz)/d;
      if(al < 0.05) continue;
      var prog = ((m.pos.x-self.pos.x)*dirX)/20;
      var s = al*3.2 + prog*0.6 - Math.abs(d-14)*0.05 - (m.role==="GK"?2.2:0);
      if(through) s += 0.8;
      if(s > bs){ bs = s; best = m; }
    }
    return best;
  }
};
