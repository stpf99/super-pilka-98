/* ============================================================
   SUPER PILKA '98 · 07-ai.js — sztuczna inteligencja 11v11
   Formacja 4-4-2, pressing, krycie, decyzje z piłką, bramkarz.
   ============================================================ */
var AI = {
  frozen: false,   // podczas wznowień AI stoi na pozycjach wyznaczonych przez zasady

  clampX: function(v){ return Math.max(-HL+2, Math.min(HL-2, v)); },
  clampZ: function(v){ return Math.max(-HW+2, Math.min(HW-2, v)); },

  update: function(dt, owner){
    var b = SIM.ball;
    var D = DIFF[SET.diff];
    for(var t=0;t<2;t++){
      var mates = SIM.teamPlayers(t);
      var opps  = SIM.teamPlayers(1-t);
      var dirX = SIM.teams[t].dir;
      var phase = "loose";
      if(b.owner) phase = b.owner.team===t ? "attack" : "defend";
      else if(b.lastTouchTeam===t) phase = "attackLoose";
      else phase = "loose";

      /* najbliższy do piłki (poza GK) */
      var chaser = null, chaser2 = null, cd = 1e9, cd2 = 1e9;
      for(var i=0;i<mates.length;i++){
        var m = mates[i];
        if(m.role==="GK") continue;
        var d = (m.pos.x-b.x)*(m.pos.x-b.x)+(m.pos.z-b.z)*(m.pos.z-b.z);
        if(d < cd){ cd2 = cd; chaser2 = chaser; cd = d; chaser = m; }
        else if(d < cd2){ cd2 = d; chaser2 = m; }
      }

      for(var k=0;k<mates.length;k++){
        var pl = mates[k];
        if(pl.isUser !== null) continue;   // sterowany przez człowieka
        if(pl.role==="GK"){ this.gk(pl, dt, D); continue; }
        if(this.frozen){ pl.moveTarget = null; continue; }

        /* --- właściciel piłki (AI) --- */
        if(b.owner===pl){
          this.decide(pl, dt, D, opps, dirX);
          continue;
        }
        /* --- bieg do luźnej piłki (takż poza liniami, do rogu) --- */
        if(!b.owner && (pl===chaser || (!b.owner && pl===chaser2 && cd2 < 400))){
          var lead = 0.28;
          pl.moveTarget = { x: Math.max(-HL-4, Math.min(HL+4, b.x + b.vx*lead)),
                            z: Math.max(-HW-4, Math.min(HW+4, b.z + b.vz*lead)), sprint: true };
          continue;
        }
        /* --- pressing przy posiadaniu przeciwnika --- */
        if(b.owner && b.owner.team!==t){
          if(pl===chaser){
            pl.moveTarget = { x: b.owner.pos.x, z: b.owner.pos.z, sprint: true };
            continue;
          }
          if(pl===chaser2 && D.press > 12){
            var gx0 = -dirX*HL;
            var bx = (b.owner.pos.x-gx0), bz = (b.owner.pos.z);
            var bl = Math.hypot(bx, bz)||1;
            pl.moveTarget = { x: b.owner.pos.x + (gx0-b.owner.pos.x)/bl*4.5, z: b.owner.pos.z - bz/bl*2, sprint: true };
            continue;
          }
        }
        /* --- krycie przy obronie --- */
        if(phase==="defend"){
          var mark = this.findMark(pl, opps, mates, D.mark);
          if(mark){
            var tgx = -dirX*HL;
            var mdx = tgx-mark.pos.x, mdz = 0-mark.pos.z;
            var ml = Math.hypot(mdx, mdz)||1;
            pl.moveTarget = { x: mark.pos.x + mdx/ml*1.7, z: mark.pos.z + mdz/ml*1.7, sprint: Math.abs(mark.pos.x-pl.pos.x)>8 };
            continue;
          }
        }
        /* --- formacja --- */
        pl.moveTarget = this.formationTarget(pl, dirX, phase==="attack" || phase==="attackLoose");
        /* koledzy właściciela: ofiaruj się na podanie */
        if(b.owner && b.owner.team===t && (pl.role==="MF" || pl.role==="FW")){
          var own = b.owner;
          var side = pl.idx%2===0 ? -1 : 1;
          var want = { x: own.pos.x + dirX*(7+Math.random()*4), z: this.clampZ(own.pos.z + side*9) };
          if(Math.random()<0.5) want = { x: this.clampX(own.pos.x + dirX*11), z: this.clampZ(own.pos.z*0.4) };
          pl.moveTarget = { x: this.clampX(want.x), z: this.clampZ(want.z), sprint: false };
        }
      }
    }
  },

  formationTarget: function(pl, dirX, attacking){
    var b = SIM.ball;
    var bx = b.x*dirX;   // w przestrzeni drużyny (atak w +)
    var adv = Math.max(-15, Math.min(24, bx*0.62));
    if(pl.role==="FW") adv = Math.max(-8, Math.min(28, bx*0.75 + (attacking?7:0)));
    if(pl.role==="DF") adv = Math.max(-18, Math.min(18, bx*0.52 - (attacking?0:5)));
    var tz = pl.home.z + b.z*(attacking?0.22:0.38);
    if(pl.role==="FW" && attacking) tz = pl.home.z*0.8 + b.z*0.15;
    tz = Math.max(-31, Math.min(31, tz));
    return { x: this.clampX((pl.home.x + adv)*dirX), z: this.clampZ(tz), sprint: false };
  },

  findMark: function(pl, opps, mates, slack){
    var best = null, bs = 1e9;
    var gx = -SIM.teams[pl.team].dir*HL;
    for(var i=0;i<opps.length;i++){
      var o = opps[i];
      if(o.role==="GK") continue;
      if(o.pos.x*SIM.teams[pl.team].dir < 0 && o.role==="DF") continue; /* daleko u siebie */
      var d = Math.hypot(o.pos.x-pl.pos.x, o.pos.z-pl.pos.z);
      if(d > 18) continue;
      /* nie kradnij krycia kolegi bliższego */
      var mateCloser = false;
      for(var j=0;j<mates.length;j++){
        var m2 = mates[j];
        if(m2===pl || m2.role==="GK") continue;
        var d2 = Math.hypot(o.pos.x-m2.pos.x, o.pos.z-m2.pos.z);
        if(d2 < d - 1.5){ mateCloser = true; break; }
      }
      if(mateCloser) continue;
      var danger = Math.abs(o.pos.x - gx) < 30 ? 0 : 8;
      var s = d + danger;
      if(s < bs){ bs = s; best = o; }
    }
    return best;
  },

  /* ---------- decyzje AI z piłką ---------- */
  decide: function(pl, dt, D, opps, dirX){
    var b = SIM.ball;
    if(pl.decideCd > 0){
      /* drybling w kierunku bramki z unikiem */
      var weave = Math.sin(performance.now()/700 + pl.idx)*0.5;
      var gx = dirX*HL;
      var dx = gx-pl.pos.x, dz = 0-pl.pos.z + weave*8;
      var l = Math.hypot(dx, dz)||1;
      dx/=l; dz/=l;
      var spread = this.spreadAhead(pl, opps, dx, dz);
      if(spread < 2.2){
        var side = (pl.idx%2===0) ? -1 : 1;
        var px = -dz, pz = dx;          /* kierunek prostopadły */
        dx = px*side; dz = pz*side;
        var l2 = Math.hypot(dx, dz)||1; dx/=l2; dz/=l2;
      }
      pl.moveTarget = { x: this.clampX(pl.pos.x + dx*6), z: this.clampZ(pl.pos.z + dz*6), sprint: spread > 4 };
      return;
    }
    pl.decideCd = D.react + Math.random()*0.15;
    var distGoal = Math.hypot(dirX*HL-pl.pos.x, pl.pos.z);
    var pressure = this.nearestOppDist(pl, opps);

    /* strzał */
    var shootRange = 20 + D.aiIQ*8;
    if(distGoal < shootRange && Math.abs(pl.pos.z) < 20 && Math.random() < 0.55+D.aiIQ*0.4){
      var aimZ = (Math.random()*2-1)*3.1*D.aiIQ;
      var tx = dirX*HL, tz = aimZ + (Math.random()*2-1)*D.shotErr;
      var pdx = tx-pl.pos.x, pdz = tz-pl.pos.z;
      var pl2 = Math.hypot(pdx, pdz)||1;
      pl.moveTarget = null;
      SIM.kick(pl, pdx/pl2, pdz/pl2, Math.min(1, 0.55+distGoal/34), "shot");
      RULES.onShot(pl);
      return;
    }
    /* ocena podań */
    var bestMate = null, bestScore = -1e9;
    var mates = SIM.teamPlayers(pl.team);
    for(var i=0;i<mates.length;i++){
      var m = mates[i];
      if(m===pl || m.role==="GK") continue;
      var dxm = m.pos.x-pl.pos.x, dzm = m.pos.z-pl.pos.z;
      var dm = Math.hypot(dxm, dzm);
      if(dm < 4 || dm > 38) continue;
      var prog = dxm*dirX;
      if(prog < -8 && pressure < 5) continue;
      var open = this.laneOpenness(pl, m, opps);
      var sc = open*10 + prog*0.35 - Math.abs(dm-16)*0.12;
      if(dm > 26) sc -= 3;
      if(sc > bestScore){ bestScore = sc; bestMate = m; }
    }
    /* podanie pod presją albo gdy dobra opcja */
    var passThresh = pressure < 4 ? 1.5 : 5.5 + (1-D.aiIQ)*3;
    if(bestMate && bestScore > passThresh){
      var lead = bestMate.vel.x*0.3 + dirX*1.5;
      var tx2 = bestMate.pos.x + lead + (Math.random()*2-1)*D.passErr;
      var tz2 = bestMate.pos.z + bestMate.vel.z*0.3 + (Math.random()*2-1)*D.passErr;
      var d2 = Math.hypot(tx2-pl.pos.x, tz2-pl.pos.z);
      SIM.kick(pl, tx2-pl.pos.x, tz2-pl.pos.z, Math.min(0.95, d2/26), "pass");
      RULES.onPass(pl, bestMate);
      return;
    }
    /* drybling / wybij z zagrożenia */
    if(pressure < 2.2 && (pl.role==="DF") && distGoal > 30){
      SIM.kick(pl, dirX, (Math.random()*2-1)*0.7, 0.8, "clear");
      return;
    }
    /* kontynuacja dryblingu */
    this.decide(pl, dt, D, opps, dirX);
    pl.decideCd = D.react*0.5;
  },

  spreadAhead: function(pl, opps, dx, dz){
    var best = 1e9;
    for(var i=0;i<opps.length;i++){
      var o = opps[i];
      var rx = o.pos.x-pl.pos.x, rz = o.pos.z-pl.pos.z;
      var proj = rx*dx+rz*dz;
      if(proj < 0 || proj > 9) continue;
      var perp = Math.abs(rx*dz - rz*dx);
      best = Math.min(best, perp);
    }
    return best===1e9 ? 9 : best;
  },
  nearestOppDist: function(pl, opps){
    var d = 1e9;
    for(var i=0;i<opps.length;i++){
      var dd = Math.hypot(opps[i].pos.x-pl.pos.x, opps[i].pos.z-pl.pos.z);
      if(dd < d) d = dd;
    }
    return d;
  },
  laneOpenness: function(a, m, opps){
    var dx = m.pos.x-a.pos.x, dz = m.pos.z-a.pos.z;
    var l = Math.hypot(dx,dz)||1;
    var best = 99;
    for(var i=0;i<opps.length;i++){
      var o = opps[i];
      var rx = o.pos.x-a.pos.x, rz = o.pos.z-a.pos.z;
      var proj = rx*dx/l + rz*dz/l;
      if(proj < 0 || proj > l) continue;
      var perp = Math.abs(rx*dz/l - rz*dx/l);
      best = Math.min(best, perp);
    }
    return Math.min(best, 8);
  },

  /* ---------- bramkarz ---------- */
  gk: function(pl, dt, D){
    var b = SIM.ball;
    var t = pl.team, dirX = SIM.teams[t].dir;
    var gx = -dirX*HL;   // własna bramka

    if(b.owner===pl){
      /* rozegranie po chwili */
      pl.decideCd -= dt;
      if(pl.decideCd <= 0){
        var mates = SIM.teamPlayers(t);
        var fb = null, bd = 1e9;
        for(var i=0;i<mates.length;i++){
          var m = mates[i];
          if(m===pl || m.role==="GK") continue;
          var d = Math.hypot(m.pos.x-pl.pos.x, m.pos.z-pl.pos.z);
          if(d<bd && m.role==="DF"){ bd=d; fb=m; }
        }
        if(fb && Math.random()<0.6 && bd<26){
          SIM.kick(pl, fb.pos.x-pl.pos.x, fb.pos.z-pl.pos.z, 0.45, "pass");
        } else {
          SIM.kick(pl, dirX, (Math.random()*2-1)*0.6, 0.85, "gklong");
        }
        RULES.onPass(pl, null);
      }
      pl.moveTarget = null;
      return;
    }
    /* dojście do luźnej piłki w polu karnym */
    var inBox = Math.abs(b.x - gx) < 16.5 && Math.abs(b.z) < 20.1;
    if(inBox && !b.owner && b.y < 1.6){
      pl.moveTarget = { x: b.x, z: b.z, sprint: true };
      return;
    }
    /* interwencja przy strzale */
    var vx = b.vx, vz = b.vz;
    var towardGoal = (gx - b.x)*vx > 0 && Math.hypot(vx, vz) > 9;
    if(towardGoal && !b.owner){
      var tt = Math.abs((gx - b.x)/(vx||0.01));
      if(tt < 1.6){
        var iz = b.z + vz*tt;
        var iy = Math.max(0.2, b.y + (b.vy*tt) - 0.5*9.81*tt*tt);
        pl.moveTarget = { x: gx + dirX*1.2, z: Math.max(-6.5, Math.min(6.5, iz)), sprint: true };
        /* próba obrony gdy blisko */
        var dx2 = b.x-pl.pos.x, dz2 = b.z-pl.pos.z, dy2 = b.y-1.0;
        var dBall = Math.hypot(dx2, dz2);
        if(dBall < 1.5 && iy < 2.5 && Math.hypot(vx,vz) > 8 && pl.decideCd <= 0){
          pl.decideCd = 0.5;
          var pSave = D.gk * (1 - Math.min(0.5, Math.hypot(vx,vz)/60));
          if(Math.random() < pSave){
            if(Math.random()<0.6){
              b.owner = pl; b.curve = 0;
              AUDIO.catchSnd();
              RULES.onSave(pl, true);
            } else {
              b.vx = dirX*Math.abs(b.vx)*0.5 + dirX*4;
              b.vz = Math.sign(b.z||1)*6; b.vy = 3;
              AUDIO.catchSnd();
              RULES.onSave(pl, false);
            }
          }
        }
        return;
      }
    }
    /* pozycjonowanie na łuku */
    var bx = b.x-gx, bz = b.z;
    var bl = Math.hypot(bx, bz)||1;
    var r = Math.min(5.2, bl*0.28 + 1.2);
    var tx = gx + bx/bl*r;
    var tz = Math.max(-6.8, Math.min(6.8, bz/bl*r*0.9));
    if(!inBox) tz *= 0.7;
    pl.moveTarget = { x: tx, z: tz, sprint: false };
  }
};
