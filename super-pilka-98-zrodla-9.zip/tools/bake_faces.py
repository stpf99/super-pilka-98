"""Bake neutral heads and expression patches from the eight supplied portraits.
Optional art tool. Run with Python, NumPy and Pillow after editing the portraits.
"""
from pathlib import Path
import numpy as np
from PIL import Image, ImageFilter

ROOT = Path(__file__).resolve().parents[1]
SKIN = [0xb88570, 0xa77359, 0xba8674, 0x795444, 0xb3826a, 0xb6816f, 0xa26c55, 0xb88272]
HAIR = [0x846849, 0x302721, 0x695038, 0x251e1c, 0x332923, 0x705c47, 0x342522, 0x83553e]
# Eye centres, lip seam, ear centres. Coordinates are fractions of an individual portrait.
FEATURES = [
    (.351,.660,.420,.417,.757,.118,.885,.546),(.352,.662,.415,.415,.761,.114,.890,.519),
    (.345,.663,.425,.424,.769,.107,.898,.526),(.330,.675,.424,.423,.761,.129,.884,.539),
    (.348,.664,.407,.405,.749,.121,.899,.533),(.350,.658,.405,.408,.750,.112,.889,.530),
    (.340,.671,.405,.411,.752,.109,.902,.526),(.354,.665,.410,.410,.763,.121,.892,.528),
]
STYLES = [2,4,3,0,1,2,0,4]

def smooth(lo, hi, value):
    t = np.clip((value-lo)/(hi-lo), 0, 1)
    return t*t*(3-2*t)

def mix(a, b, amount):
    return a+(b-a)*np.asarray(amount)[..., None]

def rgb(hex_value):
    return np.array([hex_value>>16,(hex_value>>8)&255,hex_value&255], float)

def sample(image, u, v):
    h,w = image.shape[:2]
    x = np.clip(u*(w-1),0,w-1.001)
    y = np.clip(v*(h-1),0,h-1.001)
    ix,iy = x.astype(int),y.astype(int)
    top = mix(image[iy,ix],image[iy,ix+1],x-ix)
    bottom = mix(image[iy+1,ix],image[iy+1,ix+1],x-ix)
    return mix(top,bottom,y-iy)

def expressive(photo, u, v, landmarks):
    result = sample(photo,u,v)
    for ex,ey in zip(landmarks[:2],landmarks[2:4]):
        x = (u-ex)/.081
        arch = np.sqrt(np.maximum(0,1-x*x))
        # Carry the skin of the upper eyelid over the iris, with a fine curved lash at closure.
        lash = ey+.012*arch+.002*x
        donor = sample(photo,u,ey+.049+(v-lash)*.34+.005*arch)
        donor *= (.94+.04*smooth(-.038,.005,v-lash))[...,None]
        lid = smooth(-.048,-.026,v-ey)*(1-smooth(.002,.015,v-lash))*(1-smooth(.77,1.06,np.abs(x)))
        result = mix(result,donor,lid)
        line = np.exp(-((v-lash)/.0038)**2)*(1-smooth(.65,1.0,np.abs(x)))
        result = mix(result,donor*np.array([.49,.42,.41]),line*.87)
    mouth = landmarks[4]
    x = (u-.504)/.149
    width = np.clip(1-x*x,0,1)**1.3
    seam = mouth+.006*x*x
    gap = .028*width
    # Translate both lips; stretch the surrounding skin with a smooth falloff.
    offset = np.where(v<seam,-.37,.63)*gap*2
    offset *= (1-smooth(.033,.106,np.abs(v-seam)))
    shifted = sample(photo,u,v-offset)
    area = (1-smooth(.86,1.13,np.abs(x)))*(1-smooth(.053,.106,np.abs(v-seam)))
    result = mix(result,shifted,area)
    top,bottom = seam-.74*gap,seam+1.26*gap
    cavity = smooth(top-.002,top+.002,v)*(1-smooth(bottom-.002,bottom+.002,v))*smooth(.003,.012,gap)
    # Dark oral cavity, a subdued glimpse of the upper teeth and lower lip.
    tooth = (1-smooth(.002,.010,v-top))*(1-smooth(.43,.82,np.abs(x)))*.66
    inside = mix(np.array([42.,22.,23.]),np.array([190.,164.,144.]),tooth)
    return mix(result,inside,cavity)

def noise(angle,height,columns,rows,seed):
    # Periodic bicubic-eased lattice evaluated in cylindrical coordinates.
    field=np.random.default_rng(seed).uniform(-1,1,(64,columns))
    x=angle/(2*np.pi)*columns
    y=(height+.13)*rows
    ix=np.floor(x).astype(int);iy=np.floor(y).astype(int)
    sx=smooth(0,1,x-ix);sy=smooth(0,1,y-iy)
    top=field[iy%64,ix%columns]*(1-sx)+field[iy%64,(ix+1)%columns]*sx
    low=field[(iy+1)%64,ix%columns]*(1-sx)+field[(iy+1)%64,(ix+1)%columns]*sx
    return top+(low-top)*sy

def bake(portrait, k):
    y,x = np.mgrid[:512,:512]+.5
    # Four-pixel gutters continue the wrap into the space sampled by mip filters.
    angle = (((x-8)/496+.5)%1-.5)*2*np.pi
    angle = np.arctan2(np.sin(angle-np.pi),np.cos(angle-np.pi))
    y3 = .275-np.clip((y-6)/376,0,1)*.395
    a = np.abs(angle)
    u = .504+.414*np.sin(np.clip(angle,-np.pi/2,np.pi/2))
    v = .433+(.114-y3)*4.08
    base,hair = rgb(SKIN[k]),rgb(HAIR[k])
    # A low-contrast cheek sample extends skin texture around the entire circumference.
    patch_u = .280+.046*np.cos(3*angle+8*y3)
    patch_v = .587+.052*np.sin(2*angle+21*y3)
    source=Image.fromarray(portrait.astype('uint8'))
    soft=np.asarray(source.filter(ImageFilter.GaussianBlur(source.width*.032)),float)
    fine=portrait-np.asarray(source.filter(ImageFilter.GaussianBlur(1.6)),float)
    cheek = sample(soft,patch_u,patch_v)
    cheek -= np.median(cheek.reshape(-1,3),axis=0)
    grain = np.sin(np.cos(angle)*177+np.sin(angle)*193+1800*y3)*np.sin(70*angle+1340*y3)
    neck = smooth(-.112,-.040,y3)
    pore_u=.27+.041*np.sin(9*angle+43*y3)
    pore_v=.58+.052*np.cos(7*angle-61*y3)
    pores=sample(fine,pore_u,pore_v)
    side = base+(cheek*.29+pores*.68+grain[...,None]*1.1)*neck[...,None]
    jaw_shadow = np.exp(-((y3+.034)/.047)**2)*(.48+.52*np.cos(angle)**2)
    side -= (jaw_shadow*neck)[...,None]*np.array([12,11,10])
    # Inside the jaw/temple silhouette the portraits are reliable. Beyond it the
    # photographed background is excluded, even below the lobes of narrow jaws.
    width = np.interp(v,[0,.18,.33,.45,.56,.66,.76,.86,.96,1.06],[.32,.36,.37,.361,.35,.335,.302,.245,.15,.08])
    margin = width-np.abs(u-.504)
    face_mix = smooth(.007,.097,margin)*(1-smooth(.83,1.44,a))*smooth(-.020,.015,y3)
    # Continue actual cheek and temple tones towards the ears, sampling inside the
    # portrait contour. This also preserves beard shadow underneath the jaw.
    safe_u=.504+np.sign(angle)*np.maximum(.08,width-.086-.023*np.sin(3*angle+13*y3))
    safe_v=np.clip(v,.25,.87)
    extension=sample(soft,safe_u,safe_v)+pores*.70
    profile=smooth(.50,.94,a)*(1-smooth(1.29,2.33,a))*smooth(-.041,.026,y3)*(1-smooth(.164,.20,y3))
    side=mix(side,extension,.68*profile)
    skin = mix(side,sample(portrait,u,v),face_mix)
    # Model the concha and helix on the continuous head surface. The photographed
    # centre of each ear adds colour; its external photographic silhouette is omitted.
    ex = (a-1.66)/.223
    ey = (y3-.092)/.034
    radius = np.sqrt((ex-.13*ey)**2+ey**2)
    rim = np.exp(-((radius-.71)/.19)**2)
    bowl = np.exp(-((ex+.07)/.45)**2-(ey/.62)**2)
    ear_u = np.where(angle<0,FEATURES[k][5],FEATURES[k][6])+np.sign(angle)*ex*.025
    ear_v = FEATURES[k][7]-ey*.080
    ear = sample(portrait,ear_u,ear_v)
    canal=np.exp(-((ex+.26)/.22)**2-((ey+.085)/.235)**2)
    inner_fold=np.exp(-((ex-.18-.22*ey)/.14)**2-((ey-.12)/.54)**2)
    tragus=np.exp(-((ex+.52)/.16)**2-((ey+.08)/.26)**2)
    crease=np.exp(-((radius-.53)/.11)**2)*(1-smooth(.0,.55,-ey))
    ear_skin = mix(side,ear,.36)+(rim+inner_fold*.68+tragus*.63)[...,None]*np.array([16,11,8])
    ear_skin -= (bowl*.45+canal*.87+crease*.17)[...,None]*np.array([41,48,38])
    ear_skin += (1-smooth(.65,1,radius))[...,None]*np.array([3,-3,-3])
    skin = mix(skin,ear_skin,1-smooth(.76,1.15,radius))
    style = STYLES[k]
    front = np.cos(angle)
    low = .105+.063*front-.021*np.abs(np.sin(angle))**5
    low += (-.015*(1-front) if style==2 else .011*front if style==1 else 0)
    low += .004*np.sin(3*angle+.7*k)+.003*np.sin(11*angle+k)
    # Hair runs behind the ear. Texture follows the same swept direction through the rear UV seam.
    low += .046*np.exp(-((a-1.64)/.29)**2)-.027*np.exp(-((a-1.23)/.17)**2)
    short = k in (3,6)
    clumps=noise(angle+np.sin(angle)*y3*1.8,y3,37,135,10+k)
    detail=noise(angle+(.5+.3*np.cos(angle))*y3,y3,190,440,13+k)
    locks=clumps*(.0025 if short else .005)+detail*.002
    root=smooth(-.011 if short else -.007,.024 if short else .013,y3-low+locks)
    sweep=angle+3.5*y3+.055*np.sin(6*angle+29*y3)
    fibres=(.44*np.sin(133*sweep+4*clumps)+.26*np.sin(237*sweep+5*detail))
    hair_tone=hair*(.84+.09*np.maximum(0,front))[...,None]
    hair_tone=hair_tone+(clumps*(3 if short else 8)+detail*(12 if short else 6)+fibres*(1.3 if short else 4))[...,None]
    # Small locks sampled from the original haircut, with bounded highlights.
    hair_u=.49+.18*np.sin(3*angle+23*y3)+.062*np.sin(7*angle-30*y3)
    hair_v=.069+.030*np.sin(5*angle+109*y3)+.017*np.cos(9*angle-42*y3)
    real_hair=sample(portrait,hair_u,hair_v)
    local=np.median(real_hair.reshape(-1,3),axis=0)
    hair_tone+=(5 if short else 14)*np.tanh((real_hair-local)/28)
    # Preserve authentic individual fringes; never pull the grey studio backdrop onto the side of the head.
    cut = mix(skin,hair_tone,root*(1-smooth(.56,.86,1-a)))
    photo_hair = (1-smooth(.60,1.18,a))*smooth(-.004,.020,y3-low)*(1-smooth(.198,.224,y3))
    cut = mix(cut,sample(portrait,u,v),photo_hair)
    crown = smooth(.194,.225,y3)
    cut = mix(cut,hair_tone,crown)
    alternate = mix(cut,expressive(portrait,u,v,FEATURES[k]),face_mix)
    # Only the central eyes and mouth differ. Surrounding texels are exact neutral copies.
    eye_band = (1-smooth(.052,.063,np.abs(v-np.mean(FEATURES[k][2:4]))))
    mouth_band = 1-smooth(.073,.092,np.abs(v-FEATURES[k][4]))
    marked = (1-smooth(.79,.94,a))*np.maximum(eye_band,mouth_band)
    patch = mix(cut,alternate,marked)
    result = np.clip(np.rint(cut),0,255).astype('uint8')
    result[384:512] = np.clip(np.rint(patch[133:261]),0,255).astype('uint8')
    return result

def main():
    sheet = Image.open(ROOT/'tools/portrety.webp').convert('RGB')
    out = Image.new('RGB',(2048,1024))
    tw,th=sheet.width//4,sheet.height//2
    for k in range(8):
        x,y=k%4,k//4
        source=np.asarray(sheet.crop((x*tw,y*th,(x+1)*tw,(y+1)*th)),float)
        out.paste(Image.fromarray(bake(source,k)),(512*x,512*y))
    out.save(ROOT/'source/art/twarze.webp',quality=94,method=6)

if __name__=='__main__':
    main()
