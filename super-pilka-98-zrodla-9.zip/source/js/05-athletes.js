/* Sylwetka w metrach. Wspólna siatka z wagami, miednica, kręgosłup i łańcuchy kończyn.
   Współrzędne lokalne: +Z z przodu, +Y w górę. */
var ATHLETE = {
  kitTexture: function(kit,number,name,team,keeper,staff,skin,hair){
    var cv=document.createElement("canvas");cv.width=512;cv.height=512;
    var g=cv.getContext("2d"), shirt=new THREE.Color(keeper?kit.gk:kit.shirt);
    g.fillStyle="#fff";g.fillRect(0,0,512,512);
    g.save();g.beginPath();g.rect(0,9,512,240);g.clip();
    g.fillStyle="#"+shirt.getHexString();g.fillRect(0,9,512,240);
    var ink=staff||keeper?"#172824":team===0?"#26352e":"#f2f8ff";
    var trim=staff?"#656c61":keeper?"#264536":team===0?"#bc3641":"#acd9fc";
    if(!staff){
      g.fillStyle=trim;
      if(keeper){for(var x=0;x<512;x+=22)g.fillRect(x,18,8,42);}
      else if(team===0){
        g.beginPath();g.moveTo(51,17);g.lineTo(80,17);g.lineTo(211,249);g.lineTo(178,249);g.fill();
      }else{g.fillRect(73,13,9,232);g.fillRect(86,13,3,232);}
      g.fillStyle="rgba(255,255,255,.10)";
      for(var y=19;y<247;y+=5)g.fillRect(0,y,512,.85);
      // Szwy raglanowe, oddychające panele po bokach i haft na tarczy klubowej.
      g.strokeStyle="rgba(18,31,36,.25)";g.lineWidth=1.7;
      [0,256].forEach(function(x){g.beginPath();g.moveTo(x+53,24);g.lineTo(x+91,55);g.lineTo(x+71,88);
        g.moveTo(x+204,24);g.lineTo(x+167,55);g.lineTo(x+185,88);g.stroke();
        for(var j=0;j<16;j++){g.fillStyle="rgba(30,44,40,.17)";g.fillRect(x+33+(j%2)*2,90+j*7,3,2);g.fillRect(x+220-(j%2)*2,90+j*7,3,2);}
      });
      // Fałdy spod pach i nad pasem. Delikatny cień pozostaje czytelny z kamery TV.
      for(var back=0;back<2;back++){
        var base=back*256;
        for(var fold=0;fold<8;fold++){
          var xx=base+29+fold*27, yy=218+((fold*29+number*11)%17);
          g.fillStyle=fold%2?"rgba(16,27,37,.15)":"rgba(255,255,255,.19)";
          g.beginPath();g.moveTo(xx,244);g.quadraticCurveTo(xx+5,yy-7,xx+14,yy-23);
          g.quadraticCurveTo(xx+9,yy+2,xx+8,244);g.fill();
        }
        g.strokeStyle="rgba(25,35,45,.18)";g.lineWidth=2;
        for(var side=0;side<2;side++){
          var ax=base+(side?209:46),sgn=side?-1:1;
          g.beginPath();g.moveTo(ax,70);g.quadraticCurveTo(ax+sgn*10,90,ax+sgn*38,106);g.stroke();
        }
      }
      // Kołnierzyk polo z wyłogami, jak w koszulkach meczowych z końca lat 90.
      g.fillStyle=trim;g.beginPath();g.moveTo(88,10);g.lineTo(114,13);g.lineTo(128,38);
      g.lineTo(108,49);g.lineTo(96,29);g.closePath();g.fill();
      g.beginPath();g.moveTo(168,10);g.lineTo(142,13);g.lineTo(128,38);
      g.lineTo(147,49);g.lineTo(161,29);g.closePath();g.fill();
      g.textAlign="center";g.fillStyle=ink;g.font="bold 97px Arial";g.fillText(number,384,184,112);
      g.font="bold 15px Arial";g.fillText((name||"").toUpperCase(),384,82,110);
      g.font="bold 41px Arial";g.fillText(number,128,154,54);
      g.fillStyle=trim;g.beginPath();g.moveTo(145,70);g.lineTo(160,70);g.lineTo(159,82);g.lineTo(152,87);g.lineTo(146,82);g.fill();
      g.strokeStyle="#f0d695";g.lineWidth=1.8;g.beginPath();g.moveTo(148,75);g.lineTo(152,80);g.lineTo(157,73);g.stroke();
    }
    g.fillStyle="rgba(0,0,0,.13)";g.fillRect(0,239,512,5);g.restore();
    var style=(number+team*17)%8;
    g.save();g.translate(0,256);
    var atlas=document.getElementById("faceAtlas");
    if(atlas && atlas.naturalWidth){
      g.drawImage(atlas,(style%4)*512+8,Math.floor(style/4)*512+6,496,376,0,0,256,256);
    }else SUPPORTERS.paintFace(g,style,"#"+skin.toString(16).padStart(6,"0"),"#"+hair.toString(16).padStart(6,"0"));
    g.restore();
    g.save();g.translate(256,256);
    g.fillStyle="#"+new THREE.Color(keeper?kit.gkShorts:kit.shorts).getHexString();g.fillRect(0,0,256,256);
    for(var k=0;k<10;k++){
      var x=k*28-9;var drape=g.createLinearGradient(x,0,x+26,0);
      drape.addColorStop(0,"rgba(9,17,29,.19)");drape.addColorStop(.42,"rgba(255,255,255,.11)");drape.addColorStop(1,"rgba(17,26,38,.12)");
      g.fillStyle=drape;g.beginPath();g.moveTo(x+7,8);g.lineTo(x+14,12);g.lineTo(x+29,250);g.lineTo(x,250);g.fill();
    }
    g.fillStyle=trim;[0,128].forEach(function(x){g.fillRect(x+4,4,3,248);g.fillRect(x+10,4,2,248);});
    g.fillStyle="rgba(22,31,38,.32)";g.fillRect(0,239,256,3);
    if(!staff){g.fillStyle=keeper||team===0?"#f5eee3":"#223659";g.font="bold 43px Arial";g.textAlign="center";g.fillText(number,33,211,32);}
    g.restore();
    var texture=new THREE.CanvasTexture(cv);texture.encoding=THREE.sRGBEncoding;texture.anisotropy=4;return texture;
  },

  create: function(team, keeper, number, parent, customKit, name){
    var kit=customKit||WORLD.kit[team], staff=!!customKit, idx=number+team*17;
    var skins=[0xb88570,0xa77359,0xba8674,0x795444,0xb3826a,0xb6816f,0xa26c55,0xb88272];
    var hairs=[0x846849,0x302721,0x695038,0x251e1c,0x332923,0x705c47,0x342522,0x83553e];
    var skin=skins[idx%8],hair=hairs[idx%8];
    var shorts=keeper?kit.gkShorts:kit.shorts, sock=keeper?0x273e36:kit.socks, shirt=keeper?kit.gk:kit.shirt;
    var trim=staff?shirt:keeper?0x304437:team===0?0xb72b3b:0x98ccfa;
    var bootColors=[0x1f2630,0x242828,0x422d29,0x273239];
    var boot=bootColors[idx%4], sole=idx%3===0?0xbab599:0x41484a;
    var bootTrim=idx%2?0xe6c693:0xb4d4dd;
    var group=new THREE.Group(), bones=[], positions=[], indices=[], colors=[], uvs=[], jointIndex=[], weights=[];
    var absolute=[], colorCache={};
    function joint(label,parentBone,x,y,z){
      var b=new THREE.Bone();b.name=label;b.position.set(x,y,z);
      if(parentBone)parentBone.add(b);
      var off=parentBone?absolute[parentBone.userData.index]:[0,0,0];
      b.userData.index=bones.length;absolute.push([off[0]+x,off[1]+y,off[2]+z]);bones.push(b);return b;
    }
    var hips=joint("pelvis",null,0,.933,0);
    var spine=joint("spine",hips,0,.055,0),neck=joint("neck",spine,0,.54,.012);
    var head=joint("head",neck,0,.071,.004),jaw=joint("jaw",head,0,.064,-.033);
    function vertex(b,x,y,z,c,u,v,other,blend){
      var n=b.userData.index,o=absolute[n];positions.push(x+o[0],y+o[1],z+o[2]);
      var rgb=colorCache[c]||(colorCache[c]=new THREE.Color(c).convertSRGBToLinear());
      colors.push(rgb.r,rgb.g,rgb.b);uvs.push(u,v);
      jointIndex.push(n,other?other.userData.index:n,0,0);weights.push(1-(blend||0),blend||0,0,0);
    }
    // Każdy przekrój: wysokość, promienie, przesunięcie przód/tył i opcjonalna waga sąsiedniego stawu.
    function loft(b,rings,color,sides,cx,cz,cloth,other){
      var start=positions.length/3;
      rings.forEach(function(r,j){
        for(var i=0;i<=sides;i++){
          var u=i/sides,a=(u-.25)*Math.PI*2;
          var height=(r[0]-rings[0][0])/(rings[rings.length-1][0]-rings[0][0]);
          var tu=.007,tv=.987,ripple=1;
          if(cloth===true){tu=u;tv=.5225+.455*height;ripple+=.024*(1-height)*Math.cos(a*7+.4);}
          if(cloth==="leftShort" || cloth==="rightShort"){
            tu=(cloth==="leftShort"?.504:.754)+.242*u;tv=.006+.488*height;
            ripple+=.045*(1-height)*Math.cos(a*6);
          }
          vertex(b,(cx||0)+Math.sin(a)*r[1]*ripple,r[0],(cz||0)+(r[3]||0)+Math.cos(a)*r[2]*ripple,color,tu,tv,other,r[4]);
          if(j && i){var d=start+j*(sides+1)+i;indices.push(d-sides-2,d-sides-1,d,d-sides-2,d,d-1);}
        }
      });
    }
    function oval(b,x,y,z,rx,ry,rz,color,n){
      var rings=[];
      for(var k=0;k<=6;k++){var a=k*Math.PI/6;rings.push([y-Math.cos(a)*ry,Math.max(.001,Math.sin(a)*rx),Math.max(.001,Math.sin(a)*rz)]);}
      loft(b,rings,color,n||10,x,z);
    }
    loft(hips,[[-.12,.154,.105],[-.08,.177,.121],[.05,.167,.111],[.1,.152,.107]],shorts,16);
    loft(spine,[[-.035,.178,.120],[.019,.184,.124],[.14,.170,.115],[.26,.183,.122],[.37,.205,.133,.006],[.43,.219,.123],[.48,.199,.103],[.51,.129,.081],[.525,.075,.067]],0xffffff,24,0,0,true);
    loft(spine,[[.50,.101,.075],[.518,.084,.071],[.528,.072,.067]],trim,16);
    var scalp=FACE.build(head,neck,jaw,idx,vertex,positions,indices);
    var limbs=[];
    [-1,1].forEach(function(side){
      var suffix=side<0?"L":"R";
      var thigh=joint("hip"+suffix,hips,side*.105,-.005,.004);
      var knee=joint("knee"+suffix,thigh,0,-.426,0);
      var ankle=joint("ankle"+suffix,knee,0,-.417,0);
      var toe=joint("toes"+suffix,ankle,0,-.053,.107);
      var shoulder=joint("shoulder"+suffix,spine,side*.207,.435,0);
      var elbow=joint("elbow"+suffix,shoulder,side*.03,-.268,-.004);
      var wrist=joint("wrist"+suffix,elbow,side*.012,-.245,0);
      var knuckles=joint("knuckles"+suffix,wrist,0,-.074,.012);
      limbs.push({hip:thigh,knee:knee,ankle:ankle,toe:toe,arm:shoulder,elbow:elbow,hand:wrist,knuckles:knuckles,side:side});
      loft(thigh,[[-.45,.050,.052,.006,.78],[-.403,.061,.069,.009,.30],[-.33,.076,.078],[-.21,.085,.093],[-.1,.091,.099]],skin,12,0,0,false,knee);
      loft(thigh,[[-.255,.099,.107],[-.235,.102,.109],[-.13,.108,.122],[.015,.096,.112],[.055,.071,.085]],0xffffff,18,0,0,side<0?"leftShort":"rightShort");
      loft(knee,[[-.19,.056,.064,-.012],[-.13,.064,.076,-.013],[-.055,.056,.058],[.015,.058,.061,.007],[.045,.048,.049]],skin,12);
      oval(knee,0,-.009,.041,.046,.052,.029,skin);
      loft(knee,[[-.412,.040,.043],[-.32,.041,.051],[-.24,.051,.062,-.009],[-.15,.065,.077,-.014],[-.098,.064,.069,-.009]],sock,14);
      loft(knee,[[-.130,.068,.080,-.013],[-.108,.067,.076,-.010]],staff?sock:keeper?0xc6d094:team===0?0xf5eadb:0xb2d4f2,14);
      // Przekroje od zapiętka do czubka. Przód cholewki i podeszwy zgina się razem z palcami.
      function shoeLayer(sections,color){
        var first=positions.length/3,n=14;
        sections.forEach(function(section,j){
          var z=section[0],width=section[1],bottom=section[2],top=section[3];
          var blend=Math.max(0,Math.min(1,(z-.064)/.105));
          for(var k=0;k<=n;k++){
            var theta=k*2*Math.PI/n, x=Math.cos(theta)*width;
            var y=(top+bottom)/2+Math.sin(theta)*(top-bottom)/2;
            vertex(ankle,x,y,z,color,.007,.987,toe,blend);
            if(j && k){var d=first+j*(n+1)+k;indices.push(d-n-2,d-n-1,d,d-n-2,d,d-1);}
          }
        });
      }
      shoeLayer([[-.081,.009,-.058,-.035],[-.075,.045,-.062,.021],[-.036,.051,-.062,.057],
        [.012,.050,-.062,.056],[.053,.056,-.062,.040],[.098,.063,-.062,.015],[.151,.063,-.062,-.002],
        [.196,.050,-.056,-.013],[.226,.022,-.048,-.024],[.230,.003,-.036,-.033]],boot);
      shoeLayer([[-.083,.007,-.062,-.047],[-.071,.049,-.071,-.049],[.017,.052,-.073,-.05],
        [.112,.065,-.074,-.050],[.164,.064,-.070,-.049],[.201,.049,-.061,-.044],
        [.228,.019,-.050,-.037],[.231,.003,-.042,-.038]],sole);
      for(var lace=0;lace<4;lace++)oval(ankle,0,.054-lace*.007,.024+lace*.017,.033,.004,.005,0xe2e2d7,8);
      oval(ankle,side*.052,-.026,.037,.008,.008,.045,bootTrim,10);
      oval(ankle,0,-.002,-.072,.028,.020,.007,bootTrim,10);
      [-1,1].forEach(function(s){
        oval(ankle,s*.031,-.073,-.041,.012,.012,.014,0x383c39,8);
        oval(toe,s*.033,-.017,.049,.012,.013,.016,0x383c39,8);
      });
      loft(shoulder,[[-.286,.042,.044,0,.63],[-.248,.045,.048,0,.20],[-.185,.057,.060],[-.112,.060,.066],[-.04,.067,.074]],skin,12,side*.014,0,false,elbow);
      loft(shoulder,[[-.186,.071,.079],[-.168,.075,.084],[-.065,.080,.088],[.002,.071,.087],[.047,.044,.061],[.06,.019,.034]],shirt,14,side*.012,0);
      loft(shoulder,[[-.185,.074,.082],[-.167,.077,.087]],trim,14,side*.012,0);
      loft(elbow,[[-.248,.030,.031],[-.201,.034,.037],[-.126,.042,.050],[-.063,.051,.055],[.004,.045,.048],[.025,.038,.038]],skin,12);
      oval(elbow,0,0,-.006,.046,.047,.045,skin,12);
      var handColor=keeper?0xdceba8:skin;
      loft(wrist,[[-.045,.034,.024,.007],[.014,.030,.032]],handColor,10);
      oval(wrist,0,-.051,.009,.039,.057,.026,handColor);
      for(var f=0;f<4;f++){var fx=(f-1.5)*.016;oval(knuckles,fx,-.018+(f===3 ? 0.009:0),.003,.009,.033-(f===3 ? 0.007:0),.010,handColor,8);}
      oval(wrist,-side*.035,-.044,.026,.016,.033,.018,handColor);
      if(keeper)loft(wrist,[[-.016,.042,.04],[.023,.039,.037]],0x293c39,12);
    });
    var geo=new THREE.BufferGeometry();
    geo.setIndex(indices);geo.setAttribute("position",new THREE.Float32BufferAttribute(positions,3));
    geo.setAttribute("color",new THREE.Float32BufferAttribute(colors,3));geo.setAttribute("uv",new THREE.Float32BufferAttribute(uvs,2));
    geo.setAttribute("skinIndex",new THREE.Uint16BufferAttribute(jointIndex,4));geo.setAttribute("skinWeight",new THREE.Float32BufferAttribute(weights,4));
    geo.computeVertexNormals();FACE.smoothSeam(geo,scalp);geo.boundingSphere=new THREE.Sphere(new THREE.Vector3(0,.83,0),1.9);
    var mat=new THREE.MeshLambertMaterial({vertexColors:true,map:this.kitTexture(kit,number,name,team,keeper,staff,skin,hair)});
    var facePose=FACE.material(mat,idx%8);
    if("skinning" in mat)mat.skinning=true;
    var model=new THREE.SkinnedMesh(geo,mat);model.add(hips);model.bind(new THREE.Skeleton(bones));
    model.castShadow=true;
    group.userData={model:model,hips:hips,spine:spine,neck:neck,head:head,jaw:jaw,facePose:facePose,faceSeed:(idx*.783+team*.399)%7.1,limbs:limbs,
      legL:limbs[0].hip,legR:limbs[1].hip,armL:limbs[0].arm,armR:limbs[1].arm,
      phase:(idx*.37)%1,poseT:0,kickLeg:idx%4===0?0:1};
    group.add(model);
    var height=.97+(idx%7)*.012;
    group.scale.set(height*(.95+.021*(idx%5)),height,height);
    if(parent)parent.add(group);
    return group;
  },

  dispose: function(group){
    if(group.parent)group.parent.remove(group);
    var m=group.userData.model;
    if(m.skeleton.dispose)m.skeleton.dispose();
    m.geometry.dispose();m.material.map.dispose();m.material.dispose();
  }
};
