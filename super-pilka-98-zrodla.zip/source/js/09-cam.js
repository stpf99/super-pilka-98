/* ============================================================
   SUPER PILKA '98 · 09-cam.js — trzy kamery + zbliżenia
   0: TV boczna · 1: Góra '98 · 2: Za piłką
   ============================================================ */
var CAM = {
  pos: { x:0, y:30, z:52 },
  look: { x:0, y:0, z:0 },
  fov: 38,
  menuAngle: 0,
  modeNames: ["TV", "TOP", "BEHIND"],

  setMode: function(m){ SET.cam = ((m%3)+3)%3; },

  update: function(dt, state){
    var b = SIM.ball;
    var des = { x:0, y:30, z:52 }, look = { x:0, y:0, z:0 }, fov = 38;
    var m = SET.cam|0;

    if(state==="goal"){
      /* zbliżenie na strzelca */
      var scorer = null;
      for(var i=0;i<SIM.players.length;i++)
        if(SIM.players[i].action==="celebrate"){ scorer = SIM.players[i]; break; }
      if(scorer){
        des = { x: scorer.pos.x - SIM.teams[scorer.team].dir*7, y: 4.5, z: scorer.pos.z + 9 };
        look = { x: scorer.pos.x, y: 1.2, z: scorer.pos.z };
        fov = 42;
      }
    }
    else if(state==="menu"){
      this.menuAngle += dt*0.12;
      des = { x: Math.sin(this.menuAngle)*88, y: 34, z: Math.cos(this.menuAngle)*88 };
      look = { x:0, y:2, z:0 };
      fov = 42;
    }
    else if(m===0){ /* TV boczna — nad boiskiem, jak kamera transmitcji */
      var bx = Math.max(-36, Math.min(36, b.x*0.74));
      des = { x: bx, y: 26, z: 47 };
      look = { x: Math.max(-40, Math.min(40, b.x*0.86)), y: 0.8, z: Math.max(-24, Math.min(24, b.z*0.45)) };
      fov = 35;
    }
    else if(m===1){ /* Góra '98 */
      des = { x: Math.max(-14, Math.min(14, b.x*0.28)), y: 94, z: Math.max(-8, Math.min(8, b.z*0.24)) + 12 };
      look = { x: Math.max(-26, Math.min(26, b.x*0.5)), y: 0, z: Math.max(-14, Math.min(14, b.z*0.4)) };
      fov = 45;
    }
    else { /* Za piłką */
      var d = SIM.teams[0].dir;
      des = { x: b.x - d*11, y: 7.5, z: Math.max(-30, Math.min(30, b.z*0.82)) };
      look = { x: b.x + d*15, y: 0.8, z: b.z*0.5 };
      fov = 52;
    }
    if(state==="penalty"){
      des = { x: b.x - SIM.teams[RULES.restartTeam].dir*10, y: 6.5, z: 4 };
      look = { x: b.x + SIM.teams[RULES.restartTeam].dir*8, y: 1, z: 0 };
      fov = 44;
    }

    var kp = Math.min(1, dt*3.4), kl = Math.min(1, dt*5.2), kf = Math.min(1, dt*3);
    this.pos.x += (des.x-this.pos.x)*kp;
    this.pos.y += (des.y-this.pos.y)*kp;
    this.pos.z += (des.z-this.pos.z)*kp;
    this.look.x += (look.x-this.look.x)*kl;
    this.look.y += (look.y-this.look.y)*kl;
    this.look.z += (look.z-this.look.z)*kl;
    this.fov += (fov-this.fov)*kf;

    WORLD.cam.position.set(this.pos.x, this.pos.y, this.pos.z);
    WORLD.cam.lookAt(this.look.x, this.look.y, this.look.z);
    if(Math.abs(WORLD.cam.fov - this.fov) > 0.05){
      WORLD.cam.fov = this.fov;
      WORLD.cam.updateProjectionMatrix();
    }
  }
};
