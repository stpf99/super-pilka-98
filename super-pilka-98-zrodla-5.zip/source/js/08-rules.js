/* ============================================================
   SUPER PILKA '98 · 08-rules.js — przepływ meczu i przepisy
   Stany: kickoff, play, throwin, goalkick, corner, freekick,
          penalty, goal, halftime, fulltime
   ============================================================ */
var RULES = {
  state: "menu",
  half: 1, elapsed: 0, displayMin: 0,
  restartTeam: 0, restartPos: {x:0,z:0}, taker: null,
  stateT: 0, celebT: 0,
  offsideSet: [], offsideArmTeam: -1,
  charge: -1, chargeKind: null, _charging: null,
  kickTeamFirst: 0,
  passPending: null,
  headerDone: false,
  lastFoulT: 0,

  /* ---------- start / restart meczu ---------- */
  newMatch: function(){
    this.half = 1; this.elapsed = 0; this.displayMin = 0;
    this.kickTeamFirst = 0;
    REC.reset();
    SIM.resetMatch();
    for(var i=0;i<2;i++){
      SIM.teams[i].stats = {shots:0,onT:0,corr:0,fouls:0,yel:0,red:0,pass:0,poss:0};
    }
    HUD.refreshTeams();
    this.setupKickoff(0, true);
  },
  setupKickoff: function(team, first){
    this.state = "kickoff"; this.stateT = 0;
    this.restartTeam = team; this.restartPos = {x:0, z:0};
    var d0 = SIM.teams[team].dir;
    /* wszyscy do formacji */
    for(var i=0;i<SIM.players.length;i++){
      var pl = SIM.players[i];
      if(pl.off) continue;
      var dt2 = SIM.teams[pl.team].dir;
      var fx = pl.home.x*dt2, fz = pl.home.z*dt2;
      if(pl.team===team){
        if(pl.idx===9){ fx = -1.1*dt2; fz = 0; }
        else if(pl.idx===10){ fx = -3.2*dt2; fz = 1.5*dt2; }
        else if(pl.role==="FW"){ fx = -2.5*dt2; fz = pl.home.z*dt2; }
      } else {
        /* przeciwnik: we własnej połowie, poza kołem środkowym */
        if(fx*dt2 > -9.6) fx = -9.6*dt2;
      }
      pl.pos.x = fx; pl.pos.z = fz; pl.vel.x = 0; pl.vel.z = 0;
      pl.face = Math.atan2(-fx, -fz) || 0;
      pl.moveTarget = null; pl.action = "run"; pl.actionT = 0;
    }
    var b = SIM.ball;
    b.x = 0; b.z = 0; b.y = SIM.BR; b.vx = b.vy = b.vz = 0; b.curve = 0;
    b.owner = null; b.lastTouchTeam = -1; b.lastKicker = null;
    this.offsideSet = []; this.offsideArmTeam = -1;
    this.taker = SIM.players[team===0 ? 9 : 20];  // FW idx9 każdej drużyny
    this.assignTakerControl();
    AI.frozen = true;
    AUDIO.whistle(first ? 1 : 1);
    if(first && WORLD.teleMsg) WORLD.teleMsg(t("tv_kick"), 3.5);
    HUD.restartTagShow(t("rst_kick"));
    this.hintFor(team, "hint_kick");
    HUD.commentary(first ? tPick("c_kick") : "");
  },
  teamName: function(team){ return team===0 ? SET.home : SET.away; },

  /* czy wykonawca wznowienia jest sterowany przez człowieka (zależnie od trybu) */
  humanTaker: function(team){
    if(SET.mode===2) return false;                 /* oglądanie: tylko AI */
    if(SET.mode===0 && team!==0) return false;     /* 1 gracz: gość to komputer */
    return true;
  },
  hintFor: function(team, key){
    HUD.hint(this.humanTaker(team) ? t(key).replace("{T}", this.teamName(team)) : t("hint_cpu"));
  },

  assignTakerControl: function(){
    if(!this.humanTaker(this.restartTeam)) return; /* CPU wykonuje sam — bez slotu gracza */
    var slot = this.restartTeam;   // P1 = drużyna 0, P2 = drużyna 1
    if(this.taker){ SIM.teams[slot].user = this.taker; this.taker.isUser = slot; }
  },
  clearTakerControl: function(){
    if(this.taker){ this.taker.isUser = null; }
  },

  /* ---------- wznowienia ---------- */
  setupThrow: function(team, x, z){
    this.state = "throwin"; this.stateT = 0;
    this.restartTeam = team;
    this.restartPos = { x: Math.max(-HL+1, Math.min(HL-1, x)), z: z > 0 ? HW : -HW };
    var b = SIM.ball;
    b.x = this.restartPos.x; b.z = this.restartPos.z; b.y = 1.7;
    b.vx = b.vy = b.vz = 0; b.owner = null; b.curve = 0;
    this.offsideSet = []; this.offsideArmTeam = -1;
    this.taker = this.nearestOutfield(team, this.restartPos, true);
    this.taker.pos.x = this.restartPos.x;
    this.taker.pos.z = this.restartPos.z + (z>0 ? -0.5 : 0.5);
    this.taker.vel.x = this.taker.vel.z = 0;
    this.taker.face = Math.atan2(-this.taker.pos.x, -this.taker.pos.z);
    this._pushOpponents(team, this.restartPos, 3);
    this.assignTakerControl();
    AI.frozen = true; this.headerDone = false;
    HUD.restartTagShow(t("rst_throw"));
    this.hintFor(team, "hint_throw");
    HUD.commentary(tPick("c_throw").replace("{T}", this.teamName(team)));
  },
  setupGoalkick: function(team, sideX){
    this.state = "goalkick"; this.stateT = 0;
    this.restartTeam = team;
    var dirX = SIM.teams[team].dir;
    this.restartPos = { x: -dirX*(HL-5.5), z: 0 };
    var b = SIM.ball;
    b.x = this.restartPos.x; b.z = 0; b.y = SIM.BR;
    b.vx = b.vy = b.vz = 0; b.owner = null; b.curve = 0;
    this.offsideSet = []; this.offsideArmTeam = -1;
    var gks = SIM.playersOf(team, "GK");
    this.taker = gks[0] || SIM.players[team*11];
    this.taker.pos.x = this.restartPos.x; this.taker.pos.z = 2;
    this._pushOpponents(team, this.restartPos, 10);
    this.assignTakerControl();
    AI.frozen = true; this.headerDone = false;
    HUD.restartTagShow(t("rst_goalkick"));
    this.hintFor(team, "hint_generic");
    HUD.commentary(tPick("c_gk").replace("{T}", this.teamName(team)));
  },
  setupCorner: function(team, sideX, sideZ){
    this.state = "corner"; this.stateT = 0;
    this.restartTeam = team;
    this.restartPos = { x: sideX*(HL-0.4), z: sideZ*(HW-0.4) };
    var b = SIM.ball;
    b.x = this.restartPos.x; b.z = this.restartPos.z; b.y = SIM.BR;
    b.vx = b.vy = b.vz = 0; b.owner = null; b.curve = 0;
    this.offsideSet = []; this.offsideArmTeam = -1;
    this.taker = this.nearestOutfield(team, this.restartPos, true);
    this.taker.pos.x = this.restartPos.x - Math.sign(sideX)*0.6;
    this.taker.pos.z = this.restartPos.z - Math.sign(sideZ)*0.6;
    SIM.teams[team].stats.corr++;
    this._boxCrowd(team, sideX);
    this._pushOpponents(team, this.restartPos, 9.15);
    this.assignTakerControl();
    AI.frozen = true; this.headerDone = false;
    HUD.restartTagShow(t("rst_corner"));
    this.hintFor(team, "hint_generic");
    HUD.commentary(tPick("c_corner"));
  },
  setupFree: function(team, x, z){
    this.state = "freekick"; this.stateT = 0;
    this.restartTeam = team;
    this.restartPos = { x: x, z: z };
    var b = SIM.ball;
    b.x = x; b.z = z; b.y = SIM.BR;
    b.vx = b.vy = b.vz = 0; b.owner = null; b.curve = 0;
    this.offsideSet = []; this.offsideArmTeam = -1;
    this.taker = this.nearestOutfield(team, this.restartPos, true);
    this.taker.pos.x = x; this.taker.pos.z = z + (z>0?-0.7:0.7);
    var dirX = SIM.teams[team].dir;
    var goalD = Math.hypot(dirX*HL-x, z);
    if(goalD < 30 && Math.abs(z) < 22){
      /* mur od 9.15 m */
      var gdx = dirX*HL-x, gdz = 0-z, gl = Math.hypot(gdx, gdz)||1;
      var opps = SIM.teamPlayers(1-team);
      opps = opps.filter(function(o){ return o.role!=="GK"; })
                .sort(function(a,c){
                  var da = Math.hypot(a.pos.x-x, a.pos.z-z), dc = Math.hypot(c.pos.x-x, c.pos.z-z);
                  return da-dc;
                });
      for(var w=0; w<Math.min(3, opps.length); w++){
        var o = opps[w];
        o.pos.x = x + gdx/gl*9.15 + (-gdz/gl)*(w-1)*1.1;
        o.pos.z = z + gdz/gl*9.15 + (gdx/gl)*(w-1)*1.1;
        o.moveTarget = null;
      }
    }
    this._pushOpponents(team, this.restartPos, 9.15);
    this.assignTakerControl();
    AI.frozen = true; this.headerDone = false;
    HUD.restartTagShow(t("rst_free"));
    this.hintFor(team, "hint_generic");
    HUD.commentary(tPick("c_free").replace("{T}", this.teamName(team)));
  },
  setupPenalty: function(team){
    this.state = "penalty"; this.stateT = 0;
    this.restartTeam = team;
    var dirX = SIM.teams[team].dir;
    this.restartPos = { x: dirX*(HL-11), z: 0 };
    var b = SIM.ball;
    b.x = this.restartPos.x; b.z = 0; b.y = SIM.BR;
    b.vx = b.vy = b.vz = 0; b.owner = null; b.curve = 0;
    this.offsideSet = []; this.offsideArmTeam = -1;
    var fws = SIM.playersOf(team, "FW");
    this.taker = fws[0] || this.nearestOutfield(team, this.restartPos, true);
    this.taker.pos.x = this.restartPos.x - dirX*3;
    this.taker.pos.z = 0;
    var gks = SIM.playersOf(1-team, "GK");
    if(gks[0]){ gks[0].pos.x = -dirX*(HL-0.4); gks[0].pos.z = 0; }
    /* wszyscy przed piłką, poza polem karnym */
    for(var i=0;i<SIM.players.length;i++){
      var pl = SIM.players[i];
      if(pl.off || pl===this.taker || pl.role==="GK") continue;
      pl.pos.x = dirX*(HL-23) - dirX*Math.abs(pl.home.z)*0.3;
      pl.pos.z = pl.home.z*1.4;
      pl.vel.x = 0; pl.vel.z = 0;
      pl.moveTarget = null;
    }
    this.assignTakerControl();
    AI.frozen = true; this.headerDone = false;
    HUD.restartTagShow(t("rst_pen"));
    this.hintFor(team, "hint_pen");
    HUD.commentary(tPick("c_pen"));
    AUDIO.whistle(2);
    if(WORLD.teleMsg) WORLD.teleMsg(t("tv_pen").replace("{T}", this.teamName(team)), 4, "card");
  },
  nearestOutfield: function(team, pos, move){
    var ps = SIM.teamPlayers(team), best = null, bd = 1e9;
    for(var i=0;i<ps.length;i++){
      var pl = ps[i];
      if(pl.role==="GK") continue;
      var d = Math.hypot(pl.pos.x-pos.x, pl.pos.z-pos.z);
      if(d < bd){ bd = d; best = pl; }
    }
    return best;
  },
  _pushOpponents: function(team, pos, dist){
    var opps = SIM.teamPlayers(1-team);
    for(var i=0;i<opps.length;i++){
      var o = opps[i];
      if(o.role==="GK") continue;
      var dx = o.pos.x-pos.x, dz = o.pos.z-pos.z;
      var d = Math.hypot(dx, dz);
      if(d < dist){
        if(d < 0.01){ dx = 1; dz = 0; d = 1; }
        o.pos.x = pos.x + dx/d*dist;
        o.pos.z = pos.z + dz/d*dist;
        o.moveTarget = null;
      }
    }
  },
  _boxCrowd: function(team, sideX){
    var dirX = SIM.teams[team].dir;
    var atk = SIM.teamPlayers(team), def = SIM.teamPlayers(1-team);
    var ai = 0;
    for(var i=0;i<atk.length && ai<5;i++){
      var a = atk[i];
      if(a.role==="GK" || a===this.taker) continue;
      a.pos.x = sideX*(HL-7-(ai%3)*4.5);
      a.pos.z = -8 + ai*4.5;
      a.moveTarget = null; ai++;
    }
    var di = 0;
    for(var j=0;j<def.length && di<5;j++){
      var d = def[j];
      if(d.role==="GK") continue;
      d.pos.x = sideX*(HL-8.5-(di%3)*4.2);
      d.pos.z = -8 + di*4.5 + 2;
      d.moveTarget = null; di++;
    }
  },

  /* ---------- zdarzenia z symulacji ---------- */
  onPass: function(pl, mate){
    var st = SIM.teams[pl.team].stats;
    this.passPending = { team: pl.team, kicker: pl, t: 2.2 };
    /* armowanie spalonego (nie przy autach/rożnych/karnych/golach od bramki) */
    if(this.state==="play" || this.state==="freekick"){
      var dirX = SIM.teams[pl.team].dir;
      var ballX = SIM.ball.x*dirX;
      var defs = SIM.teamPlayers(1-pl.team);
      var xs = defs.map(function(d){ return d.pos.x*dirX; }).sort(function(a,b){ return b-a; });
      var secondLast = xs.length>1 ? xs[1] : -HL;
      this.offsideSet = [];
      for(var i=0;i<SIM.players.length;i++){
        var a = SIM.players[i];
        if(a.team!==pl.team || a.off || a===pl) continue;
        var ax = a.pos.x*dirX;
        if(ax > 0 && ax > ballX && ax > secondLast) this.offsideSet.push(a);
      }
      this.offsideArmTeam = pl.team;
    }
  },
  onShot: function(pl){
    SIM.teams[pl.team].stats.shots++;
    AUDIO.excitementSet(0.75);
  },
  onSave: function(gk, caught){
    SIM.teams[1-gk.team].stats.onT++;
    HUD.commentary(tPick("c_save"));
    AUDIO.excitementSet(0.8);
  },

  /* ---------- faule i kartki ---------- */
  checkTackles: function(dt){
    var ps = SIM.players, b = SIM.ball;
    for(var i=0;i<ps.length;i++){
      var tk = ps[i];
      if(tk.off || tk.action!=="slide" || tk.actionT < 0.12 || tk.actionT > 0.62) continue;
      for(var j=0;j<ps.length;j++){
        var v = ps[j];
        if(v.off || v.team===tk.team) continue;
        var d = Math.hypot(v.pos.x-tk.pos.x, v.pos.z-tk.pos.z);
        if(d < 1.0){
          var ballDist = Math.hypot(b.x-tk.pos.x, b.z-tk.pos.z);
          var clean = ballDist < 1.5;
          v.action = "fallen"; v.actionT = 1.0;
          if(clean){
            /* czysta odbiorka: piłka wybita */
            b.owner = null;
            var ang = Math.random()*6.28;
            SIM.kick(tk, Math.sin(ang), Math.cos(ang), 0.3, "clear");
            this._advantageNoise();
          } else {
            this.foul(tk, v);
          }
          tk.actionT = 0.12;
          return;
        }
      }
    }
  },
  _advantageNoise: function(){ AUDIO.kick(0.3); },
  foul: function(tk, victim){
    var st = SIM.teams[tk.team].stats;
    st.fouls++;
    var strict = REFSTRICT[SET.ref];
    AUDIO.whistle(2);
    AUDIO.fanWhistle(1);          /* trybuny gwizdzą po faulu */
    /* ocena karty */
    var fromBehind = (Math.sin(victim.face)*(tk.vel.x) + Math.cos(victim.face)*(tk.vel.z)) < -1.5;
    var lastMan = this._isLastMan(victim);
    var yelChance = 0.32*strict + (fromBehind?0.22*strict:0);
    var roll = Math.random();
    var cardMsg = null;
    if(lastMan && roll < 0.55*strict && tk.role!=="GK"){ this.giveCard(tk, "red"); cardMsg = "red"; }
    else if(roll < yelChance){ this.giveCard(tk, "yellow"); cardMsg = "yellow"; }
    HUD.commentary(tPick("c_foul") + (cardMsg ? " " + (cardMsg==="red" ? tPick("c_red") : tPick("c_yellow")) : ""));
    AUDIO.excitementSet(0.55);
    var dirX = SIM.teams[victim.team].dir;
    var inBox = (victim.pos.x*dirX > HL-16.5) && Math.abs(victim.pos.z) < 20.1 && (victim.pos.x*dirX < HL);
    if(inBox){ this.setupPenalty(victim.team); }
    else { this.setupFree(victim.team, victim.pos.x, victim.pos.z); }
  },
  _isLastMan: function(att){
    var dirX = SIM.teams[att.team].dir;
    var defs = SIM.teamPlayers(1-att.team);
    var ahead = 0;
    for(var i=0;i<defs.length;i++){
      if(defs[i].role==="GK") continue;
      if(defs[i].pos.x*dirX > att.pos.x*dirX) ahead++;
    }
    var ax = att.pos.x*dirX;
    return ax > 0 && ahead <= 1 && Math.hypot(dirX*HL-att.pos.x, att.pos.z) < 30;
  },
  giveCard: function(pl, kind){
    if(kind==="yellow"){
      pl.yellows++;
      SIM.teams[pl.team].stats.yel++;
      if(pl.yellows >= 2) return this.giveCard(pl, "red");
      HUD.cardFlash(pl, false);
      if(WORLD.teleMsg) WORLD.teleMsg(t("tv_yel").replace("{N}", pl.num).replace("{T}", this.teamName(pl.team)), 4.5, "card");
    } else {
      if(pl.role==="GK") return this.giveCard(pl, "yellow");
      pl.off = true;
      SIM.teams[pl.team].stats.red++;
      WORLD.removePlayer(pl.mesh); pl.mesh = null;
      HUD.cardFlash(pl, true);
      AUDIO.whistle(2);
      if(WORLD.teleMsg) WORLD.teleMsg(t("tv_red").replace("{N}", pl.num).replace("{T}", this.teamName(pl.team)), 5, "card");
    }
  },

  /* ---------- spalony ---------- */
  checkOffsideTouch: function(pl){
    if(this.offsideArmTeam !== pl.team) return false;
    var idx = this.offsideSet.indexOf(pl);
    if(idx < 0) return false;
    this.offsideSet = []; this.offsideArmTeam = -1;
    AUDIO.whistle(2);
    HUD.commentary(tPick("c_off"));
    HUD.banner(t("rst_free"), "OFFSIDE", 1.4);
    if(WORLD.teleMsg) WORLD.teleMsg(t("tv_off"), 3, "info");
    var dirX = SIM.teams[pl.team].dir;
    this.setupFree(1-pl.team, pl.pos.x - dirX*1.5, pl.pos.z);
    return true;
  },

  /* ---------- gol ---------- */
  checkGoal: function(){
    var b = SIM.ball;
    if(Math.abs(b.z) < GOAL_W/2 + 0.1 && b.y < GOAL_H + 0.1){
      if(b.x > HL + 0.25){
        var t0 = SIM.teams[0].dir > 0 ? 0 : 1;
        this._goal(t0); return true;
      }
      if(b.x < -HL - 0.25){
        var t1 = SIM.teams[0].dir < 0 ? 0 : 1;
        this._goal(t1); return true;
      }
    }
    return false;
  },
  _goal: function(team){
    SIM.teams[team].score++;
    this._goalTeam = team;
    this._lastConceded = 1-team;
    var scorer = SIM.ball.lastKicker && SIM.ball.lastKicker.team===team ? SIM.ball.lastKicker : null;
    SIM.teams[team].stats.onT++;
    if(scorer){ scorer.action = "celebrate"; scorer.actionT = 3.2; }
    this.state = "goal"; this.celebT = 3.4;
    this.offsideSet = []; this.offsideArmTeam = -1;
    AUDIO.roar(1.2); AUDIO.horn(); AUDIO.whistle(1);
    AUDIO.excitementSet(1);
    HUD.banner("GOOOOL!", this.teamName(team), 3.0);
    HUD.commentary(tPick("c_goal"));
    HUD.setScore();
    if(WORLD.teleMsg) WORLD.teleMsg(t("tv_goal").replace("{M}", this.displayMin)
      .replace("{T}", this.teamName(team)).replace("{S}", SIM.teams[0].score + ":" + SIM.teams[1].score), 5, "goal");
    WORLD.aimArrow.visible = false;
  },

  /* ---------- auty / rożne / wykop ---------- */
  checkBounds: function(){
    var b = SIM.ball;
    if(Math.abs(b.z) > HW + 0.3 && !b.owner){
      var team = b.lastTouchTeam===0 ? 1 : 0;
      if(b.lastTouchTeam < 0) team = Math.random()<0.5?0:1;
      this.setupThrow(team, b.x, b.z);
      return true;
    }
    if(Math.abs(b.x) > HL + 0.3 && !b.owner){
      if(Math.abs(b.z) < GOAL_W/2 + 0.2 && b.y < GOAL_H + 0.3){
        /* bramka jest sprawdzana wcześniej; tu nie powinno trafić */
        return false;
      }
      var side = Math.sign(b.x);
      var attacker = SIM.teams[0].dir===side ? 0 : 1;
      if(b.lastTouchTeam === attacker){
        this.setupGoalkick(1-attacker, side);
      } else {
        this.setupCorner(attacker, side, Math.sign(b.z)||1);
      }
      return true;
    }
    return false;
  },

  /* ---------- wykonywanie wznowień przez człowieka / AI ---------- */
  _aimVec: function(slot, fallback){
    var inp = INPUT.slots[slot];
    var mx = inp.mx, mz = inp.mz;
    if(Math.hypot(mx, mz) < 0.3) return fallback;
    return { x: mx, z: mz };
  },
  _chargeUpdate: function(slot, kind){
    var inp = INPUT.slots[slot];
    if(kind==="A"){
      if(inp.pass){ this.charge = Math.min(1, this.charge + (this.charge<0 ? 0 : 0) + 0.0); }
    }
  },
  execRestart: function(kind, power){
    var pl = this.taker, team = this.restartTeam;
    var b = SIM.ball;
    var dirX = SIM.teams[team].dir;
    var aim = pl.isUser!==null ? this._aimVec(pl.isUser, null) : null; /* AI nie celuje gałką gracza */
    this.clearTakerControl();
    AI.frozen = false;
    if(kind==="kickoff"){
      var mate = SIM.nearestToBall(team, true);
      if(mate && mate!==pl){
        SIM.kick(pl, mate.pos.x-pl.pos.x, mate.pos.z-pl.pos.z, 0.3, "pass");
        this.onPass(pl, mate);
      } else {
        SIM.kick(pl, dirX, 0.2, 0.4, "pass");
      }
    }
    else if(kind==="throw"){
      var a2 = aim || { x: -Math.sign(pl.pos.x||0.1), z: -Math.sign(pl.pos.z||1)*0.3 };
      SIM.throwBall(pl, a2.x, a2.z, Math.max(0.2, power||0.4));
      this.passPending = { team: team, t: 2.2 };
    }
    else if(kind==="goalkick"){
      if(power!==undefined && power>0.05){ /* B: długie */
        SIM.kick(pl, dirX*0.9, (Math.random()*2-1)*0.35, Math.max(0.5,power), "gklong");
      } else {
        var df = this.nearestOutfield(team, pl.pos, false);
        if(df) SIM.kick(pl, df.pos.x-pl.pos.x, df.pos.z-pl.pos.z, 0.5, "pass");
        else SIM.kick(pl, dirX, 0, 0.7, "gklong");
      }
    }
    else if(kind==="corner"){
      var sideX = Math.sign(pl.pos.x||1), sideZ = Math.sign(pl.pos.z||1);
      if(power!==undefined && power>0.05){
        var tx = sideX*(HL-9-Math.random()*4);
        var tz = (Math.random()*2-1)*5;
        SIM.kick(pl, tx-pl.pos.x, tz-pl.pos.z, Math.max(0.4,power), "cross");
        /* krzywizna w stronę bramki */
        SIM.ball.curve = -sideZ*2.2;
      } else {
        var mate2 = this.nearestOutfield(team, pl.pos, false);
        if(mate2 && Math.hypot(mate2.pos.x-pl.pos.x, mate2.pos.z-pl.pos.z) < 14){
          SIM.kick(pl, mate2.pos.x-pl.pos.x, mate2.pos.z-pl.pos.z, 0.4, "pass");
        } else {
          SIM.kick(pl, sideX*-1, -sideZ*0.6, 0.8, "cross");
          SIM.ball.curve = -sideZ*2.0;
        }
      }
    }
    else if(kind==="freekick"){
      var goalD = Math.hypot(dirX*HL-pl.pos.x, pl.pos.z);
      if(power!==undefined && power>0.05){
        if(goalD < 32 && Math.abs(pl.pos.z) < 24){
          var tz2 = (Math.random()*2-1)*1.2;
          SIM.kick(pl, dirX*HL-pl.pos.x, tz2-pl.pos.z, Math.min(1,power), "shot");
          SIM.ball.curve = -Math.sign(pl.pos.z||1)*2.4;
          this.onShot(pl);
        } else {
          SIM.kick(pl, dirX, (Math.random()*2-1)*0.5, Math.max(0.6,power), "clear");
        }
      } else {
        var mate3 = this.nearestOutfield(team, pl.pos, false);
        if(mate3) SIM.kick(pl, mate3.pos.x-pl.pos.x, mate3.pos.z-pl.pos.z, 0.5, "pass");
        else SIM.kick(pl, dirX, 0, 0.7, "pass");
        this.onPass(pl, mate3);
      }
    }
    else if(kind==="penalty"){
      /* karny: celowanie gałką w szerokość, siła = wysokość */
      var inp = INPUT.slots[pl.isUser!==null ? pl.isUser : this.restartTeam];
      var aimZ = 0;
      if(aim) aimZ = aim.z*4.2;
      var high = Math.min(1, power||0.6);
      var ty = 0.6 + high*2.4;
      var miss = Math.random() < 0.06 + high*0.13;
      var tz3 = miss ? (Math.abs(aimZ)+0.7)*(Math.random()<0.5?-1:1)*1.1 : Math.max(-3.4, Math.min(3.4, aimZ));
      var gk = SIM.playersOf(1-team, "GK")[0];
      var dive = (Math.random()<0.78 ? Math.sign(tz3||1) : -Math.sign(tz3||1)) * (1.6+Math.random()*1.6);
      SIM.kick(pl, dirX*HL-pl.pos.x, tz3-pl.pos.z, 0.85, "shot");
      SIM.ball.vy = 1.2 + high*3.2;
      SIM.ball.vx *= 0.92; SIM.ball.vz *= 0.92;
      if(gk){
        gk.vel.x = 0; gk.vel.z = dive*3.2;
        var saved = Math.sign(dive)===Math.sign(tz3) && Math.abs(tz3)>0.5 &&
                    Math.random() < DIFF[SET.diff].gk*0.75;
        var self = this;
        setTimeout(function(){
          if(self.state!=="play" && self.state!=="goal") return;
          var bb = SIM.ball;
          if(saved && Math.abs(bb.x - (SIM.teams[1-team].dir===1? -HL:HL)) < 6 && bb.y < 2.6){
            bb.owner = null;
            bb.vx = -Math.sign(bb.vx||1)*6; bb.vz = Math.sign(bb.z||1)*5; bb.vy = 2;
            AUDIO.catchSnd();
            HUD.commentary(tPick("c_save"));
            self.onSave(gk, false);
          }
        }, 420);
      }
      this.onShot(pl);
    }
    HUD.restartTagHide();
    HUD.hint(t("hint_pause"));
    HUD.showPower(null);
    WORLD.aimArrow.visible = false;
    this.charge = -1; this._charging = null;
    this.state = "play";
    this.headerDone = false;
    b.live = true;
  },

  /* ---------- AI wykonuje wznowienie ---------- */
  aiRestart: function(){
    var kind = this.state, pl = this.taker;
    if(!pl || pl.off){ this.execRestart("kickoff", 0.3); return; }
    var r = Math.random();
    if(kind==="kickoff") this.execRestart("kickoff", 0.3);
    else if(kind==="throwin") this.execRestart("throw", 0.35+Math.random()*0.3);
    else if(kind==="goalkick") this.execRestart("goalkick", r<0.5 ? 0 : 0.8);
    else if(kind==="corner") this.execRestart("corner", r<0.25 ? 0 : 0.55+Math.random()*0.35);
    else if(kind==="freekick") this.execRestart("freekick", r<0.4 ? 0 : 0.6+Math.random()*0.4);
    else if(kind==="penalty") this.execRestart("penalty", 0.45+Math.random()*0.4);
  },

  /* ---------- nagłówki (dośrodkowania) ---------- */
  checkHeader: function(){
    if(this.headerDone) return;
    var b = SIM.ball;
    if(b.owner || b.y > 2.4) return;
    if(Math.hypot(b.vx, b.vz) < 6) return;
    var dirSide = Math.sign(b.x)||1;
    if(Math.abs(b.x) < HL-18) return;
    var atk = null, def = null, abd = 1e9, dbd = 1e9;
    for(var i=0;i<SIM.players.length;i++){
      var pl = SIM.players[i];
      if(pl.off) continue;
      var d = Math.hypot(pl.pos.x-b.x, pl.pos.z-b.z);
      if(d < 1.7){
        if(pl.team === (SIM.teams[0].dir===dirSide ? 0 : 1)){ if(d<abd){ abd=d; atk=pl; } }
        else { if(d<dbd){ dbd=d; def=pl; } }
      }
    }
    if(atk && (!def || abd <= dbd)){
      this.headerDone = true;
      var gdir = dirSide;
      var tz = (Math.random()*2-1)*2.8;
      SIM.kick(atk, gdir*HL-atk.pos.x, tz-atk.pos.z, 0.55, "shot");
      SIM.ball.vy = 1.6;
      this.onShot(atk);
      HUD.commentary(t("c_header"));
    } else if(def){
      this.headerDone = true;
      var ang = Math.random()*6.28;
      SIM.kick(def, Math.sin(ang), Math.cos(ang), 0.7, "clear");
    }
  },

  /* ---------- główna aktualizacja zasad ---------- */
  update: function(dt){
    var b = SIM.ball;
    this.stateT += dt;
    if(this.passPending){
      this.passPending.t -= dt;
      if(this.passPending.t <= 0) this.passPending = null;
    }

    if(this.state==="goal"){
      this.celebT -= dt;
      if(this.celebT <= 0){
        this.clearTakerControl();
        /* po golu: powtórka akcji (jeśli mamy materiał), potem wznowienie */
        if(REC.canReplay() && REPLAY.begin()){
          this.state = "replay";
        } else {
          this.setupKickoff(this._lastConceded, false);
        }
      }
      return;
    }
    if(this.state==="replay"){
      if(REPLAY.update(dt)) this.setupKickoff(this._lastConceded, false);
      return;
    }
    if(this.state==="halftime"){
      if(this.stateT > 3.0){
        this.half = 2;
        SIM.teams[0].dir *= -1; SIM.teams[1].dir *= -1;
        this.elapsed = 0;
        this.setupKickoff(1-this.kickTeamFirst, false);
      }
      return;
    }
    if(this.state==="fulltime") return;

    /* wznowienia oczekujące na wykonanie */
    if(this.state!=="play"){
      if(this.taker && !b.owner){
        /* piłka trzymana/przy zawodniku */
        if(this.state==="throwin"){
          b.x = this.taker.pos.x + Math.sin(this.taker.face)*0.35;
          b.z = this.taker.pos.z + Math.cos(this.taker.face)*0.35;
          b.y = 1.7;
        } else {
          b.x = this.taker.pos.x + Math.sin(this.taker.face)*0.5;
          b.z = this.taker.pos.z + Math.cos(this.taker.face)*0.5;
          b.y = SIM.BR;
        }
        b.vx = b.vy = b.vz = 0;
      }
      /* człowiek wykonuje */
      if(this.taker && this.taker.isUser!==null){
        var slot = this.taker.isUser;
        var inp = INPUT.slots[slot];
        /* zabezpieczenie: bezczynny człowiek nie blokuje meczu (karny — dłużej, bo celowanie) */
        if(this.stateT > (this.state==="penalty" ? 12 : 7)){ this.aiRestart(); return; }
        if(inp.moveLen > 0.3){
          var ta = Math.atan2(inp.mx, inp.mz);
          this.taker.face += SIM._angDelta(this.taker.face, ta) * Math.min(1, dt*9);
        }
        WORLD.aimArrow.visible = true;
        WORLD.aimArrow.position.set(this.taker.pos.x, 0.06, this.taker.pos.z);
        WORLD.aimArrow.rotation.z = this.taker.face - Math.PI/2;
        if(this.state==="penalty" || this.state==="corner" || this.state==="freekick" || this.state==="goalkick"){
          if(inp.shoot){ this.charge = Math.min(1, (this.charge<0?0:this.charge)+dt/0.9); HUD.showPower(this.charge); this._charging = "B"; }
          else if(this._charging==="B" && !inp.shoot){ var pw = Math.max(0.15, this.charge); this.charge = -1; this._charging = null; HUD.showPower(null); this.execRestart(this.state, pw); return; }
          if(inp.passP && this.state!=="penalty"){ this.charge = -1; this._charging = null; HUD.showPower(null); this.execRestart(this.state, 0); return; }
        } else if(this.state==="throwin"){
          if(inp.pass){ this.charge = Math.min(1, (this.charge<0?0:this.charge)+dt/0.8); HUD.showPower(this.charge); this._charging="A"; }
          else if(this._charging==="A" && !inp.pass){ var pw2 = Math.max(0.15, this.charge); this.charge=-1; this._charging=null; HUD.showPower(null); this.execRestart("throw", pw2); return; }
        } else if(this.state==="kickoff"){
          if(inp.passP){ this.execRestart("kickoff", 0.3); return; }
        }
      } else {
        /* AI czeka chwilę i wykonuje */
        WORLD.aimArrow.visible = false;
        if(this.stateT > (this.state==="penalty" ? 1.6 : 1.1)) this.aiRestart();
      }
      return;
    }

    /* ============ GRA WLASCIWA ============ */
    this.elapsed += dt;
    this.displayMin = Math.min(45, Math.floor(this.elapsed / SET.half * 45)) + (this.half===2 ? 45 : 0);
    if(b.owner) SIM.teams[b.owner.team].stats.poss += dt;
    else if(b.lastTouchTeam >= 0) SIM.teams[b.lastTouchTeam].stats.poss += dt*0.4;

    AI.frozen = false;
    this.checkTackles(dt);
    this.checkHeader();

    /* zdarzenia styku: spalony, podania */
    for(var e=0;e<SIM.events.length;e++){
      var ev = SIM.events[e];
      if(ev.type==="touch"){
        var tp = ev.player;
        if(this.passPending && tp.team===this.passPending.team && tp!==this.passPending.kicker){
          SIM.teams[tp.team].stats.pass++;
        }
        this.passPending = null;
        if(ev.first && SIM.ball.lastTouchTeam===tp.team){
          if(this.checkOffsideTouch(tp)){ SIM.events.length = 0; return; }
        }
        if(tp.team !== this.offsideArmTeam){ this.offsideSet = []; this.offsideArmTeam = -1; }
        AUDIO.excitementSet(Math.max(0.2, 0.5 - Math.abs(tp.pos.x)*0.006));
      }
      else if(ev.type==="post"){
        HUD.commentary(tPick("c_post"));
        AUDIO.excitementSet(0.85);
      }
    }
    SIM.events.length = 0;

    /* gol / auty */
    if(this.checkGoal()) return;
    if(this.checkBounds()) return;

    /* koniec połowy */
    if(this.elapsed >= SET.half){
      if(this.half===1){
        this.state = "halftime"; this.stateT = 0;
        AUDIO.whistle(2);
        HUD.banner(t("c_half"), SET.home + "  " + SIM.teams[0].score + " : " + SIM.teams[1].score + "  " + SET.away, 3.0);
        HUD.commentary(tPick("c_half"));
        HUD.showPower(null);
        if(WORLD.teleMsg) WORLD.teleMsg(t("tv_half") + "  " + SIM.teams[0].score + " : " + SIM.teams[1].score, 4, "info");
      } else {
        this.fullTime();
      }
    }
  },
  fullTime: function(){
    this.state = "fulltime";
    AUDIO.whistle(4);
    HUD.showEnd();
    if(WORLD.teleMsg) WORLD.teleMsg(t("tv_full") + "  " + SIM.teams[0].score + " : " + SIM.teams[1].score, 8, "info");
  },
  _goalTeam: -1,
  _lastConceded: 0
};
