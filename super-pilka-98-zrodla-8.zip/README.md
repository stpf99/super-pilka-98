# Super Piłka ’98

Samodzielna gra piłkarska 3D na komputer. Otwórz `super-pilka-98.html` w przeglądarce z obsługą WebGL. Gra działa z dysku, także offline. Przed meczem możesz ustawić tryb solo, dwóch graczy lokalnie lub mecz dwóch drużyn komputerowych.

## Transmisja TV 2000

Kamera **TV 2000** prowadzi akcję wzdłuż linii bocznej. Przy rozpoczęciu obejmuje koło środkowe. Przy rzucie rożnym, karnym i wykopie ustawia się za wykonawcą. Klawiszami w lewo i prawo lub lewą gałką obracasz strzałkę. Przytrzymaj i puść strzał, żeby posłać piłkę we wskazanym kierunku. Przed uderzeniem zawodnik robi rozbieg. Krótkie rozegranie dobiera partnera po tej stronie.

Po golu strzelec biegnie przed kamerę, a najbliżsi koledzy ruszają za nim. Podczas napomnienia sędzia podnosi kartkę przed ukaranym zawodnikiem. Belka podaje numer, nazwisko, drużynę i minutę. **C** lub **Select** pomija aktualne ujęcie. Przy odpowiednio długiej akcji po golu następuje powtórka.

## Podgląd zawodników

W zakładce **Drużyny** kliknij **Obejrzyj model 3D**. Przeciągaj myszą, by obracać postać. Wybierz ruch i kadr. Parada bramkarza pokazuje zawodnika w rękawicach. Podczas meczu klawisz **C** przełącza cztery kamery, w tym kamerę zza zawodnika. Kółko i klawisze **+** oraz **−** zmieniają zbliżenie.

## Stadion i doping

W menu głównym lub podczas pauzy wybierz **Zwiedź stadion**. Widoki **Gospodarze** i **Goście** prowadzą do sektorów obu klubów. **Bęben** i **Trąbka** przybliżają muzyków wybranego sektora. **Z murawy** pokazuje zadaszenie oraz galerię nad trybuną główną z perspektywy boiska. Wybieraj ujęcia przyciskami albo strzałkami w lewo i w prawo. **Esc** przywraca poprzedni widok. Nazwy drużyn z menu pojawiają się na szalikach, transparentach i bandach LED. Doping korzysta z ustawienia głośności gry.

## Sterowanie

| Akcja | Gracz 1 | Gracz 2 | Pad Xbox / PlayStation |
|---|---|---|---|
| Ruch i celowanie | WASD | Strzałki | Lewa gałka lub krzyżak |
| Podanie / pressing | K | Przecinek | A / ✕ |
| Strzał / odbiór na stojąco | L | Kropka | B / ◯ |
| Dośrodkowanie / wślizg | J | Ukośnik | X / □ |
| Podanie prostopadłe | I | M | Y / △ |
| Sprint | Lewy Shift lub spacja | Prawy Shift | RT / R2 |
| Bliski drybling / obrona bokiem | E | B | LT / L2 |
| Strzał techniczny | Q + L | H + kropka | RB + B / R1 + ◯ |
| Podaj i wyjdź na pozycję | O + K | N + przecinek | LB + A / L1 + ✕ |
| Zmiana obrońcy | O | N | LB / L1 |
| Pauza | Esc | Esc | Start / Options |

Przytrzymaj podanie albo strzał, aby ustalić siłę, i puść przycisk. Przy kombinacjach trzymaj modyfikator podczas ładowania. Po zagraniu bez ruchu gałką lub klawiaturą adresat sam wybiega do podania. Przy wznowieniu od środka użyj podania.

## Zbudowanie pełnej gry ze źródeł

W rozpakowanym katalogu uruchom poniższe polecenie.

```bash
python3 build.py
```

Powstanie `super-pilka-98.html`. Skrypt korzysta ze standardowej biblioteki Pythona. Silnik Three.js jest dołączony w katalogu `source`.

Osiem twarzy jest zapisanych w teksturze `source/art/twarze.webp`. Podczas budowania obraz trafia do pliku HTML. Modele i materiały znajdują się w `source/js/05-athletes.js`, animacje stawów w `source/js/05-motion.js`, a podgląd postaci w `source/js/10-showroom.js`.

Bryła stadionu i sektory są w `source/js/05-stadium.js`, modele i animacje kibiców w `source/js/05-supporters.js`, a murawa, piłka i siatki bramek w `source/js/05-pitch.js`.
