/* ============================================================
   SUPER PILKA '98 · 11-main.js — bootstrap, pętla, sterowanie
   ============================================================ */
var MAIN = {
  lastT: 0, fps: 60, fpsAcc: 0, fpsN: 0, fpsT: 0,
  chargeP:[0,0], chargeS:[0,0], combo:[false,false], finesse:[false,false],
  paused: false, running: false,

  boot: function(){
    var canvas = document.getElementById("c");
    try{ WORLD.init(canvas); }catch(e){
      document.getElementById("splash").lastElementChild.textContent="Brak dostępu do WebGL. Włącz akcelerację grafiki w przeglądarce.";
      console.error(e);return;
    }
    SET_bindAll();
    SET_applyLang();
    INPUT.init();
    HUD.refreshTeams();
    this.bindUI(); DESK.init(); STADIUM_TOUR.init();
    window.addEventListener("resize", function(){ WORLD.resize(); });
    document.getElementById("splash").style.display = "none";
    this.state = "menu";
    BROADCAST.clear();RULES.state = "menu";
    requestAnimationFrame(function(t){ MAIN.loop(t); });
  },

  bindUI: function(){
    var self = this;
    document.getElementById("btnPlay").addEventListener("click", function(){
      if(DESK.editingMatch){document.getElementById("ovMenu").classList.add("hide");DESK.editing(false);self.togglePause(false);}
      else self.startMatch();
    });
    document.getElementById("btnHelp").addEventListener("click", function(){
      AUDIO.init(); AUDIO.resume(); AUDIO.ui();
      document.getElementById("ovMenu").classList.add("hide");
      document.getElementById("ovHelp").classList.remove("hide");
    });
    document.getElementById("btnHelpBack").addEventListener("click", function(){
      AUDIO.ui();
      document.getElementById("ovHelp").classList.add("hide");
      document.getElementById("ovMenu").classList.remove("hide");
    });
    document.getElementById("btnResume").addEventListener("click", function(){ self.togglePause(false); });
    document.getElementById("btnSet").addEventListener("click", function(){
      AUDIO.ui();
      document.getElementById("ovPause").classList.add("hide");
      document.getElementById("ovMenu").classList.remove("hide");
      DESK.select("tactics"); DESK.editing(true);
    });
    document.getElementById("btnRestart").addEventListener("click", function(){ self.startMatch(); });
    document.getElementById("btnQuit").addEventListener("click", function(){ self.toMenu(); });
    document.getElementById("btnRematch").addEventListener("click", function(){ self.startMatch(); });
    document.getElementById("btnEndMenu").addEventListener("click", function(){ self.toMenu(); });
  },

  startMatch: function(){
    AUDIO.init(); AUDIO.resume(); AUDIO.ui();
    document.getElementById("ovMenu").classList.add("hide");
    document.getElementById("ovHelp").classList.add("hide");
    document.getElementById("ovPause").classList.add("hide");
    HUD.hideEnd();
    if(REPLAY.active)REPLAY.finish();
    HUD.replayUI(false);HUD.showPower(null);HUD.el("banner").classList.remove("show");
    HUD.commentary("");this.chargeS=[0,0];this.chargeP=[0,0];this.combo=[false,false];this.finesse=[false,false];
    DESK.editing(false); CAM._last=null;
    PITCH.reset();STADIUM.goalTeam=-1;STADIUM.goalLeft=0;
    RULES.newMatch();
    WORLD.refreshAds(SET.home, SET.away);
    HUD.refreshTeams();
    /* podpowiedź kick-offu zostaje — nie nadpisuj jej „ESC — pauza” */
    document.getElementById("hud").classList.add("show");
    this.paused = false;
    this.state = "match";
  },
  toMenu: function(){
    AUDIO.ui();
    document.getElementById("ovPause").classList.add("hide");
    HUD.hideEnd();
    document.getElementById("ovMenu").classList.remove("hide");
    document.getElementById("hud").classList.remove("show");
    WORLD.m1.visible = false; WORLD.m2.visible = false;
    WORLD.aimArrow.visible = false;
    BROADCAST.clear();RULES.state = "menu";
    this.state = "menu";
    if(REPLAY.active)REPLAY.finish();
    DESK.editing(false);this.paused=false;
  },
  togglePause: function(on){
    if(on === undefined) on = !this.paused;
    this.paused = on;
    document.getElementById("ovPause").classList.toggle("hide", !on);
    if(on){
      this.el2("pScore").textContent = SET.home + "  " + SIM.teams[0].score + " : " + SIM.teams[1].score + "  " + SET.away;
      HUD.stats("pauseStats");AUDIO.ui();
    }
  },
  el2: function(id){ return document.getElementById(id); },

  /* ---------- sterowanie człowieka ---------- */
  humanControl: function(dt){
    var b=SIM.ball, power=0;
    for(var s=0;s<2;s++){
      if(!RULES.humanTaker(s))continue;
      var inp=INPUT.slots[s],team=SIM.teams[s],user=team.user;
      team.switchCd=Math.max(0,team.switchCd-dt);
      var forced=b.owner && b.owner.team===s?b.owner:(!b.owner && b.receiver && b.receiver.team===s?b.receiver:null);
      var near=SIM.nearestToBall(s,true);
      if(forced && !forced.off && forced!==user){SIM.control(s,forced);team.switchCd=.3;}
      else if(!user || user.off){SIM.control(s,near);}
      else if(!forced && team.switchCd===0 && near && near!==user){
        var gap=Math.hypot(user.pos.x-b.x,user.pos.z-b.z)-Math.hypot(near.pos.x-b.x,near.pos.z-b.z);
        if(gap>8){SIM.control(s,near);team.switchCd=.35;}
      }
      if(inp.switchP && !forced && team.switchCd<=0){
        var candidates=SIM.teamPlayers(s).filter(function(p){return p!==team.user && p.role!=="GK";});
        candidates.sort(function(a,c){return Math.hypot(a.pos.x-b.x,a.pos.z-b.z)-Math.hypot(c.pos.x-b.x,c.pos.z-b.z);});
        if(candidates.length){SIM.control(s,candidates[0]);team.switchCd=.8;}
      }
      user=team.user;if(!user)continue;
      if(user.isUser!==s)SIM.control(s,user);
      user.closeControl=!!inp.jockey;
      var field=CAM.fieldInput(inp.mx,inp.mz);
      var dx=inp.moveLen>.15?field.x:Math.sin(user.face), dz=inp.moveLen>.15?field.z:Math.cos(user.face);
      user.moveTarget=inp.moveLen>.15?{x:user.pos.x+dx*5,z:user.pos.z+dz*5,amount:inp.moveLen,sprint:inp.sprint&&!inp.jockey}:null;
      if(user.action==="fallen" || user.action==="slide" || user.action==="dive"){
        this.chargeP[s]=this.chargeS[s]=0;continue;
      }
      if(b.owner!==user){
        this.chargeP[s]=this.chargeS[s]=0;this.combo[s]=this.finesse[s]=false;
        if(!b.owner && b.receiver===user && !user.moveTarget)user.moveTarget=AI.receiveTarget(user);
        if(b.owner && b.owner.team!==s && inp.pass && !inp.moveLen)
          user.moveTarget={x:b.x+b.owner.vel.x*.10,z:b.z+b.owner.vel.z*.10,sprint:!inp.jockey};
        if(inp.tackleP)SIM.startSlide(user);
        else if(inp.shootP)SIM.standingTackle(user);
        continue;
      }
      if(inp.pass){
        this.chargeP[s]=Math.min(1,this.chargeP[s]+dt/.65);
        this.combo[s]=this.combo[s]||inp.switchL;
      } else if(this.chargeP[s]>0){
        var passing=Math.max(.16,this.chargeP[s]),mate=SIM.pickPassTarget(s,dx,dz,false,user);
        SIM.deliver(user,mate,"pass",passing,dx,dz);
        if(this.combo[s] && mate)user.runT=2.7;
        this.chargeP[s]=this.chargeS[s]=0;this.combo[s]=false;
        if(mate)SIM.control(s,mate);
        continue;
      }
      if(inp.throughP || inp.tackleP){
        var cross=inp.tackleP, target=SIM.pickPassTarget(s,dx,dz,true,user);
        if(cross){
          var goalX=SIM.dirX(s)*(HL-10), mates=SIM.teamPlayers(s).filter(function(p){return p!==user && p.role!=="GK";});
          mates.sort(function(a,c){return Math.hypot(a.pos.x-goalX,a.pos.z*.84)-Math.hypot(c.pos.x-goalX,c.pos.z*.84);});
          target=mates[0]||target;
        }
        SIM.deliver(user,target,cross?"cross":"through",.73,dx,dz);
        if(target)SIM.control(s,target);
        this.chargeP[s]=this.chargeS[s]=0;this.combo[s]=false;continue;
      }
      if(inp.shoot){
        this.chargeS[s]=Math.min(1,this.chargeS[s]+dt/.78);
        this.finesse[s]=this.finesse[s]||inp.finesse;
      }else if(this.chargeS[s]>0){
        var dir=SIM.dirX(s), finesse=this.finesse[s]||inp.finesse, pw=Math.max(.23,this.chargeS[s]);
        var targetZ=inp.moveLen>.15?dz*3.50:-Math.sign(user.pos.z||1)*(finesse?2.65:1.25);
        var gx=dir*HL-b.x,gz=targetZ-b.z, curve=0;
        if(finesse){
          curve=-(Math.sign(user.pos.z)||dir)*dir*(4+pw*1.5);
          var travel=Math.min(1.35,Math.hypot(gx,gz)/(17+11*pw));
          gz-=dir*curve*travel*travel*.5;
        }
        SIM.kick(user,gx,gz,pw,finesse?"finesse":"shot");
        if(finesse)b.curve=curve;
        RULES.onShot(user);this.chargeS[s]=this.chargeP[s]=0;this.finesse[s]=false;
      }
      power=Math.max(power,this.chargeP[s],this.chargeS[s]);
    }
    HUD.showPower(power||null);
  },

  markers: function(){
    var m1 = WORLD.m1, m2 = WORLD.m2;
    if(["replay","goal","booking","halftime","fulltime"].includes(RULES.state)){ m1.visible = false; m2.visible = false; return; }
    var u0 = SIM.teams[0] && SIM.teams[0].user, u1 = SIM.teams[1] && SIM.teams[1].user;
    if(this.state==="match" && u0 && !u0.off){
      m1.visible = true;
      m1.position.set(u0.pos.x, 0, u0.pos.z);
      m1.userData.arrow.rotation.y=performance.now()*.0018;
      m1.userData.arrow.position.y = 2.18 + Math.sin(performance.now()/300)*0.06;
    } else m1.visible = false;
    if(this.state==="match" && u1 && !u1.off){
      m2.visible = true;
      m2.position.set(u1.pos.x, 0, u1.pos.z);
      m2.userData.arrow.rotation.y=performance.now()*.0018;
      m2.userData.arrow.position.y = 2.18 + Math.cos(performance.now()/300)*0.06;
    } else m2.visible = false;
  },

  /* ---------- główna pętla ---------- */
  loop: function(tms){
    var self = this;
    requestAnimationFrame(function(t){ self.loop(t); });
    var rawDt = (tms - this.lastT)/1000;
    var dt = Math.min(0.1, Math.max(0.001, rawDt));
    this.lastT = tms;
    /* prawdziwy fps liczony z nieograniczonego odstępu */
    this.fpsAcc += rawDt; this.fpsN++;
    if(this.fpsAcc > 0.5){
      this.fps = Math.round(this.fpsN/this.fpsAcc);
      this.fpsAcc = 0; this.fpsN = 0;

    }

    INPUT.update();

    if(STADIUM_TOUR.active){
      if(INPUT.slots[0].pauseP||INPUT.slots[1].pauseP)STADIUM_TOUR.close();
      else{STADIUM_TOUR.camera(dt);WORLD.tick(dt);WORLD.renderer.render(WORLD.scene,WORLD.cam);}
      return;
    }
    if(SHOWROOM.active){
      if(INPUT.slots[0].pauseP || INPUT.slots[1].pauseP)SHOWROOM.close();
      else SHOWROOM.update(dt);
      return;
    }
    /* pauza / menu — klawisze */
    if(this.state==="match" && !DESK.editingMatch){
      var s1 = INPUT.slots[0], s2 = INPUT.slots[1];
      if((s1.pauseP || s2.pauseP) && RULES.state!=="fulltime") this.togglePause();
      if(!this.paused && !["replay","goal","booking"].includes(RULES.state) && (s1.camP || s2.camP)){
        CAM.setMode(SET.cam+1);syncCameraMenu();SET_save();AUDIO.ui();
      }
      /* interaktywny zoom kamery: kółko myszy / klucze + − (poza powtórką) */
      if(RULES.state !== "replay"){
        if(INPUT.wheelAcc){ CAM.zoomBy(INPUT.wheelAcc * 0.0011); }
        var zk = INPUT.zoomKey();
        if(zk) CAM.zoomBy(-zk * dt * 1.3);
      }
      INPUT.wheelAcc = 0;
    }

    if(this.state==="menu"){
      /* tryb attract: pusta arena (flagi, kibice i telebim żyją też w menu) */
      CAM.update(dt, "menu");
      WORLD.tick(dt);
      WORLD.renderer.render(WORLD.scene, WORLD.cam);
      return;
    }
    if(this.paused){
      WORLD.renderer.render(WORLD.scene, WORLD.cam);
      return;
    }

    // Małe kroki zapobiegają przelatywaniu piłki przez zawodników przy niskim FPS.
    var n=Math.ceil(dt*60), step=dt/n;
    for(var tick=0;tick<n;tick++){
      var was=RULES.state;
      RULES.update(step);
      if(RULES.state==="play"){
        if(was!=="play")INPUT.consumeEdges();
        this.humanControl(step);AI.update(step);SIM.step(step);REC.push(step);
      }
      INPUT.consumeEdges();
    }
    if(RULES.state!=="replay")SIM.syncMeshes(dt);
    CAM.update(dt, RULES.state==="menu" ? "menu" : RULES.state);
    this.markers();
    HUD.update(dt);

    /* emocje tłumu */
    var b = SIM.ball;
    var prox = Math.max(0, 1 - Math.min(Math.abs(b.x-HL), Math.abs(b.x+HL))/40);
    AUDIO.excitementSet(0.12 + prox*0.3 + (b.owner?0.06:0.1));
    AUDIO.update(dt);
    /* trybuny: podskok tłumu przy golu, cichy szum w trakcie gry */
    if(RULES.state==="goal") WORLD.crowdPulse = 1;
    else if(RULES.state==="replay") WORLD.crowdPulse = 0.35;
    else WORLD.crowdPulse = Math.max(0, (WORLD.crowdPulse||0) - dt*0.5);
    WORLD.tick(dt);
    WORLD.tickStaff(dt, RULES.state);

    WORLD.renderer.render(WORLD.scene, WORLD.cam);
  }
};

/* przycisk pauzy = powrót do gry; ustawienia w pauzie pokazują menu */

window.addEventListener("load", function(){
  MAIN.boot();
  /* pad w menu = szybki start */
  var padWatch = setInterval(function(){
    if(!SHOWROOM.active && MAIN.state==="menu" && document.getElementById("ovMenu") && !document.getElementById("ovMenu").classList.contains("hide")){
      if(INPUT.anyPadButton()){
        INPUT.update();
        MAIN.startMatch();
      }
    }
  }, 300);
});
