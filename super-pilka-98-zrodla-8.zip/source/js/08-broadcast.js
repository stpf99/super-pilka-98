/* Ustawienie operatora i aktorów na murawie pomiędzy gwizdkami. Pozycje są w metrach. */
var BROADCAST = {
  scene:null,
  minute:function(){return Math.min(90,RULES.displayMin+1)+"′";},
  freeze:function(){
    SIM.players.forEach(function(p){
      p.vel.x=p.vel.z=0;p.moveTarget=null;p.closeControl=false;
      if(!p.off){p.action="run";p.actionT=0;}
    });
    var ball=SIM.ball;
    if(ball.owner)ball.owner.keeperHold=false;
    ball.owner=null;ball.live=false;ball.vx=ball.vy=ball.vz=0;
    WORLD.aimArrow.visible=false;HUD.showPower(null);
  },
  clear:function(){
    var s=this.scene;
    if(s){
      s.actors.forEach(function(p){p.action="run";p.actionT=0;p.vel.x=p.vel.z=0;});
      if(s.extra)WORLD.removePlayer(s.extra);
      if(WORLD.staff)WORLD.staff.card.visible=false;
    }
    this.scene=null;HUD.hideEvent();
  },
  goal:function(team,scorer,own){
    this.clear();this.freeze();
    var dir=SIM.dirX(team),b=SIM.ball;
    var attackers=SIM.teamPlayers(team).filter(function(p){return p.role!=="GK";});
    function near(point){return function(p,q){
      return Math.hypot(p.pos.x-point.x,p.pos.z-point.z)-Math.hypot(q.pos.x-point.x,q.pos.z-point.z);
    };}
    var hero=scorer||attackers.sort(near(b))[0];
    var mates=attackers.filter(function(p){return p!==hero;}).sort(near(hero.pos)).slice(0,2);
    // Wracając z pola karnego, strzelec zwraca się twarzą do kamery przy linii bocznej.
    var side=hero.pos.z>HW-8?-1:1;
    var forward={x:-dir*.80,z:side*.60};
    this.scene={type:"goal",hero:hero,actors:[hero].concat(mates),forward:forward,start:{x:hero.pos.x,z:hero.pos.z}};
    var title=own?t("own_goal"):t("goal_title"),player=scorer||own;
    if(scorer)title=t("goalCount").replace("{N}",scorer.goals);
    HUD.event("goal",title,this.minute(),player?player.num+"  –  "+player.name:"",RULES.teamName(team));
    HUD.hint(t("scene_skip"));
  },
  approach:function(p,x,z,pace,dt){
    var dx=x-p.pos.x,dz=z-p.pos.z,d=Math.hypot(dx,dz),speed=Math.min(pace,d/dt);
    p.vel.x=d>.015?dx/d*speed:0;p.vel.z=d>.015?dz/d*speed:0;
    p.pos.x+=p.vel.x*dt;p.pos.z+=p.vel.z*dt;
    if(speed>.15)p.face+=SIM._angDelta(p.face,Math.atan2(dx,dz))*Math.min(1,dt*9);
    return speed;
  },
  goalStep:function(dt,time){
    var s=this.scene;if(!s)return;
    var h=s.hero,f=s.forward;
    var dist=Math.min(4.9,time*3.25);
    this.approach(h,s.start.x+f.x*dist,s.start.z+f.z*dist,3.6,dt);
    h.action=time<1.55?"goalrun":"celebrate";h.face+=SIM._angDelta(h.face,Math.atan2(f.x,f.z))*Math.min(1,dt*8);
    for(var i=1;i<s.actors.length;i++){
      var p=s.actors[i],side=i===1?1:-1;
      var speed=this.approach(p,h.pos.x+f.z*.63*side-f.x*.32,h.pos.z-f.x*.63*side-f.z*.32,6.8,dt);
      p.action=speed>.8?"run":"goalarm";
      if(speed<.8)p.face+=SIM._angDelta(p.face,h.face)*Math.min(1,dt*8);
    }
  },
  booking:function(p,victim,kind,inBox){
    this.clear();this.freeze();
    var dx=victim.pos.x-p.pos.x,dz=victim.pos.z-p.pos.z,d=Math.hypot(dx,dz);
    var fx=d>.2?dx/d:SIM.dirX(victim.team), fz=d>.2?dz/d:0;
    // Filmujemy z boku, żeby kartka i twarz ukaranego nie zasłaniały się nawzajem.
    var ref={x:p.pos.x+fx*1.10-fz*.65,z:p.pos.z+fz*1.10+fx*.65};
    var s={type:"booking",hero:p,actors:[p,victim],ref:ref,extra:null,
      restart:{team:victim.team,x:victim.pos.x,z:victim.pos.z,penalty:inBox}};
    var rx=ref.x-p.pos.x,rz=ref.z-p.pos.z,span=Math.hypot(rx,rz);
    s.victimSpot={x:p.pos.x-rx*.79+rz/span*.94,z:p.pos.z-rz*.79-rx/span*.94};
    this.scene=s;
    if(p.off)s.extra=WORLD.makePlayer(p.team,p.role==="GK",p.num,WORLD.gFx,null,p.name);
    p.face=Math.atan2(ref.x-p.pos.x,ref.z-p.pos.z);p.action="booked";
    if(s.extra){s.extra.position.set(p.pos.x,0,p.pos.z);s.extra.rotation.y=p.face;}
    victim.action="bend";
    WORLD.staff.card.material.color.setHex(kind==="red"?0xf02b28:0xffdf23);
    WORLD.staff.card.visible=true;
    HUD.event(kind,kind==="red"?t("b_red"):t("b_yellow"),this.minute(),p.num+"  –  "+p.name,RULES.teamName(p.team));
    HUD.hint(t("scene_skip"));
  },
  bookingStep:function(dt){
    var s=this.scene,v=s.actors[1];
    var pace=this.approach(v,s.victimSpot.x,s.victimSpot.z,2.55,dt);
    if(pace>.3)v.action="run";
    else {v.action="bend";v.face+=SIM._angDelta(v.face,s.hero.face)*Math.min(1,dt*6);}
  },
  officials:function(dt){
    var s=this.scene,ref=WORLD.staff.ref,p=s.hero;
    ref.userData.pos.x=s.ref.x;ref.userData.pos.z=s.ref.z;ref.position.set(s.ref.x,0,s.ref.z);
    ref.rotation.y=Math.atan2(p.pos.x-s.ref.x,p.pos.z-s.ref.z);
    WORLD.animatePlayer(ref,0,dt,"showcard",RULES.stateT,0,0,1);
    // Trzyma krótszą krawędź kartki. Przy uniesionej ręce widz powinien rozpoznać jej kolor.
    var staff=WORLD.staff,card=staff.card,eye=WORLD.cam.position;
    card.getWorldPosition(staff.cardPoint);
    var yaw=Math.atan2(eye.x-staff.cardPoint.x,eye.z-staff.cardPoint.z);
    staff.cardFacing.setFromAxisAngle(WORLD.cam.up,yaw);
    card.parent.getWorldQuaternion(card.quaternion).invert().multiply(staff.cardFacing);
    card.rotateZ(-.10);
    if(s.extra)WORLD.animatePlayer(s.extra,0,dt,"booked",RULES.stateT,0,0,1);
  },
  shot:function(time){
    var s=this.scene,p=s.hero.pos;
    if(s.type==="goal"){
      var f=s.forward, widen=Math.min(1,time/1.8),distance=4.55+widen*.75;
      return {eye:{x:p.x+f.x*distance+f.z*1.25,y:1.32+widen*.20,z:p.z+f.z*distance-f.x*1.25},
        target:{x:p.x,y:1.10,z:p.z},fov:34};
    }
    var midX=(p.x+s.ref.x)*.5,midZ=(p.z+s.ref.z)*.5,dx=s.ref.x-p.x,dz=s.ref.z-p.z,d=Math.hypot(dx,dz);
    return {eye:{x:midX-dz/d*4.5+dx*.18,y:1.53,z:midZ+dx/d*4.5+dz*.18},
      target:{x:midX,y:1.20,z:midZ},fov:37};
  }
};
