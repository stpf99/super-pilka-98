/* ============================================================
   SUPER PILKA '98 · 06-sim.js — encje, fizyka piłki i zawodników
   ============================================================ */
var SIM = {
  players: [],
  ball: null,
  teams: [],
  events: [],          // zdarzenia dla modułu zasad
  G: 9.81, BR: 0.15,

  resetMatch: function(){
    /* POPRAWKA: usuń meshy zawodników z POPRZEDNIEGO meczu —
       inaczej 11 (lub 22) „duchów” zostaje na boisku obok nowej jedenastki */
    for(var r=0;r<this.players.length;r++){
      if(this.players[r] && this.players[r].mesh) WORLD.removePlayer(this.players[r].mesh);
    }
    this.players.length = 0;
    if(WORLD.gPlayers) WORLD.gPlayers.children.length = 0;   /* gwint bezpieczeństwa */
    this.teams = [
      { id:0, dir:1, score:0, user:null, stats:{shots:0,onT:0,corr:0,fouls:0,yel:0,red:0,pass:0,attempt:0,poss:0}, switchCd:0 },
      { id:1, dir:-1, score:0, user:null, stats:{shots:0,onT:0,corr:0,fouls:0,yel:0,red:0,pass:0,attempt:0,poss:0}, switchCd:0 }
    ];
    for(var t=0;t<2;t++){
      for(var i=0;i<11;i++){
        var form=LINEUP.formation(t), coord=LINEUP.forms[form][i];
        var f={role:LINEUP.roles[form][i],x:coord[0],z:coord[1]};
        var num=LINEUP.numbers[i], name=LINEUP.names[t][i];
        var mesh=WORLD.makePlayer(t,i===0,num,null,null,name);
        var pace = (i===0 ? 6.3 : 6.8 + Math.random()*1.2);
        this.players.push({
          team:t, idx:i, role:f.role, num:num, mesh:mesh, name:name,
          stridePhase:mesh.userData.phase, stamina:1, runT:0, challengeCd:0, turn:0, diveSide:1,
          home:{ x:f.x, z:f.z },
          pos:{ x:f.x, z:f.z }, vel:{ x:0, z:0 }, face:0,
          pace:pace, action:"run", actionT:0,
          isUser:null, moveTarget:null,
          goals:0, yellows:0, off:false, aiTarget:null, decideCd:0, slideCd:0
        });
      }
    }
    this.ball = { x:0, y:this.BR, z:0, vx:0, vy:0, vz:0,
      owner:null, lastTouchTeam:-1, lastKicker:null, curve:0, live:false, lock:0, receiver:null, route:null, flight:"", shotTeam:null };
    this.events.length = 0;
    this.syncMeshes(0);
  },

  control: function(team,player){
    var tm=this.teams[team];
    if(tm.user && tm.user!==player){tm.user.isUser=null;tm.user.moveTarget=null;}
    tm.user=player;
    if(player) player.isUser=team;
  },
  dirX: function(team){ return this.teams[team].dir; },

  /* pozycja domowa formacji dla kierunku ataku teamu */
  formPos: function(team, slotX, slotZ){
    var d = this.teams[team].dir;
    return { x: slotX * d, z: slotZ * d };
  },

  /* ================= FIZYKA ================= */
  step: function(dt){
    var b = this.ball;
    b.lock=Math.max(0,b.lock-dt);
    /* --- piłka --- */
    if(!b.owner){
      b.vy -= this.G*dt;
      var airborne = b.y > this.BR + 0.02;
      var drag = airborne ? 0.13 : 0.72;
      var f = Math.exp(-drag*dt);
      b.vx *= f; b.vz *= f;
      if(airborne && b.curve){
        /* lekki efekt Magnusa dla stałych fragmentów */
        var sp = Math.hypot(b.vx, b.vz);
        if(sp>0.5){
          var px = -b.vz/sp, pz = b.vx/sp;
          b.vx += px*b.curve*dt; b.vz += pz*b.curve*dt;
        }
      }
      b.x += b.vx*dt; b.y += b.vy*dt; b.z += b.vz*dt;
      if(b.y < this.BR){
        b.y = this.BR;
        if(b.vy < -1.4){
          b.vy = -b.vy*0.55;
          AUDIO.bounce(Math.abs(b.vy));
          if(b.vy < 1.6) b.vy = 0;
        } else b.vy = 0;
      }
      this._postCollision(b);
    }
    /* --- zawodnicy --- */
    for(var i=0;i<this.players.length;i++){
      var pl = this.players[i];
      if(pl.off) continue;
      this._stepPlayer(pl, dt);
    }
    this._separate();
    if(b.owner)this.carry(b.owner,dt);
    this._ballContacts(dt);
  },

  carry:function(p,dt){
    var b=this.ball,fx=Math.sin(p.face),fz=Math.cos(p.face);
    if(p.keeperHold){
      p.keeperHold=Math.abs(p.pos.x+this.dirX(p.team)*HL)<16.35 && Math.abs(p.pos.z)<20;
      if(p.keeperHold){
        b.x=p.pos.x+.37*fx;b.z=p.pos.z+.37*fz;b.y=1.15*p.mesh.scale.y;
        b.vx=p.vel.x;b.vz=p.vel.z;return;
      }
    }
    var speed=Math.hypot(p.vel.x,p.vel.z),tight=p.closeControl,sprint=!tight&&speed>7.3;
    var beat=Math.floor(p.stridePhase*(sprint?1:2));
    var contact=b.touchBeat!==beat || p.stridePhase<b.touchPhase;
    b.touchBeat=beat;b.touchPhase=p.stridePhase;
    var foot=Math.floor(p.stridePhase*2)===0?-1:1;
    var lead=tight?.35:sprint?.65:.46,spread=tight?.065:.12;
    var tx=p.pos.x+fx*lead+fz*spread*foot,tz=p.pos.z+fz*lead-fx*spread*foot;
    var dx=tx-b.x,dz=tz-b.z;
    // Na kontakcie but nadaje piłce impuls. Między krokami piłka toczy się z tarciem.
    var correction=Math.hypot(dx,dz)>(tight?.55:1.06);
    if(speed<1.3 || correction){
      var blend=1-Math.exp(-dt*(correction?16:10));
      b.vx+=(p.vel.x+dx*9-b.vx)*blend;b.vz+=(p.vel.z+dz*9-b.vz)*blend;
    }else if(contact){
      var duration=(sprint?1:.5)/MOTION.strideRate(speed);
      var push=tight?.39:sprint?1.70:.91;
      b.vx=p.vel.x+dx/duration+fx*push;b.vz=p.vel.z+dz/duration+fz*push;
    }
    var drag=Math.exp(-dt*(tight?1.56:sprint?.84:1.13));
    b.vx*=drag;b.vz*=drag;b.x+=b.vx*dt;b.z+=b.vz*dt;
    b.y=this.BR;b.vy=0;
  },
  _stepPlayer: function(pl, dt){
    /* cel ruchu ustawiony przez AI (aiTarget) albo przez input człowieka (w module main) */
    var tgt = pl.moveTarget;    // {x, z, sprint}
    var dvx = 0, dvz = 0, maxs = pl.pace;
    if(tgt){
      var dx = tgt.x - pl.pos.x, dz = tgt.z - pl.pos.z;
      var d = Math.hypot(dx, dz);
      if(d > 0.06){
        dvx = dx/d; dvz = dz/d;
        var boost=tgt.sprint?1.13+.24*pl.stamina:1;
        var want=Math.min(d*4,maxs*boost*(pl.closeControl ? 0.56:1)*(tgt.amount===undefined?1:tgt.amount));
        dvx *= want; dvz *= want;
      }
    }
    var moving=Math.hypot(pl.vel.x,pl.vel.z)>pl.pace*.76;
    var draining=tgt && tgt.sprint && moving;
    pl.stamina=Math.max(0,Math.min(1,pl.stamina+dt*(draining?-.058:moving ? 0.015 : 0.045)));
    pl.runT=Math.max(0,pl.runT-dt);pl.challengeCd=Math.max(0,pl.challengeCd-dt);
    if(pl.action==="fallen"){dvx=0;dvz=0;}
    if(pl.action==="slide" || pl.action==="dive"){dvx=pl.vel.x*.96;dvz=pl.vel.z*.96;}
    var acc=pl.closeControl?32:24;
    pl.vel.x += Math.max(-acc*dt, Math.min(acc*dt, dvx - pl.vel.x));
    pl.vel.z += Math.max(-acc*dt, Math.min(acc*dt, dvz - pl.vel.z));
    var sp = Math.hypot(pl.vel.x, pl.vel.z);
    if(sp > maxs*1.36){ pl.vel.x *= maxs*1.36/sp; pl.vel.z *= maxs*1.36/sp; }
    pl.pos.x += pl.vel.x*dt; pl.pos.z += pl.vel.z*dt;
    pl.stridePhase=(pl.stridePhase+dt*MOTION.strideRate(sp))%1;

    /* orientacja: cel lub kierunek ruchu */
    var prevFace=pl.face;
    if(pl.kickFace!==undefined && pl.actionT>.08 && ["kick","passkick","crosskick"].includes(pl.action)){
      pl.face+=this._angDelta(pl.face,pl.kickFace)*Math.min(1,dt*20);
    }else if(pl.closeControl && this.ball.owner && this.ball.owner.team!==pl.team){
      pl.face+=this._angDelta(pl.face,Math.atan2(this.ball.x-pl.pos.x,this.ball.z-pl.pos.z))*Math.min(1,dt*13);
    }else if(tgt && (Math.abs(tgt.x-pl.pos.x)>0.4 || Math.abs(tgt.z-pl.pos.z)>0.4)){
      var ta = Math.atan2(tgt.x-pl.pos.x, tgt.z-pl.pos.z);
      pl.face += this._angDelta(pl.face, ta) * Math.min(1, dt*10);
    } else if(sp > 0.5){
      var va = Math.atan2(pl.vel.x, pl.vel.z);
      pl.face += this._angDelta(pl.face, va) * Math.min(1, dt*12);
    }
    pl.turn+=(this._angDelta(prevFace,pl.face)/Math.max(dt,.001)*.18-pl.turn)*Math.min(1,dt*10);
    /* granice: lekko poza boisko dozwolone */
    pl.pos.x = Math.max(-HL-4, Math.min(HL+4, pl.pos.x));
    pl.pos.z = Math.max(-HW-4, Math.min(HW+4, pl.pos.z));

    if(pl.actionT > 0){
      pl.actionT -= dt;
      if(pl.actionT <= 0){ pl.action = "run"; }
    }
    if(pl.slideCd > 0) pl.slideCd -= dt;
    if(pl.decideCd > 0) pl.decideCd -= dt;
  },
  _angDelta: function(a, b){
    var d = (b - a) % (Math.PI*2);
    if(d > Math.PI) d -= Math.PI*2;
    if(d < -Math.PI) d += Math.PI*2;
    return d;
  },
  _separate: function(){
    var ps = this.players;
    for(var i=0;i<ps.length;i++){
      if(ps[i].off) continue;
      for(var j=i+1;j<ps.length;j++){
        if(ps[j].off) continue;
        var dx = ps[j].pos.x-ps[i].pos.x, dz = ps[j].pos.z-ps[i].pos.z;
        var d2 = dx*dx+dz*dz;
        if(d2 < 0.72 && d2 > 0.0001){
          var d = Math.sqrt(d2), push = (0.85-d)/d*0.5;
          var mi = ps[j].role==="GK"?0:1, mj = ps[i].role==="GK"?0:1;
          ps[i].pos.x -= dx*push*mi; ps[i].pos.z -= dz*push*mi;
          ps[j].pos.x += dx*push*mj; ps[j].pos.z += dz*push*mj;
        }
      }
    }
  },

  _postCollision: function(b){
    var posts = [ [HL,3.66],[HL,-3.66],[-HL,3.66],[-HL,-3.66] ];
    for(var i=0;i<4;i++){
      var dx = b.x-posts[i][0], dz = b.z-posts[i][1];
      var d = Math.hypot(dx,dz);
      if(d < this.BR+GK_R && b.y < GOAL_H+0.1){
        var nx = dx/(d||1), nz = dz/(d||1);
        var vn = b.vx*nx + b.vz*nz;
        if(vn < 0){
          b.vx -= 2*vn*nx; b.vz -= 2*vn*nz;
          b.vx *= 0.6; b.vz *= 0.6;
          AUDIO.bounce(8);
          this.events.push({ type:"post" });
        }
        b.x = posts[i][0] + nx*(this.BR+GK_R+0.01);
        b.z = posts[i][1] + nz*(this.BR+GK_R+0.01);
      }
    }
    /* poprzeczki: cylinder wzdłuż osi Z na (x=±52.5, y=2.44) */
    for(var s=-1; s<=1; s+=2){
      var dxb = b.x - s*HL, dyb = b.y - GOAL_H;
      var db = Math.hypot(dxb, dyb);
      if(db < this.BR+GK_R && Math.abs(b.z) < GOAL_W/2+0.3){
        var nx = dxb/(db||0.01), ny = dyb/(db||0.01);
        var vn = b.vx*nx + b.vy*ny;
        if(vn < 0){
          b.vx -= 2*vn*nx; b.vy -= 2*vn*ny;
          b.vx *= 0.55; b.vy *= 0.55;
          AUDIO.bounce(8);
          this.events.push({ type:"post" });
        }
        b.x = s*HL + nx*(this.BR+GK_R+0.01);
        b.y = GOAL_H + ny*(this.BR+GK_R+0.01);
      }
    }
  },

  _ballContacts: function(dt){
    var b = this.ball, ps = this.players;
    if(b.owner){
      var o = b.owner;
      var d2 = (b.x-o.pos.x)*(b.x-o.pos.x)+(b.z-o.pos.z)*(b.z-o.pos.z);
      if(d2 > 4.6){ b.owner = null; }
      return;
    }
    if(b.y>1.16 || Math.abs(b.x)>HL+this.BR || Math.abs(b.z)>HW+this.BR)return;
    var speed=Math.hypot(b.vx,b.vz), near=null, best=Infinity;
    for(var i=0;i<ps.length;i++){
      var p=ps[i];
      if(p.off || p.action==="fallen" || p.action==="slide" || (p===b.lastKicker && b.lock>0)) continue;
      var d=Math.hypot(b.x-p.pos.x,b.z-p.pos.z);
      var radius=p===b.receiver ? 0.94 : 0.65;
      if(p.role==="GK" && b.shotTeam!==null) continue; // interwencję przy strzale rozstrzyga AI bramkarza
      if(d<radius && d<best){near=p;best=d;}
    }
    if(!near)return;
    var pass=["pass","through","cross","throw","gklong"].includes(b.flight);
    if(speed<10.4 || (pass && speed<(b.receiver===near?30:21))){
      this.takeBall(near);
    }else if(best<.43){
      var nx=(b.x-near.pos.x)/(best||1),nz=(b.z-near.pos.z)/(best||1);
      var vn=b.vx*nx+b.vz*nz;
      if(vn<0){b.vx=(b.vx-1.65*vn*nx)*.53;b.vz=(b.vz-1.65*vn*nz)*.53;
        this.events.push({type:"touch",player:near});b.lastTouchTeam=near.team;b.lastKicker=near;b.receiver=null;b.lock=.18;}
    }
  },
  takeBall: function(pl){
    var b=this.ball;
    if(b.owner)b.owner.keeperHold=false;
    b.lastShotBy=null; b.owner=pl;b.receiver=null;b.route=null;b.curve=0;b.vy=0;b.y=this.BR;b.flight="";b.shotTeam=null;
    b.lastTouchTeam=pl.team;b.lastKicker=pl;b.lock=.15;
    b.vx=pl.vel.x+(b.vx-pl.vel.x)*.18;b.vz=pl.vel.z+(b.vz-pl.vel.z)*.18;
    b.touchBeat=-1;b.touchPhase=pl.stridePhase;
    pl.decideCd=Math.max(pl.decideCd,pl.role==="GK" ? 0.78 : 0.30);
    this.events.push({type:"touch",player:pl});
  },
  standingTackle: function(pl){
    var b=this.ball,o=b.owner;
    if(pl.challengeCd>0 || pl.action==="slide" || pl.action==="fallen" || !o || o.team===pl.team) return;
    pl.challengeCd=.76;pl.action="standtackle";pl.actionT=.28;
    var dx=b.x-pl.pos.x,dz=b.z-pl.pos.z,dist=Math.hypot(dx,dz);
    var facing=(Math.sin(pl.face)*dx+Math.cos(pl.face)*dz)/(dist||1);
    if(dist<(o.closeControl?1.08:1.51) && (facing>-.10 || dist<.69)){
      this.takeBall(pl);o.decideCd=.4;AUDIO.kick(.18);
    }
  },
  deliver: function(pl,mate,kind,power,aimX,aimZ,destination){
    var dir=this.dirX(pl.team), b=this.ball;
    var tx=b.x+aimX*18,tz=b.z+aimZ*18;
    if(mate){
      var lead=kind==="through" ? 0.46 : 0.20;
      tx=mate.pos.x+mate.vel.x*lead;tz=mate.pos.z+mate.vel.z*lead;
      if(kind==="through"){tx+=dir*(4.7+power*2.9);}
      if(kind==="cross"){tx+=dir*1.9;tz=mate.pos.z*.88;}
      tx=AI.clampX(tx);tz=AI.clampZ(tz);
    }
    if(destination){tx=destination.x;tz=destination.z;}
    var dx=tx-b.x,dz=tz-b.z,dist=Math.hypot(dx,dz)||1;
    this.kick(pl,dx,dz,power,kind);
    if(kind==="cross"){
      var flight=Math.max(.85,Math.min(1.9,dist/15));
      var sp=dist*.13/(1-Math.exp(-.13*flight));
      b.vx=dx/dist*sp;b.vz=dz/dist*sp;b.vy=.5*this.G*flight+(1.45-b.y)/flight;
      b.curve=0;
    }else{
      var speed=Math.min(35,(kind==="through"?7.9:5.7)+dist*.73+power*3.1);
      b.vx=dx/dist*speed;b.vz=dz/dist*speed;b.vy=.24;b.curve=0;
    }
    b.receiver=mate;b.route={x:tx,z:tz};RULES.onPass(pl,mate);
  },

  /* ================= UDERZENIA ================= */
  kick: function(pl, dx, dz, power, kind){
    var b = this.ball;
    var d = Math.hypot(dx, dz) || 1;
    if(pl.keeperHold){pl.keeperHold=false;b.y=kind==="gklong" ? 0.65:this.BR;}
    dx/=d;dz/=d;pl.kickFace=Math.atan2(dx,dz);
    var sp = 0, vy = 0, curve = 0;
    kind = kind || "pass";
    if(kind==="pass"){    sp = 11 + 13*power; vy = 0.4 + 2.2*power; }
    if(kind==="through"){ sp = 14 + 14*power; vy = 0.8 + 1.6*power; }
    if(kind==="shot"){    sp = 17 + 17*power; vy = 1.2 + 5.2*power; }
    if(kind==="finesse"){sp=17+11*power;vy=2.6+2.5*power;}
    if(kind==="clear"){   sp = 16 + 10*power; vy = 5.5 + 2*power; }
    if(kind==="throw"){   sp = 7 + 6*power;  vy = 3.3; }
    if(kind==="cross"){   sp = 12 + 6*power; vy = 5.6; curve = (Math.random()<0.5?-1:1)*(1.4+power); }
    if(kind==="gklong"){  sp = 21 + 7*power; vy = 7.2; }
    if(kind==="penclear"){sp = 18 + 8*power; vy = 3.0; }
    if(kind==="header"){  sp = 10 + 9*power;  vy = 0.8 + 2.4*power; }
    if(kind==="knee"){    sp = 13 + 10*power; vy = 1.0 + 3.2*power; }
    if(kind==="volley"){  sp = 15 + 14*power; vy = 1.1 + 4.6*power; }
    if(kind==="headpass"){sp = 7 + 5*power;   vy = 1.2 + 1.4*power; }
    if(kind==="headclear"){sp = 14 + 8*power; vy = 5.5 + 1.5*power; }
    /* podkręcenie z dobiegu: uderzenie pod kątem do biegu zawodnika
       kręci piłkę (efekt Magnusa w locie) — jak strzał „za uchem” */
    if(!curve && pl && (pl.vel.x || pl.vel.z)){
      var rs = Math.hypot(pl.vel.x, pl.vel.z);
      if(rs > 2){
        var crs = (pl.vel.x/rs)*dz - (pl.vel.z/rs)*dx;
        var kf = kind==="shot" ? 2.8 : kind==="volley" ? 2.4 :
                 (kind==="clear" || kind==="headclear") ? 1.1 : 0.7;
        curve = crs * kf;
      }
    }
    b.owner = null;
    b.vx = dx*sp; b.vz = dz*sp; b.vy = vy;
    b.curve = curve;
    b.lastTouchTeam = pl.team; b.lastKicker = pl;
    b.lock=.23;b.receiver=null;b.route=null;b.flight=kind;
    b.shotTeam=["shot","header","finesse","volley"].includes(kind)?pl.team:null;
    b.lastShotBy=b.shotTeam!==null?pl:null;
    pl.action=kind==="header"?"header":kind==="cross"?"crosskick":["through","pass"].includes(kind)?"passkick":"kick";
    pl.actionT=pl.action==="passkick" ? 0.30:pl.action==="header" ? 0.45 : 0.40;
    if(kind==="cross")RULES.headerDone=false;
    AUDIO.kick(power);
    return { speed: sp, kind: kind };
  },
  throwBall: function(pl, dx, dz, power){
    var b = this.ball;
    var d = Math.hypot(dx, dz) || 1;
    b.owner = null;
    /* wyrzut oburącz znad głowy: piłka startuje spod rąk, nad głową */
    b.x = pl.pos.x + Math.sin(pl.face)*0.30;
    b.z = pl.pos.z + Math.cos(pl.face)*0.30;
    b.y = 2.15;
    b.vx = dx/d*(7+8*power); b.vz = dz/d*(7+8*power); b.vy = 2.6 + power*1.4;
    b.curve = 0;
    b.lastTouchTeam = pl.team; b.lastKicker = pl;
    b.lock=.26;b.receiver=null;b.route=null;b.flight="throw";b.shotTeam=null;b.lastShotBy=null;
    pl.action = "throw"; pl.actionT = 0.52;
    AUDIO.kick(0.25);
  },

  /* ================= WŚLIZGI ================= */
  startSlide: function(pl){
    if(pl.action==="slide" || pl.action==="fallen" || pl.slideCd > 0) return false;
    pl.action = "slide"; pl.actionT = 0.72; pl.slideCd = 1.4;
    pl.vel.x = Math.sin(pl.face)*8.6;
    pl.vel.z = Math.cos(pl.face)*8.6;
    return true;
  },

  /* ================= SYNCHRONIZACJA GRAFIKI ================= */
  syncMeshes: function(dt){
    var b = this.ball;
    WORLD.ball.position.set(b.x, b.y, b.z);
    if(!b.owner || !b.owner.keeperHold){
      var roll = Math.hypot(b.vx, b.vz);
      if(roll > 0.4){
        WORLD.ball.rotation.x += (b.vz/0.15)*dt;
        WORLD.ball.rotation.z -= (b.vx/0.15)*dt;
      }
    }
    WORLD.blob.position.set(b.x, 0.022, b.z);
    var bs = 0.7 + Math.max(0, b.y-0.15)*0.55;
    WORLD.blob.scale.set(bs, bs, 1);
    WORLD.blob.material.opacity = Math.max(0.12, 0.5 - (b.y-0.15)*0.22);

    for(var i=0;i<this.players.length;i++){
      var pl = this.players[i];
      if(pl.off || !pl.mesh){ if(pl.mesh) pl.mesh.visible = false; continue; }
      pl.mesh.visible = true;
      pl.mesh.position.set(pl.pos.x,0,pl.pos.z);
      pl.mesh.rotation.y = pl.face;
      var speed = Math.hypot(pl.vel.x, pl.vel.z);
      var action=this.visualAction(pl);
      var look=this._angDelta(pl.face,Math.atan2(b.x-pl.pos.x,b.z-pl.pos.z));
      if(RULES.state==="goal")look=pl.action==="run"?0:.14*Math.sin(RULES.stateT*2.1+pl.idx);
      if(RULES.state==="booking" && pl.action==="booked")look=0;
      var lateral=(pl.vel.x*Math.cos(pl.face)-pl.vel.z*Math.sin(pl.face))/(speed||1);
      var forward=(pl.vel.x*Math.sin(pl.face)+pl.vel.z*Math.cos(pl.face))/(speed||1);
      WORLD.animatePlayer(pl.mesh,speed,dt,action,pl.actionT,pl.turn,look,pl.diveSide,lateral,forward,RULES.state==="play"?pl.stridePhase:undefined);
    }
    WORLD.playerShadows(this.players);
  },

  visualAction: function(pl){
    if(pl.action!=="run")return pl.action;
    if(pl.keeperHold && this.ball.owner===pl)return "keeperhold";
    if(pl.isUser!==null && MAIN.chargeS[pl.team]>.03 && this.ball.owner===pl)return "windup";
    if(pl.isUser!==null && MAIN.chargeP[pl.team]>.04 && this.ball.owner===pl)return "passload";
    return pl.closeControl?"jockey":"run";
  },

  nearestToBall: function(team, exclGK){
    var best = null, bd = 1e9, b = this.ball;
    for(var i=0;i<this.players.length;i++){
      var pl = this.players[i];
      if(pl.off || pl.team!==team) continue;
      if(exclGK && pl.role==="GK") continue;
      var d = (pl.pos.x-b.x)*(pl.pos.x-b.x)+(pl.pos.z-b.z)*(pl.pos.z-b.z);
      if(d < bd){ bd = d; best = pl; }
    }
    return best;
  },
  teamPlayers: function(team){
    var out = [];
    for(var i=0;i<this.players.length;i++)
      if(this.players[i].team===team && !this.players[i].off) out.push(this.players[i]);
    return out;
  },
  playersOf: function(team, role){
    var out = [];
    for(var i=0;i<this.players.length;i++)
      if(this.players[i].team===team && !this.players[i].off && (!role || this.players[i].role===role)) out.push(this.players[i]);
    return out;
  },

  /* pomocnik wyboru partnera do podania */
  pickPassTarget: function(team, mx, mz, through, self){
    var mates = this.teamPlayers(team), best = null, bs = -1e9;
    var ml = Math.hypot(mx, mz);
    if(ml < 0.25){ mx = Math.sin(self.face); mz = Math.cos(self.face); ml = 1; }
    mx /= ml; mz /= ml;
    var dirX = this.teams[team].dir;
    for(var i=0;i<mates.length;i++){
      var m = mates[i];
      if(m===self) continue;
      var dx = m.pos.x-self.pos.x, dz = m.pos.z-self.pos.z;
      var d = Math.hypot(dx, dz);
      if(d < 2 || d > 42) continue;
      var al = (dx*mx+dz*mz)/d;
      if(al < 0.05) continue;
      var prog = ((m.pos.x-self.pos.x)*dirX)/20;
      var s = al*3.2 + prog*0.6 - Math.abs(d-14)*0.05 - (m.role==="GK"?2.2:0);
      var lane=AI.laneOpenness(self,m,this.teamPlayers(1-team));
      s+=Math.min(4,lane)*.16;
      if(through)s+=prog*.85+(m.runT>0?1.9:0)+(m.role==="FW" ? 0.4:0);
      if(s > bs){ bs = s; best = m; }
    }
    return best;
  }
};
