/* Podgląd wykorzystuje dokładnie te same kości, tekstury i pozy co mecz. */
var SHOWROOM = {
  renderer:null,models:{},active:false,selection:0,angle : 0.40,time:0,key:"",
  clips:[["idle","run",0,0],["jog","run",3.7,0],["sprint","run",8.6,0],["shootAnim","kick",0,.4],
    ["passAnim","passkick",0,.3],["slideAnim","slide",0,.72],["jockeyAnim","jockey",1.8,0],["throwAnim","throw",0,.52],
    ["headAnim","header",0,.45],["diveAnim","dive",0,.65],["goalRunAnim","goalrun",3.3,0],["goalAnim","celebrate",0,0],["protestAnim","booked",0,0]],
  init: function(){
    this.renderer=new THREE.WebGLRenderer({alpha:true,antialias:true,powerPreference:"low-power"});
    this.renderer.outputEncoding=THREE.sRGBEncoding;this.renderer.setClearColor(0x000000,0);
    this.scene=new THREE.Scene();this.camera=new THREE.PerspectiveCamera(30,1,.02,25);
    this.scene.add(new THREE.HemisphereLight(0xfff4e1,0xb5c7c1,1.02));
    var key=new THREE.DirectionalLight(0xfff1d7,1.24);key.position.set(-2.5,4,3.5);this.scene.add(key);
    var rim=new THREE.DirectionalLight(0xc3e1ff,1.05);rim.position.set(3,2,-1.5);this.scene.add(rim);
    var shade=document.createElement("canvas");shade.width=shade.height=128;var g=shade.getContext("2d");
    var gradient=g.createRadialGradient(64,64,4,64,64,62);gradient.addColorStop(0,"rgba(0,0,0,.52)");gradient.addColorStop(1,"transparent");
    g.fillStyle=gradient;g.fillRect(0,0,128,128);
    this.shadow=new THREE.Mesh(new THREE.PlaneGeometry(1.38,.72),new THREE.MeshBasicMaterial({map:new THREE.CanvasTexture(shade),transparent:true,depthWrite:false}));
    this.shadow.rotation.x=-Math.PI/2;this.shadow.position.y=-.014;this.scene.add(this.shadow);
    var self=this, stage=document.getElementById("modelStage"),drag=null;
    document.querySelectorAll("[data-model]").forEach(function(btn){btn.onclick=function(){self.open(Number(btn.dataset.model));};});
    document.getElementById("modelBack").onclick=function(){self.close();};
    document.getElementById("rotLeft").onclick=function(){self.angle-=.4;};
    document.getElementById("rotRight").onclick=function(){self.angle+=.4;};
    document.getElementById("modelAnim").onchange=function(){self.time=0;self.showName();};
    stage.addEventListener("pointerdown",function(e){if(e.target.closest("button"))return;drag=e.clientX;stage.setPointerCapture(e.pointerId);});
    stage.addEventListener("pointermove",function(e){if(drag===null)return;self.angle+=(e.clientX-drag)*.013;drag=e.clientX;});
    stage.addEventListener("lostpointercapture",function(){drag=null;});
  },
  subject: function(team,keeper){
    var key=team+"-"+keeper, index=keeper?0:(team===0?9:10);
    if(!this.models[key]){
      this.models[key]=ATHLETE.create(team,keeper,LINEUP.numbers[index],this.scene,null,LINEUP.names[team][index]);
    }
    var models=this.models;Object.keys(models).forEach(function(k){models[k].visible=k===key;});
    return models[key];
  },
  portrait: function(canvas,team){
    if(!this.renderer)this.init();
    if(canvas.dataset.drawn)return;
    var m=this.subject(team,false);m.rotation.y=team===0 ? 0.38:-.38;
    m.userData.phase=team===0 ? 0.22 : 0.48;
    MOTION.animate(m,team===0?1.25:1.85,0,"run",0,0,team===0?-.19 : 0.19,1);
    this.render(canvas.width,canvas.height,.96,3.90);
    var g=canvas.getContext("2d");g.drawImage(this.renderer.domElement,0,0);
    canvas.dataset.drawn="1";
  },
  render: function(w,h,y,dist){
    var r=this.renderer,cv=r.domElement;
    if(cv.width!==w || cv.height!==h)r.setSize(w,h,false);
    this.camera.aspect=w/h;this.camera.position.set(0,y+.13,dist);this.camera.lookAt(0,y,0);
    this.camera.updateProjectionMatrix();r.render(this.scene,this.camera);
  },
  showName: function(){
    var i=Number(document.getElementById("modelAnim").value)||0,idx=this.clips[i][1]==="dive"?0:(this.selection===0?9:10);
    document.getElementById("modelName").textContent=LINEUP.numbers[idx]+"  "+LINEUP.names[this.selection][idx];
  },
  open: function(team){
    this.selection=team;this.active=true;this.angle=.38;this.time=.1;
    var select=document.getElementById("modelAnim");select.replaceChildren();
    this.clips.forEach(function(c,i){var opt=document.createElement("option");opt.value=i;opt.textContent=t(c[0]);select.add(opt);});select.value="1";
    document.getElementById("modelFrame").value="body";
    document.getElementById("ovMenu").classList.add("hide");document.getElementById("ovModel").classList.remove("hide");
    document.getElementById("modelStage").appendChild(this.renderer.domElement);this.showName();this.update(.016);
    document.getElementById("modelBack").focus();
  },
  close: function(){
    this.active=false;document.getElementById("ovModel").classList.add("hide");document.getElementById("ovMenu").classList.remove("hide");
    document.querySelector('[data-model="'+this.selection+'"]').focus();
  },
  update: function(dt){
    var clip=this.clips[Number(document.getElementById("modelAnim").value)]||this.clips[0];
    var m=this.subject(this.selection,clip[1]==="dive"), action=clip[1];
    this.time+=dt;
    var pos=this.time%(clip[3]+.76),remaining=clip[3]-pos;
    if(clip[3] && remaining<0)action=clip[1]==="kick" && remaining<-.53?"windup":"run";
    m.rotation.y=this.angle;
    MOTION.animate(m,clip[2],dt,action,Math.max(0,remaining),0,0,1);
    var stage=document.getElementById("modelStage"),frame=document.getElementById("modelFrame").value;
    var dist=frame==="feet"?1.96:frame==="upper"?2.15:3.98;
    var y=frame==="feet" ? 0.44:frame==="upper"?1.37 : 0.93;
    var w=Math.max(1,stage.clientWidth),h=Math.max(1,stage.clientHeight);
    this.render(w,h,y,dist*Math.max(1,.80/(w/h)));
  }
};
