/* ============================================================
   SUPER PILKA '98 · 05-world.js — scena Three.js, stadion, zawodnicy
   Współrzędne: X wzdłuż boiska (±52.5), Z szerokość (±34), Y w górę.
   ============================================================ */
var PL = 105, PW = 68, HL = 52.5, HW = 34;          // wymiary boiska
var GOAL_W = 7.32, GOAL_H = 2.44, GK_R = 0.06;      // bramka

var WORLD = {
  renderer: null, scene: null, cam: null,
  gPlayers: null, gBall: null, gFx: null, gLines: null,
  kit: null, ball: null, blob: null, aimArrow: null,
  marks: [], m1: null, m2: null,

  init: function(canvas){
    this.renderer = new THREE.WebGLRenderer({ canvas: canvas, antialias: true, powerPreference:"high-performance" });
    this.renderer.outputEncoding = THREE.sRGBEncoding;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.08;
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x0a1422);
    this.scene.fog = new THREE.Fog(0x0a1422, 150, 460);

    this.cam = new THREE.PerspectiveCamera(38, innerWidth/innerHeight, 0.5, 700);
    this.cam.position.set(0, 30, 52);

    this.gLines = new THREE.Group(); this.gPlayers = new THREE.Group();
    this.gBall = new THREE.Group(); this.gFx = new THREE.Group();
    this.scene.add(this.gLines, this.gPlayers, this.gBall, this.gFx);

    this._lights();
    this._sky();
    this._ground();
    this._fieldLines();
    this._goals();
    this._stands();
    this._masts();
    this._ads();
    this._markers();
    this.kit = [
      { shirt:0xf5f5f2, shorts:0xd21f2b, socks:0xd21f2b, gk:0xe8a11c, gkShorts:0x20242c, tag:0xe8352a },
      { shirt:0x2456e0, shorts:0xf5f5f2, socks:0x2456e0, gk:0x23b85c, gkShorts:0x20242c, tag:0x2a6df0 }
    ];
    this.ball = this._makeBall();
    this.gBall.add(this.ball);
    this.quality();
  },

  quality: function(){
    var q = SET.q|0;
    var dpr = window.devicePixelRatio || 1;
    if(q===0){ this.renderer.setPixelRatio(Math.min(dpr,1)); this.renderer.shadowMap.enabled=false; }
    else if(q===1){ this.renderer.setPixelRatio(Math.min(dpr,1.5)); this.renderer.shadowMap.enabled=true;
      if(this._sun) this._sun.shadow.mapSize.set(1024,1024); }
    else { this.renderer.setPixelRatio(Math.min(dpr,2)); this.renderer.shadowMap.enabled=true;
      if(this._sun) this._sun.shadow.mapSize.set(2048,2048); }
    if(this._sun){ this._sun.castShadow = this.renderer.shadowMap.enabled;
      if(this._sun.shadow.map){ this._sun.shadow.map.dispose(); this._sun.shadow.map = null; } }
    this.renderer.setSize(innerWidth, innerHeight, false);
    this.cam.aspect = innerWidth/innerHeight; this.cam.updateProjectionMatrix();
  },
  resize: function(){
    this.renderer.setSize(innerWidth, innerHeight, false);
    this.cam.aspect = innerWidth/innerHeight; this.cam.updateProjectionMatrix();
  },

  /* ---------- światła i niebo ---------- */
  _lights: function(){
    var hemi = new THREE.HemisphereLight(0x9db4d6, 0x1c2a1a, 0.85);
    this.scene.add(hemi);
    var sun = new THREE.DirectionalLight(0xfff1d0, 1.15);
    sun.position.set(46, 84, 30);
    sun.castShadow = true;
    sun.shadow.mapSize.set(2048, 2048);
    sun.shadow.camera.left = -78; sun.shadow.camera.right = 78;
    sun.shadow.camera.top = 60; sun.shadow.camera.bottom = -60;
    sun.shadow.camera.near = 10; sun.shadow.camera.far = 220;
    sun.shadow.bias = -0.0006;
    this.scene.add(sun);
    this._sun = sun;
  },
  _sky: function(){
    var n = 260, pos = new Float32Array(n*3);
    for(var i=0;i<n;i++){
      var a = Math.random()*Math.PI*2, r = 300 + Math.random()*60;
      var y = 30 + Math.random()*220;
      pos[i*3] = Math.cos(a)*r; pos[i*3+1] = y; pos[i*3+2] = Math.sin(a)*r;
    }
    var g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.BufferAttribute(pos,3));
    var m = new THREE.PointsMaterial({ color:0xcfe0ff, size:1.6, sizeAttenuation:false, transparent:true, opacity:0.8 });
    this.scene.add(new THREE.Points(g, m));
  },

  /* ---------- płaszczyzny pomocnicze ---------- */
  _mkCanvas: function(w,h){ var c=document.createElement("canvas"); c.width=w; c.height=h; return c; },
  _tex: function(cv, rx, ry){
    var t = new THREE.CanvasTexture(cv);
    t.wrapS = t.wrapT = THREE.RepeatWrapping;
    if(rx) t.repeat.set(rx, ry||1);
    t.anisotropy = 8;
    return t;
  },
  _plane: function(w, h, mat, rx){
    var m = new THREE.Mesh(new THREE.PlaneGeometry(w, h), mat);
    m.rotation.x = rx!==undefined ? rx : -Math.PI/2;
    return m;
  },

  _ground: function(){
    var cv = this._mkCanvas(512,512), g = cv.getContext("2d");
    for(var i=0;i<2;i++){ g.fillStyle = i? "#1f5e26":"#26702e"; g.fillRect(i*256,0,256,512); }
    for(var d=0;d<1600;d++){
      g.fillStyle = "rgba("+(20+Math.random()*30|0)+","+(90+Math.random()*50|0)+","+(30+Math.random()*30|0)+",0.25)";
      g.fillRect(Math.random()*512, Math.random()*512, 2, 2);
    }
    var grass = this._tex(cv, 24, 1);
    var pitch = this._plane(134, 96, new THREE.MeshLambertMaterial({ map: grass }));
    pitch.receiveShadow = true;
    this.scene.add(pitch);
    var outer = this._plane(420, 380, new THREE.MeshBasicMaterial({ color:0x070b11 }));
    outer.position.y = -0.06; outer.receiveShadow = false;
    this.scene.add(outer);
  },

  _line: function(w, l, x, z, rotY){
    var m = new THREE.Mesh(new THREE.PlaneGeometry(w, l),
      new THREE.MeshBasicMaterial({ color:0xf2f6ff }));
    m.rotation.x = -Math.PI/2;
    if(rotY) m.rotation.z = rotY;
    m.position.set(x, 0.02, z);
    this.gLines.add(m);
    return m;
  },
  _ring: function(rIn, rOut, x, z, tStart, tLen){
    var m = new THREE.Mesh(new THREE.RingGeometry(rIn, rOut, 48, 1, tStart||0, tLen||Math.PI*2),
      new THREE.MeshBasicMaterial({ color:0xf2f6ff, side:THREE.DoubleSide }));
    m.rotation.x = -Math.PI/2;
    m.position.set(x, 0.02, z);
    this.gLines.add(m);
    return m;
  },
  _spot: function(x, z){
    var m = new THREE.Mesh(new THREE.CircleGeometry(0.16, 16),
      new THREE.MeshBasicMaterial({ color:0xf2f6ff }));
    m.rotation.x = -Math.PI/2; m.position.set(x, 0.021, z);
    this.gLines.add(m);
  },
  _fieldLines: function(){
    var L = PL, W = PW;
    this._line(L+0.3, 0.13, 0,  HW); this._line(L+0.3, 0.13, 0, -HW);
    this._line(0.13, W+0.3,  HL, 0); this._line(0.13, W+0.3, -HL, 0);
    this._line(0.13, W, 0, 0);
    this._ring(9.09, 9.21, 0, 0);
    this._spot(0, 0);
    for(var s=-1; s<=1; s+=2){
      /* pole karne */
      this._line(0.13, 40.32, s*(HL-16.5), 0);
      this._line(16.5, 0.13, s*(HL-8.25),  20.16);
      this._line(16.5, 0.13, s*(HL-8.25), -20.16);
      /* pole bramkowe */
      this._line(0.13, 18.32, s*(HL-5.5), 0);
      this._line(5.5, 0.13, s*(HL-2.75),  9.16);
      this._line(5.5, 0.13, s*(HL-2.75), -9.16);
      /* punkty i łuki karne */
      this._spot(s*(HL-11), 0);
      var a = Math.acos(5.5/9.15);
      if(s<0) this._ring(9.09, 9.21, s*(HL-11), 0, -a, 2*a);
      else    this._ring(9.09, 9.21, s*(HL-11), 0, Math.PI-a, 2*a);
      /* łuki narożne */
      if(s>0){
        this._ring(0.92, 1.04,  HL,  HW, Math.PI, Math.PI/2);
        this._ring(0.92, 1.04,  HL, -HW, Math.PI/2, Math.PI/2);
        this._ring(0.92, 1.04, -HL,  HW, Math.PI*1.5, Math.PI/2);
        this._ring(0.92, 1.04, -HL, -HW, 0, Math.PI/2);
      }
    }
  },

  _goals: function(){
    var postMat = new THREE.MeshLambertMaterial({ color:0xf8f8f8 });
    var netCv = this._mkCanvas(128,128), ng = netCv.getContext("2d");
    ng.strokeStyle = "rgba(255,255,255,0.85)"; ng.lineWidth = 1.4;
    for(var i=0;i<=128;i+=9){
      ng.beginPath(); ng.moveTo(i,0); ng.lineTo(i,128); ng.stroke();
      ng.beginPath(); ng.moveTo(0,i); ng.lineTo(128,i); ng.stroke();
    }
    var netMat = new THREE.MeshBasicMaterial({ map:this._tex(netCv, 6, 3), transparent:true, opacity:0.34, side:THREE.DoubleSide, depthWrite:false });
    for(var s=-1; s<=1; s+=2){
      var gx = s*HL;
      var p1 = new THREE.Mesh(new THREE.CylinderGeometry(GK_R, GK_R, GOAL_H+0.1, 10), postMat);
      p1.position.set(gx, GOAL_H/2,  3.66);
      var p2 = p1.clone(); p2.position.z = -3.66;
      var bar = new THREE.Mesh(new THREE.CylinderGeometry(GK_R, GK_R, GOAL_W+0.24, 10), postMat);
      bar.rotation.x = Math.PI/2; bar.position.set(gx, GOAL_H, 0);
      p1.castShadow = p2.castShadow = bar.castShadow = true;
      this.scene.add(p1, p2, bar);
      /* siatka: tył, góra, boki */
      var back = new THREE.Mesh(new THREE.PlaneGeometry(GOAL_W+0.2, 2.0), netMat);
      back.position.set(s*(HL+1.5), 1.0, 0); back.rotation.y = Math.PI/2;
      var top = new THREE.Mesh(new THREE.PlaneGeometry(GOAL_W+0.2, 1.7), netMat);
      top.position.set(s*(HL+0.75), 2.2, 0); top.rotation.set(Math.PI/2, Math.PI/2*s, 0);
      var sideL = new THREE.Mesh(new THREE.PlaneGeometry(1.5, 2.0), netMat);
      sideL.position.set(s*(HL+0.75), 1.0, 3.66);
      var sideR = sideL.clone(); sideR.position.z = -3.66;
      this.scene.add(back, top, sideL, sideR);
    }
  },

  _stands: function(){
    var cv = this._mkCanvas(256,128), g = cv.getContext("2d");
    g.fillStyle = "#141a26"; g.fillRect(0,0,256,128);
    var cols = ["#e8352a","#2456e0","#f5f5f2","#ffcf3d","#7893c9","#20242c","#c9542a"];
    for(var r=0;r<10;r++){
      for(var c=0;c<64;c++){
        if(Math.random()<0.18) continue;
        g.fillStyle = cols[(Math.random()*cols.length)|0];
        g.fillRect(c*4+1, 8+r*12, 2.6, 5);
      }
      g.fillStyle = "rgba(0,0,0,0.5)"; g.fillRect(0, 6+r*12, 256, 1.6);
    }
    var crowdTex = this._tex(cv, 14, 2);
    this.crowdTex = crowdTex;
    this.crowdPlanes = [];
    var cmat = new THREE.MeshLambertMaterial({ map: crowdTex, side: THREE.DoubleSide });
    var wallMat = new THREE.MeshLambertMaterial({ color:0x10151f });
    var roofMat = new THREE.MeshLambertMaterial({ color:0x2a3242 });
    /* trybuna: mur przy boisku, pochyły płat odbiegający w górę od boiska,
       dach na szczycie. dist = odległość podstawy od środka. */
    function stand(w, dist, rotY){
      var grp = new THREE.Group();
      var wall = new THREE.Mesh(new THREE.BoxGeometry(w, 2.8, 1.4), wallMat);
      wall.position.set(0, 1.4, dist - 2.4);
      var pl = new THREE.Mesh(new THREE.PlaneGeometry(w, 26), cmat);
      pl.position.set(0, 11, dist + 2);
      pl.rotation.x = 1.06;          /* +: górna krawędź DALEJ od boiska */
      var roof = new THREE.Mesh(new THREE.BoxGeometry(w, 0.5, 9), roofMat);
      roof.position.set(0, 21.5, dist + 7);
      roof.rotation.x = 0.1;
      grp.add(wall, pl, roof);
      grp.rotation.y = rotY;
      return grp;
    }
    var s1 = stand(112, 46, 0);
    var s2 = stand(112, 46, Math.PI);
    var s3 = stand(64, 66, Math.PI/2);
    var s4 = stand(64, 66, -Math.PI/2);
    this.crowdPlanes.push(s1.children[1], s2.children[1], s3.children[1], s4.children[1]);
    this.scene.add(s1, s2, s3, s4);
  },

  _masts: function(){
    var poleMat = new THREE.MeshLambertMaterial({ color:0x1a2030 });
    var lampMat = new THREE.MeshBasicMaterial({ color:0xeaf2ff });
    for(var sx=-1; sx<=1; sx+=2) for(var sz=-1; sz<=1; sz+=2){
      var pole = new THREE.Mesh(new THREE.CylinderGeometry(0.42, 0.6, 30, 8), poleMat);
      pole.position.set(sx*66, 15, sz*48);
      var head = new THREE.Mesh(new THREE.BoxGeometry(5.6, 2.0, 0.7), lampMat);
      head.position.set(sx*66, 30.5, sz*48);
      head.lookAt(0, 2, 0);
      this.scene.add(pole, head);
    }
  },

  _ads: function(){
    this.adMat = new THREE.MeshBasicMaterial({ color:0x10141c });
    var mk = function(w, x, z, ry){
      var m = new THREE.Mesh(new THREE.BoxGeometry(w, 1.0, 0.24), WORLD.adMat);
      m.position.set(x, 0.52, z); m.rotation.y = ry||0;
      m.castShadow = false;
      return m;
    };
    this.adBoards = [
      mk(104, 0,  37.4, 0), mk(104, 0, -37.4, 0),
      mk(46,  56.6, 0, Math.PI/2), mk(46, -56.6, 0, Math.PI/2)
    ];
    this.scene.add(this.adBoards[0], this.adBoards[1], this.adBoards[2], this.adBoards[3]);
  },
  refreshAds: function(home, away){
    var cv = this._mkCanvas(1024, 64), g = cv.getContext("2d");
    g.fillStyle = "#0e1420"; g.fillRect(0,0,1024,64);
    g.fillStyle = "#ffcf3d"; g.font = "bold 30px 'Segoe UI',Arial";
    var txt = ("  SUPER PILKA '98  ★  " + home + "  —  " + away + "  ★  JEDEN PLIK HTML  ★").repeat(2);
    g.fillText(txt.slice(0, 120), 8, 44);
    g.fillStyle = "#e8352a"; g.fillRect(0,0,1024,4); g.fillRect(0,60,1024,4);
    if(this.adMat.map) this.adMat.map.dispose();
    this.adMat.map = this._tex(cv, 4, 1);
    this.adMat.needsUpdate = true;
  },

  _markers: function(){
    /* wskaźnik gracza P1 / P2: pierścień + strzałka nad głową */
    function mkMark(color){
      var grp = new THREE.Group();
      var ring = new THREE.Mesh(new THREE.RingGeometry(0.46, 0.60, 28),
        new THREE.MeshBasicMaterial({ color: color, transparent:true, opacity:0.9, side:THREE.DoubleSide, depthWrite:false }));
      ring.rotation.x = -Math.PI/2; ring.position.y = 0.03;
      var arrow = new THREE.Mesh(new THREE.ConeGeometry(0.16, 0.34, 10),
        new THREE.MeshBasicMaterial({ color: color, depthWrite:false }));
      arrow.rotation.x = Math.PI; arrow.position.y = 2.35;
      grp.add(ring, arrow);
      grp.userData = { ring: ring, arrow: arrow };
      grp.visible = false;
      return grp;
    }
    this.m1 = mkMark(0xffd23d); this.m2 = mkMark(0x3ddcff);
    this.gFx.add(this.m1, this.m2);
    /* piłka: cień „kropelka” */
    var blobCv = this._mkCanvas(64,64), bg = blobCv.getContext("2d");
    var gr = bg.createRadialGradient(32,32,4,32,32,30);
    gr.addColorStop(0,"rgba(0,0,0,0.5)"); gr.addColorStop(1,"rgba(0,0,0,0)");
    bg.fillStyle = gr; bg.fillRect(0,0,64,64);
    this.blob = new THREE.Mesh(new THREE.PlaneGeometry(1,1),
      new THREE.MeshBasicMaterial({ map:new THREE.CanvasTexture(blobCv), transparent:true, depthWrite:false }));
    this.blob.rotation.x = -Math.PI/2;
    this.gFx.add(this.blob);
    /* strzałka namieru przy wznowieniach */
    this.aimArrow = new THREE.Mesh(new THREE.PlaneGeometry(3.2, 0.14),
      new THREE.MeshBasicMaterial({ color:0xffffff, transparent:true, opacity:0.55, depthWrite:false }));
    this.aimArrow.rotation.x = -Math.PI/2;
    this.aimArrow.geometry.translate(1.6, 0, 0);
    this.aimArrow.visible = false;
    this.gFx.add(this.aimArrow);
  },

  /* ---------- zawodnicy ---------- */
  _numTex: function(num, dark){
    var cv = this._mkCanvas(64, 80), g = cv.getContext("2d");
    g.fillStyle = dark ? "#1a1a22" : "#ffffff";
    g.font = "bold 58px 'Segoe UI',Arial";
    g.textAlign = "center"; g.textBaseline = "middle";
    g.fillText(String(num), 32, 42);
    return new THREE.CanvasTexture(cv);
  },
  makePlayer: function(team, isGk, num){
    var kit = this.kit[team];
    var shirt = isGk ? kit.gk : kit.shirt;
    var shorts = isGk ? kit.gkShorts : kit.shorts;
    var socks = isGk ? 0x20242c : kit.socks;
    var skins = [0xf0c8a0, 0xdca475, 0xa86a3d, 0x74462a];
    var hairs = [0x17120e, 0x3a2a18, 0x6e4f1f, 0xb08d5a, 0x0e0c0a];
    var skin = skins[(Math.random()*skins.length)|0];
    var hair = hairs[(Math.random()*hairs.length)|0];

    var grp = new THREE.Group();
    var shirtMat = new THREE.MeshLambertMaterial({ color: shirt });
    var shortsMat = new THREE.MeshLambertMaterial({ color: shorts });
    var sockMat = new THREE.MeshLambertMaterial({ color: socks });
    var skinMat = new THREE.MeshLambertMaterial({ color: skin });

    function leg(sx){
      var pivot = new THREE.Group();
      pivot.position.set(sx*0.095, 0.58, 0);
      var thigh = new THREE.Mesh(new THREE.CylinderGeometry(0.062, 0.05, 0.26, 8), skinMat);
      thigh.position.y = -0.14;
      var sock = new THREE.Mesh(new THREE.CylinderGeometry(0.055, 0.05, 0.24, 8), sockMat);
      sock.position.y = -0.38;
      var boot = new THREE.Mesh(new THREE.BoxGeometry(0.11, 0.07, 0.2), new THREE.MeshLambertMaterial({ color:0x14141a }));
      boot.position.set(0, -0.52, 0.04);
      pivot.add(thigh, sock, boot);
      return pivot;
    }
    var legL = leg(-1), legR = leg(1);
    var body = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.5, 0.24), shirtMat);
    body.position.y = 1.02;
    var hip = new THREE.Mesh(new THREE.BoxGeometry(0.36, 0.2, 0.22), shortsMat);
    hip.position.y = 0.68;
    var num = new THREE.Mesh(new THREE.PlaneGeometry(0.26, 0.32),
      new THREE.MeshBasicMaterial({ map: this._numTex(num, isGk), transparent:true }));
    num.position.set(0, 1.06, -0.125); num.rotation.y = Math.PI;
    function arm(sx){
      var pivot = new THREE.Group();
      pivot.position.set(sx*0.26, 1.2, 0);
      var a = new THREE.Mesh(new THREE.CylinderGeometry(0.048, 0.04, 0.4, 8), shirtMat);
      a.position.y = -0.18;
      var hand = new THREE.Mesh(new THREE.SphereGeometry(0.05, 6, 6), skinMat);
      hand.position.y = -0.4;
      pivot.add(a, hand);
      return pivot;
    }
    var armL = arm(-1), armR = arm(1);
    var head = new THREE.Mesh(new THREE.SphereGeometry(0.125, 10, 8), skinMat);
    head.position.y = 1.44;
    var hairMesh = new THREE.Mesh(new THREE.SphereGeometry(0.132, 10, 8, 0, Math.PI*2, 0, Math.PI/2.1),
      new THREE.MeshLambertMaterial({ color: hair }));
    hairMesh.position.y = 1.46;

    grp.add(legL, legR, body, hip, num, armL, armR, head, hairMesh);
    grp.traverse(function(o){ if(o.isMesh){ o.castShadow = true; } });
    grp.userData = { legL:legL, legR:legR, armL:armL, armR:armR, phase: Math.random()*6.28 };
    this.gPlayers.add(grp);
    return grp;
  },
  removePlayer: function(mesh){
    this.gPlayers.remove(mesh);
    mesh.traverse(function(o){ if(o.isMesh && o.geometry) o.geometry.dispose(); });
  },

  _makeBall: function(){
    var cv = this._mkCanvas(128, 64), g = cv.getContext("2d");
    g.fillStyle = "#fafafa"; g.fillRect(0,0,128,64);
    g.fillStyle = "#1c1c22";
    for(var i=0;i<10;i++){
      g.beginPath();
      g.arc(8+(i%5)*26, 14+(i/5|0)*32, 7, 0, 6.29); g.fill();
    }
    var tex = this._tex(cv, 2, 1);
    var m = new THREE.Mesh(new THREE.SphereGeometry(0.15, 14, 12),
      new THREE.MeshPhongMaterial({ map: tex, shininess: 40 }));
    m.castShadow = true;
    return m;
  },

  /* animacja biegu zawodnika — styl '98: szerokie wymachy, pochylenie, bujanie */
  animatePlayer: function(mesh, speed, dt, action, actionT){
    var u = mesh.userData;
    var rate = 4 + speed*1.9;
    u.phase += dt * rate * (speed > 0.3 ? 1 : 0.25);
    var s = Math.sin(u.phase) * Math.min(1, speed/4);
    var c = Math.cos(u.phase) * Math.min(1, speed/4);
    if(action === "slide"){
      mesh.rotation.x = -1.15;
      u.legL.rotation.x = -0.5; u.legR.rotation.x = -0.1;
      u.armL.rotation.x = 2.6; u.armR.rotation.x = 0.6;
    } else if(action === "kick"){
      /* dwie fazy: zamach, potem wybij nogi */
      mesh.rotation.x = 0.06;
      var t = actionT || 0;
      if(t > 0.12){
        u.legR.rotation.x = 0.85; u.legL.rotation.x = -0.18;
        u.armL.rotation.x = 0.35; u.armR.rotation.x = -0.45;
      } else {
        u.legR.rotation.x = -1.35; u.legL.rotation.x = 0.42;
        u.armL.rotation.x = -0.7; u.armR.rotation.x = 0.55;
      }
    } else if(action === "fallen"){
      mesh.rotation.x = -1.5;
      u.legL.rotation.x = 0.3; u.legR.rotation.x = -0.2;
      u.armL.rotation.x = 0.4; u.armR.rotation.x = -0.4;
    } else if(action === "celebrate"){
      mesh.rotation.x = 0;
      var wig = Math.sin(performance.now()/110)*0.2;
      u.legL.rotation.x = 0; u.legR.rotation.x = 0;
      u.armL.rotation.x = Math.PI*0.85 + wig; u.armR.rotation.x = -Math.PI*0.85 - wig;
    } else {
      mesh.rotation.x = -Math.min(0.11, speed*0.013);   /* pochylenie w biegu */
      u.legL.rotation.x = s*1.05; u.legR.rotation.x = -s*1.05;
      u.armL.rotation.x = -s*0.95; u.armR.rotation.x = s*0.95;
      if(speed <= 0.3){
        /* spokojny oddech na stojąco */
        var br = Math.sin(u.phase*0.8);
        u.armL.rotation.x = -0.14 + br*0.07; u.armR.rotation.x = 0.14 - br*0.07;
        u.legL.rotation.x = 0; u.legR.rotation.x = 0;
        mesh.position.y += br*0.012;
      }
      /* bujanie biegu */
      mesh.position.y += Math.abs(Math.sin(u.phase))*0.05*Math.min(1, speed/5);
    }
  },

  /* puls trybun: szum tekstury i podskok przy golu / ekscytacji */
  crowdPulse: 0,
  tick: function(dt){
    if(!this.crowdTex) return;
    var p = this.crowdPulse || 0;
    this.crowdTex.offset.y = (this.crowdTex.offset.y + dt*(0.010 + p*0.10)) % 1;
    if(this.crowdPlanes){
      var hop = Math.sin(performance.now()/85)*0.26*p;
      for(var i=0;i<this.crowdPlanes.length;i++) this.crowdPlanes[i].position.y = 11 + hop;
    }
  }
};
