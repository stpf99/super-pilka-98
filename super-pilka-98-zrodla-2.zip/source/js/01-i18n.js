/* ============================================================
   SUPER PILKA '98 · 01-i18n.js — teksty PL/EN
   ============================================================ */
var I18N = {
pl: {
  /* menu */
  s_match:"Mecz", s_look:"Wygląd", s_teams:"Drużyny",
  s_mode:"Tryb gry", m0:"1 gracz vs komputer", m1:"2 graczy", m2:"Oglądaj (AI vs AI)",
  s_half:"Czas połowy", s_diff:"Poziom AI", s_ref:"Sędzia (faule)",
  s_cam:"Kamera", s_gfx:"Jakość grafiki", s_sfx:"Dźwięk",
  s_lang:"Język", s_home:"Gospodarz", s_away:"Gość",
  d0:"Łatwy", d1:"Normalny", d2:"Trudny",
  r0:"Łagodny", r1:"Normalny", r2:"Surowy",
  c0:"TV boczna", c1:"Góra '98", c2:"Za piłką",
  q0:"Niska", q1:"Średnia", q2:"Wysoka",
  off0:"Wyłącz", on06:"60%", on1:"100%",
  b_play:"ROZPOCZNIJ MECZ", b_help:"STEROWANIE", b_back:"WRÓĆ",
  note_pads:"Podłącz pady i naciśnij dowolny przycisk, aby je wykryć. Bez padów: gracz 1 — lewa strona klawiatury, gracz 2 — strzałki.",
  menuSub:"Mecz 11 na 11 · dwa pady · pełne zasady",
  /* pomoc */
  h_controls:"Sterowanie", h_p1:"GRACZ 1 — klawiatura", h_p2:"GRACZ 2 — klawiatura (bez pada 2)",
  h_pad1:"PAD 1 — GRACZ 1", h_pad2:"PAD 2 — GRACZ 2", h_pad:"PAD (standard Xbox/PS)",
  h_note:"Kierunek podań i strzałów = lewa gałka / kierunek biegu. Przytrzymaj przycisk dla mocniejszego uderzenia.",
  h_note_kb:"Gracz 1 bez pada: WASD + K L J I O. Gracz 2 bez pada 2: strzałki + , . / M N.",
  /* pauza / koniec */
  p_title:"Pauza", p_resume:"WZNÓW", p_set:"USTAWIENIA", p_restart:"RESTART MECZU",
  p_quit:"MENU GŁÓWNE", p_note:"ESC lub START — pauza. Zmiany ustawień działają od razu.",
  e_full:"Koniec meczu", e_re:"REWANŻ", e_menu:"MENU", e_win:"WYGRYWA", e_draw:"REMIS",
  /* HUD / restarty */
  k1p:"1P", k2p:"2P", k1p_done:"KONIEC", pen:"karne",
  rst_kick:"RZUT OD ŚRODKA", rst_corner:"RZUT ROŻNY", rst_throw:"AUT",
  rst_goalkick:"WYKOP OD BRAMKI", rst_free:"RZUT WOLNY", rst_pen:"RZUT KARNY",
  hint_kick:"{T}: wciśnij A / K — podanie od środka",
  hint_generic:"{T}: skieruj i wciśnij A (podanie) lub B (strzał)",
  hint_throw:"{T}: skieruj i wciśnij A — wrzut z autu",
  hint_pen:"Skieruj strzał gałką, przytrzymaj B i puść!",
  hint_cpu:"Przeciwnik (AI) wykonuje wznowienie…",
  hint_pause:"ESC — pauza · C — zmiana kamery",
  /* komentator */
  c_goal:["GOOOOL! Świetne uderzenie!","GOOOL! Trybuna szaleje!","GOL! Idealne podanie i wykończenie!","GOOOL! Co dla bramkarza sceny!"],
  c_foul:["Faul! Sędzia nic nie pomylił.","Przerwanie gry — faul.","Ostre wejście! Faul."],
  c_yellow:["Żółta kartka!","Byle jak weszło — żółta kartka.","Zagrożenie zdrowia? Sędzia pokazuje żółty."],
  c_red:["CZERWONA KARTKA! Gra w dziesiątkę!","Feralne wejście — czerwona kartka!","Sędzia nie miał wątpliwości — czerwona!"],
  c_off:["Spalony! Linia była czujna.","Spalony! Chorągiewka podniesiona.","Spalony — chwilę za wcześnie ruszył."],
  c_corner:["Rzut rożny!","Piłka za bramką — rożny."],
  c_throw:["Aut dla {T}.","Wrzut z autu dla {T}."],
  c_gk:["Wykop od bramki dla {T}.","Piłka wybita — od bramki {T}."],
  c_free:["Rzut wolny dla {T}.","Przerwanie — wolny dla {T}."],
  c_pen:["RZUT KARNY! Sprawdzimy z wagi awantury!","Karny! Decyzja bez wahania!"],
  c_half:["Koniec połowy."], c_full:["Koniec meczu!"],
  c_kick:["Zaczynamy!","Piłka w grze — do dzieła!"],
  c_save:["Świetna obrona bramkarza!","Paruje! Co dla obrony!"],
  c_post:["Rama! Piłka trafia w poprzeczkę!","Żelazna rama!"],
  c_header:"Główka!",
  c_miss:["Nad poprzeczką!","Próba niecelna."],
  h_m_move:"Bieg", h_m_pass:"Podanie", h_m_shoot:"Strzał", h_m_tackle:"Wślizg / odbiór",
  h_m_through:"Podanie prosto", h_m_sprint:"Sprint", h_m_switch:"Zmiana zawodnika",
  h_m_cam:"Zmiana kamery", h_m_pause:"Pauza",
  b_yellow:"ŻÓŁTA KARTKA", b_red:"CZERWONA KARTKA",
  /* statystyki */
  st_poss:"Posiadanie", st_shots:"Strzały", st_target:"Strzały celne",
  st_corr:"Rożne", st_fouls:"Faule", st_yel:"Żółte kartki", st_red:"Czerwone kartki",
  st_pass:"Podania celne",
  lag:"klatek/s: {V} · pad1:{A} pad2:{B}"
},
en: {
  s_match:"Match", s_look:"Visuals", s_teams:"Teams",
  s_mode:"Game mode", m0:"1 player vs CPU", m1:"2 players", m2:"Watch (AI vs AI)",
  s_half:"Half length", s_diff:"AI level", s_ref:"Referee (fouls)",
  s_cam:"Camera", s_gfx:"Graphics quality", s_sfx:"Sound",
  s_lang:"Language", s_home:"Home", s_away:"Away",
  d0:"Easy", d1:"Normal", d2:"Hard",
  r0:"Lenient", r1:"Normal", r2:"Strict",
  c0:"TV side", c1:"Top '98", c2:"Behind ball",
  q0:"Low", q1:"Medium", q2:"High",
  off0:"Off", on06:"60%", on1:"100%",
  b_play:"START MATCH", b_help:"CONTROLS", b_back:"BACK",
  note_pads:"Plug in gamepads and press any button to detect them. Without pads: player 1 — left keyboard, player 2 — arrow keys.",
  menuSub:"11 vs 11 match · two gamepads · full rules",
  h_controls:"Controls", h_p1:"PLAYER 1 — keyboard", h_p2:"PLAYER 2 — keyboard (if no pad 2)",
  h_pad1:"PAD 1 — PLAYER 1", h_pad2:"PAD 2 — PLAYER 2", h_pad:"GAMEPAD (Xbox/PS layout)",
  h_note:"Pass/shot direction = left stick / running direction. Hold a button for a stronger kick.",
  h_note_kb:"Player 1 without a pad: WASD + K L J I O. Player 2 without pad 2: arrows + , . / M N keys.",
  p_title:"Paused", p_resume:"RESUME", p_set:"SETTINGS", p_restart:"RESTART MATCH",
  p_quit:"MAIN MENU", p_note:"ESC or START — pause. Settings apply immediately.",
  e_full:"Full time", e_re:"REMATCH", e_menu:"MENU", e_win:"WINS", e_draw:"DRAW",
  k1p:"1H", k2p:"2H", k1p_done:"FT", pen:"pen",
  rst_kick:"KICK-OFF", rst_corner:"CORNER", rst_throw:"THROW-IN",
  rst_goalkick:"GOAL KICK", rst_free:"FREE KICK", rst_pen:"PENALTY",
  hint_kick:"{T}: press A / K — kick-off pass",
  hint_generic:"{T}: aim and press A (pass) or B (shot)",
  hint_throw:"{T}: aim and press A — throw-in",
  hint_pen:"Aim with the stick, hold B and release!",
  hint_cpu:"The opponent (AI) is taking the restart…",
  hint_pause:"ESC — pause · C — change camera",
  c_goal:["GOOOAL! What a strike!","GOAL! The stands erupt!","GOL! Perfect pass and finish!","GOAL! Brilliant play!"],
  c_foul:["Foul! The referee spotted it.","Play stopped — foul.","Rough tackle! Foul."],
  c_yellow:["Yellow card!","Careless challenge — yellow card.","The referee shows yellow."],
  c_red:["RED CARD! Down to ten men!","Fateful tackle — red card!","No doubt from the referee — red!"],
  c_off:["Offside! The line was alert.","Offside! Flag is up.","Offside — moved a moment too early."],
  c_corner:["Corner kick!","Ball behind the goal — corner."],
  c_throw:["Throw-in for {T}.","Throw-in for {T}."],
  c_gk:["Goal kick for {T}.","Ball cleared — goal kick {T}."],
  c_free:["Free kick for {T}.","Stopped — free kick for {T}."],
  c_pen:["PENALTY! A big decision!","Penalty! No hesitation!"],
  c_half:["End of the half."], c_full:["Full time!"],
  c_kick:["We're underway!","Ball in play — let's go!"],
  c_save:["Brilliant save by the keeper!","He parries it away!"],
  c_post:["The woodwork! Off the crossbar!","Iron frame saves the day!"],
  c_header:"Header!",
  c_miss:["Over the bar!","Off target."],
  h_m_move:"Run", h_m_pass:"Pass", h_m_shoot:"Shoot", h_m_tackle:"Slide / tackle",
  h_m_through:"Through ball", h_m_sprint:"Sprint", h_m_switch:"Switch player",
  h_m_cam:"Change camera", h_m_pause:"Pause",
  b_yellow:"YELLOW CARD", b_red:"RED CARD",
  st_poss:"Possession", st_shots:"Shots", st_target:"Shots on target",
  st_corr:"Corners", st_fouls:"Fouls", st_yel:"Yellow cards", st_red:"Red cards",
  st_pass:"Completed passes",
  lag:"fps: {V} · pad1:{A} pad2:{B}"
}};
var I18N_cur = "pl";
function t(k){ var d=I18N[I18N_cur]||I18N.pl; return (d[k]!==undefined)?d[k]:(I18N.pl[k]!==undefined?I18N.pl[k]:k); }
function tPick(k){ var a=t(k); return a[Math.floor(Math.random()*a.length)]; }
function applyI18n(){
  document.querySelectorAll("[data-i18n]").forEach(function(el){
    var v=I18N[I18N_cur]&&I18N[I18N_cur][el.getAttribute("data-i18n")];
    if(v!==undefined) el.textContent=v;
  });
  document.documentElement.lang = I18N_cur;
  if(typeof HUD !== "undefined" && HUD.buildHelp) HUD.buildHelp();
}
