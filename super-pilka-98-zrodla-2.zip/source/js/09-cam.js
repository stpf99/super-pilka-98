/* ============================================================
   SUPER PILKA '98 · 09-cam.js — trzy kamery + najazdy (styl '98)
   0: TV boczna · 1: Góra '98 · 2: Za piłką
   • TV: kadr adaptacyjny — przy bliskiej bandzie kamera cofa się,
     unosi i rozszerza FOV, więc piłka (aut/wrzut) zawsze w kadrze.
   • Cięcia reżysera: kick-off (intro zza wykonawcy), gol (zbliżenie
     z powolnym najazdem), karny (najazd podczas celowania).
   ============================================================ */
var CAM = {
  pos: { x:0, y:30, z:52 },
  look: { x:0, y:0, z:0 },
  fov: 38,
  menuAngle: 0,
  modeNames: ["TV", "TOP", "BEHIND"],
  _last: null,

  setMode: function(m){ SET.cam = ((m%3)+3)%3; },

  update: function(dt, state){
    var b = SIM.ball;
    var des = { x:0, y:30, z:52 }, look = { x:0, y:0, z:0 }, fov = 38;
    var m = SET.cam|0;
    var snap = false;
    if(this._last !== state){
      /* twarde cięcie tylko w kluczowych momentach transmisji */
      snap = state==="kickoff" || state==="goal" || state==="penalty" ||
             (state==="play" && this._last==="kickoff");
      this._last = state;
    }

    if(state==="goal"){
      /* zbliżenie na strzelca + powolny najazd */
      var scorer = null;
      for(var i=0;i<SIM.players.length;i++)
        if(SIM.players[i].action==="celebrate"){ scorer = SIM.players[i]; break; }
      if(scorer){
        des = { x: scorer.pos.x - SIM.teams[scorer.team].dir*7, y: 4.5, z: scorer.pos.z + 9 };
        look = { x: scorer.pos.x, y: 1.2, z: scorer.pos.z };
        var el = Math.max(0, 3.4 - (RULES.celebT||0));
        fov = 45 - Math.min(10, el*4.2);
      } else { des = { x:0, y:22, z:44 }; look = { x:0, y:0.5, z:0 }; fov = 38; }
    }
    else if(state==="kickoff"){
      /* intro zza wykonawcy — jak w '98 */
      var tk = RULES.taker;
      if(tk){
        var dir = SIM.teams[RULES.restartTeam].dir;
        des = { x: tk.pos.x - dir*7.5, y: 5.2, z: tk.pos.z*0.6 + 3.6 };
        look = { x: tk.pos.x + dir*14, y: 0.9, z: tk.pos.z*0.5 };
        fov = 47;
      }
    }
    else if(state==="menu"){
      this.menuAngle += dt*0.12;
      des = { x: Math.sin(this.menuAngle)*88, y: 34, z: Math.cos(this.menuAngle)*88 };
      look = { x:0, y:2, z:0 };
      fov = 42;
    }
    else if(m===0){ /* TV boczna — kadr jak transmisja '98 zza trybuny:
                       obie linie boczne zawsze w kadrze, piłka przy aucie widoczna */
      var tx = Math.max(-44, Math.min(44, b.x*0.85));
      var lx = Math.max(-46, Math.min(46, b.x));
      des = { x: tx, y: 40, z: 60 };
      look = { x: lx, y: 0, z: 14 };      /* stały pochyłony kąt — bez „wypadania” boków */
      fov = 44 - Math.min(3, Math.abs(b.x)/HL*4)  /* lekki najazd przy bramkach */
              + Math.min(9, Math.max(0, b.y-4)*1.4);  /* odzoom za lotem piłki */
    }
    else if(m===1){ /* Góra '98 */
      des = { x: Math.max(-14, Math.min(14, b.x*0.28)), y: 94, z: Math.max(-8, Math.min(8, b.z*0.24)) + 12 };
      look = { x: Math.max(-26, Math.min(26, b.x*0.5)), y: 0, z: Math.max(-16, Math.min(16, b.z*0.42)) };
      fov = 45;
    }
    else { /* Za piłką */
      var d = SIM.teams[0].dir;
      des = { x: b.x - d*11, y: 7.5 + Math.max(0, b.z)*0.16, z: Math.max(-32, Math.min(32, b.z*0.75)) };
      look = { x: b.x + d*15, y: 0.8, z: Math.max(-31, Math.min(31, b.z*0.9)) };
      fov = 52;
    }
    if(state==="penalty"){
      des = { x: b.x - SIM.teams[RULES.restartTeam].dir*10, y: 6.5, z: 4 };
      look = { x: b.x + SIM.teams[RULES.restartTeam].dir*8, y: 1, z: 0 };
      fov = 46 - Math.min(7, RULES.stateT*2.0);   /* najazd podczas celowania */
    }

    if(snap){
      this.pos.x=des.x; this.pos.y=des.y; this.pos.z=des.z;
      this.look.x=look.x; this.look.y=look.y; this.look.z=look.z;
      this.fov=fov;
    } else {
      var kp = Math.min(1, dt*3.4), kl = Math.min(1, dt*5.2), kf = Math.min(1, dt*3);
      this.pos.x += (des.x-this.pos.x)*kp;
      this.pos.y += (des.y-this.pos.y)*kp;
      this.pos.z += (des.z-this.pos.z)*kp;
      this.look.x += (look.x-this.look.x)*kl;
      this.look.y += (look.y-this.look.y)*kl;
      this.look.z += (look.z-this.look.z)*kl;
      this.fov += (fov-this.fov)*kf;
    }

    WORLD.cam.position.set(this.pos.x, this.pos.y, this.pos.z);
    WORLD.cam.lookAt(this.look.x, this.look.y, this.look.z);
    if(Math.abs(WORLD.cam.fov - this.fov) > 0.05){
      WORLD.cam.fov = this.fov;
      WORLD.cam.updateProjectionMatrix();
    }
  }
};
