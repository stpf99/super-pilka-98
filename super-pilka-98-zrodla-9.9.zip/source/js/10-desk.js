/* Ekran przedmeczowy i tablica taktyczna. */
var DESK = {
  page:"teams", editingMatch:false,
  select: function(page){
    this.page=page;
    document.querySelectorAll("[data-page]").forEach(function(button){
      var selected = button.dataset.page===page;
      button.classList.toggle("on",selected);
      button.setAttribute("aria-pressed",String(selected));
      document.getElementById("page-"+button.dataset.page).hidden=!selected;
    });
  },
  editing: function(on){
    this.editingMatch=on;
    document.querySelectorAll("#segMode button,#segHalf button,#inHome,#inAway").forEach(function(control){ control.disabled=on; });
    this.refresh();
  },
  init: function(){
    document.querySelector(".tabs").addEventListener("click",function(e){
      var button=e.target.closest("[data-page]");
      if(button){ DESK.select(button.dataset.page); UI_click(); }
    });
    this.select("teams"); this.refresh();
  },
  refresh: function(){
    document.getElementById("playText").textContent=t(this.editingMatch?"p_resume":"b_play");
    document.getElementById("summaryMode").textContent=t("mode"+SET.mode);
    document.getElementById("summaryRules").textContent="2 × "+SET.half/60+" min  ·  "+t("d"+SET.diff);
    document.getElementById("lightName").textContent=t("n"+SET.night);
    ["H","A"].forEach(function(side,team){
      var name=team===0?SET.home:SET.away;
      document.getElementById("in"+(team===0?"Home":"Away")).setAttribute("aria-label",t(team===0?"s_home":"s_away"));
      document.getElementById("tName"+side+"T").textContent=name;
      document.getElementById("plan"+side).textContent=LINEUP.formation(team)+"   ·   "+t("plan_"+LINEUP.tactic(team));
      SHOWROOM.portrait(document.getElementById("kit"+side),team);
      DESK.pitch(document.getElementById("formPitch"+side),team);
    });
  },
  pitch: function(canvas,team){
    var g=canvas.getContext("2d"), w=canvas.width,h=canvas.height;
    g.clearRect(0,0,w,h); g.fillStyle="#163e33"; g.fillRect(0,0,w,h);
    var x=12,y=12,pw=w-24,ph=h-24;
    g.lineWidth=2; g.strokeStyle="#b5d6bf65"; g.strokeRect(x,y,pw,ph);
    g.beginPath(); g.moveTo(w/2,y);g.lineTo(w/2,y+ph);g.stroke();
    g.beginPath();g.arc(w/2,h/2,ph*.15,0,2*Math.PI);g.stroke();
    [x,x+pw-41].forEach(function(left){g.strokeRect(left,h*.28,41,h*.44);});
    var coords=LINEUP.forms[LINEUP.formation(team)];
    // Rozciągnięcie linii pokazuje nominalne ustawienie przed przesuwaniem za piłką.
    var rows=[-50].concat(Array.from(new Set(coords.slice(1).map(function(p,i){return LINEUP.roles[LINEUP.formation(team)][i+1]==="DF"?-32:p[0];}))).sort(function(a,b){return a-b;}));
    coords.forEach(function(p,i){
      var r=LINEUP.roles[LINEUP.formation(team)][i], lane=r==="DF"?-32:p[0];
      var px=x+15+(pw-30)*rows.indexOf(lane)/(rows.length-1);
      var py=h/2+p[1]*ph/62;
      g.beginPath(); g.arc(px,py,9,0,Math.PI*2);
      g.fillStyle=i===0?"#dcff70":team===0?"#fff2df":"#81baff";g.fill();
      g.fillStyle="#172719";g.textAlign="center";g.textBaseline="middle";g.font="bold 11px Arial";g.fillText(LINEUP.numbers[i],px,py+.5);
    });
  }
};
