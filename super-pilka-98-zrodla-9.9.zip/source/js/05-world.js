/* ============================================================
   SUPER PIŁKA '98 · 05-world.js — scena Three.js, stadion, zawodnicy
   Współrzędne: X wzdłuż boiska (±52.5), Z szerokość (±34), Y w górę.
   ============================================================ */
var PL = 105, PW = 68, HL = 52.5, HW = 34;          // wymiary boiska
var GOAL_W = 7.32, GOAL_H = 2.44, GK_R = 0.06;      // bramka

var WORLD = {
  renderer: null, scene: null, cam: null,
  gPlayers: null, gBall: null, gFx: null, gLines: null,
  kit: null, ball: null, blob: null, aimArrow: null,
  marks: [], m1: null, m2: null,

  init: function(canvas){
    this.renderer = new THREE.WebGLRenderer({ canvas: canvas, antialias: true, powerPreference:"high-performance" });
    this.renderer.outputEncoding = THREE.sRGBEncoding;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.08;
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x0a1422);
    this.scene.fog = new THREE.Fog(0x0a1422, 150, 460);

    this.cam = new THREE.PerspectiveCamera(38, innerWidth/innerHeight, 0.5, 700);
    this.cam.position.set(0, 30, 52);

    this.gLines = new THREE.Group(); this.gPlayers = new THREE.Group();
    this.gBall = new THREE.Group(); this.gFx = new THREE.Group();
    this.scene.add(this.gLines, this.gPlayers, this.gBall, this.gFx);
    /* stroje muszą być zdefiniowane PRZED budową sędziów/ławek (recolor) */
    this.kit = [
      { shirt:0xf5f5f2, shorts:0xd21f2b, socks:0xd21f2b, gk:0xe8a11c, gkShorts:0x20242c, tag:0xe8352a },
      { shirt:0x2456e0, shorts:0xf5f5f2, socks:0x2456e0, gk:0x23b85c, gkShorts:0x20242c, tag:0x2a6df0 }
    ];

    this._lights();
    this._sky();
    PITCH.grass(this);
    this._fieldLines();
    PITCH.goals(this);
    STADIUM.init(this);
    this._masts();
    this._flags();
    this._staff();
    this._benches();
    this._telebims();
    this._ads();
    this._markers();
    this.setNight(!SET || SET.night !== 0);  
    this.ball = PITCH.ball();
    this.gBall.add(this.ball);
    this.quality();
  },

  quality: function(){
    var q = SET.q|0;
    var dpr = window.devicePixelRatio || 1;
    if(q===0){ this.renderer.setPixelRatio(Math.min(dpr,1)); this.renderer.shadowMap.enabled=false; }
    else if(q===1){ this.renderer.setPixelRatio(Math.min(dpr,1.5)); this.renderer.shadowMap.enabled=true;
      if(this._sun) this._sun.shadow.mapSize.set(1024,1024); }
    else { this.renderer.setPixelRatio(Math.min(dpr,2)); this.renderer.shadowMap.enabled=true;
      if(this._sun) this._sun.shadow.mapSize.set(2048,2048); }
    if(this._sun){ this._sun.castShadow = this.renderer.shadowMap.enabled;
      if(this._sun.shadow.map){ this._sun.shadow.map.dispose(); this._sun.shadow.map = null; } }
    STADIUM.quality(q);
    if(this.teleLiveMat) this._teleRTEnsure();
    this.renderer.setSize(innerWidth, innerHeight, false);
    this.cam.aspect = innerWidth/innerHeight; this.cam.updateProjectionMatrix();
  },
  resize: function(){
    this.renderer.setSize(innerWidth, innerHeight, false);
    this.cam.aspect = innerWidth/innerHeight; this.cam.updateProjectionMatrix();
  },

  /* ---------- światła i niebo ---------- */
  _lights: function(){
    this.hemi = new THREE.HemisphereLight(0x9db4d6, 0x1c2a1a, 0.85);
    this.scene.add(this.hemi);
    var sun = new THREE.DirectionalLight(0xfff1d0, 1.15);
    sun.position.set(58, 61, 36);
    sun.castShadow = true;
    sun.shadow.mapSize.set(2048, 2048);
    sun.shadow.camera.left = -78; sun.shadow.camera.right = 78;
    sun.shadow.camera.top = 60; sun.shadow.camera.bottom = -60;
    sun.shadow.camera.near = 10; sun.shadow.camera.far = 220;
    sun.shadow.bias = -0.0006;
    this.scene.add(sun);
    this._sun = sun;
    /* 4 reflektory z masztów — realne światła sceny (cień liczy tylko jedno światło) */
    this.spots = [];
    for(var sx=-1; sx<=1; sx+=2) for(var sz=-1; sz<=1; sz+=2){
      var sp = new THREE.SpotLight(0xdfeaff, 0, 340, 0.64, 0.5, 1.1);
      sp.position.set(sx*66, 30.5, sz*48);
      sp.target.position.set(sx*24, 0, sz*16);
      sp.castShadow = false;
      this.scene.add(sp);
      this.scene.add(sp.target);
      this.spots.push(sp);
    }
  },
  _sky: function(){
    this.skyGradient=new THREE.ShaderMaterial({side:THREE.BackSide,depthWrite:false,fog:false,
      uniforms:{nightSky:{value:0}},vertexShader:"varying vec3 skyDir; void main(){skyDir=position;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0);}",
      fragmentShader:[
        "varying vec3 skyDir; uniform float nightSky;",
        "void main(){vec3 d=normalize(skyDir);float v=smoothstep(-.05,.75,d.y);",
        "vec3 day=mix(vec3(.57,.66,.65),vec3(.085,.24,.48),v);",
        "float haze=exp(-9.0*abs(d.y-.05));day+=vec3(.12,.064,.018)*haze;",
        "vec3 night=mix(vec3(.040,.064,.092),vec3(.002,.006,.021),smoothstep(-.08,.48,d.y));",
        "gl_FragColor=vec4(mix(day,night,nightSky),1.0);","#include <encodings_fragment>","}"].join("\n")});
    var dome=new THREE.Mesh(new THREE.SphereGeometry(420,36,16),this.skyGradient);dome.renderOrder=-50;this.scene.add(dome);
    var n = 260, pos = new Float32Array(n*3);
    for(var i=0;i<n;i++){
      var a = Math.random()*Math.PI*2, r = 300 + Math.random()*60;
      var y = 30 + Math.random()*220;
      pos[i*3] = Math.cos(a)*r; pos[i*3+1] = y; pos[i*3+2] = Math.sin(a)*r;
    }
    var g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.BufferAttribute(pos,3));
    var m = new THREE.PointsMaterial({ color:0xcfe0ff, size:1.6, sizeAttenuation:false, transparent:true, opacity:0.8 });
    this.stars = new THREE.Points(g, m);
    this.scene.add(this.stars);
  },

  /* dzień / noc pod reflektorami */
  setNight: function(n){
    this.night = !!n;
    var bg = this.night ? 0x05080f : 0x4a7ab5;
    this.scene.background = new THREE.Color(bg);
    this.scene.fog = new THREE.Fog(this.night ? 0x05080f : 0x7fa3c8, this.night ? 130 : 170, this.night ? 430 : 560);
    if(this.hemi){
      this.hemi.intensity = this.night ? 0.90 : 0.95;
      this.hemi.color.setHex(this.night ? 0xc2d9eb : 0xceebf4);
      this.hemi.groundColor.setHex(this.night ? 0x0c1210 : 0x1c2a1a);
    }
    if(this._sun){
      this._sun.intensity = this.night ? 1.02 : 1.08;
      this._sun.color.setHex(this.night ? 0xe5f1ff : 0xfff1d0);
    }
    if(this.spots) for(var i=0;i<this.spots.length;i++) this.spots[i].intensity = this.night ? 0.95 : 0;
    if(this.cones) for(var c=0;c<this.cones.length;c++) this.cones[c].visible = this.night;
    if(this.glows) for(var g2=0;g2<this.glows.length;g2++) this.glows[g2].material.opacity = this.night ? 0.48 : 0.07;
    if(this.stars) this.stars.visible = this.night;
    this.skyGradient.uniforms.nightSky.value=this.night?1:0;
    STADIUM.glassMat.map=STADIUM.glassMaps[this.night?1:0];
    STADIUM.eaves.color.setHex(this.night?0xffeed2:0xb5babe);
    this.lampFace.color.setHex(this.night?0xfff2d5:0xabb9bd);
    this.renderer.toneMappingExposure = this.night ? 1.12 : 1.0;
  },

  /* ---------- płaszczyzny pomocnicze ---------- */
  _mkCanvas: function(w,h){ var c=document.createElement("canvas"); c.width=w; c.height=h; return c; },
  _plane: function(w, h, mat, rx){
    var m = new THREE.Mesh(new THREE.PlaneGeometry(w, h), mat);
    m.rotation.x = rx!==undefined ? rx : -Math.PI/2;
    return m;
  },

  _line: function(w, l, x, z, rotY){
    var m = new THREE.Mesh(new THREE.PlaneGeometry(w, l),
      new THREE.MeshBasicMaterial({ color:0xf2f6ff }));
    m.rotation.x = -Math.PI/2;
    if(rotY) m.rotation.z = rotY;
    m.position.set(x, 0.02, z);
    this.gLines.add(m);
    return m;
  },
  _ring: function(rIn, rOut, x, z, tStart, tLen){
    var m = new THREE.Mesh(new THREE.RingGeometry(rIn, rOut, 48, 1, tStart||0, tLen||Math.PI*2),
      new THREE.MeshBasicMaterial({ color:0xf2f6ff, side:THREE.DoubleSide }));
    m.rotation.x = -Math.PI/2;
    m.position.set(x, 0.02, z);
    this.gLines.add(m);
    return m;
  },
  _spot: function(x, z){
    var m = new THREE.Mesh(new THREE.CircleGeometry(0.16, 16),
      new THREE.MeshBasicMaterial({ color:0xf2f6ff }));
    m.rotation.x = -Math.PI/2; m.position.set(x, 0.021, z);
    this.gLines.add(m);
  },
  _fieldLines: function(){
    var L = PL, W = PW;
    this._line(L+0.3, 0.13, 0,  HW); this._line(L+0.3, 0.13, 0, -HW);
    this._line(0.13, W+0.3,  HL, 0); this._line(0.13, W+0.3, -HL, 0);
    this._line(0.13, W, 0, 0);
    this._ring(9.09, 9.21, 0, 0);
    this._spot(0, 0);
    for(var s=-1; s<=1; s+=2){
      /* pole karne */
      this._line(0.13, 40.32, s*(HL-16.5), 0);
      this._line(16.5, 0.13, s*(HL-8.25),  20.16);
      this._line(16.5, 0.13, s*(HL-8.25), -20.16);
      /* pole bramkowe */
      this._line(0.13, 18.32, s*(HL-5.5), 0);
      this._line(5.5, 0.13, s*(HL-2.75),  9.16);
      this._line(5.5, 0.13, s*(HL-2.75), -9.16);
      /* punkty i łuki karne */
      this._spot(s*(HL-11), 0);
      var a = Math.acos(5.5/9.15);
      if(s<0) this._ring(9.09, 9.21, s*(HL-11), 0, -a, 2*a);
      else    this._ring(9.09, 9.21, s*(HL-11), 0, Math.PI-a, 2*a);
      /* łuki narożne — ćwiartki skierowane DO WNĄTRZA boiska
         (RingGeometry: lokalny +X → świat +X, lokalny +Y → świat −Z,
          więc kąt 0° = kierunek +X, kąt 90° = kierunek −Z) */
      if(s>0){
        this._ring(0.92, 1.04,  HL,  HW, Math.PI/2,   Math.PI/2);  /* w głąb: −X i −Z */
        this._ring(0.92, 1.04,  HL, -HW, Math.PI,     Math.PI/2);  /* −X i +Z */
        this._ring(0.92, 1.04, -HL,  HW, 0,           Math.PI/2);  /* +X i −Z */
        this._ring(0.92, 1.04, -HL, -HW, Math.PI*1.5, Math.PI/2);
      }
    }
  },

  _masts: function(){
    var lampMat=this.lampFace=new THREE.MeshBasicMaterial({color:0xfff2d5});
    var framing=new ArenaGeometry(),housings=[],lenses=[],flat=new THREE.BoxGeometry(1,1,1);
    var lampShell=new THREE.MeshLambertMaterial({color:0x384750});
    /* poświata lampy */
    var glowCv = this._mkCanvas(128, 128), gg = glowCv.getContext("2d");
    var gr = gg.createRadialGradient(64, 64, 4, 64, 64, 62);
    gr.addColorStop(0, "rgba(235,244,255,0.95)");
    gr.addColorStop(0.28, "rgba(190,214,255,0.42)");
    gr.addColorStop(1, "rgba(160,190,255,0)");
    gg.fillStyle = gr; gg.fillRect(0, 0, 128, 128);
    var glowTex = new THREE.CanvasTexture(glowCv);
    /* stożek światła (alphaMap: jasno przy głowie, zanika przy murawie) */
    var coneCv = this._mkCanvas(16, 256), cg = coneCv.getContext("2d");
    var lg = cg.createLinearGradient(0, 0, 0, 256);
    lg.addColorStop(0, "rgb(255,255,255)");
    lg.addColorStop(1, "rgb(0,0,0)");
    cg.fillStyle = lg; cg.fillRect(0, 0, 16, 256);
    var coneMat = new THREE.MeshBasicMaterial({ color:0x9fbfe8, transparent:true, opacity:0.035,
      alphaMap:new THREE.CanvasTexture(coneCv), blending:THREE.AdditiveBlending,
      depthWrite:false, side:THREE.DoubleSide, fog:false });
    this.cones = []; this.glows = [];
    var up = new THREE.Vector3(0, 1, 0);
    for(var sx=-1; sx<=1; sx+=2) for(var sz=-1; sz<=1; sz+=2){
      var hx = sx*66, hz = sz*48;
      // Trójkątny maszt kratownicowy i panel piętnastu osobnych opraw.
      var legs=[[-.61,-.46],[.61,-.46],[0,.62]];
      function foot(j,y){var v=legs[j],k=1-y*.014;return [hx+v[0]*k,y,hz+v[1]*k];}
      for(var j=0;j<3;j++){
        framing.rod(foot(j,0),foot(j,30.5),.104,.068,0x7e9097,7);
        for(var y=.3;y<30;y+=2.8){
          framing.rod(foot(j,y),foot((j+1)%3,Math.min(y+2.8,30.45)),.048,.048,0x647980,5);
          framing.rod(foot(j,y),foot((j+1)%3,y),.038,.038,0x8b9ba0,5);
        }
      }
      var head=new THREE.Object3D();head.position.set(hx,30.5,hz);head.lookAt(0,2,0);head.updateMatrix();
      function lampCell(x,y,z,w,h,d){return head.matrix.clone().multiply(new THREE.Matrix4().makeTranslation(x,y,z)).scale(new THREE.Vector3(w,h,d));}
      housings.push({matrix:lampCell(0,0,-.10,5.98,2.77,.26)});
      for(var lx=-2;lx<=2;lx++)for(var ly=-1;ly<=1;ly++){
        housings.push({matrix:lampCell(lx*1.15,ly*.86,.11,1.04,.76,.34)});
        lenses.push({matrix:lampCell(lx*1.15,ly*.86,.298,.80,.51,.051)});
      }
      var glow = new THREE.Sprite(new THREE.SpriteMaterial({ map:glowTex, color:0xffffff,
        blending:THREE.AdditiveBlending, depthWrite:false, transparent:true, opacity:0.9, fog:false }));
      glow.scale.set(8.0, 5.2, 1);
      glow.position.set(hx - sx*.62, 30.3, hz - sz*.45);
      this.scene.add(glow);
      this.glows.push(glow);
      /* stożek: od głowy masztu do ćwiartki boiska */
      var tp = new THREE.Vector3(sx*24, 0, sz*16);
      var hp = new THREE.Vector3(hx, 30.5, hz);
      var dir = tp.clone().sub(hp);          /* głowa -> murawa */
      var len = Math.max(20, dir.length());
      var cone = new THREE.Mesh(new THREE.CylinderGeometry(0.8, 13, 1, 20, 1, true), coneMat);
      cone.scale.y = len;
      cone.position.copy(hp).addScaledVector(dir, 0.5);
      cone.quaternion.setFromUnitVectors(up, dir.clone().negate().normalize());
      this.scene.add(cone);
      this.cones.push(cone);
    }
    this.scene.add(new THREE.Mesh(framing.build(false),new THREE.MeshLambertMaterial({vertexColors:true})));
    arenaInstances(flat,lampShell,housings,this.scene);arenaInstances(flat,lampMat,lenses,this.scene);
  },

  /* chorągiewki narożne */
  _flags: function(){
    this.flags = [];
    var poleMat = new THREE.MeshLambertMaterial({ color:0xdddddd });
    var flagTex=arenaTexture(64,64,function(g){
      g.fillStyle="#efab2c";g.fillRect(0,0,64,64);g.fillStyle="#b64833";g.fillRect(0,0,32,32);g.fillRect(32,32,32,32);
      g.fillStyle="#ead598";g.fillRect(0,0,4,64);
    });
    var flagMat=new THREE.MeshLambertMaterial({map:flagTex,side:THREE.DoubleSide});
    for(var sx=-1; sx<=1; sx+=2) for(var sz=-1; sz<=1; sz+=2){
      var pole = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.035, 1.6, 6), poleMat);
      pole.position.set(sx*HL, 0.8, sz*HW);
      var fg = new THREE.PlaneGeometry(0.55, 0.38, 7, 2);
      fg.translate(0.275, 0, 0);              /* kotwica na drzewcu */
      var flag = new THREE.Mesh(fg, flagMat);
      flag.position.set(sx*HL, 1.48, sz*HW);
      flag.userData.base = Math.random()*6.28;
      this.scene.add(pole, flag);
      this.flags.push(flag);
    }
  },

  /* ---------- sędziowie: główny + dwaj liniowi z chorągiewkami ---------- */
  _staff: function(){
    this.gStaff = new THREE.Group();
    this.scene.add(this.gStaff);
    var self = this;
    var refKit = { shirt:0xe7c539, shorts:0x17171f, socks:0x17171f };
    var linKit = { shirt:0xcdd93a, shorts:0x20242c, socks:0xcdd93a };
    function official(kit, flag){
      var g = self.makePlayer(0,false,0,self.gStaff,kit);
      if(flag){
        var fpole = new THREE.Mesh(new THREE.CylinderGeometry(0.014, 0.014, 0.55, 6),
          new THREE.MeshLambertMaterial({ color:0x1c1c22 }));
        fpole.position.set(0,-.28,.03);
        var fcloth = new THREE.Mesh(new THREE.BoxGeometry(0.20, 0.15, 0.012),
          new THREE.MeshBasicMaterial({ color:0xff6a2a, side:THREE.DoubleSide }));
        fcloth.position.set(0,-.48,.03);
        g.userData.limbs[1].hand.add(fpole, fcloth);
      }
      g.userData.pos = { x: 0, z: 0 };
      return g;
    }
    this.staff = {
      ref:  official(refKit, false),
      lins: [ official(linKit, true), official(linKit, true) ]
    };
    var card=new THREE.Mesh(new THREE.BoxGeometry(.110,.162,.012),new THREE.MeshBasicMaterial({color:0xffdf23}));
    card.position.set(.008,-.160,.018);card.visible=false;
    this.staff.ref.userData.limbs[1].hand.add(card);this.staff.card=card;
    this.staff.cardPoint=new THREE.Vector3();this.staff.cardFacing=new THREE.Quaternion();
    this.staff.ref.position.set(8, 0, 10);
    this.staff.ref.userData.pos = { x: 8, z: 10 };
    this.staff.lins[0].position.set(-8, 0,  HW + 1.15);
    this.staff.lins[0].userData.pos = { x: -8, z:  HW + 1.15 };
    this.staff.lins[1].position.set(8, 0, -(HW + 1.15));
    this.staff.lins[1].userData.pos = { x: 8, z: -(HW + 1.15) };
  },

  /* ruch sędziów w trakcie meczu (kosmetyka — nie kolidują z grą) */
  tickStaff: function(dt, state){
    var st = this.staff; if(!st) return;
    if(state==="booking" && BROADCAST.scene){BROADCAST.officials(dt);return;}
    if(state === "replay") return;
    var b = SIM.ball; if(!b) return;
    /* główny: trzyma się ~8 m od piłki, ustawiony skosem do akcji */
    var rf = st.ref, rp = rf.userData.pos;
    var tx = Math.max(-HL+2, Math.min(HL-2, b.x*0.88));
    var tz = Math.max(-HW+2, Math.min(HW-2, b.z*0.55 + (b.z >= 0 ? -8 : 8)));
    var dx = tx-rp.x, dz = tz-rp.z, d = Math.hypot(dx, dz);
    var spd = Math.min(6.2, d*2.0);
    if(d > 0.06){ rp.x += dx/d*spd*dt; rp.z += dz/d*spd*dt; }
    rf.position.set(rp.x, 0, rp.z);
    rf.rotation.y = Math.atan2(b.x-rp.x, b.z-rp.z);
    var indirect=(state==="freekick" && RULES.freeIndirect) || RULES.indirectTaker;
    this.animatePlayer(rf,d>.5?spd:0,dt,indirect?"signalIndirect":"run",indirect?1:0);
    /* liniowi: bieg wzdłuż linii autu, na wysokości piłki (z małym wyprzedzeniem) */
    for(var i=0;i<2;i++){
      var ln = st.lins[i], lp = ln.userData.pos;
      var lz = (i===0 ? 1 : -1)*(HW+1.15);
      var lx = Math.max(-HL-2, Math.min(HL+2, b.x + b.vx*0.22));
      var mdx = lx - lp.x;
      var ms = Math.min(5.8, Math.abs(mdx)*2.0);
      if(Math.abs(mdx) > 0.05) lp.x += (mdx > 0 ? 1 : -1) * ms * dt;
      lp.z = lz;
      ln.position.set(lp.x, 0, lz);
      ln.rotation.y = Math.abs(mdx) > 0.3 ? Math.atan2(mdx, 0.6) : Math.atan2(b.x-lp.x, b.z-lz);
      this.animatePlayer(ln, Math.abs(mdx) > 0.4 ? ms : 0, dt, "run", 0);
    }
  },

  /* ---------- ławki trenerskie z rezerwowymi i trenerem ---------- */
  _benches: function(){
    var self = this;
    var matFrame = new THREE.MeshLambertMaterial({ color:0x141a24 });
    var matSeat  = new THREE.MeshLambertMaterial({ color:0x232e40 });
    var matRoof  = new THREE.MeshLambertMaterial({ color:0x2b3446 });
    function dugout(x0, team){
      var grp = new THREE.Group();
      var back = new THREE.Mesh(new THREE.BoxGeometry(12.8, 1.2, 0.22), matFrame);
      back.position.set(0, 0.62, -2.75);
      var roof = new THREE.Mesh(new THREE.BoxGeometry(13.4, 0.10, 3.6), matRoof);
      roof.position.set(0, 2.30, -0.85); roof.rotation.x = -0.09;
      grp.add(back, roof);
      for(var px=-1; px<=1; px+=2) for(var pz=-1; pz<=1; pz+=2){
        var pole = new THREE.Mesh(new THREE.BoxGeometry(0.13, 2.3, 0.13), matFrame);
        pole.position.set(px*6.4, 1.15, pz===-1 ? -2.6 : 0.1);
        grp.add(pole);
      }
      /* 7 rezerwowych siedzi na ławce (numery 12-18) */
      for(var i=0;i<7;i++){
        var sx = -5.25 + i*1.75;
        var seat = new THREE.Mesh(new THREE.BoxGeometry(0.60, 0.09, 0.52), matSeat);
        seat.position.set(sx, 0.60, -1.62);
        grp.add(seat);
        var p = self.makePlayer(team, false, 12+i, grp);
        p.position.set(sx, 0.075, -1.66);
        MOTION.sit(p);
      }
      var coach = self.makePlayer(team,false,0,grp,{shirt:0x243038,shorts:0x202932,socks:0x242a30});
      coach.position.set(5.9, 0, -1.4);
      coach.rotation.y = 0.15;
      grp.position.set(x0, 0, -38.9);
      self.scene.add(grp);
    }
    dugout(-16, 0);
    dugout(16, 1);
  },

  /* ---------- telebimy: podgląd na żywo + wynik + komunikaty sędziego ---------- */
  _telebims: function(){
    this.teleCurMsg = ""; this.teleMsgT = 0; this.teleMsgStyle = "info"; this.telePaintKey = "";
    this.teleCv = this._mkCanvas(512, 288);
    this.teleTex = new THREE.CanvasTexture(this.teleCv);
    this.teleTex.encoding = THREE.sRGBEncoding;
    this.teleTex.anisotropy = 4;
    var bezelMat = new THREE.MeshLambertMaterial({ color:0x0c0f16 });
    this.teleLiveMat = new THREE.MeshBasicMaterial({ color:0x0a1a28 });
    var overlayMat = new THREE.MeshBasicMaterial({ map: this.teleTex, transparent:true, depthWrite:false });
    var self = this;
    function screen(x, y, z, ry){
      var grp = new THREE.Group();
      var frame = new THREE.Mesh(new THREE.BoxGeometry(15.4, 9.45, 0.8), bezelMat);
      var live = new THREE.Mesh(new THREE.PlaneGeometry(14, 7.875), self.teleLiveMat);
      live.position.z = 0.41;
      var ov = new THREE.Mesh(new THREE.PlaneGeometry(14, 7.875), overlayMat);
      ov.position.z = 0.42;
      /* nogi konstrukcyjne — telebim „stoi” na trybunie za bramką */
      for(var lx=-1; lx<=1; lx+=2){
        var leg = new THREE.Mesh(new THREE.BoxGeometry(0.3, 12.4, 0.3), bezelMat);
        leg.position.set(lx*5.2, -6.0, -0.55);
        grp.add(leg);
      }
      grp.add(frame, live, ov);
      grp.position.set(x, y, z);
      grp.rotation.y = ry;
      /* warstwa 1: telebimy widoczne dla kamery TV, ale NIE rysowane
         na własnym podglądzie (podgląd korzysta tylko z warstwy 0) */
      grp.traverse(function(o){ o.layers.set(1); });
      self.scene.add(grp);
      return grp;
    }
    /* Ekrany na wspornikach nad galerią za każdą z bramek. */
    screen( 76.6, 20.45, 0, -Math.PI/2);   /* za bramką wschodnią */
    screen(-76.6, 20.45, 0,  Math.PI/2);   /* za bramką zachodnią */
    /* kamera podglądu — stały szeroki widok z wysoka („kamera taktyczna”);
       kamera TV widzi też warstwę 1 (telebimy), podgląd — tylko warstwę 0 */
    this.teleCam = new THREE.PerspectiveCamera(46, 16/9, 1, 500);
    this.teleCam.position.set(0, 42, 76);
    this.teleCam.lookAt(0, 0, -4);
    if(this.cam.layers) this.cam.layers.enable(1);
    this._teleRTEnsure();
    this._telePaint();
  },

  /* podgląd na żywo: render do tekstury (wyłączony przy niskiej jakości) */
  _teleRTEnsure: function(){
    if(!this.teleLiveMat)return;
    var q=SET.q|0,sz=q===2?512:320;
    if(this.teleRT&&(q===0||this.teleRT.width!==sz)){this.teleRT.dispose();this.teleRT=null;}
    if(q>0&&!this.teleRT){this.teleRT=new THREE.WebGLRenderTarget(sz,Math.round(sz*.5625));this.teleRT.texture.encoding=THREE.sRGBEncoding;}
    this.teleLiveMat.map=this.teleRT?this.teleRT.texture:null;
    this.teleLiveMat.color.setHex(this.teleRT?0xffffff:0x152735);this.teleLiveMat.needsUpdate=true;
  },

  /* komunikat na telebimie (np. decyzja sędziego) */
  teleMsg: function(text, dur, style){
    this.teleCurMsg = text || "";
    this.teleMsgT = dur || 4;
    this.teleMsgStyle = style || "info";
    this.telePaintKey = "";
  },

  _telePaint: function(){
    var g = this.teleCv.getContext("2d");
    g.clearRect(0, 0, 512, 288);
    /* pasek górny: drużyny, wynik, minuta */
    g.fillStyle = "rgba(6,10,18,0.9)"; g.fillRect(0, 0, 512, 66);
    g.fillStyle = "#e8352a"; g.fillRect(0, 0, 512, 3);
    g.textAlign = "center"; g.textBaseline = "middle";
    var h = (SET.home || "—").slice(0, 14), a = (SET.away || "—").slice(0, 14);
    var s0 = SIM.teams.length ? SIM.teams[0].score : 0;
    var s1 = SIM.teams.length ? SIM.teams[1].score : 0;
    g.font = "bold 26px 'Segoe UI',Arial";
    g.fillStyle = "#f2f4f8";
    g.fillText(h, 104, 26); g.fillText(a, 408, 26);
    var m = RULES.state === "fulltime" ? "90'" : ((RULES.displayMin < 10 ? "0" : "") + RULES.displayMin + "'");
    g.font = "bold 30px 'Segoe UI',Arial";
    g.fillStyle = "#ffcf3d";
    g.fillText(s0 + " : " + s1 + "   ·   " + m, 256, 49);
    /* pasek dolny: komunikaty sędziego (gol / kartki / karny / spalony) */
    if(this.teleCurMsg){
      var bg = this.teleMsgStyle === "card" ? "rgba(150,18,14,0.92)" :
               this.teleMsgStyle === "goal" ? "rgba(18,105,38,0.92)" : "rgba(6,10,18,0.9)";
      g.fillStyle = bg; g.fillRect(0, 244, 512, 44);
      g.fillStyle = "#ffcf3d"; g.fillRect(0, 244, 512, 3);
      g.font = "bold 24px 'Segoe UI',Arial";
      g.fillStyle = "#ffffff";
      var msg = this.teleCurMsg;
      if(msg.length > 42) msg = msg.slice(0, 41) + "…";
      g.fillText(msg, 256, 268);
    }
    this.teleTex.needsUpdate = true;
  },

  _ads: function(){
    var self=this;this.adMat=[];this.adTex=[];this.adNames="";
    var long=arenaTexture(1024,64),short=long.clone();short.image=long.image;
    [long,short].forEach(function(tex,i){
      tex.wrapS=THREE.RepeatWrapping;tex.repeat.x=i===0?5:2;tex.needsUpdate=true;
      self.adTex.push(tex);self.adMat.push(new THREE.MeshBasicMaterial({map:tex,side:THREE.FrontSide}));
    });
    this.adBoards=[];var frame=new ArenaGeometry();
    [[104,0,37.42,Math.PI,0],[104,0,-37.42,0,0],[46,56.6,0,-Math.PI/2,1],[46,-56.6,0,Math.PI/2,1]].forEach(function(a){
      var screen=new THREE.Mesh(new THREE.PlaneGeometry(a[0],.82),self.adMat[a[4]]);
      screen.position.set(a[1],.59,a[2]);screen.rotation.y=a[3];self.scene.add(screen);self.adBoards.push(screen);
      var tx=Math.cos(a[3]),tz=-Math.sin(a[3]),x=a[1],z=a[2];
      [.135,1.03].forEach(function(y){frame.rod([x-tx*a[0]/2,y,z-tz*a[0]/2],[x+tx*a[0]/2,y,z+tz*a[0]/2],.04,.04,0x414e55,6);});
    });
    self.scene.add(new THREE.Mesh(frame.build(false),new THREE.MeshLambertMaterial({vertexColors:true})));
    this.refreshAds(SET.home,SET.away);
  },
  refreshAds: function(home,away){
    STADIUM.setNames(home,away);
    var key=JSON.stringify([home,away]);if(key===this.adNames)return;this.adNames=key;
    var tex=this.adTex[0],g=tex.image.getContext("2d");
    g.fillStyle="#162c29";g.fillRect(0,0,1024,64);g.fillStyle="#aa3349";g.fillRect(0,0,320,64);
    g.fillStyle="#275e9a";g.fillRect(704,0,320,64);
    g.textBaseline="middle";g.textAlign="center";g.font="bold 38px Arial";g.fillStyle="#fff3d9";
    g.fillText(home,160,32,285);g.fillText(away,864,32,285);
    g.font="bold 34px Arial";g.fillStyle="#daf09c";g.fillText("SUPER PIŁKA ’98",512,32,342);
    g.fillStyle="rgba(0,8,12,.24)";for(var i=0;i<64;i+=4)g.fillRect(0,i,1024,1);
    this.adTex.forEach(function(t){t.needsUpdate=true;});this.telePaintKey="";
  },

  _markers: function(){
    /* wskaźnik gracza P1 / P2: pierścień + strzałka nad głową */
    function mkMark(ringColor,jewelColor){
      var grp=new THREE.Group();
      var ring=new THREE.Mesh(new THREE.RingGeometry(.45,.61,40),
        new THREE.MeshBasicMaterial({color:ringColor,side:THREE.DoubleSide,depthWrite:false}));
      ring.rotation.x=-Math.PI/2;ring.position.y=.035;
      var jewel=new THREE.Mesh(new THREE.OctahedronGeometry(.175),
        new THREE.MeshLambertMaterial({color:jewelColor,emissive:jewelColor,emissiveIntensity:.21}));
      jewel.scale.y=1.35;jewel.position.y=2.20;
      grp.add(ring,jewel);grp.userData={ring:ring,arrow:jewel};grp.visible=false;
      return grp;
    }
    this.m1=mkMark(0xffe448,0xdf262d);this.m2=mkMark(0x88ceff,0x2757df);
    this.gFx.add(this.m1, this.m2);
    /* piłka: cień „kropelka” */
    var blobCv = this._mkCanvas(64,64), bg = blobCv.getContext("2d");
    var gr = bg.createRadialGradient(32,32,4,32,32,30);
    gr.addColorStop(0,"rgba(0,0,0,0.5)"); gr.addColorStop(1,"rgba(0,0,0,0)");
    bg.fillStyle = gr; bg.fillRect(0,0,64,64);
    this.blob = new THREE.Mesh(new THREE.PlaneGeometry(1,1),
      new THREE.MeshBasicMaterial({ map:new THREE.CanvasTexture(blobCv), transparent:true, depthWrite:false }));
    this.blob.rotation.x = -Math.PI/2;
    this.gFx.add(this.blob);
    var footprint=new THREE.PlaneGeometry(1.05,.74);footprint.rotateX(-Math.PI/2);
    this.contactShadows=new THREE.InstancedMesh(footprint,new THREE.MeshBasicMaterial({
      map:this.blob.material.map,transparent:true,opacity : 0.77,depthWrite:false}),22);
    this.contactShadows.count=0;this.contactShadows.frustumCulled=false;
    this.shadowMatrix=new THREE.Matrix4();this.gFx.add(this.contactShadows);
    /* strzałka namieru przy wznowieniach */
    // Przekroje dwuspadowej strzałki. Przód wskazuje lokalne +Z, jak stopa wykonawcy.
    var arrowVerts=[],arrowColors=[];
    function triangle(a,b,c,color){
      var rgb=new THREE.Color(color).convertSRGBToLinear();
      [a,b,c].forEach(function(p){arrowVerts.push(p[0],p[1],p[2]);arrowColors.push(rgb.r,rgb.g,rgb.b);});
    }
    function section(z,width,top){return [[-width,top-.15,z],[0,top,z],[width,top-.15,z]];}
    var rows=[section(.30,.15,.21),section(2.12,.20,.63),section(2.13,.44,.64),section(3.25,.02,.94)];
    for(var r=1;r<rows.length;r++){
      var a=rows[r-1],b=rows[r];
      for(var i=0;i<2;i++){
        var color=r===3?(i?0xaa3026:0xf66029):i?0xcf7428:0xffca48;
        triangle(a[i],b[i],a[i+1],color);triangle(a[i+1],b[i],b[i+1],color);
      }
      triangle(a[0],a[2],b[0],0x71301e);triangle(a[2],b[2],b[0],0x71301e);
    }
    var geom=new THREE.BufferGeometry();
    geom.setAttribute("position",new THREE.Float32BufferAttribute(arrowVerts,3));
    geom.setAttribute("color",new THREE.Float32BufferAttribute(arrowColors,3));
    this.aimArrow=new THREE.Mesh(geom,new THREE.MeshBasicMaterial({vertexColors:true,side:THREE.DoubleSide}));
    this.aimArrow.visible = false;
    this.gFx.add(this.aimArrow);
  },

  playerShadows: function(players){
    var mesh=this.contactShadows,count=0;
    for(var i=0;i<players.length;i++){
      var p=players[i];if(p.off || !p.mesh)continue;
      this.shadowMatrix.makeTranslation(p.mesh.position.x,.025,p.mesh.position.z);
      mesh.setMatrixAt(count++,this.shadowMatrix);
    }
    mesh.count=count;mesh.instanceMatrix.needsUpdate=true;
  },

  /* ---------- zawodnicy ---------- */
  makePlayer: function(team,isGk,num,parent,customKit,name){
    return ATHLETE.create(team,isGk,num,parent||this.gPlayers,customKit,name);
  },
  removePlayer: function(mesh){ ATHLETE.dispose(mesh); },
  animatePlayer: function(mesh,speed,dt,action,time,turn,look,side,sideSpeed,forwardSpeed,phase){
    MOTION.animate(mesh,speed,dt,action,time,turn,look,side,sideSpeed,forwardSpeed,phase);
  },

  /* puls trybun: skoki przy golu / ekscytacji (shader) + flagi + drganie lamp */
  crowdPulse: 0,
  tick: function(dt){
    STADIUM.tick(dt,(MAIN.state==="match"&&!MAIN.paused)||STADIUM_TOUR.active);
    var tt=STADIUM.time.value;
    if(MAIN.state==="match"&&!MAIN.paused)PITCH.tick(dt);
    if(this.flags){
      for(var i=0;i<this.flags.length;i++){
        var f = this.flags[i];
        var strand=f.geometry.attributes.position;
        for(var v=0;v<strand.count;v++){var u=strand.getX(v);strand.setZ(v,u*.18*Math.sin(tt*4.3-10*u+i));}
        strand.needsUpdate=true;
        f.rotation.y = f.userData.base + Math.sin(tt*2.4 + i*1.7)*0.30 + Math.sin(tt*7.1 + i)*0.06;
      }
    }
    if(this.glows && this.night){
      var fl = 0.88 + Math.sin(tt*37)*0.03 + Math.sin(tt*9.3)*0.04;
      for(var g=0; g<this.glows.length; g++) this.glows[g].material.opacity = 0.50*fl;
    }
    /* telebim: podgląd na żywo (RT ~12 Hz) + wynik i komunikaty sędziego */
    if(this.teleCv){
      if(this.teleMsgT > 0){
        this.teleMsgT -= dt;
        if(this.teleMsgT <= 0){ this.teleCurMsg = ""; this.telePaintKey = ""; }
      }
      this._teleAcc = (this._teleAcc || 0) + dt;
      if(this.teleRT && (SET.q|0) > 0 && this._teleAcc > 0.08){
        this._teleAcc = 0;
        this.renderer.setRenderTarget(this.teleRT);
        this.renderer.render(this.scene, this.teleCam);
        this.renderer.setRenderTarget(null);
      }
      var tk = RULES.displayMin + "|" + (SIM.teams.length ? SIM.teams[0].score : 0) + "|" +
               (SIM.teams.length ? SIM.teams[1].score : 0) + "|" + this.teleCurMsg;
      if(tk !== this.telePaintKey){ this.telePaintKey = tk; this._telePaint(); }
    }
  }
};
