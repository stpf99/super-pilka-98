/* Podgląd wykorzystuje dokładnie te same kości, tekstury i pozy co mecz. */
var SHOWROOM = {
  renderer:null,models:{},active:false,selection:0,angle : 0.40,time:0,key:"",
  clips:[["idle","run",0,0],["jog","run",3.7,0],["sprint","run",8.6,0],["shootAnim","kick",0,.4],
    ["passAnim","passkick",0,.3],["slideAnim","slide",0,.72],["jockeyAnim","jockey",1.8,0],["throwAnim","throw",0,.52],
    ["headAnim","header",0,.45],["diveAnim","dive",0,.65],["goalRunAnim","goalrun",3.3,0],["goalAnim","celebrate",0,0],["protestAnim","booked",0,0],
    ["faceAnim","expression",0,0],["trapHead","trapHead",0,0],["trapChest","trapChest",0,0],
    ["trapThigh","trapThigh",0,0],["trapFoot","trapFoot",0,0]],
  init: function(){
    this.renderer=new THREE.WebGLRenderer({alpha:true,antialias:true,powerPreference:"low-power"});
    this.renderer.outputEncoding=THREE.sRGBEncoding;this.renderer.setClearColor(0x000000,0);
    this.scene=new THREE.Scene();this.camera=new THREE.PerspectiveCamera(30,1,.02,25);
    this.ball=PITCH.ball();this.ball.visible=false;this.scene.add(this.ball);
    this.contact=new THREE.Vector3();this.probe=new THREE.Vector3();
    this.scene.add(new THREE.HemisphereLight(0xfff4e1,0xb5c7c1,1.02));
    var key=new THREE.DirectionalLight(0xfff1d7,1.24);key.position.set(-2.5,4,3.5);this.scene.add(key);
    var rim=new THREE.DirectionalLight(0xc3e1ff,1.05);rim.position.set(3,2,-1.5);this.scene.add(rim);
    var shade=document.createElement("canvas");shade.width=shade.height=128;var g=shade.getContext("2d");
    var gradient=g.createRadialGradient(64,64,4,64,64,62);gradient.addColorStop(0,"rgba(0,0,0,.52)");gradient.addColorStop(1,"transparent");
    g.fillStyle=gradient;g.fillRect(0,0,128,128);
    this.shadow=new THREE.Mesh(new THREE.PlaneGeometry(1.38,.72),new THREE.MeshBasicMaterial({map:new THREE.CanvasTexture(shade),transparent:true,depthWrite:false}));
    this.shadow.rotation.x=-Math.PI/2;this.shadow.position.y=-.014;this.scene.add(this.shadow);
    var self=this, stage=document.getElementById("modelStage"),drag=null;
    document.querySelectorAll("[data-model]").forEach(function(btn){btn.onclick=function(){self.open(Number(btn.dataset.model));};});
    document.getElementById("modelBack").onclick=function(){self.close();};
    document.getElementById("rotLeft").onclick=function(){self.angle-=.4;};
    document.getElementById("rotRight").onclick=function(){self.angle+=.4;};
    document.getElementById("modelAnim").onchange=function(){
      self.time=0;self.contactValid=false;self.showName();
      var action=self.clips[Number(this.value)][1],frame=document.getElementById("modelFrame");
      if(action==="expression")frame.value="face";
      else if(RECEPTION.clips[action] && frame.value==="face")frame.value="body";
    };
    stage.addEventListener("pointerdown",function(e){if(e.target.closest("button"))return;drag=e.clientX;stage.setPointerCapture(e.pointerId);});
    stage.addEventListener("pointermove",function(e){if(drag===null)return;self.angle+=(e.clientX-drag)*.013;drag=e.clientX;});
    stage.addEventListener("lostpointercapture",function(){drag=null;});
  },
  subject: function(team,keeper){
    var key=team+"-"+keeper, index=keeper?0:(team===0?9:10);
    if(!this.models[key]){
      this.models[key]=ATHLETE.create(team,keeper,LINEUP.numbers[index],this.scene,null,LINEUP.names[team][index]);
    }
    var models=this.models;Object.keys(models).forEach(function(k){models[k].visible=k===key;});
    return models[key];
  },
  portrait: function(canvas,team){
    if(!this.renderer)this.init();
    if(canvas.dataset.drawn)return;
    this.ball.visible=false;
    var m=this.subject(team,false);m.rotation.y=team===0 ? 0.38:-.38;
    m.userData.phase=team===0 ? 0.22 : 0.48;
    MOTION.animate(m,team===0?1.25:1.85,0,"run",0,0,team===0?-.19 : 0.19,1);
    this.render(canvas.width,canvas.height,.96,3.90);
    var g=canvas.getContext("2d");g.drawImage(this.renderer.domElement,0,0);
    canvas.dataset.drawn="1";
  },
  render: function(w,h,y,dist){
    var r=this.renderer,cv=r.domElement;
    if(cv.width!==w || cv.height!==h)r.setSize(w,h,false);
    this.camera.aspect=w/h;this.camera.position.set(0,y+.13,dist);this.camera.lookAt(0,y,0);
    this.camera.updateProjectionMatrix();r.render(this.scene,this.camera);
  },
  showName: function(){
    var i=Number(document.getElementById("modelAnim").value)||0,idx=this.clips[i][1]==="dive"?0:(this.selection===0?9:10);
    document.getElementById("modelName").textContent=LINEUP.numbers[idx]+"  "+LINEUP.names[this.selection][idx];
  },
  open: function(team){
    this.selection=team;this.active=true;this.angle=.38;this.time=.1;this.contactValid=false;
    var select=document.getElementById("modelAnim");select.replaceChildren();
    this.clips.forEach(function(c,i){var opt=document.createElement("option");opt.value=i;opt.textContent=t(c[0]);select.add(opt);});select.value="1";
    document.getElementById("modelFrame").value="body";
    document.getElementById("ovMenu").classList.add("hide");document.getElementById("ovModel").classList.remove("hide");
    document.getElementById("modelStage").appendChild(this.renderer.domElement);this.showName();this.update(.016);
    document.getElementById("modelBack").focus();
  },
  close: function(){
    this.active=false;this.ball.visible=false;document.getElementById("ovModel").classList.add("hide");document.getElementById("ovMenu").classList.remove("hide");
    document.querySelector('[data-model="'+this.selection+'"]').focus();
  },
  receiveBall:function(m,action,t){
    var u=m.userData,active=u.receiveLeg===undefined?u.kickLeg:u.receiveLeg;
    var limb=u.limbs[active],side=active===0?-1:1,v=this.probe,bone;
    if(action==="trapHead"){bone=u.head;v.set(0,.144,.242);}
    else if(action==="trapChest"){bone=u.spine;v.set(0,.354,.270);}
    else if(action==="trapThigh"){bone=limb.hip;v.set(0,-.347,.177);}
    else{bone=limb.ankle;v.set(0,.143,.129);}
    m.updateMatrixWorld(true);
    if(t<=0 || !this.contactValid){
      this.contact.copy(m.worldToLocal(bone.localToWorld(v)));
      this.contactValid=true;
    }
    v.copy(this.contact);
    if(t<0){
      v.x-=side*t*.61;v.z-=t*3.0;v.y-=t*(action==="trapHead"?1.02:1.9)+1.8*t*t;
    }else{
      var vy=action==="trapThigh"?.55:action==="trapFoot"?.34:-.42;
      var floor=SIM.BR/m.scale.y;
      v.x+=side*t*.105;v.z+=t*.66;
      v.y=Math.max(floor,v.y+vy*t-.5*SIM.G*t*t);
    }
    this.ball.position.copy(m.localToWorld(v));this.ball.rotation.x=1.6+t*(t<0?-5.8:2.4);
  },
  update: function(dt){
    var clip=this.clips[Number(document.getElementById("modelAnim").value)]||this.clips[0];
    var m=this.subject(this.selection,clip[1]==="dive"), action=clip[1];
    this.time+=dt;
    var pos=this.time%(clip[3]+.76),remaining=clip[3]-pos;
    if(clip[3] && remaining<0)action=clip[1]==="kick" && remaining<-.53?"windup":"run";
    var reception=RECEPTION.clips[clip[1]],flight=0;
    if(reception){
      var period=.73+reception.follow+.79;
      flight=this.time%period-.73;
      m.userData.receiveLeg=(m.userData.kickLeg+Math.floor(this.time/period))%2;
      remaining=reception.follow-flight;
      action=flight>=-reception.wind && remaining>0?clip[1]:"run";
      m.userData.contactHeight=reception.height;
    }
    m.rotation.y=this.angle;
    if(action==="expression")m.userData.poseT=this.time-dt;
    MOTION.animate(m,clip[2],dt,action,Math.max(0,remaining),0,0,1);
    this.ball.visible=!!reception;
    if(reception)this.receiveBall(m,clip[1],flight);
    var stage=document.getElementById("modelStage"),frame=document.getElementById("modelFrame").value;
    var dist=frame==="face"?.87:frame==="feet"?1.96:frame==="upper"?2.15:3.98;
    var y=frame==="face"?1.684*m.scale.y:frame==="feet" ? 0.44:frame==="upper"?1.37 : 0.93;
    var w=Math.max(1,stage.clientWidth),h=Math.max(1,stage.clientHeight);
    this.render(w,h,y,dist*Math.max(1,.80/(w/h)));
  }
};
