// Ujęcia tej samej sceny, dostępnych także po zatrzymaniu meczu.
var STADIUM_TOUR={
  active:false,view:1,team:0,elapsed:0,
  init:function(){
    var self=this;
    this.el=document.getElementById("ovStadium");this.title=document.getElementById("tourTitle");
    this.buttons=Array.from(this.el.querySelectorAll("[data-stand-view]"));
    this.buttons.forEach(function(btn){btn.onclick=function(){self.select(Number(btn.getAttribute("data-stand-view")));};});
    document.getElementById("btnTour").onclick=function(){self.open("ovMenu");};
    document.getElementById("btnPauseTour").onclick=function(){self.open("ovPause");};
    document.getElementById("btnTourBack").onclick=function(){self.close();};
    window.addEventListener("keydown",function(e){
      if(!self.active)return;
      if(e.code==="ArrowLeft"||e.code==="ArrowRight"){
        e.preventDefault();self.select((self.view+self.buttons.length+(e.code==="ArrowLeft"?-1:1))%self.buttons.length);self.buttons[self.view].focus();
      }
    });
  },
  open:function(origin){
    if(this.active)return;
    this.origin=origin;this.active=true;var cam=WORLD.cam;
    this.saved={p:cam.position.clone(),q:cam.quaternion.clone(),fov:cam.fov,hud:document.getElementById("hud").classList.contains("show")};
    document.getElementById("hud").classList.remove("show");document.getElementById(origin).classList.add("hide");
    this.el.classList.remove("hide");AUDIO.init();AUDIO.resume();this.team=0;this.select(1);this.buttons[1].focus();
  },
  select:function(v){
    this.view=v;this.elapsed=0;if(v===1||v===2)this.team=v-1;
    this.buttons.forEach(function(b,i){b.classList.toggle("on",i===v);b.setAttribute("aria-pressed",String(i===v));});
    var name=this.team?SET.away:SET.home;
    this.title.textContent=v===0?t("stadium"):v===5?t("tour_pitch"):v<3?name:name+" · "+t(v===3?"tour_drum":"tour_brass");
    this.camera(0);
  },
  camera:function(dt){
    this.elapsed+=dt;
    var cam=WORLD.cam,view=this.view,p,look,fov,aspect=Math.max(.5,cam.aspect);
    if(view===0){
      var a=-.48+.18*Math.sin(this.elapsed*.10);
      p=new THREE.Vector3(Math.sin(a)*59,19.5,Math.cos(a)*50);look=new THREE.Vector3(0,4,-12);fov=65;
    }else if(view===5){
      var step=Math.sin(this.elapsed*.12)*.9;p=new THREE.Vector3(-34+step,2.7,1.5);
      look=new THREE.Vector3(0,6.45,-46);fov=62;
    }else{
      var kind=view<3?"scarf":view===3?"drum":"brass",a=STADIUM.anchors[this.team][kind];
      var s=STADIUM.sides[a.side],x=a.p[0],y=a.p[1],z=a.p[2];
      var far=view<3?5.15:2.25,side=view<3?.31:view===3?-.80:.86;
      far*=Math.max(1,(view<3?1.13:.88)/aspect);
      var drift=Math.sin(this.elapsed*.40)*.10;
      p=new THREE.Vector3(x-s.nx*far+(side+drift)*s.nz,y+(view<3?2.13:view===3?1.89:1.65),z-s.nz*far-(side+drift)*s.nx);
      look=new THREE.Vector3(x-s.nx*.11,y+(view<3?1.35:view===3?1.15:1.48),z-s.nz*.11);
      fov=view<3?40:view===3?34:30;
    }
    cam.position.copy(p);cam.lookAt(look);
    if(cam.fov!==fov){cam.fov=fov;cam.updateProjectionMatrix();}
  },
  close:function(){
    if(!this.active)return;this.active=false;this.el.classList.add("hide");
    document.getElementById(this.origin).classList.remove("hide");
    if(this.saved.hud)document.getElementById("hud").classList.add("show");
    WORLD.cam.position.copy(this.saved.p);WORLD.cam.quaternion.copy(this.saved.q);WORLD.cam.fov=this.saved.fov;WORLD.cam.updateProjectionMatrix();
    INPUT.wheelAcc=0;
    document.getElementById(this.origin==="ovMenu"?"btnTour":"btnPauseTour").focus();
  }
};
