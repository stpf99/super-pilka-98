/* Czasy w sekundach, wysokości i zasięgi w metrach. Ta sama faza kontaktu
   prowadzi animację w meczu, podglądzie oraz powtórce. */
var RECEPTION = {
  clips:{
    trapHead:{height:1.79,wind:.19,follow:.43,forward:.11,reach:.27},
    trapChest:{height:1.36,wind:.19,follow:.46,forward:.15,reach:.30},
    trapThigh:{height:.85,wind:.22,follow:.49,forward:.30,reach:.32},
    trapFoot:{height:.34,wind:.16,follow:.36,forward:.33,reach:.34}
  },
  type:function(height){
    if(height<.207 || height>2.05)return null;
    return height>1.57?"trapHead":height>1.10?"trapChest":height>.585?"trapThigh":"trapFoot";
  },
  allowed:function(ball){
    return ball.shotTeam===null && ball.vy<3.3 && Math.hypot(ball.vx,ball.vz)<32;
  },
  receivingLeg:function(pl,b){
    var side=(b.x-pl.pos.x)*Math.cos(pl.face)-(b.z-pl.pos.z)*Math.sin(pl.face);
    return Math.abs(side)>.065?(side<0?0:1):pl.mesh.userData.kickLeg;
  },
  prepare:function(pl,b){
    var previous=pl.readyAction;
    pl.readyAction=null;
    if(b.owner || b.cushion || pl.action!=="run" || (b.lastKicker===pl && b.lock>0))return;
    var dx=b.x-pl.pos.x,dz=b.z-pl.pos.z;
    if(dx*dx+dz*dz>21 || b.y<.22 || !this.allowed(b))return;
    var vx=b.vx-pl.vel.x,vz=b.vz-pl.vel.z,squared=vx*vx+vz*vz;
    var until=squared>.25?-(dx*vx+dz*vz)/squared:0;
    if(until<0 || until>.62)return;
    var miss=Math.hypot(dx+vx*until,dz+vz*until);
    if(miss>.48)return;
    var scale=pl.mesh.scale.y,relativeSpeed=Math.sqrt(squared),arrival=0;
    if(relativeSpeed>.5){
      arrival=Math.max(0,until-.50*scale/relativeSpeed);
    }else if(b.vy<-.1 && b.y>1.88*scale){
      arrival=(b.vy+Math.sqrt(b.vy*b.vy+2*SIM.G*(b.y-1.88*scale)))/SIM.G;
    }
    var height=(b.y+b.vy*arrival-.5*SIM.G*arrival*arrival)/scale;
    var action=this.type(Math.max(.211,height)),clip=this.clips[action];
    if(!clip)return;
    // The lifted instep meets the pass in front of the torso, substantially earlier
    // than the projected time at which the ball would reach the player's centre.
    if(relativeSpeed>.5){
      var reach=(clip.forward+clip.reach)*scale;
      arrival=Math.max(0,until-Math.sqrt(Math.max(0,reach*reach-miss*miss))/relativeSpeed);
      height=(b.y+b.vy*arrival-.5*SIM.G*arrival*arrival)/scale;
      action=this.type(Math.max(.211,height));clip=this.clips[action];
    }
    if(!clip || arrival>clip.wind)return;
    if(previous!==action)pl.trapLeg=this.receivingLeg(pl,b);
    pl.readyAction=action;pl.readyT=clip.follow+arrival;pl.trapHeight=height;
    pl.trapFace=Math.hypot(dx,dz)>.10?Math.atan2(dx,dz):pl.face;
  },
  distance:function(pl,b,action){
    var clip=this.clips[action],scale=pl.mesh.scale.y;
    var fx=Math.sin(pl.face),fz=Math.cos(pl.face);
    var leg=action==="trapThigh" || action==="trapFoot";
    var active=pl.readyAction===action?pl.trapLeg:this.receivingLeg(pl,b);
    var side=leg?(active===0?-.10:.10)*scale:0;
    var dx=b.x-pl.pos.x-fx*clip.forward*scale-fz*side;
    var dz=b.z-pl.pos.z-fz*clip.forward*scale+fx*side;
    return Math.hypot(dx,dz);
  },
  touch:function(pl,b,action){
    var clip=this.clips[action],scale=pl.mesh.scale.y;
    if(pl.readyAction!==action)pl.trapLeg=this.receivingLeg(pl,b);
    pl.trapHeight=b.y/scale;
    pl.trapFace=pl.readyAction?pl.trapFace:Math.atan2(b.x-pl.pos.x,b.z-pl.pos.z);
    pl.readyAction=null;pl.action=action;pl.actionT=clip.follow;
    var fx=Math.sin(pl.face),fz=Math.cos(pl.face);
    b.vy=action==="trapThigh"?.55:action==="trapFoot"?.34:-.42;
    var air=Math.max(.18,(b.vy+Math.sqrt(b.vy*b.vy+2*SIM.G*Math.max(0,b.y-SIM.BR)))/SIM.G);
    // Cushion the ball into the player's path. Ownership can still be won by an opponent.
    b.vx=pl.vel.x*.70+(pl.pos.x+fx*.40*scale-b.x)/air+fx*.19;
    b.vz=pl.vel.z*.70+(pl.pos.z+fz*.40*scale-b.z)/air+fz*.19;
    b.cushion=pl;b.settleT=air+.34;b.receiver=pl;b.route={x:b.x+b.vx*air,z:b.z+b.vz*air};
    b.curve=0;b.flight="control";b.lastKicker=pl;b.lastTouchTeam=pl.team;b.lastShotBy=null;b.lock=.09;
    pl.decideCd=Math.max(pl.decideCd,air+.11);
    SIM.events.push({type:"touch",player:pl});AUDIO.kick(.12);
  }
};
