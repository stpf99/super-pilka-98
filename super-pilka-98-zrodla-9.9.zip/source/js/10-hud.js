/* ============================================================
   SUPER PILKA '98 · 10-hud.js — HUD, ekrany, pomoc sterowania
   ============================================================ */
var HUD = {
  el: function(id){ return document.getElementById(id); },
  bannerT: 0, commT: 0,

  refreshTeams: function(){
    this.el("tNameH").textContent = SET.home;
    this.el("tNameA").textContent = SET.away;
    this.setScore();
  },
  setScore: function(){
    this.el("gH").textContent = SIM.teams[0] ? SIM.teams[0].score : 0;
    this.el("gA").textContent = SIM.teams[1] ? SIM.teams[1].score : 0;
    this.updateCards();
  },
  updateClock: function(){
    var sec = (RULES.half-1)*2700 + Math.min(2700,Math.floor(RULES.elapsed/SET.half*2700));
    if(RULES.state==="fulltime") sec=5400;
    this.el("clkMin").textContent = String(Math.floor(sec/60)).padStart(2,"0")+":"+String(sec%60).padStart(2,"0");
    var tag = RULES.half===1 ? t("k1p") : t("k2p");
    if(RULES.state==="fulltime") tag = t("k1p_done");
    this.el("halfTag").textContent = tag;
  },
  updateCards: function(){
    var h = this.el("cardsH"), a = this.el("cardsA");
    h.innerHTML = ""; a.innerHTML = "";
    if(!SIM.players.length) return;
    var yell = [0,0], red = [0,0];
    for(var i=0;i<SIM.players.length;i++){
      var pl = SIM.players[i];
      if(pl.yellows>0 && !pl.off) yell[pl.team]++;
      if(pl.off && pl.yellows>0){ /* czerwona po dwóch żółtych */ }
      if(pl.off) red[pl.team]++;
    }
    for(var k=0;k<yell[0];k++){ var d1=document.createElement("span"); d1.className="cardDot"; h.appendChild(d1); }
    for(var k2=0;k2<red[0];k2++){ var d2=document.createElement("span"); d2.className="cardDot red"; h.appendChild(d2); }
    for(var k3=0;k3<yell[1];k3++){ var d3=document.createElement("span"); d3.className="cardDot"; a.appendChild(d3); }
    for(var k4=0;k4<red[1];k4++){ var d4=document.createElement("span"); d4.className="cardDot red"; a.appendChild(d4); }
  },
  cardFlash: function(pl, isRed){
    this.updateCards();
  },
  event:function(kind,title,minute,player,team,reason){
    var box=this.el("tvEvent");
    box.className=kind;box.hidden=false;this.el("hud").classList.add("hasEvent");
    this.el("eventTitle").textContent=title;this.el("eventMinute").textContent=minute;
    var why=this.el("eventReason");why.textContent=reason||"";why.hidden=!reason;
    this.el("eventPlayer").textContent=player;this.el("eventTeam").textContent=team;
    this.el("banner").classList.remove("show");this.bannerT=0;
  },
  hideEvent:function(){
    this.el("tvEvent").hidden=true;this.el("hud").classList.remove("hasEvent");
  },
  teamNameOf: function(team){ return team===0 ? SET.home : SET.away; },

  banner: function(main, sub, dur, color){
    var b = this.el("banner");
    b.textContent = main;
    if(sub){ var detail=document.createElement("small");detail.textContent=sub;b.appendChild(detail); }
    b.style.color = color || "#fff";
    b.classList.add("show");
    this.bannerT = dur || 2.2;
  },
  commentary: function(txt){
    var el = this.el("comm");
    if(!txt){ el.style.visibility = "hidden"; return; }
    el.textContent = txt;
    el.style.visibility = "visible";
    this.commT = 3.6;
  },
  hint: function(txt){
    this.el("hintbar").textContent = txt || "";
  },
  restartTagShow: function(txt){ this.el("restartTag").textContent = txt; this.el("restartTag").classList.add("show"); },
  restartTagHide: function(){ this.el("restartTag").classList.remove("show"); },
  replayUI: function(on){
    var on2 = !!on;
    this.el("hud").classList.toggle("replaying",on2);
    document.getElementById("lbT").classList.toggle("show", on2);
    document.getElementById("lbB").classList.toggle("show", on2);
    document.getElementById("repTag").classList.toggle("show", on2);
    this.el("hintbar").textContent = on2 ? t("rep_skip") : "";
  },
  showPower: function(v){
    var p = this.el("pwr");
    if(v===null || v===undefined){ p.classList.remove("show"); return; }
    p.classList.add("show");
    this.el("pwrFill").style.width = Math.round(v*100) + "%";
  },
  drawRadar: function(){
    var canvas=this.el("radar"), g=canvas.getContext("2d"), w=canvas.width,h=canvas.height;
    var px=function(x){return 14+(x+HL)/PL*(w-28);};
    var pz=function(z){return 13+(z+HW)/PW*(h-26);};
    g.clearRect(0,0,w,h); g.fillStyle="rgba(13,28,37,.34)";g.fillRect(0,0,w,h);
    g.strokeStyle="rgba(235,246,229,.65)";g.lineWidth=2;g.strokeRect(14,13,w-28,h-26);
    g.beginPath();g.moveTo(w/2,13);g.lineTo(w/2,h-13);g.stroke();g.beginPath();g.ellipse(w/2,h/2,(px(9.15)-px(0)),pz(9.15)-pz(0),0,0,Math.PI*2);g.stroke();
    [1,-1].forEach(function(side){
      var x=side<0?px(-HL):px(HL-16.5);g.strokeRect(x,pz(-20.15),px(16.5)-px(0),pz(20.15)-pz(-20.15));
    });
    SIM.players.forEach(function(p){
      if(p.off)return;
      var x=px(p.pos.x), y=pz(p.pos.z);
      g.fillStyle=p.team===0?"#fff3e4":"#72b5ff";g.strokeStyle="#17211d";g.lineWidth=1.4;g.beginPath();
      if(p.team===0) g.arc(x,y,5.2,0,Math.PI*2);else g.rect(x-4.8,y-4.8,9.6,9.6);
      g.fill();g.stroke();
      if(SIM.teams[p.team].user===p && p.isUser!==null){g.strokeStyle="#edff66";g.lineWidth=2.8;g.beginPath();g.arc(x,y,8.7,0,Math.PI*2);g.stroke();}
    });
    var ball=SIM.ball;g.beginPath();g.arc(px(ball.x),pz(ball.z),5.3,0,Math.PI*2);g.fillStyle="#feef45";g.fill();g.strokeStyle="#302c0b";g.lineWidth=1.8;g.stroke();
  },
  playerPanels: function(){
    ["H","A"].forEach(function(side,team){
      var human = RULES.humanTaker(team);
      var b=SIM.ball;
      var p=(human && SIM.teams[team].user) || (b.owner && b.owner.team===team && b.owner) || SIM.nearestToBall(team,false);
      if(!p || p.off)return;
      HUD.el("pNum"+side).textContent=p.num;
      HUD.el("pName"+side).textContent=p.name;
      HUD.el("pRole"+side).textContent=(human?"P"+(team+1):"CPU")+" · "+t("role"+p.role);
      var bar=HUD.el("pBar"+side);
      bar.style.transform="scaleX("+p.stamina.toFixed(2)+")";
      bar.style.backgroundColor=p.stamina<.28?"#ff9462":"var(--lime)";
    });
  },
  update: function(dt){
    if(this.bannerT > 0){
      this.bannerT -= dt;
      if(this.bannerT <= 0) this.el("banner").classList.remove("show");
    }
    if(this.commT > 0){
      this.commT -= dt;
      if(this.commT <= 0) this.el("comm").style.visibility = "hidden";
    }
    this.updateClock();
    this.fieldTimer=(this.fieldTimer||0)-dt;
    if(this.fieldTimer<=0 && RULES.state!=="replay"){
      this.fieldTimer=0.07; this.drawRadar(); this.playerPanels();
    }
  },

  showEnd: function(){
    var s0 = SIM.teams[0].score, s1 = SIM.teams[1].score;
    this.el("eH").textContent = s0;
    this.el("eA").textContent = s1;
    var win = "";
    if(s0 > s1) win = t("e_win") + " · " + SET.home;
    else if(s1 > s0) win = t("e_win") + " · " + SET.away;
    else win = t("e_draw");
    this.el("eWin").textContent = win;
    this.stats("endStats");
    this.el("ovEnd").classList.remove("hide");
  },
  stats: function(id){
    var a=SIM.teams[0].stats, b=SIM.teams[1].stats, total=a.poss+b.poss;
    var home=total?Math.round(a.poss/total*100):50;
    function accuracy(s){ return s.attempt?Math.round(100*s.pass/s.attempt)+"%":"—"; }
    var rows=[[t("st_poss"),home+"%",100-home+"%"],[t("st_shots"),a.shots,b.shots],
      [t("st_target"),a.onT,b.onT],[t("st_pass"),a.pass,b.pass],[t("st_accuracy"),accuracy(a),accuracy(b)],
      [t("st_corr"),a.corr,b.corr],[t("st_fouls"),a.fouls,b.fouls],[t("st_yel"),a.yel,b.yel],[t("st_red"),a.red,b.red]];
    var table=document.createElement("table"), head=table.createTHead().insertRow();
    function cell(row,tag,value){var el=document.createElement(tag);el.textContent=value;row.appendChild(el);}
    [SET.home,"",SET.away].forEach(function(name){cell(head,"th",name);});
    var body=table.createTBody();
    rows.forEach(function(data){var row=body.insertRow();cell(row,"td",data[1]);cell(row,"th",data[0]);cell(row,"td",data[2]);});
    this.el(id).replaceChildren(table);
  },
  hideEnd: function(){ document.getElementById("ovEnd").classList.add("hide"); },

  /* pomoc sterowania — budowana z i18n */
  buildHelp: function(){
    var cols = document.getElementById("helpCols");
    if(!cols) return;
    function table(title, rows){
      var h = "<div><h3>" + title + "</h3><table class='keys'>";
      for(var i=0;i<rows.length;i++)
        h += "<tr><td>" + rows[i][0] + "</td><td>" + rows[i][1] + "</td></tr>";
      return h + "</table></div>";
    }
    var kk = function(k){ return "<span class='kbd'>" + k + "</span>"; };
    var padRows = [
      [kk("LS") + " / " + kk("D-PAD"), t("h_m_move")],
      [kk("A / ✕"), t("h_m_pass")],
      [kk("B / ◯"), t("h_m_shoot")],
      [kk("X / ▢"), t("h_m_tackle")],
      [kk("Y / △"), t("h_m_through")],
      [kk("RT / R2"), t("h_m_sprint")],
      [kk("LB / L1"), t("h_m_switch")],
      [kk("LB + A / L1 + ✕"),t("h_m_oneTwo")],
      [kk("RB + B / R1 + ◯"),t("h_m_finesse")],
      [kk("LT / L2"),t("h_m_jockey")],
      [kk("SELECT / SHARE"), t("h_m_cam")],
      [kk("START / OPTIONS"), t("h_m_pause")]
    ];
    var kb1 = [
      [kk("W") + kk("A") + kk("S") + kk("D"), t("h_m_move")],
      [kk("K"), t("h_m_pass")],
      [kk("L"), t("h_m_shoot")],
      [kk("J"), t("h_m_tackle")],
      [kk("I"), t("h_m_through")],
      [kk("SPACE") + " / " + kk("L-SHIFT"), t("h_m_sprint")],
      [kk("O"), t("h_m_switch")],
      [kk("O + K"), t("h_m_oneTwo")],
      [kk("Q + L"), t("h_m_finesse")],
      [kk("E"), t("h_m_jockey")],
      [kk("C"), t("h_m_cam")],
      [kk("+") + " / " + kk("−") + " · " + kk(I18N_cur==="pl"?"KÓŁKO":"WHEEL"), t("h_m_zoom")],
      [kk("ESC") + " / " + kk("ENTER"), t("h_m_pause")]
    ];
    var kb2 = [
      [kk("←") + kk("↑") + kk("↓") + kk("→"), t("h_m_move")],
      [kk(","), t("h_m_pass")],
      [kk("."), t("h_m_shoot")],
      [kk("/"), t("h_m_tackle")],
      [kk("M"), t("h_m_through")],
      [kk("R-SHIFT"), t("h_m_sprint")],
      [kk("N"), t("h_m_switch")],
      [kk("N + ,"), t("h_m_oneTwo")],
      [kk("H + ."), t("h_m_finesse")],
      [kk("B"), t("h_m_jockey")],
      ["—", t("h_m_cam") + " (C gr.1)"],
      [kk("ESC"), t("h_m_pause")]
    ];
    cols.innerHTML =
      table(t("h_pad"), padRows) +
      table(t("h_p1"), kb1) +
      table(t("h_p2"), kb2);
    document.getElementById("helpNote").textContent = t("h_note");
  }
};
