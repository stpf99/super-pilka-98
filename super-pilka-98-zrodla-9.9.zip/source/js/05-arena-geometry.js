// Geometria indeksowana, współrzędne w metrach. Lokalny +Z wskazuje przód postaci.
function ArenaGeometry(){
  this.p=[];this.c=[];this.uv=[];this.index=[];this.motion=[];this.palette=new Map();
}
ArenaGeometry.prototype.vertex=function(p,color,u,v,weight,action){
  var rgb=this.palette.get(color);
  if(!rgb){rgb=new THREE.Color(color).convertSRGBToLinear();this.palette.set(color,rgb);}
  var i=this.p.length/3;
  this.p.push(p[0],p[1],p[2]);this.c.push(rgb.r,rgb.g,rgb.b);this.uv.push(u||0,v||0);
  this.motion.push(weight||0,action||0);return i;
};
ArenaGeometry.prototype.face=function(a,b,c,d){
  this.index.push(a,b,c);if(d!==undefined)this.index.push(a,c,d);
};
ArenaGeometry.prototype.quad=function(a,b,c,d,color){
  var i=this.vertex(a,color,0,0);this.vertex(b,color,1,0);this.vertex(c,color,1,1);this.vertex(d,color,0,1);
  this.face(i,i+1,i+2,i+3);
};
ArenaGeometry.prototype.rings=function(rings,color,weight,action){
  var first=this.p.length/3,n=rings[0].length;
  for(var j=0;j<rings.length;j++)for(var k=0;k<n;k++){
    this.vertex(rings[j][k],color,k/n,j/(rings.length-1),Array.isArray(weight)?weight[j]:weight,action);
    if(j){var lo=first+(j-1)*n+k,nx=first+(j-1)*n+(k+1)%n;this.face(lo,nx,nx+n,lo+n);}
  }
  for(var h=1;h<n-1;h++){
    this.face(first,first+h+1,first+h);var end=first+(rings.length-1)*n;this.face(end,end+h,end+h+1);
  }
};
ArenaGeometry.prototype.loft=function(x,z,sections,n,color,weight,action){
  var rings=sections.map(function(s){var ring=[];
    for(var i=0;i<n;i++){var a=i*2*Math.PI/n;ring.push([x+s[1]*Math.sin(a),s[0],z+(s[3]||0)+s[2]*Math.cos(a)]);}
    return ring;
  });this.rings(rings,color,weight,action);
};
ArenaGeometry.prototype.oval=function(x,y,z,rx,ry,rz,color,n,w,a){
  this.loft(x,z,[[y-ry,rx*.25,rz*.24],[y-ry*.49,rx*.90,rz*.88],[y+ry*.29,rx,rz],
    [y+ry*.81,rx*.63,rz*.67],[y+ry,rx*.19,rz*.19]],n,color,w,a);
};
ArenaGeometry.prototype.rod=function(a,b,r0,r1,color,n,wa,wb,action){
  var axis=new THREE.Vector3(b[0]-a[0],b[1]-a[1],b[2]-a[2]).normalize();
  var right=(Math.abs(axis.y)<.94?new THREE.Vector3(0,1,0):new THREE.Vector3(0,0,1)).cross(axis).normalize();
  var tangent=axis.clone().cross(right),rings=[[],[]];n=n||6;
  for(var j=0;j<2;j++)for(var i=0;i<n;i++){
    var c=j?b:a,ang=i*2*Math.PI/n,r=j?r1:r0,cs=Math.cos(ang)*r,sn=Math.sin(ang)*r;
    rings[j].push([c[0]+right.x*cs+tangent.x*sn,c[1]+right.y*cs+tangent.y*sn,c[2]+right.z*cs+tangent.z*sn]);
  }
  this.rings(rings,color,[wa,wb],action);
};
ArenaGeometry.prototype.build=function(animated){
  var g=new THREE.BufferGeometry();g.setIndex(this.index);
  g.setAttribute("position",new THREE.Float32BufferAttribute(this.p,3));g.setAttribute("color",new THREE.Float32BufferAttribute(this.c,3));
  g.setAttribute("uv",new THREE.Float32BufferAttribute(this.uv,2));
  if(animated)g.setAttribute("fanMotion",new THREE.Float32BufferAttribute(this.motion,2));
  g.computeVertexNormals();g.computeBoundingSphere();return g;
};
function arenaTexture(w,h,paint){
  var canvas=document.createElement("canvas");canvas.width=w;canvas.height=h;
  if(paint)paint(canvas.getContext("2d"),w,h);
  var tex=new THREE.CanvasTexture(canvas);tex.encoding=THREE.sRGBEncoding;tex.anisotropy=4;return tex;
}
function arenaInstances(g,mat,items,group){
  var mesh=new THREE.InstancedMesh(g,mat,items.length);
  items.forEach(function(item,i){mesh.setMatrixAt(i,item.matrix);if(item.color)mesh.setColorAt(i,item.color);});
  group.add(mesh);return mesh;
}
function arenaMatrix(x,y,z,yaw,sx,sy,sz){
  var q=new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0,1,0),yaw);
  return new THREE.Matrix4().compose(new THREE.Vector3(x,y,z),q,new THREE.Vector3(sx,sy,sz));
}
