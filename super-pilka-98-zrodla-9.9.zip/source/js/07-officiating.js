/* Kontakty rozstrzygane w kroku fizyki, przed odsunięciem nachodzących na siebie graczy. */
var OFFICIAL = {
  start:function(p,slide){
    var speed=Math.hypot(p.vel.x,p.vel.z),fx=Math.sin(p.face),fz=Math.cos(p.face);
    p.challenge={slide:slide,face:p.face,speed:speed,t:0,won:false,
      footX:p.pos.x+.18*fx+.09*fz,footZ:p.pos.z+.18*fz-.09*fx};
  },
  hit:function(x,z,dx,dz,r){
    var distance=x*x+z*z-r*r;
    if(distance<=0)return 0;
    var length=dx*dx+dz*dz,dot=x*dx+z*dz,delta=dot*dot-length*distance;
    if(length<.0000001 || dot>=0 || delta<0)return Infinity;
    var t=(-dot-Math.sqrt(delta))/length;
    return t<=1?t:Infinity;
  },
  check:function(dt){
    var ps=SIM.players,b=SIM.ball;
    for(var i=0;i<ps.length;i++){
      var p=ps[i];
      if(p.off)continue;
      var c=p.challenge;
      if(!c)continue;
      var slide=c.slide;
      if((p.action!==(slide?"slide":"standtackle")) || (c.t+=dt)>(slide?.47:.28)){
        p.challenge=null;continue;
      }
      var fx=Math.sin(c.face),fz=Math.cos(c.face);
      var reach=.18+(slide?.71:.75)*Math.min(1,c.t/(slide?.14:.13));
      var x=p.pos.x+fx*reach+.09*fz,z=p.pos.z+fz*reach-.09*fx;
      var oldX=c.footX,oldZ=c.footZ,dx=x-oldX,dz=z-oldZ;
      c.footX=x;c.footZ=z;
      var ballHit=Infinity;
      if(!c.won && !b.owner?.keeperHold && b.y<.40){
        ballHit=this.hit(oldX-b.prevX,oldZ-b.prevZ,dx-(b.x-b.prevX),dz-(b.z-b.prevZ),SIM.BR+.13);
      }
      var v=null,bodyHit=Infinity;
      for(var j=0;j<ps.length;j++){
        var q=ps[j];if(q.off || q.team===p.team || q.action==="fallen")continue;
        var gap=Math.hypot(p.pos.x-q.pos.x,p.pos.z-q.pos.z);
        if(gap>1.52)continue;
        var hit=this.hit(oldX-q.prevX,oldZ-q.prevZ,dx-(q.pos.x-q.prevX),dz-(q.pos.z-q.prevZ),slide?.32:.28);
        // Contact with the hip/torso also counts if the boot missed on the other side.
        var body=this.hit(p.prevX-q.prevX,p.prevZ-q.prevZ,
          p.pos.x-p.prevX-(q.pos.x-q.prevX),p.pos.z-p.prevZ-(q.pos.z-q.prevZ),slide?.68:.59);
        hit=Math.min(hit,body);
        if(hit<bodyHit){bodyHit=hit;v=q;}
      }
      var won=c.won || ballHit<bodyHit-.015;
      if(v){
        var approach=(p.pos.x-v.pos.x)*Math.sin(v.face)+(p.pos.z-v.pos.z)*Math.cos(v.face);
        var dist=Math.hypot(b.x-v.pos.x,b.z-v.pos.z);
        var late=(b.lastKicker===v && !b.owner && b.flightAge<.72 && dist>.50) || dist>1.55;
        var borderline=REFSTRICT[SET.ref]-1;
        var risky=slide && c.speed>=6.8 && (approach<-.27 || late);
        var protects=b.owner===v && v.keeperHold;
        if(!won || risky || protects){
          p.challenge=null;
          var severity=risky?"excessive":slide && (c.speed>4.6-.80*borderline || approach<-.26 || late)?"reckless":"careless";
          var kind=protects?"keeperContact":slide?(late?"lateTackle":"slidingFoul"):late?"lateTackle":"trip";
          RULES.foul(p,v,{kind:kind,severity:severity,attempt:!protects && !late && dist<1.48});
          return true;
        }
      }
      if(!c.won && ballHit<Infinity){
        c.won=true;
        if(!slide){SIM.takeBall(p);p.challenge=null;}
        else{
          if(b.owner)b.owner.keeperHold=false;
          b.owner=null;b.receiver=null;b.route=null;b.cushion=null;b.flight="block";b.curve=0;
          b.x=x+fx*.12;b.z=z+fz*.12;b.vx=fx*(5.9+.29*c.speed);b.vz=fz*(5.9+.29*c.speed);
          b.vy=.58;b.flightAge=0;b.shotTeam=null;b.lastShotBy=null;b.lastTouchTeam=p.team;b.lastKicker=p;b.lock=.25;
          SIM.events.push({type:"touch",player:p});
        }
        AUDIO.kick(.26);
      }
    }
    // An opponent may charge the carrier while sprinting without pressing either tackle button.
    var carrier=b.owner;
    if(!carrier)return false;
    for(var j=0;j<ps.length;j++){
      var d=ps[j];
      if(d.off || d.team===carrier.team || d.challenge || d.challengeCd>0 || !d.moveTarget?.sprint || d.action!=="run")continue;
      var rx=carrier.pos.x-d.pos.x,rz=carrier.pos.z-d.pos.z,gap=Math.hypot(rx,rz);
      if(gap<.01 || gap>.87)continue;
      var closing=((d.vel.x-carrier.vel.x)*rx+(d.vel.z-carrier.vel.z)*rz)/gap;
      var back=(rx*Math.sin(carrier.face)+rz*Math.cos(carrier.face))/gap;
      var ballClear=Math.hypot(b.x-d.pos.x,b.z-d.pos.z)>.69;
      // A fair shoulder-to-shoulder contest is allowed.
      if(closing>4.35-(REFSTRICT[SET.ref]-1)*.88 && back>.48 && ballClear){
        d.challengeCd=.8;
        RULES.foul(d,carrier,{kind:"charge",severity:closing>6.5?"reckless":"careless",attempt:false});
        return true;
      }
    }
    return false;
  },
  attack:function(offender,victim){
    var goal=SIM.dirX(victim.team)*HL,dx=goal-victim.pos.x,dz=-victim.pos.z,dist=Math.hypot(dx,dz);
    var b=SIM.ball,near=Math.hypot(b.x-victim.pos.x,b.z-victim.pos.z);
    if(b.shotTeam!==null || dist<.1 || dist>40 || (b.owner!==victim && !(near<1.15 && b.y<1.55 && !b.owner)))return "";
    var speed=Math.hypot(victim.vel.x,victim.vel.z);
    var direction=speed>.8?(victim.vel.x*dx+victim.vel.z*dz)/(speed*dist):
      (Math.sin(victim.face)*dx+Math.cos(victim.face)*dz)/dist;
    if(direction<.48)return "";
    var cover=0;
    SIM.teamPlayers(offender.team).forEach(function(d){
      if(d===offender)return;
      var x=d.pos.x-victim.pos.x,z=d.pos.z-victim.pos.z,along=(x*dx+z*dz)/dist,side=Math.abs(x*dz-z*dx)/dist;
      if(along>-.45 && along<dist+1.4 && side<2.3+Math.max(0,along)*.17)cover++;
    });
    if(dist<29 && direction>.65 && cover<=1 && Math.abs(victim.pos.z)<16)return "dogso";
    return dist<37 && cover<3?"promising":"";
  },
  decision:function(p,v,incident,inBox){
    var min=(RULES.half-1)*45+45*RULES.elapsed/SET.half;
    p.foulLoad=Math.max(0,p.foulLoad-Math.max(0,min-(p.lastFoulMinute??min))*.07)+1;
    p.lastFoulMinute=min;p.foulCount++;
    var attack=this.attack(p,v),card=null,reason=incident.kind;
    if(incident.severity==="excessive"){card="red";reason="serious";}
    else if(attack==="dogso"){card=inBox && incident.attempt?"yellow":"red";reason=attack;}
    else if(incident.severity==="reckless"){card="yellow";reason="reckless";}
    else if(attack==="promising" && !(inBox && incident.attempt)){card="yellow";reason=attack;}
    else if(p.foulCount>=3 && p.foulLoad>2.85-(REFSTRICT[SET.ref]-1)*.65){card="yellow";reason="persistent";}
    if(card)p.foulLoad=0;
    return {card:card,reason:reason};
  }
};
