/* ============================================================
   SUPER PILKA '98 · 03-audio.js — proceduralne dźwięki WebAudio
   ============================================================ */
var AUDIO = {
  ctx: null, master: null, crowdGain: null, roarGain: null,
  ok: false, excitement: 0.15, _fwT: 4,

  init: function(){
    if(this.ok) return;
    try{
      var AC = window.AudioContext || window.webkitAudioContext;
      this.ctx = new AC();
      this.master = this.ctx.createGain();
      this.master.gain.value = SET.snd;
      this.master.connect(this.ctx.destination);
      this._crowd();
      this.ok = true;
    }catch(e){ this.ok = false; }
  },
  setVolume: function(){ if(this.master) this.master.gain.value = SET.snd; },
  resume: function(){ if(this.ctx && this.ctx.state === "suspended") this.ctx.resume(); },

  _noiseBuf: function(sec, brown){
    var n = Math.floor(this.ctx.sampleRate * sec), b = this.ctx.createBuffer(1, n, this.ctx.sampleRate);
    var d = b.getChannelData(0), last = 0;
    for(var i=0;i<n;i++){
      var w = Math.random()*2-1;
      if(brown){ last = (last + 0.02*w) / 1.02; d[i] = last*3.2; } else d[i] = w;
    }
    return b;
  },
  _crowd: function(){
    var src = this.ctx.createBufferSource();
    src.buffer = this._noiseBuf(2.4, true); src.loop = true;
    var lp = this.ctx.createBiquadFilter(); lp.type="lowpass"; lp.frequency.value=430;
    this.crowdGain = this.ctx.createGain(); this.crowdGain.gain.value = 0.12;
    src.connect(lp); lp.connect(this.crowdGain); this.crowdGain.connect(this.master);
    src.start();
    /* warstwa „huku” do kibiców */
    var r = this.ctx.createBufferSource();
    r.buffer = this._noiseBuf(2.0, false); r.loop = true;
    var bp = this.ctx.createBiquadFilter(); bp.type="bandpass"; bp.frequency.value=900; bp.Q.value=0.6;
    this.roarGain = this.ctx.createGain(); this.roarGain.gain.value = 0;
    r.connect(bp); bp.connect(this.roarGain); this.roarGain.connect(this.master);
    r.start();
  },
  excitementSet: function(v){ this.excitement = Math.max(0, Math.min(1, v)); },
  update: function(dt){
    if(!this.ok) return;
    var target = 0.10 + this.excitement*0.38;
    this.crowdGain.gain.value += (target - this.crowdGain.gain.value) * Math.min(1, dt*2.2);
    /* gwizdy z trybun — od czasu do czasu, częściej przy emocjach */
    this._fwT -= dt;
    if(this._fwT <= 0){
      this._fwT = 6 + Math.random()*9 - this.excitement*4;
      if(this.excitement > 0.14) this.fanWhistle(0.5 + this.excitement*0.5);
    }
  },
  /* seria krótkich gwizdów kibiców (protest / nerwy na trybunach) */
  fanWhistle: function(strength){
    if(!this.ok) return;
    var self = this;
    strength = strength || 0.6;
    var now = this.ctx.currentTime + 0.02;
    var n = 2 + (Math.random()*3|0);
    for(var i=0;i<n;i++){
      var t0 = now + i*0.16 + Math.random()*0.08;
      var o = this.ctx.createOscillator(), g = this.ctx.createGain();
      o.type = "square"; o.frequency.value = 2300 + Math.random()*700;
      var trem = this.ctx.createOscillator(), tg = this.ctx.createGain();
      trem.frequency.value = 40 + Math.random()*30; tg.gain.value = 500;
      trem.connect(tg); tg.connect(o.frequency);
      g.gain.setValueAtTime(0.0001, t0);
      g.gain.linearRampToValueAtTime(0.035*strength, t0+0.02);
      g.gain.exponentialRampToValueAtTime(0.0001, t0+0.30+Math.random()*0.2);
      o.connect(g); g.connect(this.master);
      o.start(t0); o.stop(t0+0.55); trem.start(t0); trem.stop(t0+0.55);
    }
  },
  roar: function(strength){
    if(!this.ok) return;
    strength = strength || 1;
    var now = this.ctx.currentTime;
    this.roarGain.gain.cancelScheduledValues(now);
    this.roarGain.gain.setValueAtTime(this.roarGain.gain.value, now);
    this.roarGain.gain.linearRampToValueAtTime(0.55*strength, now+0.12);
    this.roarGain.gain.exponentialRampToValueAtTime(0.001, now+2.6*strength);
  },
  whistle: function(kind){ /* 1 krótki, 2 podwójny, 3 długi (koniec), 4 potrójny */
    if(!this.ok) return;
    var self = this;
    function peep(t0, dur, f){
      var o = self.ctx.createOscillator(), g = self.ctx.createGain();
      o.type="square"; o.frequency.value = f || 2350;
      var trem = self.ctx.createOscillator(), tg = self.ctx.createGain();
      trem.frequency.value = 31; tg.gain.value = 380;
      trem.connect(tg); tg.connect(o.frequency);
      g.gain.setValueAtTime(0.0001, t0);
      g.gain.linearRampToValueAtTime(0.14, t0+0.02);
      g.gain.setValueAtTime(0.14, t0+dur-0.04);
      g.gain.exponentialRampToValueAtTime(0.0001, t0+dur);
      o.connect(g); g.connect(self.master);
      o.start(t0); o.stop(t0+dur+0.02); trem.start(t0); trem.stop(t0+dur+0.02);
    }
    var now = this.ctx.currentTime + 0.02;
    if(kind===1) peep(now, 0.32);
    else if(kind===2){ peep(now,0.14); peep(now+0.2,0.3); }
    else if(kind===3) peep(now, 1.0, 2400);
    else { peep(now,0.16); peep(now+0.22,0.16); peep(now+0.44,0.7); }
  },
  kick: function(power){
    if(!this.ok) return;
    var now = this.ctx.currentTime, p = Math.min(1, power||0.5);
    var src = this.ctx.createBufferSource(); src.buffer = this._noiseBuf(0.09,false);
    var lp = this.ctx.createBiquadFilter(); lp.type="lowpass";
    lp.frequency.value = 500 + 900*p;
    var g = this.ctx.createGain();
    g.gain.setValueAtTime(0.22+0.3*p, now);
    g.gain.exponentialRampToValueAtTime(0.001, now+0.09);
    src.connect(lp); lp.connect(g); g.connect(this.master); src.start(now);
    var o = this.ctx.createOscillator(), g2 = this.ctx.createGain();
    o.type="sine"; o.frequency.setValueAtTime(95+40*p, now);
    o.frequency.exponentialRampToValueAtTime(45, now+0.1);
    g2.gain.setValueAtTime(0.3+0.35*p, now);
    g2.gain.exponentialRampToValueAtTime(0.001, now+0.12);
    o.connect(g2); g2.connect(this.master); o.start(now); o.stop(now+0.14);
  },
  bounce: function(v){
    if(!this.ok) return;
    var now = this.ctx.currentTime, p = Math.min(1, (v||1)/18);
    var o = this.ctx.createOscillator(), g = this.ctx.createGain();
    o.type="sine"; o.frequency.setValueAtTime(120, now);
    o.frequency.exponentialRampToValueAtTime(60, now+0.06);
    g.gain.setValueAtTime(0.05+0.14*p, now);
    g.gain.exponentialRampToValueAtTime(0.001, now+0.08);
    o.connect(g); g.connect(this.master); o.start(now); o.stop(now+0.09);
  },
  catchSnd: function(){
    if(!this.ok) return;
    var now = this.ctx.currentTime;
    var src = this.ctx.createBufferSource(); src.buffer = this._noiseBuf(0.12,false);
    var lp = this.ctx.createBiquadFilter(); lp.type="lowpass"; lp.frequency.value=350;
    var g = this.ctx.createGain(); g.gain.setValueAtTime(0.16, now);
    g.gain.exponentialRampToValueAtTime(0.001, now+0.12);
    src.connect(lp); lp.connect(g); g.connect(this.master); src.start(now);
  },
  horn: function(){
    if(!this.ok) return;
    var now = this.ctx.currentTime;
    var o = this.ctx.createOscillator(), g = this.ctx.createGain();
    o.type="sawtooth"; o.frequency.value=196;
    var o2 = this.ctx.createOscillator(); o2.type="sawtooth"; o2.frequency.value=294;
    g.gain.setValueAtTime(0.0001, now);
    g.gain.linearRampToValueAtTime(0.14, now+0.06);
    g.gain.setValueAtTime(0.14, now+0.5);
    g.gain.exponentialRampToValueAtTime(0.0001, now+0.8);
    o.connect(g); o2.connect(g); g.connect(this.master);
    o.start(now); o.stop(now+0.82); o2.start(now); o2.stop(now+0.82);
  },
  // Puls animacji pałek i krótkie frazy orkiestry korzystają ze wspólnego zegara stadionu.
  standBeat: function(beat,tour,goal){
    var bar=beat%32,level=tour?.22:goal?.13:.055;
    if(!tour&&!goal&&bar>=12)return;
    var now=this.ctx.currentTime,ctx=this.ctx,dest=this.master;
    function voice(type,hz,end,duration,amount,filter){
      var o=ctx.createOscillator(),g=ctx.createGain();
      o.type=type;o.frequency.setValueAtTime(hz,now);o.frequency.exponentialRampToValueAtTime(end,now+duration*.68);
      g.gain.setValueAtTime(.0001,now);g.gain.linearRampToValueAtTime(amount,now+(filter?.036:.009));g.gain.exponentialRampToValueAtTime(.0001,now+duration);
      if(filter){var f=ctx.createBiquadFilter();f.type="lowpass";f.frequency.value=1250;f.Q.value=.8;o.connect(f);f.connect(g);}
      else o.connect(g);
      g.connect(dest);o.start(now);o.stop(now+duration+.01);
    }
    voice("sine",beat%2?125:145,beat%2?64:53,.23,level*(beat%2?.68:1),false);
    var phrase=[294,0,349.23,392,0,349.23,294,0];
    if((tour||goal||bar<8)&&phrase[bar%8]&&bar%16<8){
      var note=phrase[bar%8];voice("sawtooth",note*.988,note,bar%8===3?.39:.23,level*.32,true);
    }
  },
  card: function(){ this.whistle(1); },
  ui: function(){
    if(!this.ok) return;
    var now = this.ctx.currentTime;
    var o = this.ctx.createOscillator(), g = this.ctx.createGain();
    o.type="square"; o.frequency.value=740;
    g.gain.setValueAtTime(0.06, now);
    g.gain.exponentialRampToValueAtTime(0.001, now+0.05);
    o.connect(g); g.connect(this.master); o.start(now); o.stop(now+0.06);
  }
};
function UI_click(){ AUDIO.ui(); }
