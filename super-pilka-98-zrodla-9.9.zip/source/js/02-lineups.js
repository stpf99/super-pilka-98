/* Każda pozycja jest podana dla drużyny atakującej w stronę +X. */
var LINEUP = {
  forms: {
    "4-4-2": [[-50,0],[-29,-24],[-34,-8],[-34,8],[-29,24],[-8,-23],[-13,-7],[-13,7],[-8,23],[9,-8],[9,8]],
    "4-3-3": [[-50,0],[-29,-24],[-34,-8],[-34,8],[-29,24],[-9,-14],[-17,0],[-9,14],[7,-23],[12,0],[7,23]],
    "4-2-3-1": [[-50,0],[-29,-24],[-34,-8],[-34,8],[-29,24],[-18,-8],[-18,8],[-1,-22],[1,0],[11,0],[-1,22]]
  },
  roles: {
    "4-4-2": ["GK","DF","DF","DF","DF","MF","MF","MF","MF","FW","FW"],
    "4-3-3": ["GK","DF","DF","DF","DF","MF","MF","MF","FW","FW","FW"],
    "4-2-3-1": ["GK","DF","DF","DF","DF","MF","MF","MF","MF","FW","MF"]
  },
  names: [
    ["Wrona","Sikora","Zając","Górski","Kruk","Lis","Mazur","Kowal","Borek","Wilk","Duda"],
    ["Mróz","Brzoza","Wolski","Nowicki","Latoń","Sowa","Kurek","Urban","Drozd","Sarna","Lasota"]
  ],
  numbers: [1,2,4,5,3,7,6,8,11,9,10],
  formation: function(team){ return SET[team===0 ? "formH" : "formA"]; },
  tactic: function(team){ return SET[team===0 ? "tacticH" : "tacticA"]; },
  apply: function(team){
    var name = this.formation(team);
    SIM.teamPlayers(team).forEach(function(p){
      if(p.emergencyGK)return;
      var coord = LINEUP.forms[name][p.idx];
      p.home = { x:coord[0], z:coord[1] };
      p.role = LINEUP.roles[name][p.idx];
    });
  }
};
