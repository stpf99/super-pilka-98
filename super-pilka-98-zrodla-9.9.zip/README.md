# Super Piłka ’98

Samodzielna gra piłkarska 3D na komputer. Otwórz `super-pilka-98.html` w przeglądarce z obsługą WebGL. Gra działa z dysku, także offline. Przed meczem możesz ustawić tryb solo, dwóch graczy lokalnie lub mecz dwóch drużyn komputerowych.

## Transmisja TV 2000

Kamera **TV 2000** prowadzi akcję wzdłuż linii bocznej. Przy rozpoczęciu obejmuje koło środkowe. Przy rzucie rożnym, karnym i wykopie ustawia się za wykonawcą. Klawiszami w lewo i prawo lub lewą gałką obracasz strzałkę. Przytrzymaj i puść strzał, żeby posłać piłkę we wskazanym kierunku. Przed uderzeniem zawodnik robi rozbieg. Krótkie rozegranie dobiera partnera po tej stronie.

Po golu strzelec biegnie przed kamerę, a najbliżsi koledzy ruszają za nim. Podczas napomnienia sędzia podnosi kartkę przed ukaranym zawodnikiem. Belka podaje numer, nazwisko, drużynę i minutę. **C** lub **Select** pomija aktualne ujęcie. Przy odpowiednio długiej akcji po golu następuje powtórka.

## Podgląd zawodników

W zakładce **Drużyny** kliknij **Obejrzyj model 3D**. Przeciągaj myszą, by obracać postać. Wybierz ruch i kadr. Parada bramkarza pokazuje zawodnika w rękawicach. Podczas meczu klawisz **C** przełącza cztery kamery, w tym kamerę zza zawodnika. Kółko i klawisze **+** oraz **−** zmieniają zbliżenie.

Wybierz **Mimika**, aby obejrzeć z bliska powieki i ruch ust. Przeciągnij model w bok, żeby obejrzeć skronie, uszy i kark. Wśród ruchów są także cztery przyjęcia z piłką. W meczu zawodnik dobiera kontakt głową, klatką, udem lub stopą do wysokości podania. Aby zgasić dośrodkowanie w polu karnym, przytrzymaj bliską kontrolę (**E** dla pierwszego gracza, **B** dla drugiego, **LT / L2** na padzie).

## Przeciwnik i ustawienie do piłki

W ustawieniach meczu wybierz **Początkujący**, **Łatwy**, **Normalny** lub **Trudny**. Nowa instalacja zaczyna na poziomie początkującym. Przy aktualizacji gra odczytuje wcześniejszy wybór. W grze solo poziom reguluje szybkość przeciwnika, czas na opanowanie podania przed pressingiem, rozrzut podań i strzałów oraz interwencje bramkarza. Na początkującym obrona czeka około 1,55 sekundy od przejęcia piłki przed aktywnym doskokiem. Na łatwym około 0,95 sekundy. Obrońca może w tym czasie zająć pozycję i przeciąć podanie. Zawodnik oczekujący na piłkę i bramkarz śledzą ją tułowiem i głową. Obrońca może biec bokiem lub cofać się twarzą do akcji.

## Decyzje sędziego

**L** wykonuje odbiór na stojąco, **J** wślizg. W grze na padzie są to **B / ◯** oraz **X / □**. Sędzia sprawdza kolejność kontaktu stopy z piłką i przeciwnikiem, prędkość wejścia, kierunek i możliwość zagrania piłki. Rozróżnia m.in. podstawienie nogi, spóźniony atak, wślizg w nogi, niedozwolone szarżowanie i atak na bramkarza trzymającego piłkę. Te reguły obejmują obie drużyny.

Nieostrożny kontakt zwykle kończy się rzutem wolnym lub karnym. Nierozważne wejście grozi żółtą kartką, a poważny, rażący faul bezpośrednią czerwoną. Przy ocenie pozbawienia realnej szansy na bramkę gra uwzględnia kierunek ataku, kontrolę piłki, odległość od bramki i asekurację. W polu karnym rozróżnia spóźnioną próbę zagrania piłki od szarży bez takiej próby. Przy drugiej żółtej sędzia najpierw pokazuje napomnienie, opuszcza rękę i podnosi czerwoną. Belka podaje nazwisko, minutę i powód. [Przepis 12 IFAB](https://www.theifab.com/laws/latest/fouls-and-misconduct/)

### Porównanie z rzeczywistym meczem

| Sytuacja | Stan w tej wersji |
|---|---|
| Faule kontaktowe, kartki i karne | Sędzia ocenia zarejestrowany kontakt. Zespół ukaranego czerwoną gra w osłabieniu. |
| Spalony | Gra wykrywa dotknięcie piłki przez gracza na spalonym i przyznaje wolny pośredni. Sędzia sygnalizuje go uniesioną ręką. Nie rozpoznaje zasłonięcia bramkarzowi widoku przez zawodnika bez kontaktu z piłką. |
| Korzyść | Sędzia gwiżdże po wykryciu faulu. Brakuje gry na korzyść i powrotu do przewinienia, gdy akcja się nie rozwinie. |
| Ręka i gra bramkarza | Bramkarz łapie i paruje strzały. Gra nie ocenia ustawienia ręki zawodnika z pola ani czasu trzymania piłki w rękach przez bramkarza. |
| Zmiany i urazy | Można zmienić formację. Rezerwowi na ławce nie wchodzą za zmęczonego lub kontuzjowanego zawodnika. |
| Czas meczu | Są dwie połowy i przerwa. Zegar zatrzymuje się podczas przerw w grze. Nie ma oddzielnego czasu doliczonego 45+ i 90+. |

Punktem odniesienia są przepisy IFAB dotyczące sędziego, spalonego, liczby zawodników i czasu gry. [Sędzia](https://www.theifab.com/laws/latest/the-referee/) · [Spalony](https://www.theifab.com/laws/latest/offside/) · [Zawodnicy](https://www.theifab.com/laws/latest/the-players/) · [Czas gry](https://www.theifab.com/laws/latest/the-duration-of-the-match/)

## Stadion i doping

W menu głównym lub podczas pauzy wybierz **Zwiedź stadion**. Widoki **Gospodarze** i **Goście** prowadzą do sektorów obu klubów. **Bęben** i **Trąbka** przybliżają muzyków wybranego sektora. **Z murawy** pokazuje zadaszenie oraz galerię nad trybuną główną z perspektywy boiska. Wybieraj ujęcia przyciskami albo strzałkami w lewo i w prawo. **Esc** przywraca poprzedni widok. Nazwy drużyn z menu pojawiają się na szalikach, transparentach i bandach LED. Doping korzysta z ustawienia głośności gry.

## Sterowanie

| Akcja | Gracz 1 | Gracz 2 | Pad Xbox / PlayStation |
|---|---|---|---|
| Ruch i celowanie | WASD | Strzałki | Lewa gałka lub krzyżak |
| Podanie / pressing | K | Przecinek | A / ✕ |
| Strzał / odbiór na stojąco | L | Kropka | B / ◯ |
| Dośrodkowanie / wślizg | J | Ukośnik | X / □ |
| Podanie prostopadłe | I | M | Y / △ |
| Sprint | Lewy Shift lub spacja | Prawy Shift | RT / R2 |
| Bliski drybling / obrona bokiem | E | B | LT / L2 |
| Strzał techniczny | Q + L | H + kropka | RB + B / R1 + ◯ |
| Podaj i wyjdź na pozycję | O + K | N + przecinek | LB + A / L1 + ✕ |
| Zmiana obrońcy | O | N | LB / L1 |
| Pauza | Esc | Esc | Start / Options |

Przytrzymaj podanie albo strzał, aby ustalić siłę, i puść przycisk. Przy kombinacjach trzymaj modyfikator podczas ładowania. Po zagraniu bez ruchu gałką lub klawiaturą adresat sam wybiega do podania. Przy wznowieniu od środka użyj podania.

## Zbudowanie pełnej gry ze źródeł

W rozpakowanym katalogu uruchom poniższe polecenie.

```bash
python3 build.py
```

Powstanie `super-pilka-98.html`. Skrypt korzysta ze standardowej biblioteki Pythona. Silnik Three.js jest dołączony w katalogu `source`.

Osiem twarzy jest zapisanych w teksturze `source/art/twarze.webp`. Podczas budowania obraz trafia do pliku HTML. Atlas zawiera skórę od kołnierza po czubek głowy oraz warianty powiek i ust. Siatkę głowy i materiał obsługuje `source/js/05-face.js`, a przyjęcia piłki `source/js/06-reception.js`. Po edycji ośmiu portretów w `tools/portrety.webp` można odtworzyć atlas poleceniem `python3 tools/bake_faces.py` (Pillow i NumPy). Modele i materiały znajdują się w `source/js/05-athletes.js`, animacje stawów w `source/js/05-motion.js`, a podgląd postaci w `source/js/10-showroom.js`.

Bryła stadionu i sektory są w `source/js/05-stadium.js`, modele i animacje kibiców w `source/js/05-supporters.js`, a murawa, piłka i siatki bramek w `source/js/05-pitch.js`.
