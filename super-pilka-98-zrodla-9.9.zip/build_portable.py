#!/usr/bin/env python3
"""Zgodność z poprzednią wersją archiwum."""
from build import build

if __name__ == "__main__":
    build()
