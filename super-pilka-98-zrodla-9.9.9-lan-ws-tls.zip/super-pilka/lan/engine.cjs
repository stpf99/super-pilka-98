/* Authoritative 60 Hz match worker. No window or GPU is needed on the host. */
'use strict';
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),readline=require('node:readline');
const root=path.join(__dirname,'../source'),database=fs.readFileSync(path.join(root,'data/teams.json'),'utf8');
/* Migawki co 3 ticki (60/3 = 20 Hz) — poz. 6 „Hz”; save co 2 s bez zmian. */
const SNAP_EVERY=3,SAVE_EVERY=120;
let seed=19780321,tick=0,paused=false,started=false,events=[],seq=0,eventId=0,seats={},inputs={},records=[],hudEvent=null,tag="",power=0;
const math=Object.create(Math);math.random=()=>((seed=(Math.imul(seed,1664525)+1013904223)>>>0)/4294967296);
const noop=()=>{}, xyz=()=>({x:0,y:0,z:0,set(x,y,z){Object.assign(this,{x,y,z});}}),stubs=new Proxy({},{get:()=>noop});
function actor(team,gk,n){return {scale:{y:.97+((n+17*team)%7)*.012},position:xyz(),rotation:xyz(),userData:{phase:((n+17*team)*.37)%1,kickLeg:n%4?1:0}};}
const W={makePlayer:actor,removePlayer:noop,teleMsg:noop,aimArrow:{position:xyz(),rotation:xyz()},staff:{card:{material:{color:{setHex:noop}}}}};
function note(type,data){events.push({id:++eventId,t:tick/60,type,data});events=events.slice(-12);}
const HUD=new Proxy({event:(type,title,min,name,team,reason)=>{hudEvent={type,title,min,name,team,reason};note('event',hudEvent);},hideEvent:()=>{hudEvent=null;},
 banner:(title,detail)=>note('banner',{title,detail}),restartTagShow:s=>{tag=s;},restartTagHide:()=>{tag="";},showPower:n=>{power=n||0;}},{get:(o,k)=>k in o?o[k]:noop});
const ctx={Math:math,console:{log:noop,warn:noop,error:console.error},HL:52.5,HW:34,GOAL_H:2.44,GOAL_W:7.32,GK_R:.06,
 WORLD:W,HUD,AUDIO:stubs,STADIUM:stubs,PITCH:stubs,REC:{reset:noop,canReplay:()=>false},REPLAY:stubs,
 VOICE:{speak:(keys,urgent)=>note('voice',{keys,urgent}),anthem:t=>note('anthem',t),stopMusic:()=>note('musicStop',null)},
 MAIN:{chargeS:[0,0],chargeP:[0,0]},INPUT:{slots:[{},{}],padSeen:[false,false]},CAM:{fieldInput:(x,z)=>({x,z})},localStorage:{getItem:()=>null},window:{},document:{getElementById:()=>null}};
vm.createContext(ctx);
for(const f of ['01-i18n','02-countries','02-lineups','02-settings','05-conditions','05-face','05-motion','06-first-touch','06-human','06-reception','06-sim','07-ai','07-officiating','08-broadcast','08-ceremony','08-matchday','08-rules']){
 let code=fs.readFileSync(path.join(root,'js',f+'.js'),'utf8').replace('/*SQUADS*/null',()=>database);
 vm.runInContext(code,ctx,{filename:f});
}
const {SIM:S,RULES:R,SET,AI,MATCHDAY:D,BROADCAST:B,CEREMONY:C}=ctx;
S.syncMeshes=noop;R.humanTaker=team=>!!(R.taker && R.taker.team===team && R.taker.netHuman);
function emit(obj){process.stdout.write(JSON.stringify(obj)+'\n');}
function pack(value,top){
 if(!value || typeof value!=='object')return value;
 if(!top){let i=S.players.indexOf(value);if(i>=0)return {$p:i};}
 if(Array.isArray(value))return value.map(v=>pack(v,false));
 let out={};for(const [k,val] of Object.entries(value)){
   if(['mesh','extra','netHuman','nick','isUser','user'].includes(k)||typeof val==='function')continue;
   out[k]=pack(val,false);
 }return out;
}
function unpack(o){
 if(!o || typeof o!=='object')return o;
 if(Object.hasOwn(o,'$p'))return S.players[o.$p];
 if(Array.isArray(o))return o.map(unpack);
 return Object.fromEntries(Object.entries(o).map(([k,v])=>[k,unpack(v)]));
}
function checkpoint(){return {version:1,tick,seed,eventId,events,records,hudEvent,tag,paused,players:S.players.map(p=>pack(p,true)),teams:S.teams.map(t=>pack(t,true)),
 ball:pack(S.ball,true),rules:pack(R,true),day:pack(D,true),scene:pack(B.scene,true),ceremony:pack(C,true),frozen:AI.frozen};}
function restore(a){
 if(!a || a.version!==1)return;
 S.players.forEach((p,i)=>{Object.assign(p,unpack(a.players[i]));p.mesh=p.off?null:actor(p.team,p.role==='GK',p.num);});
 S.teams.forEach((t,i)=>Object.assign(t,unpack(a.teams[i])));
 Object.assign(S.ball,unpack(a.ball));Object.assign(R,unpack(a.rules));Object.assign(D,unpack(a.day));Object.assign(C,unpack(a.ceremony));
 B.scene=unpack(a.scene);AI.frozen=a.frozen;tick=a.tick;seed=a.seed;eventId=a.eventId;events=a.events||[];records=a.records||[];hudEvent=a.hudEvent;tag=a.tag;paused=a.paused;
}
function snapshot(){
 const id=p=>p?S.players.indexOf(p):-1,b=S.ball;
 return {seq:++seq,t:tick/60,half:R.half,clock:R.elapsed,added:D.added,state:R.state,stateT:R.stateT,paused,score:S.teams.map(t=>t.score),dir:S.teams[0].dir,
 team:R.restartTeam,taker:id(R.taker),hero:id(B.scene?.hero),trick:B.scene?.trick,ce:C.stage,winner:C.winner,tag,power,hud:hudEvent,events,adv:!!D.adv,indirect:R.freeIndirect,
 ref:B.scene?.ref||null,card:B.scene?.stage||null,cardTime:B.scene?.stageTime||0,second:B.scene?.second,forward:B.scene?.forward,actors:(B.scene?.actors||[]).map(id),aim:R.taker?.face||0,
 ball:[b.x,b.y,b.z,b.vx,b.vy,b.vz,id(b.owner),id(b.receiver),b.lastTouchTeam],stats:S.teams.map(t=>t.stats),
 bench:S.teams.map(t=>t.bench),changes:S.teams.map(t=>t.changes),
 players:S.players.map(p=>[+p.pos.x.toFixed(3),+p.pos.z.toFixed(3),+p.face.toFixed(3),+p.vel.x.toFixed(2),+p.vel.z.toFixed(2),+p.stridePhase.toFixed(3),p.off?'run':S.visualAction(p),+S.visualTime(p).toFixed(3),p.num,p.name,+p.stamina.toFixed(2),+p.off,p.goals,p.yellows,p.role,p.fullName,p.trapLeg??p.dribbleFoot??0,p.trapHeight||0,p.diveSide||1,+p.turn.toFixed(3)])};
}
function controls(p,d,dt){
 // Wspólny moduł sterowania (06-human.js): te same akcje co w grze lokalnej,
 // siła podania/strzału z czasu przytrzymania zmierzonego u klienta.
 let st=p.ctl||(p.ctl=ctx.HUMAN.newState());
 let len=Math.hypot(d.x||0,d.z||0),field=len>.15?{x:(d.x||0)/len,z:(d.z||0)/len}:{x:0,z:0};
 ctx.HUMAN.drive(p.team,p,ctx.HUMAN.fromNet(d,st),field,st,dt,null);
}
function frame(){
 if(paused||!started||R.state==='fulltime')return;
 tick++;let before=R.state;
 for(let i=0;i<22;i++){
   let p=S.players[i],d=inputs[i];p.netHuman=!!seats[i];p.nick=seats[i]||null;p.isUser=p.netHuman?p.team:null;
   if(d && Date.now()-d.stamp>700){for(const k of ['x','z','mx','mz'])d[k]=0;for(const k of ['pass','shot','cross','through','skip','sprint','close','finesse','combo'])d[k]=false;
     if(p.ctl){p.ctl.chargeP=p.ctl.chargeS=0;p.ctl.combo=p.ctl.finesse=false;}}
 }
 ctx.INPUT.slots=[{},{}];
 if(R.taker?.netHuman){
   let i=S.players.indexOf(R.taker),d=inputs[i]||{};
   ctx.INPUT.slots[R.taker.team]={mx:d.mx||0,mz:d.mz||0,moveLen:Math.hypot(d.x||0,d.z||0),pass:d.pass,passP:d.passEdge,shoot:d.shot,camP:d.skipEdge};
 }
 if(R.state==='penalty'){
   const defending=1-R.restartTeam,goalie=S.playersOf(defending,'GK')[0],d=inputs[S.players.indexOf(goalie)];
   if(goalie?.netHuman && d)ctx.INPUT.slots[defending]={mx:d.mx||0};
 }
 if(Object.values(inputs).some(d=>d.skipEdge))ctx.INPUT.slots[0].camP=true;
 R.update(1/60);
 if(R.state==='play'){
   for(let i=0;i<22;i++)if(S.players[i].netHuman && !S.players[i].off)controls(S.players[i],inputs[i]||{x:0,z:0},1/60);
   AI.update(1/60);S.step(1/60);
 }
 for(const d of Object.values(inputs))for(const k of ['passEdge','crossEdge','throughEdge','shotEdge','shotUp','passUp','skipEdge'])d[k]=false;
 if(before!==R.state && ['goal','booking','substitution','penalty','halftime','fulltime'].includes(R.state))records.push({state:R.state,minute:D.minute(),score:S.teams.map(t=>t.score),detail:hudEvent?.name||R.lastScorer||''});
 if(tick%SNAP_EVERY===0 || before!==R.state){
   let msg={state:snapshot()};if(tick%SAVE_EVERY===0||before!==R.state)msg.save=checkpoint();emit(msg);
 }
}
readline.createInterface({input:process.stdin}).on('line',line=>{
 try{
   const m=JSON.parse(line);
   if(m.op==='start'){
     Object.assign(SET,m.config,{mode:2});ctx.I18N_cur=SET.lang||'pl';R.newMatch();restore(m.saved);
     seats=m.seats||{};started=true;emit({state:snapshot(),save:checkpoint()});
   }else if(m.op==='seat'){
     const next=m.seats||{};
     for(const i of Object.keys(inputs))if(next[i]!==seats[i]){
       delete inputs[i];S.players[i].netCharge=0;S.players[i].firstTouch=null;S.players[i].moveTarget=null;
     }
     seats=next;
   }
   else if(m.op==='input'&&seats[m.slot]){
     let d=inputs[m.slot]||(inputs[m.slot]={}),n=m.input;if(n.seq<=(d.seq??-1))return;
     for(const key of ['pass','shot','cross','through','skip','finesse','combo']){if(n[key]&&!d[key]||n[key+'Edge'])d[key+'Edge']=true;}
     if((!n.shot&&d.shot)||n.shotUp){d.shotUp=true;if(n.shotHold!=null)d.shotHold=n.shotHold;}
     if((!n.pass&&d.pass)||n.passUp){d.passUp=true;if(n.passHold!=null)d.passHold=n.passHold;}
     Object.assign(d,{x:n.x,z:n.z,mx:n.mx,mz:n.mz,seq:n.seq,stamp:Date.now()});for(const k of ['pass','shot','cross','through','skip','close','sprint','finesse','combo'])d[k]=!!n[k];
   }else if(m.op==='pause'){paused=m.value;emit({state:snapshot(),save:checkpoint()});}
   else if(m.op==='sub' && D.queue(m.team,m.idx,m.num)){if(R.state==='halftime')D.commit();emit({state:snapshot(),save:checkpoint()});}
   else if(m.op==='stop'){emit({state:snapshot(),save:checkpoint()});process.exitCode=0;clearInterval(timer);process.stdin.destroy();}
 }catch(e){console.error(e.stack);}
});
let last=performance.now(),debt=0;
const timer=setInterval(()=>{let now=performance.now();debt+=Math.min(.18,(now-last)/1000);last=now;while(debt>=1/60){debt-=1/60;frame();}},8);
process.stdin.on('end',()=>{clearInterval(timer);});
