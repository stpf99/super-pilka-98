#!/usr/bin/env python3
"""Super Piłka 98 LAN. python3 serve.py --port 8906 [--tls auto]"""
import argparse
import base64
import hashlib
import hmac
import json
import math
import os
from pathlib import Path
import secrets
import shutil
import signal
import socket
import sqlite3
import ssl
import struct
import subprocess
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit, parse_qs
from build import build
from tools.voice import speech

ROOT=Path(__file__).resolve().parent
DATA=json.loads((ROOT/'source/data/teams.json').read_text())
LOCK=threading.RLock()
workers={}
SNAP_HZ=20          # migawki stanu na sekundę (poz. 6: Hz)
WS_GUID='258EAFA5-E914-47DA-95CA-C5AB0DC85B11'
WS_MAX=262144       # maksymalny rozmiar wiadomości WebSocket
def js(x):return json.dumps(x,ensure_ascii=False,separators=(',',':'))
def query(sql,*args):
    with LOCK:return [dict(row) for row in db.execute(sql,args)]
def one(sql,*args):
    rows=query(sql,*args)
    return rows[0] if rows else None
def run(sql,*args):
    with LOCK,db:return db.execute(sql,args).lastrowid
def require(ok,message='Odmowa',code=400):
    if not ok:raise ApiError(code,message)
class ApiError(Exception):
    def __init__(self,code,message):self.code=code;super().__init__(message)
def label(value,limit=42):
    text=' '.join(str(value or '').split());require(1<=len(text)<=limit,'Nieprawidłowa nazwa')
    return text
def tokenhash(token):return hashlib.sha256(token.encode()).hexdigest()
def password(p,s):return hashlib.scrypt(p.encode(),salt=bytes.fromhex(s),n=16384,r=8,p=1).hex()
def init_database(folder):
    global db,conf,admin_key
    conf=folder;folder.mkdir(parents=True,exist_ok=True);(folder/'voices').mkdir(exist_ok=True)
    db=sqlite3.connect(folder/'liga.sqlite3',check_same_thread=False);db.row_factory=sqlite3.Row
    db.executescript("""
    PRAGMA journal_mode=WAL;
    CREATE TABLE IF NOT EXISTS profiles(id INTEGER PRIMARY KEY,nick TEXT NOT NULL,key TEXT UNIQUE,salt TEXT,pw TEXT);
    CREATE TABLE IF NOT EXISTS appearances(uid INTEGER,room INTEGER,slot INTEGER,PRIMARY KEY(uid,room));
    CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY,uid INTEGER,admin INTEGER DEFAULT 0,until INTEGER);
    CREATE TABLE IF NOT EXISTS clans(id INTEGER PRIMARY KEY,name TEXT UNIQUE,owner INTEGER);
    CREATE TABLE IF NOT EXISTS members(clan INTEGER,uid INTEGER,PRIMARY KEY(clan,uid));
    CREATE TABLE IF NOT EXISTS cups(id INTEGER PRIMARY KEY,name TEXT,scope TEXT,owner INTEGER);
    CREATE TABLE IF NOT EXISTS rooms(id INTEGER PRIMARY KEY,name TEXT,owner INTEGER,config TEXT,cup INTEGER DEFAULT 0,h INTEGER DEFAULT 0,a INTEGER DEFAULT 0,status TEXT DEFAULT 'ready',save TEXT,result TEXT);
    CREATE TABLE IF NOT EXISTS seats(room INTEGER,slot INTEGER,uid INTEGER,seen REAL,ready INTEGER DEFAULT 0,PRIMARY KEY(room,slot),UNIQUE(room,uid));
    CREATE TABLE IF NOT EXISTS chat(id INTEGER PRIMARY KEY,room INTEGER,uid INTEGER,nick TEXT,body TEXT,t REAL,scope TEXT DEFAULT 'room');
    """)
    # migracje dla starszych baz
    try:db.execute('ALTER TABLE seats ADD COLUMN ready INTEGER DEFAULT 0')
    except sqlite3.OperationalError:pass
    key=folder/'admin.key'
    if not key.exists():
        with open(os.open(key,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600),'w') as f:f.write(secrets.token_urlsafe(12))
    admin_key=key.read_text().strip()
def formation(code):
    team=DATA['teams'].get(code);require(team,'Nieznana reprezentacja')
    return team
def spec(m):
    nh=m.get('nationH','pol');na=m.get('nationA','eng')
    h,a=formation(nh),formation(na)
    def option(k,values,default):
        value=m.get(k,default);return value if value in values else default
    return dict(nationH=nh,nationA=na,home=label(m.get('home') or h['pl'],32),away=label(m.get('away') or a['pl'],32),
       half=option('half',[60,120,180,300,2700],120),diff=option('diff',[0,1,2,3],3),ref=option('ref',[0,1,2],1),mode=2,lang=option('lang',['pl','en'],'pl'),
       weather=option('weather',['clear','rain','snow','fog'],'clear'),stadium=option('stadium',['classic','arena','terrace'],'classic'),
       formH=option('formH',['4-3-3','4-4-2','4-2-3-1'],'4-3-3'),formA=option('formA',['4-3-3','4-4-2','4-2-3-1'],'4-4-2'),
       tacticH=option('tacticH',['balanced','press','counter'],'balanced'),tacticA=option('tacticA',['balanced','press','counter'],'balanced'),
       stripH=option('stripH',['home','away'],'home'),stripA=option('stripA',['home','away'],'away' if na==nh else 'home'),
       ballStyle=option('ballStyle',['classic','winter','wave'],'classic'),night=option('night',[0,1],0))
def roomrow(r):
    result=one('SELECT * FROM rooms WHERE id=?',r);require(result,'Brak meczu',404);return result
def seat_rows(room,active=False):
    rows=query('SELECT s.slot,p.nick,s.seen,COALESCE(s.ready,0) ready FROM seats s JOIN profiles p ON p.id=s.uid WHERE room=?',room)
    return [r for r in rows if not active or time.time()-r['seen']<6]
def seat_map(room,active=False):
    """mapa slot→nick (silnik + stare UI)"""
    return {str(r['slot']):r['nick'] for r in seat_rows(room,active)}
def seat_info(room,active=False):
    """mapa slot→{nick,ready} dla lobby"""
    return {str(r['slot']):{'nick':r['nick'],'ready':bool(r['ready'])} for r in seat_rows(room,active)}

# ============================================================
#  WebSocket (RFC 6455) bez zależności — poz. 6 z listy ulepszeń.
#  Jeden kanał przenosi stan meczu (SNAP_HZ), wejścia graczy,
#  czat, listę meczów i widzów na trybunach (poz. 7).
# ============================================================
class Hub:
    def __init__(self):
        self.lock=threading.Lock()
        self.rooms={}                 # room → set(WSConn)
        self.lobby=set()              # połączenia subskrybujące listę meczów
        self.watchers={}              # room → {'list':[...],'count':N} (cache)
        self.last_lobby=''
    def conns(self,room):
        with self.lock:return [c for c in self.rooms.get(room,()) if c.alive]
    def join(self,conn,room,mode):
        with self.lock:
            self.part_locked(conn)
            conn.room=room;conn.mode=mode
            if room>0:
                conns=self.rooms.setdefault(room,set());conns.add(conn)
                if mode=='fan':self.watchers_dirty(room)
            else:
                self.lobby.add(conn);conn.lobby_fresh=True
    def lobby_on(self,conn,on):
        with self.lock:
            if on:
                self.lobby.add(conn)
                fresh=not getattr(conn,'lobby_fresh',False);conn.lobby_fresh=True
            else:
                self.lobby.discard(conn);conn.lobby_fresh=False
                fresh=False
        return fresh
    def part_locked(self,conn):
        self.lobby.discard(conn)
        old=conn.room
        if old>0:
            conns=self.rooms.get(old)
            if conns:
                conns.discard(conn)
                if not conns:self.rooms.pop(old,None)
            if conn.mode=='fan':self.watchers_dirty(old)
        conn.room=0
    def drop(self,conn):
        with self.lock:self.part_locked(conn)
        conn.alive=False
    def watchers_dirty(self,room):
        """oznacza cache widzów do przebudowy (wywoływane pod self.lock)"""
        self.watchers.pop(room,None)
    def watcher_payload(self,room):
        with self.lock:
            payload=self.watchers.get(room)
            if payload is None:
                fans=[c for c in self.rooms.get(room,()) if c.mode=='fan' and c.alive]
                payload={'list':[{'nick':c.nick,'sector':c.fan['sector'],'row':c.fan['row'],'seat':c.fan['seat']} for c in fans[:48]],
                         'count':len(fans)}
                self.watchers[room]=payload
            return payload
    def fanseat(self,conn,fan):
        with self.lock:
            conn.fan={'sector':max(0,min(7,int(fan.get('sector',0) or 0))),
                      'row':max(1,min(14,int(fan.get('row',8) or 8))),
                      'seat':max(1,min(40,int(fan.get('seat',20) or 20)))}
            if conn.room>0 and conn.mode=='fan':self.watchers_dirty(conn.room);room=conn.room
            else:return None
        return room
    def push_state(self,room,state):
        """rozsyła migawkę do subskrybentów pokoju; wstrzykuje widzów"""
        conns=self.conns(room)
        payload=self.watcher_payload(room)
        state['watchers']=payload['list'];state['fans']=payload['count']
        if not conns:return
        text=js({'op':'state','state':state})
        for c in conns:c.send_text(text)
    def push_watchers(self,room):
        payload=self.watcher_payload(room)
        text=js({'op':'watchers','watchers':payload['list'],'fans':payload['count']})
        for c in self.conns(room):c.send_text(text)
    def push_chat(self,room,message):
        text=js({'op':'chat','message':message})
        for c in self.conns(room):c.send_text(text)
    def push_lobby(self,rooms):
        text=js({'op':'lobby','rooms':rooms})
        changed=text!=self.last_lobby
        if changed:self.last_lobby=text
        with self.lock:conns=list(self.lobby)
        for c in conns:
            if not c.alive:continue
            if changed or getattr(c,'lobby_fresh',False):
                c.send_text(text)
                c.lobby_fresh=False
    def ping_all(self):
        with self.lock:everyone=[c for conns in self.rooms.values() for c in conns]+list(self.lobby)
        for c in everyone:
            if c.alive:c.send_ping()
HUB=Hub()

class WSConn:
    """Jedno połączenie WebSocket obsługiwane w wątku HTTP."""
    def __init__(self,handler):
        self.h=handler;self.lock=threading.Lock();self.alive=True
        self.room=0;self.mode='fan';self.user=None;self.uid=0;self.nick=None
        self.fan={'sector':0,'row':8,'seat':20}
        self.budget=time.time()
    def _frame(self,opcode,payload=b''):
        n=len(payload);h=bytearray([0x80|opcode])
        if n<126:h.append(n)
        elif n<65536:h.append(126);h+=struct.pack('!H',n)
        else:h.append(127);h+=struct.pack('!Q',n)
        return bytes(h)+payload
    def send_text(self,text):
        if not self.alive:return
        try:
            with self.lock:self.h.connection.sendall(self._frame(1,text.encode()))
        except OSError:self.alive=False
    def send_ping(self):
        if not self.alive:return
        try:
            with self.lock:self.h.connection.sendall(self._frame(9))
        except OSError:self.alive=False
    def _pong(self,payload):
        try:
            with self.lock:self.h.connection.sendall(self._frame(10,payload))
        except OSError:self.alive=False
    def close(self,code=1000):
        try:
            with self.lock:self.h.connection.sendall(self._frame(8,struct.pack('!H',code)))
        except OSError:pass
        self.alive=False
    def read(self):
        """kolejna wiadomość tekstowa; ConnectionError przy zamknięciu"""
        h=self.h.rfile
        def need(n):
            data=h.read(n)
            if data is None or len(data)<n:raise ConnectionError('koniec strumienia')
            return data
        parts=[];final=None
        while True:
            head=need(2);b1,b2=head[0],head[1]
            fin=b1&0x80;opcode=b1&0x0f;masked=b2&0x80;ln=b2&0x7f
            if ln==126:ln=struct.unpack('!H',need(2))[0]
            elif ln==127:ln=struct.unpack('!Q',need(8))[0]
            require(ln<=WS_MAX,'Za duża wiadomość',1009)
            mask=need(4) if masked else None
            data=need(ln) if ln else b''
            if mask and data:data=bytes(b^mask[i%4] for i,b in enumerate(data))
            if opcode==8:raise ConnectionError('zamknięto')
            if opcode==9:self._pong(data);continue
            if opcode==10:continue
            if opcode in (1,2):
                if final is not None:raise ConnectionError('zła ramka')
                final=opcode;parts=[data]
            elif opcode==0:
                if final is None:raise ConnectionError('zła ramka')
                parts.append(data)
            if fin and final is not None:
                blob=b''.join(parts)
                if final==1:return blob.decode('utf-8','replace')
                raise ConnectionError('binarne ramki nieobsługiwane')

def ws_handshake(handler):
    key=handler.headers.get('Sec-WebSocket-Key')
    require(key and handler.headers.get('Upgrade','').lower()=='websocket','Brak ulepszenia WebSocket',400)
    origin=handler.headers.get('Origin')
    require(not origin or urlsplit(origin).netloc==handler.headers.get('Host'),'Nieprawidłowe pochodzenie',403)
    accept=base64.b64encode(hashlib.sha1((key+WS_GUID).encode()).digest()).decode()
    handler.send_response(101,'Switching Protocols')
    handler.send_header('Upgrade','websocket');handler.send_header('Connection','Upgrade')
    handler.send_header('Sec-WebSocket-Accept',accept)
    handler.end_headers()
    handler.close_connection=True

def sanitize_input(n):
    """wspólne czyszczenie pakietu wejścia (HTTP i WebSocket)"""
    ctrl={k:bool(n.get(k)) for k in ('pass','shot','cross','through','skip','passEdge','shotEdge','crossEdge','throughEdge','skipEdge','shotUp','passUp','sprint','close','finesse','combo')}
    for k in ('x','z','mx','mz'):
        v=float(n.get(k,0));require(math.isfinite(v),'Nieprawidłowy kierunek');ctrl[k]=max(-1,min(1,v))
    ctrl['seq']=int(n.get('seq',0))
    for k in ('passHold','shotHold'):
        try: v=float(n.get(k,0))
        except (TypeError,ValueError): v=0
        require(math.isfinite(v),'Nieprawidłowy czas przytrzymania');ctrl[k]=max(0,min(1.6,v))
    return ctrl

def store_chat(uid,nick,room,body,scope='room'):
    body=label(str(body or ''),160)
    require(body,'Pusta wiadomość')
    require(scope in ('room','team','watch'),'Nieprawidłowy zakres')
    t=time.time()
    cid=run('INSERT INTO chat(room,uid,nick,body,t,scope) VALUES(?,?,?,?,?,?)',room,uid,nick,body,t,scope)
    message={'id':cid,'nick':nick,'body':body,'t':t,'scope':scope}
    HUB.push_chat(room,message)
    return message

class Worker:
    def __init__(self,row):
        self.id=row['id'];self.condition=threading.Condition();self.frame=None;self.sequence=0;self.failed=False
        self.write_lock=threading.Lock();self.seats=seat_map(self.id,True)
        node=shutil.which('node') or shutil.which('nodejs');require(node,'Zainstaluj Node.js na gospodarzu',503)
        self.proc=subprocess.Popen([node,str(ROOT/'lan/engine.cjs')],cwd=ROOT,stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True,bufsize=1)
        self.thread=threading.Thread(target=self.read,daemon=True);self.thread.start()
        self.send(dict(op='start',config=json.loads(row['config']),saved=json.loads(row['save']) if row['save'] else None,seats=self.seats))
    def send(self,obj):
        try:
            with self.write_lock:self.proc.stdin.write(js(obj)+'\n');self.proc.stdin.flush()
        except (BrokenPipeError,ValueError):self.failed=True
    def read(self):
        try:
            for line in self.proc.stdout:
                packet=json.loads(line)
                if 'state' in packet:
                    with self.condition:
                        self.sequence+=1;self.frame=packet['state'];self.frame['revision']=self.sequence;self.frame['seats']=self.seats;self.condition.notify_all()
                    HUB.push_state(self.id,self.frame)
                if 'save' in packet:
                    state=packet['state'];finished=state['state']=='fulltime'
                    result=dict(score=state['score'],stats=state['stats'],events=packet['save']['records'],players=[[p[9],p[12],p[13]] for p in state['players']],departed=[t['departed'] for t in packet['save']['teams']])
                    run('UPDATE rooms SET save=?,status=?,result=? WHERE id=?',js(packet['save']),'done' if finished else 'live',js(result),self.id)
        finally:
            with self.condition:self.failed=True;self.condition.notify_all()
    def wait(self,after):
        with self.condition:
            self.condition.wait_for(lambda:self.frame is not None and self.sequence!=after or self.failed,1.5)
            require(self.frame is not None,'Silnik meczu nie odpowiedział',503)
            return self.frame
    def update_seats(self):
        m=seat_map(self.id,True)
        if m!=self.seats:self.seats=m;self.send(dict(op='seat',seats=m))
def worker(room):
    with LOCK:
        w=workers.get(room)
        if not w or w.failed:
            row=roomrow(room);w=workers[room]=Worker(row)
        return w
def roomlist():
    out=query('SELECT id,name,owner,cup,h,a,status,config,result FROM rooms ORDER BY id DESC')
    for r in out:
        r['config']=json.loads(r['config']);r['score']=json.loads(r.pop('result') or '{}').get('score',[0,0])
        info=seat_info(r['id'],True);r['seatInfo']=info;r['seats']={k:v['nick'] for k,v in info.items()}
        r['fans']=HUB.watcher_payload(r['id'])['count']
    return out
def standings(rows,which):
    scores={}
    for r in rows:
        if r['cup']!=which:continue
        for side in [r['h'],r['a']]:scores.setdefault(side,dict(clan=side,played=0,points=0,gf=0,ga=0))
        if r['status']!='done':continue
        a,b=r['score']
        for side,x,y in [(r['h'],a,b),(r['a'],b,a)]:
            s=scores[side];s['played']+=1;s['gf']+=x;s['ga']+=y;s['points']=3 if x>y else 1 if x==y else 0
    return sorted(scores.values(),key=lambda r:(r['points'],r['gf']-r['ga'],r['gf']),reverse=True)

class Handler(BaseHTTPRequestHandler):
    server_version='SuperPilkaLAN/2'
    protocol_version='HTTP/1.1'  # keep-alive zamiast HTTP/1.0 (poz. 5)
    def log_message(self,*args):pass
    def reply(self,data,status=200,mime='application/json; charset=utf-8'):
        if not isinstance(data,bytes):data=js(data).encode()
        self.send_response(status)
        self.send_header('Content-Type',mime)
        self.send_header('Content-Length',str(len(data)))
        self.send_header('Cache-Control','no-store')
        self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('Connection','keep-alive')
        self.end_headers()
        self.wfile.write(data)
    def auth(self,needed=True):
        token=self.headers.get('Authorization','').removeprefix('Bearer ')
        u=self.user_by_token(token)
        if needed:require(u,'Zaloguj się',401)
        return u
    def user_by_token(self,token):
        if not token:return None
        return one('SELECT p.id,p.nick,s.admin FROM sessions s JOIN profiles p ON p.id=s.uid WHERE token=? AND until>?',tokenhash(token),int(time.time()))
    def handle_one(self,post):
        try:
            parts=urlsplit(self.path);path=parts.path;args={k:v[-1] for k,v in parse_qs(parts.query).items()}
            if not post and path=='/ws':
                # ---- WebSocket: przejęcie połączenia (poz. 6) ----
                ws_handshake(self)
                return self.ws_serve()
            if post:
                origin=self.headers.get('Origin')
                require(not origin or urlsplit(origin).netloc==self.headers.get('Host'),'Nieprawidłowe pochodzenie',403)
                size=int(self.headers.get('Content-Length','0'));require(0<size<=32768,'Nieprawidłowy rozmiar')
                args=json.loads(self.rfile.read(size));require(isinstance(args,dict),'Nieprawidłowy JSON')
            if not post and path in ('/','/index.html','/super-pilka-98.html'):
                return self.reply((ROOT/'super-pilka-98.html').read_bytes(),mime='text/html; charset=utf-8')
            if not post and path=='/api/info':
                profile=self.auth(False)
                if profile:profile['played']=one("SELECT COUNT(*) n FROM appearances a JOIN rooms r ON r.id=a.room WHERE a.uid=? AND r.status!='ready'",profile['id'])['n']
                return self.reply(dict(lan=True,profile=profile,clans=query('SELECT id,name,owner FROM clans'),cups=query('SELECT * FROM cups'),rooms=roomlist(),hz=SNAP_HZ))
            if not post and path=='/api/state':
                r=int(args['room']);row=one('SELECT status FROM rooms WHERE id=?',r);require(row,'Brak meczu',404);require(row['status']!='ready','Organizator jeszcze nie rozpoczął meczu',409)
                return self.reply(worker(r).wait(int(args.get('after',-1))))
            if not post and path=='/api/history':
                rooms=roomlist();c=int(args.get('clan',0));cup=int(args.get('cup',0));r=int(args.get('room',0))
                matches=[a for a in rooms if (not c or c in (a['h'],a['a'])) and (not cup or cup==a['cup']) and (not r or r==a['id'])]
                for m in matches:m['record']=json.loads(roomrow(m['id'])['result'] or '{}')
                summary=None
                if c:
                    summary=dict(played=0,wins=0,draws=0,losses=0,gf=0,ga=0,points=0)
                    for m in matches:
                        if m['status']!='done':continue
                        gf,ga=m['score'] if m['h']==c else m['score'][::-1]
                        summary['played']+=1;summary['gf']+=gf;summary['ga']+=ga
                        summary['wins' if gf>ga else 'draws' if gf==ga else 'losses']+=1
                    summary['points']=3*summary['wins']+summary['draws']
                table=standings(rooms,cup) if cup else [];champions=[]
                if table and all(m['status']=='done' for m in rooms if m['cup']==cup):
                    def rank(t):return t['points'],t['gf']-t['ga'],t['gf']
                    champions=[row['clan'] for row in table if rank(row)==rank(table[0])]
                return self.reply(dict(matches=matches,table=table,summary=summary,champions=champions))
            if not post and path=='/api/nick.wav':
                nick=label(args['nick'],28);lang=args.get('lang','pl');require(lang in ['pl','en'] and one('SELECT id FROM profiles WHERE nick=?',nick),'Brak profilu',404)
                dst=conf/'voices'/(tokenhash(lang+nick)+'.wav')
                if not dst.is_file():
                    raw=speech(nick,lang);tmp=dst.with_suffix('.'+secrets.token_hex(5));tmp.write_bytes(raw);os.replace(tmp,dst)
                return self.reply(dst.read_bytes(),mime='audio/wav')
            if not post and path=='/api/chat':
                r=int(args.get('room',0));require(r,'Brak meczu')
                after=int(args.get('after',0))
                rows=query('SELECT id,nick,body,t,scope FROM chat WHERE room=? AND id>? ORDER BY id ASC LIMIT 80',r,after)
                return self.reply({'messages':[dict(row) for row in rows]})
            require(post,'Nie znaleziono',404)
            if path in ('/api/register','/api/login'):
                nick=label(args['nick'],28);pw=str(args['password']);require(6<=len(pw)<=180,'Hasło musi mieć od 6 do 180 znaków')
                if path.endswith('register'):
                    salt=secrets.token_hex(16);hashed=password(pw,salt);run('INSERT INTO profiles(nick,key,salt,pw) VALUES(?,?,?,?)',nick,nick.casefold(),salt,hashed)
                profile=one('SELECT * FROM profiles WHERE key=?',nick.casefold())
                require(profile and hmac.compare_digest(profile['pw'],password(pw,profile['salt'])),'Błędny login lub hasło',401)
                token=secrets.token_urlsafe(32);admin=bool(args.get('admin')) and hmac.compare_digest(str(args['admin']),admin_key)
                run('INSERT INTO sessions VALUES(?,?,?,?)',tokenhash(token),profile['id'],int(admin),int(time.time())+30*86400)
                return self.reply(dict(token=token,nick=profile['nick'],id=profile['id'],admin=admin))
            u=self.auth();uid=u['id']
            if path=='/api/logout':
                run('DELETE FROM sessions WHERE token=?',tokenhash(self.headers['Authorization'].removeprefix('Bearer ')));return self.reply({})
            if path=='/api/clan':
                name=label(args['name']);clan=run('INSERT INTO clans(name,owner) VALUES(?,?)',name,uid);run('INSERT INTO members VALUES(?,?)',clan,uid);return self.reply({'id':clan})
            if path=='/api/join-clan':
                clan=int(args['clan']);require(one('SELECT id FROM clans WHERE id=?',clan),'Nieznany klan');run('INSERT OR IGNORE INTO members VALUES(?,?)',clan,uid);return self.reply({})
            if path=='/api/cup':
                name=label(args['name']);ids=list(dict.fromkeys(map(int,args['clans'])));require(2<=len(ids)<=16,'Wybierz 2–16 klanów')
                clubs={c['id']:c['name'] for c in query('SELECT id,name FROM clans')};require(all(i in clubs for i in ids),'Nieznany klan')
                scope=args.get('scope','class');require(scope in ('class','world'),'Nieznany rodzaj turnieju')
                config=spec(args.get('config',{}))
                with LOCK,db:
                    cup=db.execute('INSERT INTO cups(name,scope,owner) VALUES(?,?,?)',(name,scope,uid)).lastrowid
                    for j,h in enumerate(ids):
                        for a in ids[j+1:]:
                            db.execute('INSERT INTO rooms(name,owner,config,cup,h,a) VALUES(?,?,?,?,?,?)',(clubs[h]+' – '+clubs[a],uid,js(dict(config,home=clubs[h],away=clubs[a])),cup,h,a))
                return self.reply({'id':cup})
            if path=='/api/room':
                config=spec(args.get('config',{}));h=int(args.get('h',0));a=int(args.get('a',0))
                require(not h or h!=a,'Wybierz dwa różne klany')
                for k,team in [(h,'home'),(a,'away')]:
                    if k:
                        clan=one('SELECT name FROM clans WHERE id=?',k);require(clan,'Nieznany klan');config[team]=clan['name']
                room=run('INSERT INTO rooms(name,owner,config,h,a) VALUES(?,?,?,?,?)',label(args.get('name') or config['home']+' – '+config['away']),uid,js(config),h,a)
                return self.reply({'id':room})
            r=int(args['room']);row=one('SELECT status,owner,h,a FROM rooms WHERE id=?',r);require(row,'Brak meczu',404)
            if path in ('/api/start','/api/pause','/api/sub'):
                require(u['admin'] or row['owner']==uid,'Tylko organizator',403)
                if path=='/api/start':
                    require(row['status']!='done','Mecz zakończony',409);run("UPDATE rooms SET status='live' WHERE id=?",r);worker(r)
                elif path=='/api/pause':
                    require(row['status']=='live','Mecz nie jest w toku',409);worker(r).send(dict(op='pause',value=bool(args.get('value'))))
                else:
                    team,idx,num=map(int,[args['team'],args['idx'],args['num']])
                    require(row['status']=='live' and team in (0,1) and 0<=idx<11 and 1<=num<=99,'Nieprawidłowa zmiana')
                    w=worker(r);current=w.wait(-1);player=current['players'][team*11+idx]
                    require(not player[11] and current['changes'][team]<5 and any(n['num']==num and (n['role']=='GK')==(player[14]=='GK') for n in current['bench'][team]),'Zmiana niedostępna')
                    w.send(dict(op='sub',team=team,idx=idx,num=num))
                return self.reply({})
            if path=='/api/seat':
                slot=int(args['slot']);require(0<=slot<22,'Pozycja poza składem');require(row['status']!='done','Mecz zakończony')
                clan=row['h'] if slot<11 else row['a']
                if clan:require(one('SELECT uid FROM members WHERE uid=? AND clan=?',uid,clan),'Najpierw dołącz do klanu',403)
                with LOCK,db:
                    occupied=db.execute('SELECT uid,seen FROM seats WHERE room=? AND slot=?',(r,slot)).fetchone()
                    require(not occupied or occupied['uid']==uid or time.time()-occupied['seen']>20,'Miejsce zajęte',409)
                    db.execute('DELETE FROM seats WHERE room=? AND (uid=? OR slot=?)',(r,uid,slot))
                    db.execute('INSERT INTO seats(room,slot,uid,seen,ready) VALUES(?,?,?,?,0)',(r,slot,uid,time.time()))
                    db.execute('INSERT OR REPLACE INTO appearances VALUES(?,?,?)',(uid,r,slot))
                if r in workers:workers[r].update_seats()
                return self.reply({'slot':slot})
            if path=='/api/leave':
                run('DELETE FROM seats WHERE room=? AND uid=?',r,uid)
                if r in workers:workers[r].update_seats()
                return self.reply({})
            if path=='/api/ready':
                # flaga gotowości na pozycji (poz. 17)
                val=1 if args.get('value',True) else 0
                with LOCK,db:
                    seat=db.execute('SELECT slot FROM seats WHERE room=? AND uid=?',(r,uid)).fetchone()
                    require(seat,'Najpierw zajmij pozycję',403)
                    db.execute('UPDATE seats SET ready=?,seen=? WHERE room=? AND uid=?',(val,time.time(),r,uid))
                if r in workers:workers[r].update_seats()
                info=seat_info(r,True)
                return self.reply({'ready':bool(val),'seatInfo':info})
            if path=='/api/chat':
                return self.reply(store_chat(uid,u['nick'],r,args.get('body'),args.get('scope') or 'room'))
            if path=='/api/input':
                return self.reply(self.apply_input(uid,r,args.get('input',{})))
            raise ApiError(404,'Nie znaleziono')
        except (BrokenPipeError,ConnectionResetError):pass
        except ApiError as e:self.reply({'error':str(e)},e.code)
        except sqlite3.IntegrityError:self.reply({'error':'Ta nazwa lub pozycja jest już zajęta'},409)
        except (KeyError,TypeError,ValueError,OverflowError):self.reply({'error':'Nieprawidłowe dane'},400)
        except Exception as e:
            print('Błąd serwera:',repr(e),file=sys.stderr);self.reply({'error':'Błąd serwera'},500)
    def apply_input(self,uid,room,n):
        """wspólna ścieżka wejścia dla HTTP i WebSocket"""
        ctrl=sanitize_input(n)
        with LOCK:
            seat=one('SELECT slot,seen FROM seats WHERE room=? AND uid=?',room,uid);require(seat,'Wybierz zawodnika',403)
            if time.time()-seat['seen']>=.65:run('UPDATE seats SET seen=? WHERE room=? AND uid=?',time.time(),room,uid)
            row=one('SELECT status FROM rooms WHERE id=?',room)
            if row['status']=='live':
                w=worker(room)
                if str(seat['slot']) not in w.seats:w.update_seats()
                w.send(dict(op='input',slot=seat['slot'],input=ctrl))
        return {}
    # ---------------- pętla WebSocket ----------------
    def ws_serve(self):
        conn=WSConn(self)
        try:
            self.connection.settimeout(90)
            first=json.loads(conn.read());require(first.get('op')=='hello','Oczekiwano hello',4002)
            token=first.get('token');user=self.user_by_token(token) if token else None
            room=int(first.get('room',0) or 0)
            mode=first.get('mode','fan')
            require(mode in ('play','fan','director','lobby'),'Nieznany tryb',4003)
            if mode=='play':require(user,'Zaloguj się',4001)
            if mode=='lobby':room=0
            if room>0:
                require(one('SELECT id FROM rooms WHERE id=?',room),'Brak meczu',4004)
            if first.get('fan'):HUB.fanseat(conn,first['fan'])
            conn.user=user;conn.uid=user['id'] if user else 0;conn.nick=user['nick'] if user else None
            HUB.join(conn,room,mode)
            conn.send_text(js(dict(op='welcome',nick=conn.nick,mode=mode,room=room,hz=SNAP_HZ)))
            if room>0:
                with LOCK:frame=workers.get(room).frame if room in workers else None
                if frame is not None:HUB.push_state(room,frame)
                HUB.push_watchers(room)
            while conn.alive:
                text=conn.read()
                now=time.time()
                if now>conn.budget+5:
                    conn.budget=now;conn.count=0
                conn.count=getattr(conn,'count',0)+1
                if conn.count>240:conn.close(1008);break
                try:msg=json.loads(text)
                except ValueError:continue
                if not isinstance(msg,dict):continue
                op=msg.get('op')
                if op=='ping':
                    conn.send_text(js(dict(op='pong',t=msg.get('t'))))
                elif op=='hello':
                    # ponowne hello: zmiana pokoju/trybu, odświeżenie tokenu po zalogowaniu
                    token2=msg.get('token')
                    if token2 is not None:
                        user2=self.user_by_token(token2)
                        if user2:
                            conn.user=user2;conn.uid=user2['id'];conn.nick=user2['nick']
                    room2=int(msg.get('room',0) or 0);mode2=msg.get('mode','fan')
                    require(mode2 in ('play','fan','director','lobby'),'Nieznany tryb',4003)
                    if mode2=='play':require(conn.user,'Zaloguj się',4001)
                    if mode2=='lobby':room2=0
                    if room2>0:require(one('SELECT id FROM rooms WHERE id=?',room2),'Brak meczu',4004)
                    if msg.get('fan'):HUB.fanseat(conn,msg['fan'])
                    HUB.join(conn,room2,mode2)
                    conn.send_text(js(dict(op='welcome',nick=conn.nick,mode=mode2,room=room2,hz=SNAP_HZ)))
                    if room2>0:
                        with LOCK:frame=workers.get(room2).frame if room2 in workers else None
                        if frame is not None:HUB.push_state(room2,frame)
                        HUB.push_watchers(room2)
                elif op=='input':
                    require(conn.user,'Zaloguj się',4001);require(conn.room>0,'Wybierz mecz',4005)
                    self.apply_input(conn.uid,conn.room,msg.get('input',{}))
                elif op=='chat':
                    require(conn.user,'Zaloguj się',4001);require(conn.room>0,'Wybierz mecz',4005)
                    store_chat(conn.uid,conn.nick,conn.room,msg.get('body'),msg.get('scope') or 'room')
                elif op=='fanseat':
                    room=HUB.fanseat(conn,msg.get('fan') or {})
                    if room:HUB.push_watchers(room)
                elif op=='lobby':
                    if HUB.lobby_on(conn,bool(msg.get('on',True))):
                        try:conn.send_text(js({'op':'lobby','rooms':roomlist()}))
                        except Exception:pass
                        conn.lobby_fresh=False
        except (ApiError,ValueError,KeyError,TypeError,ConnectionError,OSError,ssl.SSLError) as e:
            if not isinstance(e,(ConnectionError,BrokenPipeError,ConnectionResetError,ssl.SSLError)):
                print('WS:',repr(e),file=sys.stderr)
        finally:
            HUB.drop(conn)
            if conn.alive:conn.close()
        return None
    def do_GET(self):self.handle_one(False)
    def do_POST(self):self.handle_one(True)
class Server(ThreadingHTTPServer):
    daemon_threads=True
    request_queue_size=96
    def __init__(self,address,handler,sslctx=None):
        self.sslctx=sslctx
        super().__init__(address,handler)
    def get_request(self):
        sock,addr=super().get_request()
        if self.sslctx is None:return sock,addr
        # uścisk TLS w wątku akceptującym; martwe połączenia odcina limit 10 s
        sock.settimeout(10)
        try:tls=self.sslctx.wrap_socket(sock,server_side=True)
        except OSError:
            try:sock.close()
            except OSError:pass
            raise
        tls.settimeout(None)
        return tls,addr
def ensure_tls(spec):
    """--tls auto → self-signed w conf/; --tls certyfikat.pem,klucz.pem"""
    require(spec,'Brak certyfikatu')
    if spec=='auto':
        crt,key=conf/'tls.crt',conf/'tls.key'
        if not (crt.is_file() and key.is_file()):
            require(shutil.which('openssl'),'Brak openssl — wskaż certyfikat przez --tls certyfikat.pem,klucz.pem',503)
            ips={'127.0.0.1'}
            try:ips.update(i for i in socket.gethostbyname_ex(socket.gethostname())[2] if ':' not in i)
            except OSError:pass
            san='subjectAltName=DNS:localhost'+','.join('IP:'+i for i in sorted(ips))
            subprocess.run(['openssl','req','-x509','-newkey','rsa:2048','-sha256','-days','3650','-nodes',
                '-keyout',str(key),'-out',str(crt),'-subj','/CN=Super Pilka 98 LAN','-addext',san],
                check=True,capture_output=True)
        return crt,key
    crt,key=spec.split(',')
    crt,key=Path(crt),Path(key)
    require(crt.is_file() and key.is_file(),'Nie znaleziono plików certyfikatu',503)
    return crt,key
def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--port',type=int,default=8906);parser.add_argument('--bind',default='0.0.0.0')
    parser.add_argument('--data',type=Path,default=ROOT/'conf')
    parser.add_argument('--tls',default=None,help='"auto" (self-signed) albo "certyfikat.pem,klucz.pem" — HTTPS i WSS')
    a=parser.parse_args()
    if not shutil.which('node') and not shutil.which('nodejs'):parser.error('Serwer wymaga Node.js 18 lub nowszego.')
    build();init_database(a.data)
    sslctx=None
    if a.tls:
        crt,key=ensure_tls(a.tls)
        sslctx=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER);sslctx.load_cert_chain(str(crt),str(key))
    srv=Server((a.bind,a.port),Handler,sslctx)
    scheme='https' if sslctx else 'http'
    print('Super Piłka LAN: '+scheme+'://localhost:'+str(srv.server_port)+' · klucz administratora w '+str(conf/'admin.key')+' · migawki '+str(SNAP_HZ)+' Hz przez WebSocket',flush=True)
    for r in query("SELECT id FROM rooms WHERE status='live'"):worker(r['id'])
    def maintain():
        while True:
            time.sleep(2)
            for w in list(workers.values()):
                if not w.failed:w.update_seats()
            HUB.push_lobby(roomlist())
            HUB.ping_all()
    threading.Thread(target=maintain,daemon=True).start()
    def shut(*_):threading.Thread(target=srv.shutdown,daemon=True).start()
    signal.signal(signal.SIGTERM,shut);signal.signal(signal.SIGINT,shut)
    try:srv.serve_forever()
    finally:
        srv.server_close()
        for w in list(workers.values()):
            if not w.failed:w.send({'op':'stop'})
        for w in list(workers.values()):
            try:w.proc.wait(timeout=3);w.thread.join(1)
            except subprocess.TimeoutExpired:w.proc.terminate()
if __name__=='__main__':main()
