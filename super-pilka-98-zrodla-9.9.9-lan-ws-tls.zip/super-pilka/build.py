#!/usr/bin/env python3
"""Zbuduj samodzielny plik super-pilka-98.html obok źródeł."""
from base64 import b64encode
from pathlib import Path
import re
import json

def build():
    root = Path(__file__).resolve().parent
    source = root / "source"
    shell = (source / "shell.html").read_text(encoding="utf-8")
    atlas = b64encode((source / "art" / "twarze.webp").read_bytes()).decode("ascii")
    shell = shell.replace("<!--FACE_ATLAS-->", atlas)
    ears = b64encode((source / "art" / "uszy.webp").read_bytes()).decode("ascii")
    shell = shell.replace("<!--EAR_ATLAS-->", ears)
    css = (source / "match.css").read_text(encoding="utf-8")
    scripts = sorted((source / "js").glob("*.js"))
    if not scripts:
        raise ValueError("Brak modułów gry w source/js")
    game = "\n;\n".join(path.read_text(encoding="utf-8") for path in scripts)
    game = game.replace("/*SQUADS*/null", (source / "data" / "teams.json").read_text(encoding="utf-8"))
    sounds = source / "audio"
    bank = {"index": json.loads((sounds / "index.json").read_text(encoding="utf-8"))}
    for track in sorted(sounds.glob("*.mp3")):
        bank[track.stem] = "data:audio/mpeg;base64," + b64encode(track.read_bytes()).decode("ascii")
    game = game.replace("/*AUDIOBANK*/null", json.dumps(bank,ensure_ascii=False,separators=(",",":")))
    three = (source / "vendor-three.min.js").read_text(encoding="utf-8")
    for label, body in (("THREE", three), ("GAME", game)):
        if re.search(r"</script", body, re.I):
            raise ValueError(f"Niedozwolony znacznik w module {label}")
        shell = shell.replace(f"<!--{label}-->", "<script>\n" + body + "\n</script>")
    shell = shell.replace("<!--STYLE-->", "<style>\n" + css + "\n</style>")
    dest = root / "super-pilka-98.html"
    dest.write_text(shell, encoding="utf-8")
    print(dest)

if __name__ == "__main__":
    build()
