var CEREMONY={
  stage:-1,
  prepare:function(closing){
    this.stage=-1;this.winner=SIM.teams[0].score===SIM.teams[1].score?-1:SIM.teams[0].score>SIM.teams[1].score?0:1;
    RULES.state=closing?"closing":"opening";RULES.stateT=0;
    
    var x=closing?3:0;
    for(var p of SIM.players){
      if(p.off)continue;
      p.pos.x=x+(p.idx-5)*(closing?1.02:1.28);p.pos.z=(p.team===0?-1:1)*(closing?1.8:3.2);
      p.face=0;p.vel.x=p.vel.z=0;p.action="lineup";p.actionT=0;
    }
    if(WORLD.cup)WORLD.cup.visible=false;
    HUD.hint(t("scene_skip"));this.step(0,false);
  },
  step:function(dt,skip){
    var close=RULES.state==="closing",time=RULES.stateT;
    if(skip){this.finish(close);return;}
    var stage=close?0:time<6?-1:time<17.7?0:1,team=close?this.winner:stage;
    if(stage!==this.stage || time===0){
      this.stage=stage;
      SIM.players.forEach(function(p){if(!p.off)p.action=p.team===team?"anthem":"lineup";});
      if(team>=0){
        HUD.event(close?"goal":"kickoff",t(close?"cupLift":"anthem"),"",RULES.teamName(team),TEAMS.selected(team).coach||SQUADS.clubCoaches[team]);
        var national=TEAMS.selected(team),name=RULES.teamName(team);
        var audioTeam=name===national.pl || name===national.en?"team_"+SET[team?"nationA":"nationH"]:name===(team?"TS ORZEŁ":"KS SOKÓŁ")?(team?"club_a":"club_h"):null;
        VOICE.speak(close?["winner",audioTeam]:["coach",TEAMS.selected(team).coach||SQUADS.clubCoaches[team]],true);
        VOICE.anthem(team);
      }else if(close){VOICE.speak(["full"],true);HUD.event("kickoff",t("e_full"),"",SET.home+"  "+SIM.teams[0].score+" – "+SIM.teams[1].score+"  "+SET.away,"");}
      else{VOICE.speak(["opening","ref",SQUADS.officials[0]],true);HUD.event("kickoff",t("opening"),t("friendly"),SET.home,SET.away);}
    }
    if(close && team>=0){
      var captain=SIM.teamPlayers(team).find(function(p){return p.role==="FW";})||SIM.teamPlayers(team)[0];
      captain.action="liftcup";captain.actionT=Math.max(0,time-2.10);
      if(WORLD.cup){WORLD.cup.visible=true;WORLD.cup.position.set(captain.pos.x,1.25+.76*FACE.smooth(0,1.15,captain.actionT),captain.pos.z+.32);}
    }
    if(time>=(close?(team>=0?11.5:4):29.4))this.finish(close);
  },
  finish:function(close){
    VOICE.stopMusic();if(WORLD.cup)WORLD.cup.visible=false;HUD.hideEvent();HUD.hint("");
    if(close){RULES.state="fulltime";HUD.showEnd();}
    else RULES.setupKickoff(RULES.kickTeamFirst,true);
  },
  officials:function(dt){
    var st=WORLD.staff,ref=st.ref;
    if(RULES.state==="opening" || this.winner<0){
      ref.position.set(-8.3,0,0);ref.rotation.y=0;WORLD.animatePlayer(ref,0,dt,"lineup",0,0,0,1);return;
    }
    var p=SIM.teamPlayers(this.winner).find(function(q){return q.action==="liftcup";});
    if(!p || !p.mesh)return;
    var time=RULES.stateT,approach=FACE.smooth(0,1.35,time),back=FACE.smooth(2.0,3.7,time);
    ref.position.set(p.pos.x+2.25-1.68*approach+1.50*back,0,p.pos.z+.82-.29*approach);
    ref.rotation.y=Math.atan2(p.pos.x-ref.position.x,p.pos.z-ref.position.z);
    WORLD.animatePlayer(ref,0,dt,back>.95?"lineup":"presentcup",time,0,0,1);
    if(!WORLD.cup)return;
    var first=this.fromHand||(this.fromHand=new THREE.Vector3()),second=this.toHand||(this.toHand=new THREE.Vector3()),v=this.otherHand||(this.otherHand=new THREE.Vector3());
    function grip(mesh,out){
      var arms=mesh.userData.limbs;
      arms[0].knuckles.getWorldPosition(out);arms[1].knuckles.getWorldPosition(v);out.add(v).multiplyScalar(.5);out.y-=.30;
    }
    grip(ref,first);grip(p.mesh,second);WORLD.cup.position.lerpVectors(first,second,FACE.smooth(1.35,2.10,time));WORLD.cup.visible=true;
    st.ref.userData.pos.x=ref.position.x;st.ref.userData.pos.z=ref.position.z;
  },
  camera:function(){
    var close=RULES.state==="closing",side=close?this.winner:this.stage;
    var x=close?3.7:Math.sin(RULES.stateT*.23)*3,z=side===0?-3.2:3.2;
    if(close && side>=0){var c=SIM.teamPlayers(side).find(function(p){return p.action==="liftcup";});if(c){x=c.pos.x;z=c.pos.z;}}
    return {eye:{x:x+(close?2.4:3.2),y:close?1.85:1.62,z:z+(close?4.8:8.2)},target:{x:x,y:close?1.42:1.12,z:z},fov:43};
  },
  trophy:function(){
    var gold=new THREE.MeshPhongMaterial({color:0xe8ba52,shininess:86,specular:0xffedaa}),group=new THREE.Group();
    var profile=[[.12,0],[.14,.05],[.075,.075],[.047,.16],[.075,.22],[.125,.26],[.168,.36],[.176,.44],[.160,.445],[.150,.37],[.095,.31]];
    group.add(new THREE.Mesh(new THREE.LatheGeometry(profile.map(function(p){return new THREE.Vector2(p[0],p[1]);}),24),gold));
    for(var side of [-1,1]){
      var loop=new THREE.Mesh(new THREE.TorusGeometry(.093,.012,7,22),gold);
      loop.scale.x=.70;loop.position.set(side*.16,.32,0);group.add(loop);
    }
    group.visible=false;WORLD.scene.add(group);return group;
  }
};
