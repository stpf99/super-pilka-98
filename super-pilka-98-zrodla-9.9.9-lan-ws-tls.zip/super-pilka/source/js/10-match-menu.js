var MATCH_MENU={
  fill:function(id,items,value){
    var e=document.getElementById(id);e.replaceChildren();
    items.forEach(function(o){var el=document.createElement("option");el.value=String(o[0]);el.textContent=o[1];e.add(el);});
    e.value=String(value);return e;
  },
  refresh:function(){
    if(!this.ready)return;
    var self=this,lang=SET.lang;
    [0,1].forEach(function(team){
      var side=team?"A":"H",key="nation"+side;
      self.fill(key,Object.entries(TEAMS.data).map(function(pair){return [pair[0],pair[1][lang]];}),SET[key]);
      self.fill("strip"+side,[["home",t("homeKit")],["away",t("awayKit")]],SET["strip"+side]);
      var input=document.getElementById(team?"inAway":"inHome");input.disabled=DESK.editingMatch || SET[key]!=="club";input.value=SET[team?"away":"home"];
    });
    this.fill("stadium",Object.keys(CONDITIONS.venues).map(function(k){return [k,CONDITIONS.venues[k][0]];}),SET.stadium);
    this.fill("ballStyle",["classic","wave","winter"].map(function(k){return [k,t(k+"Ball")];}),SET.ballStyle);
    this.fill("weather",["clear","rain","snow","fog"].map(function(k){return [k,t(k)];}),SET.weather);
  },
  init:function(){
    this.ready=true;
    ["nationH","nationA","stripH","stripA","stadium","ballStyle","weather"].forEach(function(key){
      document.getElementById(key).onchange=function(){
        SET[key]=this.value;
        if(key.indexOf("nation")===0){
          var team=key==="nationA"?1:0;
          SET[team?"away":"home"]=this.value==="club"?(team?"TS ORZEŁ":"KS SOKÓŁ"):TEAMS.selected(team)[SET.lang];
        }
        if(key==="stadium")CONDITIONS.venue();else if(key==="weather")WORLD.setNight(!!SET.night);
        else if(key==="ballStyle")CONDITIONS.ball();else TEAMS.apply();
        SET_save();DESK.refresh();HUD.refreshTeams();
      };
    });
    document.getElementById("subTeam").onchange=function(){MATCH_MENU.subs();};
    document.getElementById("subOut").onchange=function(){MATCH_MENU.subs();};
    document.getElementById("subConfirm").onclick=function(){
      var t=Number(document.getElementById("subTeam").value),idx=Number(document.getElementById("subOut").value),num=Number(document.getElementById("subIn").value);
      if(MATCHDAY.queue(t,idx,num) && RULES.state==="halftime")MATCHDAY.commit();MATCH_MENU.subs();
    };
  },
  subs:function(){
    if(!SIM.teams.length || !MATCHDAY.queued)return;
    var team=Number(document.getElementById("subTeam").value)||0,tm=SIM.teams[team];
    if(SET.mode===0){team=0;tm=SIM.teams[0];}
    this.fill("subTeam",SET.mode===0?[[0,SET.home]]:[[0,SET.home],[1,SET.away]],team);
    var q=MATCHDAY.queued[team],out=SIM.teamPlayers(team).filter(function(p){return !q.some(function(c){return c.idx===p.idx;});});
    var idx=Number(document.getElementById("subOut").value),who=out.find(function(p){return p.idx===idx;})||out[0];
    this.fill("subOut",out.map(function(p){return [p.idx,p.num+"  "+p.name+" · "+Math.round(100*p.stamina)+"%"]; }),who?.idx);
    var bench=tm.bench.filter(function(r){return who && (r.role==="GK")===(who.role==="GK") && !q.some(function(c){return c.num===r.num;});});
    this.fill("subIn",bench.map(function(r){return [r.num,r.num+"  "+r.name];}),bench[0]?.num);
    document.getElementById("subConfirm").disabled=!bench.length || tm.changes+q.length>=5;
    document.getElementById("subInfo").textContent=tm.changes+" / 5 · "+t("pending")+" "+q.length;
  }
};
