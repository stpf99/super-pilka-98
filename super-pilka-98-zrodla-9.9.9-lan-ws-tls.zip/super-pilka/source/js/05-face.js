/* Głowa, małżowiny i szyja korzystają z tego samego atlasu skóry.
   Dolna szczęka obraca się wokół własnego stawu. */
var FACE = {
  smooth:function(lo,hi,value){
    var t=Math.max(0,Math.min(1,(value-lo)/(hi-lo)));
    return t*t*(3-2*t);
  },

  build:function(head,neck,jaw,index,vertex,positions,indices,skin){
    var jawWidth=1+(index%3-1)*.046,style=[2,4,3,0,1,2,0,4][index%8];
    var outline=[
      [-.120,.068,.064,-.010],[-.086,.065,.062,-.010],[-.054,.062,.061,-.008],
      [-.034,.061,.064,-.005],[-.023,.064,.070,.003],[-.008,.074*jawWidth,.083,.014],
      [.018,.086*jawWidth,.093,.018],[.034,.093,.099,.012],[.052,.096,.102,.009],
      [.077,.101,.104,.006],[.107,.106,.109,.003],[.138,.107,.109,0],
      [.162,.106,.108,-.003],[.186,.102,.105,-.007],[.207,.094,.101,-.009],
      [.229,.076,.085,-.010],[.244,.052,.062,-.009],[.253,.027,.035,-.008],[.256,0,0,-.008]
    ];
    var first=positions.length/3,levels=[],angles=[];
    // Reserve the tighter strips for the nose and pinnae; the nape needs fewer vertices.
    for(var longitude=0;longitude<48;longitude++){
      var a0=-Math.PI+longitude*Math.PI/24,mid=a0+Math.PI/48,absolute=Math.abs(mid);
      angles.push(a0);
      if(absolute<.46 || (absolute>1.34 && absolute<1.99))angles.push(mid);
    }
    angles.push(Math.PI);
    var n=angles.length-1;
    // Shape-preserving Hermite tangents avoid flat bands along the jaw and neck.
    function tangent(key,channel){
      var j0=Math.max(0,key-1),j1=Math.min(outline.length-1,key+1);
      var left=outline[j0],mid=outline[key],right=outline[j1];
      var a=(mid[channel]-left[channel])/(mid[0]-left[0] || 1);
      var b=(right[channel]-mid[channel])/(right[0]-mid[0] || 1);
      if(j0===key)return b;
      if(j1===key)return a;
      return a*b>0?2*a*b/(a+b):0;
    }
    // Finer rings through the ear give the outer rim and the lobe a smooth silhouette.
    for(var k=0;k<outline.length-1;k++){
      var lo=outline[k],hi=outline[k+1];
      var steps=Math.ceil((hi[0]-lo[0])/(lo[0]>=.052 && lo[0]<.138?.006:.014));
      for(var j=0;j<steps;j++){
        var t=j/steps,t2=t*t,t3=t2*t,span=hi[0]-lo[0];
        levels.push(lo.map(function(value,c){
          if(!c)return lo[0]+t*span;
          return (2*t3-3*t2+1)*value+(-2*t3+3*t2)*hi[c]
            +span*((t3-2*t2+t)*tangent(k,c)+(t3-t2)*tangent(k+1,c));
        }));
      }
    }
    levels.push(outline[outline.length-1]);
    var smooth=this.smooth;
    levels.forEach(function(r,row){
      for(var i=0;i<=n;i++){
        var a=angles[i],u=.5+a/(2*Math.PI),side=Math.sin(a),front=Math.cos(a),ab=Math.abs(a),y=r[0];
        var earRoot=.003*Math.exp(-Math.pow((ab-1.66)/.22,2)-Math.pow((y-.092)/.036,2));
        var nose=.030*Math.exp(-Math.pow(a/.19,2)-Math.pow((y-.077)/.029,2))
          +.014*Math.exp(-Math.pow(a/.15,2)-Math.pow((y-.105)/.039,2))
          +.006*Math.exp(-Math.pow((ab-.16)/.10,2)-Math.pow((y-.066)/.011,2));
        var relief=nose-.008*Math.exp(-Math.pow((ab-.40)/.20,2)-Math.pow((y-.115)/.013,2))
          +.008*Math.exp(-Math.pow((ab-.61)/.24,2)-Math.pow((y-.084)/.024,2))
          +.0043*Math.exp(-Math.pow(a/.29,2)-Math.pow((y-.033)/.014,2));
        var hairLine=.105+.063*front-.021*Math.pow(Math.abs(side),5)+.046*Math.exp(-Math.pow((ab-1.64)/.29,2));
        hairLine+=style===2?-.015*(1-front):style===1?.011*front:0;
        hairLine-=.027*Math.exp(-Math.pow((ab-1.23)/.17,2));
        hairLine+=.004*Math.sin(3*a+.7*(index%8))+.003*Math.sin(11*a+index%8);
        var hair=smooth(-.003,.020,y-hairLine), crown=smooth(.17,.256,y);
        var thick=(.002+style*.0014)*hair*(.85+.15*Math.cos(13*a+23*y))*(1-crown);
        var jawAngle=(1-front)*.018*Math.exp(-Math.pow((y+.012)/.049,2));
        var scalpY=y+jawAngle+hair*crown*(.003+style*.0031);
        var chin=smooth(-.040,-.009,y)*(1-smooth(.016,.058,y))*smooth(.08,.86,front);
        var neckWeight=1-smooth(-.095,-.041,y);
        var other=neckWeight>0?neck:jaw,weight=neckWeight>0?neckWeight:chin;
        vertex(head,side*(r[1]+earRoot+thick)+.0015*style*crown,scalpY,
          r[3]+front*(r[2]+thick)+relief+.005*chin,0xffffff,
          .004+.492*u,.006+.488*(y+.120)/.395,other,weight);
        if(row && i){var d=first+row*(n+1)+i;indices.push(d-n-2,d-n-1,d,d-n-2,d,d-1);}
      }
    });
    this.addEar(-1,head,index,vertex,positions,indices,skin);
    this.addEar(1,head,index,vertex,positions,indices,skin);
    return {first:first,sides:n,rows:levels.length};
  },

  earPixels:function(){
    if(this.earData!==undefined)return this.earData;
    var image=document.getElementById("earAtlas");
    if(!image || !image.naturalWidth)return null;
    var canvas=document.createElement("canvas");canvas.width=canvas.height=384;
    var g=canvas.getContext("2d");
    try{
      g.drawImage(image,0,0);
      this.earData=g.getImageData(0,0,384,384).data;
    }catch(e){this.earData=null;}
    return this.earData;
  },

  addEar:function(side,head,index,vertex,positions,indices,skin){
    var pixels=this.earPixels(),style=index%8,baseSkin=skin||0xb88570;
    var segments=32,scale=.97+.015*(index%5),centerY=.092+.0007*(index%5-2);
    var flare=.0011*(index%3-1),smooth=this.smooth;
    // Od dna muszli przez wolny brzeg do nasady schowanej pod skórą.
    var rings=[[.19,0],[.35,0],[.49,0],[.62,0],[.74,0],[.83,0],[.91,0],[.97,0],[1,0],
      [.97,.003],[.86,.006],[.68,.012],[.46,.023]];
    var first=positions.length/3;
    function fold(h,v,x,y,width,height){
      return Math.exp(-Math.pow((h-x)/width,2)-Math.pow((v-y)/height,2));
    }
    function point(radius,sin,cos,backDepth){
      var h=radius*sin,v=radius*cos; // h rośnie w stronę potylicy
      var y=centerY+scale*.036*v,z=-.0065-scale*(.0215*h*(1+.20*v)+.0055*v);
      var anterior=(1-smooth(-.76,-.32,h))*(1-smooth(.25,.79,v));
      var base=.1136+.0104*h+.0035*v+flare-.002*anterior;
      var x=base-backDepth,shade=1,warmth=0;
      if(!backDepth){
        var helix=Math.exp(-Math.pow((radius-.88)/.16,2))*(.0025+.0061*smooth(-.72,-.15,v))*(1-.87*anterior);
        var antihelix=.0064*fold(h,v,.22+.20*v,-.01,.19,.48)
          +.0045*fold(h,v,-.02,.34-.50*h,.33,.15);
        var tragus=.0088*fold(h,v,-.58,-.09,.23,.22);
        var antitragus=.0035*fold(h,v,.07,-.43,.23,.15);
        var bowl=fold(h,v,-.14,-.08,.40,.41),canal=fold(h,v,-.29,-.11,.20,.18);
        var lobe=.0065*fold(h,v,-.08,-.75,.45,.23);
        x=base+helix+antihelix+tragus+antitragus+lobe-.0037*bowl;
        shade-=.055*bowl+.085*canal+.035*fold(h,v,-.08,.58,.32,.14);
        warmth=.047*bowl+.022*fold(h,v,.22,.50,.45,.28);
      }
      var sampleRadius=backDepth?1.08:radius;
      var px=(style%4)*96+Math.floor(48+40*sampleRadius*sin);
      var py=(Math.floor(style/4)*2+(side<0?0:1))*96+Math.floor(48-40*sampleRadius*cos);
      var i=(py*384+px)*4;
      var red=Math.round(shade*(pixels?pixels[i]:baseSkin>>16));
      var green=Math.round(shade*(1-warmth)*(pixels?pixels[i+1]:(baseSkin>>8)&255));
      var blue=Math.round(shade*(1-1.14*warmth)*(pixels?pixels[i+2]:baseSkin&255));
      // Ten sam biały piksel i kolor wierzchołka co na dłoniach i przedramionach.
      vertex(head,side*x,y,z,(red<<16)|(green<<8)|blue,.007,.987);
    }
    function face(a,b,c){
      if(side<0)indices.push(a,b,c);
      else indices.push(a,c,b);
    }
    point(0,0,0,0);
    rings.forEach(function(section,row){
      var ring=first+1+row*segments;
      for(var i=0;i<segments;i++){
        var angle=i*2*Math.PI/segments;
        point(section[0],Math.sin(angle),Math.cos(angle),section[1]);
        var a=ring+i,b=ring+(i+1)%segments;
        if(row===0)face(first,a,b);
        else{face(a-segments,a,b);face(a-segments,b,b-segments);}
      }
    });
    var cap=positions.length/3,back=cap-segments;
    point(0,0,0,.027);
    for(var i=0;i<segments;i++)face(back+i,cap,back+(i+1)%segments);
  },

  smoothSeam:function(geometry,surface){
    var normal=geometry.attributes.normal,v=new THREE.Vector3(),w=new THREE.Vector3();
    for(var j=0;j<surface.rows;j++){
      var first=surface.first+j*(surface.sides+1),last=first+surface.sides;
      v.fromBufferAttribute(normal,first).add(w.fromBufferAttribute(normal,last)).normalize();
      normal.setXYZ(first,v.x,v.y,v.z);normal.setXYZ(last,v.x,v.y,v.z);
      if(j===surface.rows-1)for(var k=first;k<=last;k++)normal.setXYZ(k,0,1,0);
    }
  },

  material:function(mat,style){
    var pose=new THREE.Vector4(style%4,Math.floor(style/4),0,0),image=document.getElementById("faceAtlas");
    if(!image || !image.naturalWidth)return pose;
    if(!this.atlas){
      this.atlas=new THREE.Texture(image);this.atlas.encoding=THREE.sRGBEncoding;
      this.atlas.anisotropy=4;this.atlas.needsUpdate=true;
    }
    var atlas=this.atlas;
    mat.onBeforeCompile=function(shader){
      shader.uniforms.faceSheet={value:atlas};shader.uniforms.facePose={value:pose};
      shader.fragmentShader="uniform sampler2D faceSheet;\nuniform vec4 facePose;\n"+shader.fragmentShader;
      shader.fragmentShader=shader.fragmentShader.replace("#include <map_fragment>",[
        "#ifdef USE_MAP",
        "vec4 texelColor;",
        "if (vUv.x <= 0.497 && vUv.y < 0.50) {",
        "  vec2 surface = vec2((vUv.x-0.004)/0.492, 1.0-(vUv.y-0.006)/0.488);",
        "  vec2 pixel = vec2(8.0,6.0)+surface*vec2(496.0,376.0);",
        "  vec2 at = (facePose.xy + pixel/512.0) * vec2(0.25,0.5);",
        "  at.y=1.0-at.y;",
        "  texelColor=texture2D(faceSheet,at);",
        "  float weight=pixel.y<201.0 ? facePose.z : facePose.w;",
        "  if(weight>0.001 && pixel.y>134.0 && pixel.y<258.0 && abs(pixel.x-256.0)<85.0) {",
        "    vec2 alternate=at-vec2(0.0,251.0/1024.0);",
        "    float sweepingLash=0.0;",
        "    if(pixel.y<201.0){",
        "      float ex=(abs(pixel.x-256.0)-29.0)/17.8;",
        "      float arch=max(0.0,1.0-ex*ex);",
        "      float edge=mix(141.0,170.0,weight)-arch*(1.0-weight)*2.8;",
        "      sweepingLash=(1.0-smoothstep(0.0,1.3,abs(pixel.y-edge)))",
        "                   *arch*sin(3.14159*weight)*0.26;",
        "      weight=(1.0-smoothstep(edge-1.2,edge+1.2,pixel.y))*smoothstep(0.0,0.12,weight);",
        "    } else {",
        "      float lip=pixel.y-235.0;",
        "      alternate.y-=lip*(1.0-smoothstep(8.0,19.0,abs(lip)))*(1.0-weight)*0.61/1024.0;",
        "    }",
        "    vec4 expression=texture2D(faceSheet,alternate);",
        "    texelColor=mix(texelColor,expression,weight);",
        "    texelColor.rgb*=1.0-sweepingLash;",
        "  }",
        "} else { texelColor=texture2D(map,vUv); }",
        "diffuseColor *= mapTexelToLinear(texelColor);",
        "#endif"
      ].join("\n"));
    };
    mat.customProgramCacheKey=function(){return "athlete-face-skin-v6";};
    return pose;
  },

  animate:function(u,speed,action,impact){
    var seed=u.faceSeed,clock=(u.replayFaceTime===undefined?u.poseT:u.replayFaceTime)+seed,beat=clock%(3.16+(seed%1.47));
    // Quick close, short hold, and a slower reopening. The second blink is occasional.
    if((Math.floor(clock/(3.16+(seed%1.47)))%4)===2 && beat>.24)beat-=.26;
    var blink=this.smooth(0,.058,beat)*(1-this.smooth(.074,.183,beat));
    var cheer=action==="celebrate" || action==="goalrun" || action==="goalarm";
    var breathing=(.48+.52*Math.sin(clock*(speed>4?4.4:2.2)));
    var mouth=(speed>4?.21+Math.min(speed,10)*.031:.035)*Math.max(0,breathing);
    if(action==="anthem" || action==="liftcup"){
      var pulse=.5+.5*Math.sin(u.poseT*8.2+Math.sin(u.poseT*2.3)*.8+seed*.10);
      mouth=.11+.48*pulse*(.68+.32*Math.sin(u.poseT*1.58));}
    if(cheer)mouth=.61+.32*Math.sin(clock*6.1);
    if(action==="expression"){
      var cycle=u.poseT%3.1;
      blink=Math.max(blink,this.smooth(.36,.45,cycle)*(1-this.smooth(.51,.66,cycle)));
      mouth=.84*this.smooth(.89,1.35,cycle)*(1-this.smooth(1.85,2.36,cycle));
    }
    u.facePose.z=Math.max(blink,impact*.82);u.facePose.w=Math.min(1,mouth+impact*.23);
    u.jaw.rotation.x=.090*u.facePose.w;
  }
};
