/* ============================================================
   SUPER PILKA '98 · 04-input.js — klawiatura + Gamepad API (2 pady)
   Profile sterowania (poz. 20–22): mapowanie „naciśnij, aby przypisać”,
   martwa strefa, czułość, jawny wybór urządzenia, zapis lokalny.
   ============================================================ */
var INPUT = {
  kb: {},
  slots: [null, null],
  padIdx: [-1, -1],
  padSeen: [false, false],
  _prev: [null, null],
  wheelAcc: 0,
  dead: 0.20,
  sens: 1.0,
  devicePref: ["auto", "auto"], /* auto | kb | pad */
  listening: null,             /* { profile, action } podczas przypisywania */
  maps: null,

  ACTIONS: [
    { id:"up", label:"Góra" }, { id:"down", label:"Dół" },
    { id:"left", label:"Lewo" }, { id:"right", label:"Prawo" },
    { id:"pass", label:"Podanie" }, { id:"shoot", label:"Strzał" },
    { id:"tackle", label:"Wślizg / dośrodkowanie" }, { id:"through", label:"Prostopadłe" },
    { id:"sprint", label:"Sprint" }, { id:"finesse", label:"Strzał techniczny" },
    { id:"jockey", label:"Bliskie prowadzenie" }, { id:"switch", label:"Zmiana / combo" },
    { id:"cam", label:"Kamera" }, { id:"pause", label:"Pauza" }
  ],

  defaults: function(){
    return {
      kb1: {
        up:"KeyW", down:"KeyS", left:"KeyA", right:"KeyD",
        pass:"KeyK", shoot:"KeyL", tackle:"KeyJ", through:"KeyI",
        sprint:"Space", finesse:"KeyQ", jockey:"KeyE", switch:"KeyO",
        cam:"KeyC", pause:"Escape"
      },
      kb2: {
        up:"ArrowUp", down:"ArrowDown", left:"ArrowLeft", right:"ArrowRight",
        pass:"Comma", shoot:"Period", tackle:"Slash", through:"KeyM",
        sprint:"ShiftRight", finesse:"KeyH", jockey:"KeyB", switch:"KeyN",
        cam:"KeyC", pause:"Escape"
      },
      pad: {
        up:"btn12", down:"btn13", left:"btn14", right:"btn15",
        pass:"btn0", shoot:"btn1", tackle:"btn2", through:"btn3",
        sprint:"btn7", finesse:"btn5", jockey:"btn6", switch:"btn4",
        cam:"btn8", pause:"btn9"
      }
    };
  },

  load: function(){
    var d = this.defaults();
    try{
      var raw = localStorage.getItem("sp98.controls");
      if(raw){
        var saved = JSON.parse(raw);
        ["kb1","kb2","pad"].forEach(function(p){
          if(saved[p] && typeof saved[p]==="object")
            Object.keys(d[p]).forEach(function(k){ if(typeof saved[p][k]==="string") d[p][k]=saved[p][k]; });
        });
        if(typeof saved.dead==="number") this.dead=Math.max(0.05,Math.min(0.4,saved.dead));
        if(typeof saved.sens==="number") this.sens=Math.max(0.5,Math.min(1.5,saved.sens));
        if(Array.isArray(saved.devicePref)){
          this.devicePref[0]=["auto","kb","pad"].includes(saved.devicePref[0])?saved.devicePref[0]:"auto";
          this.devicePref[1]=["auto","kb","pad"].includes(saved.devicePref[1])?saved.devicePref[1]:"auto";
        }
      }
    }catch(e){}
    this.maps = d;
  },
  save: function(){
    try{
      localStorage.setItem("sp98.controls", JSON.stringify({
        kb1:this.maps.kb1, kb2:this.maps.kb2, pad:this.maps.pad,
        dead:this.dead, sens:this.sens, devicePref:this.devicePref
      }));
    }catch(e){}
  },
  reset: function(){
    this.maps = this.defaults();
    this.dead = 0.20; this.sens = 1.0;
    this.devicePref = ["auto","auto"];
    this.save();
  },

  /* etykieta kodu klawisza / przycisku */
  label: function(code){
    if(!code) return "—";
    if(code.indexOf("btn")===0) return "Pad "+code.slice(3);
    var map = {
      Space:"Spacja", Escape:"Esc", Enter:"Enter",
      ShiftLeft:"Shift L", ShiftRight:"Shift P",
      ArrowUp:"↑", ArrowDown:"↓", ArrowLeft:"←", ArrowRight:"→",
      Comma:",", Period:".", Slash:"/", Equal:"+", Minus:"−",
      NumpadAdd:"Num+", NumpadSubtract:"Num−"
    };
    if(map[code]) return map[code];
    if(code.indexOf("Key")===0) return code.slice(3);
    if(code.indexOf("Digit")===0) return code.slice(5);
    return code;
  },

  /* wykrywanie konfliktów w profilu */
  conflicts: function(profile){
    var m = this.maps[profile]||{}, used={}, bad=[];
    Object.keys(m).forEach(function(act){
      var c = m[act]; if(!c) return;
      if(used[c]) bad.push([used[c], act, c]);
      else used[c]=act;
    });
    return bad;
  },

  _norm: function(e){
    if(e.code && e.code.length) return e.code;
    var k = e.key || "";
    var map = { " ": "Space", ",": "Comma", ".": "Period", "/": "Slash" };
    if(map[k]) return map[k];
    if(k.length === 1) return "Key" + k.toUpperCase();
    return k;
  },

  init: function(){
    var self = this;
    this.load();
    window.addEventListener("keydown", function(e){
      var c = self._norm(e);
      if(e.target.closest && e.target.closest("input,textarea,select"))return;
      if(self.listening){
        e.preventDefault();
        if(c==="Escape"){ self.listening=null; if(self.onListen) self.onListen(null); return; }
        var L=self.listening; self.maps[L.profile][L.action]=c;
        self.listening=null; if(self.onListen) self.onListen(L);
        return;
      }
      if(MAIN.state==="match" && !MAIN.paused && ["ArrowUp","ArrowDown","ArrowLeft","ArrowRight","Space","Enter"].includes(c))e.preventDefault();
      self.kb[c] = true;
    });
    window.addEventListener("keyup", function(e){ self.kb[self._norm(e)] = false; });
    window.addEventListener("blur", function(){ self.kb = {}; });
    window.addEventListener("wheel", function(e){
      var dy = e.deltaY || 0;
      if(e.deltaMode === 1) dy *= 33;
      else if(e.deltaMode === 2) dy *= 100;
      if(MAIN.state==="match" && !MAIN.paused)self.wheelAcc += dy;
    }, { passive:true });
    window.addEventListener("gamepadconnected", function(e){
      if(self.padIdx[0]<0) self.padIdx[0]=e.gamepad.index;
      else if(self.padIdx[1]<0 && e.gamepad.index!==self.padIdx[0]) self.padIdx[1]=e.gamepad.index;
      self._reassign();
    });
    window.addEventListener("gamepaddisconnected", function(e){
      if(self.padIdx[0]===e.gamepad.index) self.padIdx[0]=-1;
      if(self.padIdx[1]===e.gamepad.index) self.padIdx[1]=-1;
      self._reassign();
    });
  },

  pads: function(){
    try{return navigator.getGamepads?navigator.getGamepads():[];}catch(e){return [];}
  },
  _reassign: function(){
    var pads = this.pads();
    var used = [];
    if(this.padIdx[0]>=0 && pads[this.padIdx[0]]) used.push(this.padIdx[0]); else this.padIdx[0]=-1;
    if(this.padIdx[1]>=0 && pads[this.padIdx[1]] && used.indexOf(this.padIdx[1])<0) used.push(this.padIdx[1]);
    else if(this.padIdx[1]>=0 && (used.indexOf(this.padIdx[1])>=0 || !pads[this.padIdx[1]])) this.padIdx[1]=-1;
    if(this.padIdx[0]<0){
      for(var i=0;i<pads.length;i++) if(pads[i] && used.indexOf(i)<0){ this.padIdx[0]=i; used.push(i); break; }
    }
    if(this.padIdx[1]<0){
      for(var j=0;j<pads.length;j++) if(pads[j] && used.indexOf(j)<0){ this.padIdx[1]=j; used.push(j); break; }
    }
    this.padSeen[0] = this.padIdx[0]>=0;
    this.padSeen[1] = this.padIdx[1]>=0;
  },

  _empty: function(){
    return { mx:0, mz:0, moveLen:0,
      pass:false, shoot:false, tackle:false, through:false,
      switchL:false, camL:false, pauseL:false, sprint:false, finesse:false, jockey:false,
      passP:false, shootP:false, passR:false, shootR:false,
      tackleP:false, throughP:false, switchP:false, camP:false, pauseP:false,
      device:"—", pad:null };
  },

  _padBtn: function(gp, code){
    if(!gp || !code || code.indexOf("btn")!==0) return false;
    var i = +code.slice(3);
    var b = gp.buttons[i];
    return !!(b && (b.pressed || b.value>0.5));
  },

  _padState: function(gp){
    var s = this._empty(); if(!gp) return s;
    var m = this.maps.pad, dead = this.dead, sens = this.sens;
    var ax = gp.axes[0]||0, az = gp.axes[1]||0;
    var mag = Math.hypot(ax, az);
    if(mag > dead){
      var t = Math.min(1,(mag-dead)/(1-dead))*sens;
      s.mx = (ax/mag)*Math.min(1,t); s.mz = (az/mag)*Math.min(1,t); s.moveLen = Math.min(1,t);
    }
    if(this._padBtn(gp,m.up))    { s.mz = -1; s.moveLen = 1; }
    if(this._padBtn(gp,m.down))  { s.mz =  1; s.moveLen = 1; }
    if(this._padBtn(gp,m.left))  { s.mx = -1; s.moveLen = 1; }
    if(this._padBtn(gp,m.right)) { s.mx =  1; s.moveLen = 1; }
    s.pass=this._padBtn(gp,m.pass); s.shoot=this._padBtn(gp,m.shoot);
    s.tackle=this._padBtn(gp,m.tackle); s.through=this._padBtn(gp,m.through);
    s.sprint=this._padBtn(gp,m.sprint); s.finesse=this._padBtn(gp,m.finesse);
    s.jockey=this._padBtn(gp,m.jockey);
    s.switchL=this._padBtn(gp,m.switch); s.camL=this._padBtn(gp,m.cam); s.pauseL=this._padBtn(gp,m.pause);
    s.device = "PAD"; s.pad = gp;
    /* nasłuch przypisania z pada */
    if(this.listening && this.listening.profile==="pad"){
      for(var bi=0;bi<gp.buttons.length;bi++){
        if(gp.buttons[bi] && gp.buttons[bi].pressed){
          var L=this.listening; this.maps.pad[L.action]="btn"+bi;
          this.listening=null; if(this.onListen) this.onListen(L); break;
        }
      }
    }
    return s;
  },

  _kbState: function(profile, deviceName){
    var s = this._empty(), k = this.kb, m = this.maps[profile]||{};
    var x = (k[m.right]?1:0) - (k[m.left]?1:0);
    var z = (k[m.down]?1:0) - (k[m.up]?1:0);
    if(x||z){ var l=Math.hypot(x,z); s.mx=x/l; s.mz=z/l; s.moveLen=Math.min(1,this.sens); }
    s.pass=!!k[m.pass]; s.shoot=!!k[m.shoot]; s.tackle=!!k[m.tackle]; s.through=!!k[m.through];
    s.sprint=!!k[m.sprint]; s.finesse=!!k[m.finesse]; s.jockey=!!k[m.jockey];
    s.switchL=!!k[m.switch]; s.camL=!!k[m.cam]; s.pauseL=!!k[m.pause];
    s.device = deviceName;
    return s;
  },
  _kb1State: function(){ return this._kbState("kb1","KLAW.1"); },
  _kb2State: function(){ return this._kbState("kb2","KLAW.2"); },

  zoomKey: function(){
    var k = this.kb;
    return ((k["Equal"]||k["NumpadAdd"])?1:0) - ((k["Minus"]||k["NumpadSubtract"])?1:0);
  },

  consumeEdges: function(){
    this.slots.forEach(function(s){
      ["passP","shootP","passR","shootR","tackleP","throughP","switchP","camP","pauseP"].forEach(function(key){s[key]=false;});
    });
  },

  _pickDevice: function(slot, pads){
    var pref = this.devicePref[slot]||"auto";
    var hasPad = this.padIdx[slot]>=0 && pads[this.padIdx[slot]];
    if(pref==="kb") return "kb";
    if(pref==="pad") return hasPad ? "pad" : "kb";
    return hasPad ? "pad" : "kb"; /* auto */
  },

  update: function(){
    this._reassign();
    var pads = this.pads();
    var d0 = this._pickDevice(0, pads), d1 = this._pickDevice(1, pads);
    var s1 = d0==="pad" ? this._padState(pads[this.padIdx[0]]) : this._kb1State();
    var s2 = d1==="pad" ? this._padState(pads[this.padIdx[1]]) : this._kb2State();
    /* wspólne klawisze awaryjne */
    s1.pauseL = s1.pauseL || !!this.kb["Escape"] || !!this.kb["Enter"];
    s2.pauseL = s2.pauseL || !!this.kb["Escape"] || !!this.kb["Enter"];
    if(!s1.camL) s1.camL = !!this.kb["KeyC"];

    var levels = ["pass","shoot","tackle","through","switch","cam","pause"];
    for(var sl=0; sl<2; sl++){
      var cur = sl===0 ? s1 : s2, prev = this._prev[sl];
      var map = { switch:"switchL", cam:"camL", pause:"pauseL" };
      for(var c=0;c<levels.length;c++){
        var name = levels[c];
        var levelKey = map[name] || name;
        var held = !!cur[levelKey], was = prev ? !!prev[levelKey] : false;
        cur[name+"P"] = held && !was;
        if(name==="pass"){ cur.passR = !held && was; cur.passP = held && !was; }
        if(name==="shoot"){ cur.shootR = !held && was; cur.shootP = held && !was; }
        if(name==="switch"||name==="cam"||name==="pause") cur[name+"P"] = held && !was;
      }
      this._prev[sl] = cur;
    }
    this.slots[0] = s1; this.slots[1] = s2;
  },

  anyPadButton: function(){
    var pads = this.pads();
    for(var i=0;i<pads.length;i++){
      var gp = pads[i]; if(!gp) continue;
      for(var b=0;b<gp.buttons.length;b++) if(gp.buttons[b].pressed) return true;
    }
    return false;
  },

  /* ---------- UI przypisywania ---------- */
  openRemapUI: function(){
    var self=this, list=document.getElementById("remapList");
    if(!list) return;
    var profile=document.getElementById("remapProfile").value||"kb1";
    list.replaceChildren();
    this.ACTIONS.forEach(function(a){
      var row=document.createElement("button");
      row.type="button"; row.className="remapAct";
      row.dataset.action=a.id;
      var code=(self.maps[profile]||{})[a.id]||"";
      row.innerHTML="<span class='remapName'></span><span class='remapKey'></span>";
      row.querySelector(".remapName").textContent=a.label;
      row.querySelector(".remapKey").textContent=self.label(code);
      if(self.listening && self.listening.profile===profile && self.listening.action===a.id)
        row.classList.add("listening");
      row.onclick=function(){
        self.listening={profile:profile,action:a.id};
        var st=document.getElementById("remapStatus");
        if(st) st.textContent="Naciśnij klawisz lub przycisk pada dla: "+a.label;
        self.openRemapUI();
      };
      list.appendChild(row);
    });
    var bad=this.conflicts(profile);
    var st=document.getElementById("remapStatus");
    if(st && bad.length && !this.listening)
      st.textContent="Konflikt: "+bad.map(function(x){return x[0]+" / "+x[1];}).join(", ");
  },

  bindRemapUI: function(){
    var self=this;
    var tabView=document.getElementById("helpTabView");
    var tabRemap=document.getElementById("helpTabRemap");
    var cols=document.getElementById("helpCols");
    var remap=document.getElementById("helpRemap");
    var note=document.getElementById("helpNote");
    function show(tab){
      var isRemap=tab==="remap";
      if(tabView) tabView.classList.toggle("on",!isRemap);
      if(tabRemap) tabRemap.classList.toggle("on",isRemap);
      if(cols) cols.classList.toggle("hide",isRemap);
      if(remap) remap.classList.toggle("hide",!isRemap);
      if(note) note.classList.toggle("hide",isRemap);
      if(isRemap) self.openRemapUI();
    }
    if(tabView) tabView.onclick=function(){ show("view"); };
    if(tabRemap) tabRemap.onclick=function(){ show("remap"); };
    var prof=document.getElementById("remapProfile");
    if(prof) prof.onchange=function(){ self.listening=null; self.openRemapUI(); };
    var dead=document.getElementById("remapDead");
    if(dead){
      dead.value=Math.round(self.dead*100);
      dead.oninput=function(){
        self.dead=Math.max(0.05,Math.min(0.4,(+dead.value||20)/100));
        var v=document.getElementById("deadVal"); if(v) v.textContent=self.dead.toFixed(2);
      };
    }
    var sens=document.getElementById("remapSens");
    if(sens){
      sens.value=Math.round(self.sens*100);
      sens.oninput=function(){
        self.sens=Math.max(0.5,Math.min(1.5,(+sens.value||100)/100));
        var v=document.getElementById("sensVal"); if(v) v.textContent=self.sens.toFixed(2);
      };
    }
    ["remapDev0","remapDev1"].forEach(function(id,i){
      var el=document.getElementById(id); if(!el) return;
      el.value=self.devicePref[i]||"auto";
      el.onchange=function(){ self.devicePref[i]=el.value; };
    });
    var btnReset=document.getElementById("btnRemapReset");
    if(btnReset) btnReset.onclick=function(){
      self.reset(); self.openRemapUI();
      if(dead) dead.value=20; if(sens) sens.value=100;
      var dv=document.getElementById("deadVal"); if(dv) dv.textContent="0.20";
      var sv=document.getElementById("sensVal"); if(sv) sv.textContent="1.00";
      ["remapDev0","remapDev1"].forEach(function(id,i){ var el=document.getElementById(id); if(el) el.value="auto"; });
      var st=document.getElementById("remapStatus"); if(st) st.textContent="Przywrócono domyślne.";
    };
    var btnSave=document.getElementById("btnRemapSave");
    if(btnSave) btnSave.onclick=function(){
      self.save();
      var st=document.getElementById("remapStatus"); if(st) st.textContent="Zapisano profil lokalnie.";
    };
    self.onListen=function(){ self.openRemapUI(); var st=document.getElementById("remapStatus"); if(st&&!self.listening) st.textContent="Przypisano."; };
  }
};
