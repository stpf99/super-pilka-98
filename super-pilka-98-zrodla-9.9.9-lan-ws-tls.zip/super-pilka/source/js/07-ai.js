/* ============================================================
   SUPER PILKA '98 · 07-ai.js — sztuczna inteligencja 11v11
   Formacja 4-4-2, pressing, krycie, decyzje z piłką, bramkarz.
   ============================================================ */
var AI = {
  frozen: false,   // podczas wznowień AI stoi na pozycjach wyznaczonych przez zasady

  clampX: function(v){ return Math.max(-HL+2, Math.min(HL-2, v)); },
  clampZ: function(v){ return Math.max(-HW+2, Math.min(HW-2, v)); },

  profile:function(team){
    return DIFF[SET.mode===0 && team===0?1:SET.diff];
  },
  update: function(dt, owner){
    var b = SIM.ball;
    for(var t=0;t<2;t++){
      var D=this.profile(t),mates = SIM.teamPlayers(t);
      var opps  = SIM.teamPlayers(1-t);
      var dirX = SIM.teams[t].dir;
      var plan=LINEUP.tactic(t);
      var opposingLine=opps.map(function(p){return p.pos.x*dirX;}).sort(function(a,b){return b-a;})[1]||0;
      var phase = "loose";
      if(b.owner) phase = b.owner.team===t ? "attack" : "defend";
      else if(b.lastTouchTeam===t) phase = "attackLoose";
      else phase = "loose";

      /* najbliższy do piłki (poza GK) */
      var chaser = null, chaser2 = null, cd = 1e9, cd2 = 1e9;
      for(var i=0;i<mates.length;i++){
        var m = mates[i];
        if(m.role==="GK" || m.isUser!==null || m.netHuman)continue;
        var d = (m.pos.x-b.x)*(m.pos.x-b.x)+(m.pos.z-b.z)*(m.pos.z-b.z);
        if(d < cd){ cd2 = cd; chaser2 = chaser; cd = d; chaser = m; }
        else if(d < cd2){ cd2 = d; chaser2 = m; }
      }

      for(var k=0;k<mates.length;k++){
        var pl = mates[k];
        if(pl.isUser !== null || pl.netHuman) continue;   // sterowany przez człowieka
        if(pl.role==="GK"){ this.gk(pl, dt, D); continue; }
        pl.closeControl=false;
        if(this.frozen){ pl.moveTarget = null; continue; }

        /* --- właściciel piłki (AI) --- */
        if(b.owner===pl){
          this.decide(pl, dt, D, opps, dirX);
          continue;
        }
        if(!b.owner && pl===chaser && b.shotTeam===1-t && b.y>.65 && b.y<1.72 && cd<1.15 && pl.challengeCd<=0 && pl.role==="DF" && Math.random()<dt*.7){
          SIM.standingTackle(pl);
        }
        if(!b.owner && b.receiver===pl && b.route){
          pl.moveTarget=this.receiveTarget(pl);continue;
        }
        if(pl.runT>0 && (!b.owner || b.owner.team===t) && b.lastTouchTeam===t){
          pl.moveTarget={x:this.clampX(pl.pos.x+dirX*9),z:this.clampZ(pl.pos.z*.96),sprint:true};continue;
        }
        if(!b.owner && (pl===chaser || pl===chaser2 && cd2<36 && !b.receiver) && (!b.receiver || b.receiver.team!==t || cd<9 || Math.hypot(b.vx,b.vz)<2.4)){
          pl.moveTarget=this.receiveTarget(pl);continue;
        }
        /* --- pressing przy posiadaniu przeciwnika --- */
        if(b.owner && b.owner.team!==t){
          var mayPress=b.ownerAge>=D.delay;
          if(pl===chaser && cd<D.press*D.press){
            if(!mayPress){
              pl.moveTarget={x:this.clampX(b.x-dirX*D.space),z:b.z,amount:.43};
            }else{
              pl.moveTarget={x:b.x+b.owner.vel.x*.09,z:b.z+b.owner.vel.z*.09,sprint:cd>8};
              if(cd<2.45 && pl.challengeCd<=0 && !pl.challenge){
                var gapX=b.x-pl.pos.x,gapZ=b.z-pl.pos.z;
                var closing=gapX*pl.vel.x+gapZ*pl.vel.z;
                var sprinting=Math.hypot(pl.vel.x,pl.vel.z)>4.1;
                if(sprinting && closing>2 && cd>1.18 && Math.random()<.09+.13*D.aiIQ)SIM.startSlide(pl);
                else SIM.standingTackle(pl);
              }
            }
            continue;
          }
          if(mayPress && pl===chaser2 && D.aiIQ>.55 && (plan==="press" || (plan==="balanced" && cd2<65))){
            var gx0 = -dirX*HL;
            var bx = (b.owner.pos.x-gx0), bz = (b.owner.pos.z);
            var bl = Math.hypot(bx, bz)||1;
            pl.moveTarget = { x: b.owner.pos.x + (gx0-b.owner.pos.x)/bl*4.5, z: b.owner.pos.z - bz/bl*2, sprint: true };
            continue;
          }
        }
        /* --- krycie przy obronie --- */
        if(phase==="defend"){
          var mark = this.findMark(pl, opps, mates);
          if(mark){
            var tgx = -dirX*HL;
            var mdx = tgx-mark.pos.x, mdz = 0-mark.pos.z;
            var ml = Math.hypot(mdx, mdz)||1;
            pl.moveTarget = { x: mark.pos.x + mdx/ml*D.space, z: mark.pos.z + mdz/ml*D.space, sprint: Math.abs(mark.pos.x-pl.pos.x)>8 };
            continue;
          }
        }
        pl.moveTarget=this.formationTarget(pl,dirX,phase==="attack" || phase==="attackLoose",opposingLine,plan);
      }
    }
  },

  receiveTarget: function(pl){
    var b=SIM.ball,x=b.x,z=b.z,y=b.y,vx=b.vx,vz=b.vz,vy=b.vy;
    var speed=pl.pace*AI.profile(pl.team).spd*1.22,dt=.09;
    for(var i=1;i<=28;i++){
      var air=y>SIM.BR+.025,drag=Math.exp(-(air?.13:.72*CONDITIONS.drag())*dt);
      vx*=drag;vz*=drag;x+=vx*dt;z+=vz*dt;vy-=SIM.G*dt;y+=vy*dt;
      if(y<SIM.BR){y=SIM.BR;vy=vy<-1.4?-vy*CONDITIONS.bounce():0;}
      if(Math.abs(x)>HL || Math.abs(z)>HW || y<1.93 && Math.hypot(x-pl.pos.x,z-pl.pos.z)<speed*dt*i+.45)break;
    }
    return {x:Math.max(-HL-.15,Math.min(HL+.15,x)),z:Math.max(-HW-.15,Math.min(HW+.15,z)),sprint:true};
  },
  formationTarget: function(pl,dir,attacking,line,plan){
    var b=SIM.ball,bx=b.x*dir,homeX=pl.home.x,homeZ=pl.home.z*dir;
    var advance=attacking?(pl.role==="DF"?10:17):2;
    var depth=homeX+advance+bx*(pl.role==="DF" ? 0.51 : 0.54)+(plan==="press"?5:0);
    if(pl.role==="FW" && attacking)depth=Math.max(depth,bx+7+(plan==="counter"?6:0));
    if(attacking && pl.role!=="DF")depth=Math.min(depth,Math.max(0,line-1.1,bx-.4));
    if(!attacking && plan==="counter")depth-=4.5;
    var width=attacking?1.05 : 0.78;
    var tz=homeZ*width+b.z*(attacking ? 0.19 : 0.29);
    if(attacking && Math.abs(homeZ)>17 && bx>29 && Math.sign(homeZ)!==Math.sign(b.z))tz*=.64;
    return {x:this.clampX(dir*depth),z:this.clampZ(tz),sprint:attacking && plan==="counter" && pl.role!=="DF"};
  },

  findMark: function(pl, opps, mates){
    var best = null, bs = 1e9;
    var gx = -SIM.teams[pl.team].dir*HL;
    for(var i=0;i<opps.length;i++){
      var o = opps[i];
      if(o.role==="GK") continue;
      if(o.pos.x*SIM.teams[pl.team].dir < 0 && o.role==="DF") continue; /* daleko u siebie */
      var d = Math.hypot(o.pos.x-pl.pos.x, o.pos.z-pl.pos.z);
      if(d > 18) continue;
      /* nie kradnij krycia kolegi bliższego */
      var mateCloser = false;
      for(var j=0;j<mates.length;j++){
        var m2 = mates[j];
        if(m2===pl || m2.role==="GK") continue;
        var d2 = Math.hypot(o.pos.x-m2.pos.x, o.pos.z-m2.pos.z);
        if(d2 < d - 1.5){ mateCloser = true; break; }
      }
      if(mateCloser) continue;
      var danger = Math.abs(o.pos.x - gx) < 30 ? 0 : 8;
      var s = d + danger;
      if(s < bs){ bs = s; best = o; }
    }
    return best;
  },

  /* ---------- decyzje AI z piłką ---------- */
  decide: function(pl, dt, D, opps, dirX){
    var b = SIM.ball;
    if(b.release)return;
    if(pl.decideCd > 0){
      /* drybling w kierunku bramki z unikiem */
      var weave = Math.sin(RULES.elapsed*1.4 + pl.idx)*0.5;
      var gx = dirX*HL;
      var dx = gx-pl.pos.x, dz = 0-pl.pos.z + weave*8;
      var l = Math.hypot(dx, dz)||1;
      dx/=l; dz/=l;
      var spread = this.spreadAhead(pl, opps, dx, dz);
      if(spread < 2.2){
        var side = (pl.idx%2===0) ? -1 : 1;
        var px = -dz, pz = dx;          /* kierunek prostopadły */
        dx = px*side; dz = pz*side;
        var l2 = Math.hypot(dx, dz)||1; dx/=l2; dz/=l2;
      }
      pl.moveTarget = { x: this.clampX(pl.pos.x + dx*6), z: this.clampZ(pl.pos.z + dz*6), sprint: spread > 4 };
      return;
    }
    pl.decideCd = D.react + Math.random()*0.15;
    var distGoal = Math.hypot(dirX*HL-pl.pos.x, pl.pos.z);
    var pressure = this.nearestOppDist(pl, opps);

    /* strzał */
    var shootRange = D.range;
    if(distGoal < shootRange && Math.abs(pl.pos.z) < 20 && Math.random() < .25+D.aiIQ*.61){
      var aimZ=(Math.random()<.5?-1:1)*(1.35+Math.random()*1.35);
      var tx = dirX*HL, tz = aimZ + (Math.random()*2-1)*D.shotErr;
      var pdx = tx-pl.pos.x, pdz = tz-pl.pos.z;
      var pl2 = Math.hypot(pdx, pdz)||1;
      pl.moveTarget = null;
      SIM.shoot(pl,pdx/pl2,pdz/pl2,Math.min(.54+.44*D.aiIQ,.43+distGoal/42),"shot");
      return;
    }
    /* ocena podań */
    var bestMate = null, bestScore = -1e9;
    var mates = SIM.teamPlayers(pl.team);
    for(var i=0;i<mates.length;i++){
      var m = mates[i];
      if(m===pl || m.role==="GK") continue;
      var dxm = m.pos.x-pl.pos.x, dzm = m.pos.z-pl.pos.z;
      var dm = Math.hypot(dxm, dzm);
      if(dm < 4 || dm > 38) continue;
      var prog = dxm*dirX;
      if(prog < -8 && pressure < 5) continue;
      var open = this.laneOpenness(pl, m, opps);
      var sc = open*10 + prog*0.35 - Math.abs(dm-16)*0.12;
      if(dm > 26) sc -= 3;
      if(sc > bestScore){ bestScore = sc; bestMate = m; }
    }
    /* podanie pod presją albo gdy dobra opcja */
    var passThresh = pressure < 4 ? 1.5 : 28+(1-D.aiIQ)*10;
    if(Math.abs(pl.pos.z)>16 && pl.pos.x*dirX>24){
      var inside=mates.filter(function(m){return m!==pl && m.pos.x*dirX>20 && Math.abs(m.pos.z)<15;})
        .sort(function(a,b){return b.pos.x*dirX-a.pos.x*dirX;})[0];
      if(inside){SIM.deliver(pl,inside,"cross",.72,dirX,0,null,D.passErr);return;}
    }
    if(bestMate && bestScore > passThresh && (pressure<6 || bestMate.pos.x*dirX>pl.pos.x*dirX+3)){
      var through=(bestMate.runT>0 || (bestMate.role==="FW" && pressure<5 && bestMate.pos.x*dirX>0));
      SIM.deliver(pl,bestMate,through?"through":"pass",.46+D.aiIQ*.25,dirX,0,null,D.passErr);
      if(pl.role!=="DF" && pressure<5)pl.runT=1.55;
      return;
    }
    /* drybling / wybij z zagrożenia */
    if(pressure < 2.2 && (pl.role==="DF") && distGoal > 30){
      SIM.kick(pl, dirX, (Math.random()*2-1)*0.7, 0.8, "clear");
      return;
    }
    /* kontynuacja dryblingu */
    this.decide(pl, dt, D, opps, dirX);
    pl.decideCd = D.react*.85;
  },

  spreadAhead: function(pl, opps, dx, dz){
    var best = 1e9;
    for(var i=0;i<opps.length;i++){
      var o = opps[i];
      var rx = o.pos.x-pl.pos.x, rz = o.pos.z-pl.pos.z;
      var proj = rx*dx+rz*dz;
      if(proj < 0 || proj > 9) continue;
      var perp = Math.abs(rx*dz - rz*dx);
      best = Math.min(best, perp);
    }
    return best===1e9 ? 9 : best;
  },
  nearestOppDist: function(pl, opps){
    var d = 1e9;
    for(var i=0;i<opps.length;i++){
      var dd = Math.hypot(opps[i].pos.x-pl.pos.x, opps[i].pos.z-pl.pos.z);
      if(dd < d) d = dd;
    }
    return d;
  },
  laneOpenness: function(a, m, opps){
    var dx = m.pos.x-a.pos.x, dz = m.pos.z-a.pos.z;
    var l = Math.hypot(dx,dz)||1;
    var best = 99;
    for(var i=0;i<opps.length;i++){
      var o = opps[i];
      var rx = o.pos.x-a.pos.x, rz = o.pos.z-a.pos.z;
      var proj = rx*dx/l + rz*dz/l;
      if(proj < 0 || proj > l) continue;
      var perp = Math.abs(rx*dz/l - rz*dx/l);
      best = Math.min(best, perp);
    }
    return Math.min(best, 8);
  },

  /* ---------- bramkarz ---------- */
  gk: function(pl, dt, D){
    var b = SIM.ball;
    var t = pl.team, dirX = SIM.teams[t].dir;
    var gx = -dirX*HL;   // własna bramka

    if(b.owner===pl){
      /* rozegranie po chwili */
      /* Czas decyzji odlicza fizyka zawodnika. */
      if(pl.decideCd <= 0){
        var mates = SIM.teamPlayers(t);
        var fb = null, bd = 1e9;
        for(var i=0;i<mates.length;i++){
          var m = mates[i];
          if(m===pl || m.role==="GK") continue;
          var d = Math.hypot(m.pos.x-pl.pos.x, m.pos.z-pl.pos.z);
          if(d<bd && m.role==="DF"){ bd=d; fb=m; }
        }
        if(fb && Math.random()<0.6 && bd<26){
          SIM.deliver(pl,fb,"pass",.45,dirX,0,null,D.passErr);
        } else {
          SIM.kick(pl, dirX, (Math.random()*2-1)*0.6, 0.85, "gklong"); RULES.onPass(pl,null);
        }
      }
      pl.moveTarget = null;
      return;
    }
    var inBox=Math.abs(b.x-gx)<16.5 && Math.abs(b.z)<20.1;
    var shot=!b.owner && b.shotTeam===1-t && (gx-b.x)*b.vx>0;
    if(shot && Math.abs(b.vx)>3){
      var eta=(gx-b.x)/b.vx, iz=b.z+b.vz*eta;
      if(eta>0 && eta<.65+D.gk*.57 && b.flightAge>.44-.42*D.gk && Math.abs(iz)<6){
        pl.moveTarget={x:gx+dirX*1.0,z:this.clampZ(iz),sprint:true};
        var d=Math.hypot(b.x-pl.pos.x,b.z-pl.pos.z);
        if(d<.92+D.gk*1.04 && b.y<2.7 && pl.challengeCd<=0){
          pl.challengeCd=.76;pl.diveSide=-(b.z>pl.pos.z?1:-1)*dirX;
          pl.face=Math.atan2(dirX,0);pl.action="dive";pl.actionT=.65;
          pl.vel.z=(b.z>pl.pos.z?1:-1)*3.4;
          if(d<.42 || Math.random()<D.gk*.92){
            var caught=d<1.18 && b.y<1.8;
            RULES.onSave(pl,caught);
            if(caught){SIM.takeBall(pl);pl.keeperHold=true;}
            else{b.vx=dirX*(6+Math.abs(b.vx)*.3);b.vz=(Math.sign(b.z)||1)*9;b.vy=3;
              b.lastTouchTeam=t;b.lastKicker=pl;b.shotTeam=null;b.flight="parry";b.lock=.35;}
            AUDIO.catchSnd();
          }
        }
        return;
      }
    }
    if(inBox && !b.owner && b.y<1.6 && !shot){
      pl.moveTarget={x:b.x,z:b.z,sprint:true};return;
    }
    /* pozycjonowanie na łuku */
    var bx = b.x-gx, bz = b.z;
    var bl = Math.hypot(bx, bz)||1;
    var r = Math.min(5.2, bl*0.28 + 1.2);
    var tx = gx + bx/bl*r;
    var tz = Math.max(-6.8, Math.min(6.8, bz/bl*r*0.9));
    if(!inBox) tz *= 0.7;
    pl.moveTarget = { x: tx, z: tz, sprint: false };
  }
};
