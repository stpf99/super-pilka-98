var CONDITIONS={
  drag:function(){return SET.weather==="snow"?1.36:SET.weather==="rain"?.82:1;},
  bounce:function(){return SET.weather==="snow"?.34:SET.weather==="rain"?.45:.55;},
  venues:{classic:["Stadion Miejski",0xffffff,0xffffff],terrace:["Park Kasztanowy",0xb7ab8a,0xbea783],arena:["Arena Północna",0xa7cfe3,0x92bde5]},
  venue:function(){
    var s=STADIUM,v=this.venues[SET.stadium],g=s.plaque.image.getContext("2d");
    s.masonry.color.setHex(v[1]);s.frames.color.setHex(v[2]);
    g.fillStyle=SET.stadium==="terrace"?"#542d20":SET.stadium==="arena"?"#173b5e":"#23373a";g.fillRect(0,0,512,64);
    g.fillStyle="#f3deb2";g.fillRect(0,4,512,3);g.font="bold 37px Arial";g.textAlign="center";g.textBaseline="middle";g.fillText(v[0].toUpperCase(),256,35,465);s.plaque.needsUpdate=true;
    if(!s.decor){
      s.decor={};
      ["terrace","arena"].forEach(function(kind){
        var geo=new ArenaGeometry();
        s.sides.forEach(function(side){
          for(var i=0;i<side.bays;i++){
            var u=i/side.bays,v=(i+1)/side.bays,m=(u+v)/2;
            if(kind==="arena"){
              geo.rod(side.at(u,17,15.9),side.at(m,18,20.2),.18,.16,0xd2e1e4,8);
              geo.rod(side.at(m,18,20.2),side.at(v,17,15.9),.16,.18,0xd2e1e4,8);
              geo.rod(side.at(m,18,20.2),side.at(m,8,14.6),.045,.035,0x8da4b4,5);
            }else{
              geo.quad(side.at(u,6.84,14.12),side.at(v,6.84,14.12),side.at(v,6.84,13.42),side.at(u,6.84,13.42),i%2?0x963b32:0xedcf91);
            }
          }
        });
        s.decor[kind]=new THREE.Mesh(geo.build(false),new THREE.MeshLambertMaterial({vertexColors:true,side:THREE.DoubleSide}));s.group.add(s.decor[kind]);
      });
    }
    Object.keys(s.decor).forEach(function(k){s.decor[k].visible=k===SET.stadium;});
  },
  apply:function(){
    var mode=SET.weather,w=WORLD;
    if(!this.rain){
      var count=2600,rain=new Float32Array(count*6),snow=new Float32Array(count*3);
      for(var i=0;i<count;i++){
        var n=i*3;snow[n]=Math.random()*138-69;snow[n+1]=Math.random()*30;snow[n+2]=Math.random()*96-48;
        for(var j=0;j<3;j++)rain[i*6+j]=snow[n+j];
        rain[i*6+3]=snow[n]-.09;rain[i*6+4]=snow[n+1]+.53;rain[i*6+5]=snow[n+2]+.025;
      }
      function layer(array,lines){
        var geo=new THREE.BufferGeometry(),attribute=new THREE.BufferAttribute(array,3);attribute.setUsage(THREE.DynamicDrawUsage);geo.setAttribute("position",attribute);
        var obj=lines?new THREE.LineSegments(geo,new THREE.LineBasicMaterial({color:0xb8d9ef,transparent:true,opacity:.42,depthWrite:false})):
          new THREE.Points(geo,new THREE.PointsMaterial({color:0xfcfcff,size:.105,transparent:true,opacity:.88,depthWrite:false}));
        obj.frustumCulled=false;w.scene.add(obj);return obj;
      }
      this.rain=layer(rain,true);this.snow=layer(snow,false);
    }
    this.rain.visible=mode==="rain";this.snow.visible=mode==="snow";
    var count=[680,1500,2600][SET.q];this.rain.geometry.setDrawRange(0,count*2);this.snow.geometry.setDrawRange(0,count);
    if(mode!=="clear"){
      var shade=w.night?0x3d485a:mode==="rain"?0x687e90:0xb5c3c6;
      w.scene.fog=new THREE.Fog(shade,mode==="fog"?14:45,mode==="fog"?107:190);
      w._sun.intensity*=mode==="fog"?.54:.72;if(w.stars)w.stars.visible=false;
    }
    if(PITCH.surfaceWeather)PITCH.surfaceWeather.value=mode==="snow"?1:mode==="rain"?-1:0;
  },
  tick:function(dt){
    var rain=this.rain?.visible,obj=rain?this.rain:this.snow;
    if(!obj || !obj.visible)return;
    var p=obj.geometry.attributes.position,a=p.array,step=rain?6:3;
    for(var i=0;i<obj.geometry.drawRange.count*3;i+=step){
      a[i]+=dt*(rain?2.4:.67+.50*Math.sin(a[i+1]+i));a[i+1]-=dt*(rain?14:1.85+(i%7)*.08);
      if(a[i+1]<0)a[i+1]+=30;if(a[i]>69)a[i]-=138;
      if(rain){a[i+3]=a[i]-.09;a[i+4]=a[i+1]+.53;a[i+5]=a[i+2]+.025;}
    }
    p.needsUpdate=true;
  },
  ball:function(){
    [WORLD,SHOWROOM].forEach(function(w){if(!w.ball)return;
      var old=w.ball,fresh=PITCH.ball();old.geometry.dispose();old.geometry=fresh.geometry;
      old.material.dispose();old.material=fresh.material;
    });
  }
};
