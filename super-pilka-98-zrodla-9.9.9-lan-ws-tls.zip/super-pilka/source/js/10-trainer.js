/* ============================================================
   SUPER PILKA '98 · 10-trainer.js — szkołka sterowania (pad / klawiatura)
   Ćwiczenia na prawdziwym rdzeniu symulacji (SIM + HUMAN), więc uczysz się
   dokładnie tych samych zachowań co w meczu — w tym utrzymania kontaktu
   z piłką i wysuwania jej po dłuższym biegu w jednym kierunku.
   Jeden podopieczny (napastnik gospodarzy), kolega do podań, bramkarz gości
   i manekin do odbiorów. Podpowiedzi same wybierają nazwy klawiszy pada
   albo klawiatury. Wyjście: Esc lub przycisk „Wróć".
   ============================================================ */
var TRAINER = {
  active:false, ready:false, step:-1, t:0, flashT:0, hits:0, need:0,
  attempts:0, attemptsTotal:0, completed:0, power:0, gate:0,
  finesseSeen:false, comboSeen:false, goalDelay:0, status:"", statusKey:"",
  trainee:null, mate:null, gk:null, dummy:null,
  gfx:null, _geo:[], cones:[], rings:[], meRing:null, modeBackup:0,

  el: function(id){ return document.getElementById(id); },

  /* nazwy przycisków zależne od urządzenia i profilu INPUT */
  names: function(){
    if(INPUT.padSeen[0] && (INPUT.devicePref[0]!=="kb")){
      var p=INPUT.maps.pad||{};
      return { dev:"pada", move:"lewa gałka", sprint:INPUT.label(p.sprint), jockey:INPUT.label(p.jockey),
        pass:INPUT.label(p.pass), shoot:INPUT.label(p.shoot), slide:INPUT.label(p.tackle),
        through:INPUT.label(p.through), finesse:INPUT.label(p.finesse), combo:INPUT.label(p.switch), switch:INPUT.label(p.switch) };
    }
    var k=INPUT.maps.kb1||{};
    return { dev:"klawiatury",
      move:[k.up,k.left,k.down,k.right].map(function(c){return INPUT.label(c);}).join(""),
      sprint:INPUT.label(k.sprint), jockey:INPUT.label(k.jockey), pass:INPUT.label(k.pass),
      shoot:INPUT.label(k.shoot), slide:INPUT.label(k.tackle), through:INPUT.label(k.through),
      finesse:INPUT.label(k.finesse), combo:INPUT.label(k.switch), switch:INPUT.label(k.switch) };
  },
  fill: function(str){
    var n=this.names();
    return String(str).replace(/\{(\w+)\}/g, function(m,k){ return n[k]!==undefined?n[k]:m; });
  },

  /* ---------- wejście / wyjście ---------- */
  open: function(){
    if(this.active) return;
    this.active=true; this.modeBackup=SET.mode; SET.mode=0;
    this.el("ovMenu").classList.add("hide");
    this.el("ovTrain").classList.remove("hide");
    this.buildSquad();
    this.buildGfx();
    this.step=-1; this.attemptsTotal=0; this.completed=0;
    this.applyDrill();
  },
  close: function(){
    if(!this.active) return;
    this.active=false; this.ready=false;
    this.el("ovTrain").classList.add("hide");
    this.el("ovMenu").classList.remove("hide");
    if(this.gfx){ WORLD.gFx.remove(this.gfx); this.gfx=null; }
    this._disposeGeo();
    SET.mode=this.modeBackup;
    BROADCAST.clear(); RULES.state="menu"; RULES.lastFoul=null; MAIN.state="menu";
    HUD.showPower(null); HUD.hideEvent(); HUD.restartTagHide();
    DESK.refresh(); VOICE.stopSpeech();
  },

  buildSquad: function(){
    PITCH.reset(); STADIUM.goalTeam=-1; STADIUM.goalLeft=0;
    RULES.newMatch();                       /* pełny rdzeń: piłka, zawodnicy, statystyki */
    RULES.state="play"; RULES.half=1; RULES.elapsed=0; RULES.stateT=0;
    HUD.restartTagHide(); HUD.hideEvent(); HUD.hint("");
    /* zostawiamy czwórkę: podopieczny, kolega, bramkarz i manekin gości */
    var keep={ "0-9":1, "0-10":1, "1-0":1, "1-9":1 };
    for(var i=SIM.players.length-1;i>=0;i--){
      var p=SIM.players[i];
      if(!keep[p.team+"-"+p.idx]){ if(p.mesh)WORLD.removePlayer(p.mesh); SIM.players.splice(i,1); }
    }
    this.trainee=SIM.players.find(function(p){return p.team===0&&p.idx===9;});
    this.mate=SIM.players.find(function(p){return p.team===0&&p.idx===10;});
    this.gk=SIM.players.find(function(p){return p.team===1&&p.role==="GK";});
    this.dummy=SIM.players.find(function(p){return p.team===1&&p.idx===9;});
    SIM.control(0,this.trainee);
    CAM._last=null; CAM.zoomT=1;
    this.ready=true;
  },

  /* ---------- markery na murawie ---------- */
  buildGfx: function(){
    if(this.gfx)WORLD.gFx.remove(this.gfx);
    this._disposeGeo();
    var g=new THREE.Group(), self=this;
    var coneGeo=new THREE.ConeGeometry(.20,.56,10); this._geo.push(coneGeo);
    var ringGeo=new THREE.RingGeometry(2.75,3.2,44); this._geo.push(ringGeo);
    var smallGeo=new THREE.RingGeometry(1.6,1.95,36); this._geo.push(smallGeo);
    var orange=new THREE.MeshBasicMaterial({color:0xff8a3d});
    var lime=new THREE.MeshBasicMaterial({color:0xd9ff59,transparent:true,opacity:.9,side:THREE.DoubleSide});
    var dim=new THREE.MeshBasicMaterial({color:0x6e8f7e,transparent:true,opacity:.5,side:THREE.DoubleSide});
    this._mat=[orange,lime,dim];
    this.cones=[]; this.rings=[];
    for(var i=0;i<10;i++){ var c=new THREE.Mesh(coneGeo,orange); c.position.y=.29; g.add(c); this.cones.push(c); }
    for(var j=0;j<4;j++){ var r=new THREE.Mesh(ringGeo,j===0?lime:dim); r.rotation.x=-Math.PI/2; r.position.y=.045; g.add(r); this.rings.push(r); }
    var me=new THREE.Mesh(smallGeo,lime); me.rotation.x=-Math.PI/2; me.position.y=.05; g.add(me);
    this.meRing=me;
    this.gfx=g; WORLD.gFx.add(g);
  },
  _disposeGeo: function(){
    (this._geo||[]).forEach(function(x){ if(x.dispose)x.dispose(); });
    (this._mat||[]).forEach(function(x){ if(x.dispose)x.dispose(); });
    this._geo=[]; this._mat=[];
  },
  ring: function(i,x,z,active){
    var r=this.rings[i]; if(!r)return;
    r.visible=true; r.position.set(x,.045,z);
    r.material=active?(this._mat?this._mat[1]:r.material):(this._mat?this._mat[2]:r.material);
  },
  cone: function(i,x,z){ var c=this.cones[i]; if(c){ c.visible=true; c.position.set(x,.29,z); } },

  /* ---------- piłka ---------- */
  placeBall: function(x,z,owner){
    var b=SIM.ball, u=this.trainee;
    HUMAN.clear(u);
    b.owner=null;b.cushion=null;b.receiver=null;b.route=null;b.flight="";b.shotTeam=null;b.lastShotBy=null;
    b.lastKicker=null;b.lock=.12;b.curve=0;b.release=null;b.nextTouch=0;b.rollDrag=2.1;b.live=true;
    b.vx=b.vy=b.vz=0;b.x=x;b.y=SIM.BR;b.z=z;b.ownerAge=0;
    if(owner){ b.owner=owner; }
    else if(u){
      u.pos.x=x-1.15; u.pos.z=z; u.vel.x=u.vel.z=0; u.action="run"; u.actionT=0;
      u.challenge=null; u.challengeCd=0; u.face=Math.atan2(HL-x,-z)||0;
    }
    SIM.teams[0].switchCd=0; SIM.control(0,u);
  },

  /* ---------- definicje ćwiczeń ---------- */
  DRILLS: [
    { key:"move", frozen:true, need:1,
      setup:function(){
        this.hideBall(true);
        var T=this;
        T.trainee.pos.x=-40;T.trainee.pos.z=0;T.trainee.vel.x=T.trainee.vel.z=0;T.trainee.face=Math.PI/2;
        T.mate.pos.x=-46;T.mate.pos.z=8;T.gk.pos.x=HL-2;T.gk.pos.z=0;T.dummy.pos.x=-HL+2;T.dummy.pos.z=-6;
        var gates=[[-24,-10],[-10,10],[4,-6]];
        T.gatePoints=gates; T.gate=0;
        T.cones.forEach(function(c){c.visible=false;}); T.rings.forEach(function(r,i){r.visible=i<1;});
        T.ring(0,gates[0][0],gates[0][1],true);
        T.cone(0,gates[0][0],gates[0][1]-2.6); T.cone(1,gates[0][0],gates[0][1]+2.6);
        T.status=t("tr_status_gate").replace("{n}","1");
      },
      check:function(){
        var g=this.gatePoints[this.gate],p=this.trainee;
        if(Math.hypot(p.pos.x-g[0],p.pos.z-g[1])<2.9){
          AUDIO.ui(); this.gate++;
          if(this.gate>=3)return true;
          var n=this.gatePoints[this.gate];
          this.ring(0,n[0],n[1],true);
          this.cone(0,n[0],n[1]-2.6); this.cone(1,n[0],n[1]+2.6);
          this.status=t("tr_status_gate").replace("{n}",String(this.gate+1));
        }
        return false;
      } },
    { key:"sprint", frozen:true, need:1, time:8.5,
      setup:function(){
        this.hideBall(true);
        var T=this;
        T.trainee.pos.x=-40;T.trainee.pos.z=0;T.trainee.vel.x=T.trainee.vel.z=0;T.trainee.face=Math.PI/2;
        T.mate.pos.x=-46;T.mate.pos.z=8;T.gk.pos.x=HL-2;T.gk.pos.z=0;T.dummy.pos.x=-HL+2;T.dummy.pos.z=-6;
        T.cones.forEach(function(c){c.visible=false;});
        T.rings.forEach(function(r,i){r.visible=i<2;});
        T.ring(0,-6,0,false); T.ring(1,28,0,true);
        T.status=t("tr_status_sprint");
      },
      check:function(){
        var p=this.trainee;
        if(Math.hypot(p.pos.x-28,p.pos.z)<3.8)return true;
        if(this.t>this.DRILLS[this.step].time){ this.fail(t("tr_status_slow")); this.applyDrill(); }
        return false;
      } },
    { key:"dribble", frozen:true, need:1,
      setup:function(){
        this.hideBall(false);
        var T=this;
        T.trainee.pos.x=-40;T.trainee.pos.z=0;T.trainee.vel.x=T.trainee.vel.z=0;T.trainee.face=Math.PI/2;
        T.mate.pos.x=-46;T.mate.pos.z=-8;T.gk.pos.x=HL-2;T.gk.pos.z=0;T.dummy.pos.x=-HL+2;T.dummy.pos.z=6;
        var cs=[[-26,-5],[-18,5],[-10,-5],[-2,5],[6,-5]];
        T.cones.forEach(function(c,i){ c.visible=i<cs.length; if(i<cs.length)c.position.set(cs[i][0],.29,cs[i][1]); });
        T.rings.forEach(function(r,i){r.visible=i<2;});
        T.ring(0,20,0,false); T.ring(1,20,0,true);
        this.placeBall(-38.8,0);
        T.lostGrace=0;
        T.status=t("tr_status_dribble");
      },
      check:function(dt){
        var p=this.trainee,b=SIM.ball;
        var near=Math.hypot(b.x-p.pos.x,b.z-p.pos.z);
        /* chwilowa utrata ownera (np. przy zwrocie) nie kasuje od razu — daj ~0,75 s na odzyskanie */
        if(b.owner!==p && near>8.5){
          this.lostGrace=(this.lostGrace||0)+(dt||0.016);
          if(this.lostGrace>0.75){
            this.fail(t("tr_status_lost")); this.placeBall(-38.8,0); this.lostGrace=0;
          }
          return false;
        }
        this.lostGrace=0;
        if(Math.hypot(p.pos.x-20,p.pos.z)<3.8 && (b.owner===p||near<2.8))return true;
        return false;
      } },
    { key:"pass", frozen:true, need:3,
      setup:function(){
        this.hideBall(false);
        var T=this;
        T.trainee.pos.x=-8;T.trainee.pos.z=0;T.trainee.vel.x=T.trainee.vel.z=0;T.trainee.face=Math.PI/2;
        T.mate.pos.x=-14;T.mate.pos.z=9;T.gk.pos.x=HL-2;T.gk.pos.z=0;T.dummy.pos.x=-HL+2;T.dummy.pos.z=-8;
        T.cones.forEach(function(c){c.visible=false;});
        T.rings.forEach(function(r){r.visible=true;});
        T.ring(0,14,7,false); T.ring(1,28,-7,false); T.ring(2,42,5,false);
        T.rings[3].visible=false;
        this.placeBall(-6.8,0);
        T.status=t("tr_status_pass").replace("{n}","0");
      },
      check:function(){
        var b=SIM.ball;
        if(b.owner===this.trainee)return false;         /* czekamy na podanie */
        if(Math.hypot(b.vx,b.vz)<.9){
          var hit=-1, R=this.DRILLS[this.step].rings;
          for(var i=0;i<3;i++){
            if(Math.hypot(b.x-R[i][0],b.z-R[i][1])<4.2){hit=i;break;}
          }
          if(hit>=0){
            AUDIO.whistle(1); this.hits++;
            this.ring(hit,R[hit][0],R[hit][1],true);
            if(this.hits>=this.need)return true;
            this.status=t("tr_status_pass").replace("{n}",String(this.hits));
            this.placeBall(this.trainee.pos.x+1.1,this.trainee.pos.z);
          }else if(Math.hypot(b.vx,b.vz)<.35){
            /* fail dopiero gdy piłka naprawdę stoi poza kręgami */
            this.fail(t("tr_status_off"));
            this.placeBall(this.trainee.pos.x+1.1,this.trainee.pos.z);
          }
        }
        return false;
      },
      rings:[[14,7],[28,-7],[42,5]] },
    { key:"shot", frozen:true, need:2, goal:true,
      setup:function(){
        this.hideBall(false);
        var T=this, spots=[[36.5,-7],[36.5,0],[36.5,7]];
        T.trainee.vel.x=T.trainee.vel.z=0;
        T.mate.pos.x=30;T.mate.pos.z=14;T.dummy.pos.x=30;T.dummy.pos.z=-14;
        T.cones.forEach(function(c){c.visible=false;});
        T.rings.forEach(function(r){r.visible=false;});
        var s=spots[T.hits%3];
        this.placeBall(s[0],s[1]);
        T.goalDelay=0;
        T.status=t("tr_status_shot").replace("{n}",String(this.hits));
      },
      check:function(dt){
        var b=SIM.ball,T=this;
        if(T.goalDelay>0){
          T.goalDelay-=dt;
          if(T.goalDelay<=0)this.DRILLS[T.step].setup.call(T);
          return false;
        }
        if(this.crossed()){
          AUDIO.roar(.7); this.hits++; this.status=t("tr_status_goal").replace("{n}",String(this.hits));
          if(this.hits>=this.need)return true;
          T.goalDelay=1.5; return false;
        }
        var stopped=!b.owner && Math.hypot(b.vx,b.vz)<.6 && b.y<=SIM.BR+.05;
        var gkGot=b.owner===T.gk;
        var away=Math.abs(b.x)>HL+3 || Math.abs(b.z)>HW+3;
        if(stopped || gkGot || away){
          if(gkGot)this.status=t("tr_status_save");
          else this.fail(t("tr_status_off"));
          T.goalDelay=1.1;
        }
        return false;
      } },
    { key:"finesse", frozen:true, need:2, goal:true,
      setup:function(){
        this.hideBall(false);
        var T=this, spots=[[40,-9],[40,9]];
        T.trainee.vel.x=T.trainee.vel.z=0;
        T.mate.pos.x=32;T.mate.pos.z=14;T.dummy.pos.x=32;T.dummy.pos.z=-14;
        T.cones.forEach(function(c){c.visible=false;});
        T.rings.forEach(function(r){r.visible=false;});
        var s=spots[T.hits%2];
        this.placeBall(s[0],s[1]);
        T.finesseSeen=false; T.goalDelay=0;
        T.status=t("tr_status_finesse").replace("{n}",String(this.hits));
      },
      check:function(dt){
        var b=SIM.ball,T=this;
        if(T.goalDelay>0){
          T.goalDelay-=dt;
          if(T.goalDelay<=0)this.DRILLS[T.step].setup.call(T);
          return false;
        }
        if(this.crossed()){
          if(!T.finesseSeen){ this.fail(t("tr_status_nofin")); T.goalDelay=1.1; return false; }
          AUDIO.roar(.7); this.hits++; this.status=t("tr_status_goal").replace("{n}",String(this.hits));
          if(this.hits>=this.need)return true;
          T.goalDelay=1.5; return false;
        }
        var stopped=!b.owner && Math.hypot(b.vx,b.vz)<.6 && b.y<=SIM.BR+.05;
        var gkGot=b.owner===T.gk;
        var away=Math.abs(b.x)>HL+3 || Math.abs(b.z)>HW+3;
        if(stopped || gkGot || away){
          if(gkGot)this.status=t("tr_status_save");
          else this.fail(t("tr_status_off"));
          T.goalDelay=1.1;
        }
        return false;
      } },
    { key:"through", frozen:true, need:2,
      setup:function(){
        this.hideBall(false);
        var T=this;
        T.trainee.pos.x=0;T.trainee.pos.z=6;T.trainee.vel.x=T.trainee.vel.z=0;T.trainee.face=Math.PI/2;
        T.mate.pos.x=26;T.mate.pos.z=-6;T.mate.vel.x=T.mate.vel.z=0;T.mate.face=Math.PI/2;
        T.gk.pos.x=HL-2;T.gk.pos.z=0;T.dummy.pos.x=-HL+2;T.dummy.pos.z=-18;
        T.cones.forEach(function(c){c.visible=false;});
        T.rings.forEach(function(r,i){r.visible=i<1;});
        T.ring(0,26,-6,false);
        this.placeBall(1.2,6);
        T.status=t("tr_status_through").replace("{n}",String(this.hits));
      },
      check:function(){
        var b=SIM.ball,T=this;
        var toMate=b.receiver===T.mate || b.owner===T.mate || b.cushion===T.mate;
        if(toMate && (b.flight==="through" || b.flight==="pass" || !b.owner)){
          if(b.owner===T.mate || b.cushion===T.mate || (b.receiver===T.mate && Math.hypot(b.x-T.mate.pos.x,b.z-T.mate.pos.z)<4)){
            AUDIO.whistle(1); this.hits++;
            if(this.hits>=this.need)return true;
            this.status=t("tr_status_through").replace("{n}",String(this.hits));
            this.placeBall(1.2,6);
            return false;
          }
        }
        if(!b.owner && Math.hypot(b.vx,b.vz)<.45 && b.y<=SIM.BR+.08){
          this.fail(t("tr_status_off"));
          this.placeBall(1.2,6);
        }
        return false;
      } },
    { key:"combo", frozen:true, need:1,
      setup:function(){
        this.hideBall(false);
        var T=this;
        T.trainee.pos.x=0;T.trainee.pos.z=0;T.trainee.vel.x=T.trainee.vel.z=0;T.trainee.face=Math.PI/2;
        T.mate.pos.x=24;T.mate.pos.z=4;T.mate.vel.x=T.mate.vel.z=0;T.mate.face=Math.PI/2;
        T.gk.pos.x=HL-2;T.gk.pos.z=0;T.dummy.pos.x=-HL+2;T.dummy.pos.z=-18;
        T.cones.forEach(function(c){c.visible=false;});
        T.rings.forEach(function(r,i){r.visible=i<1;});
        T.ring(0,24,4,false);
        this.placeBall(1.2,0);
        T.comboSeen=false;
        T.status=t("tr_status_combo");
      },
      check:function(){
        var b=SIM.ball,T=this;
        var mateHas=b.owner===T.mate || b.cushion===T.mate;
        if(mateHas && T.comboSeen){
          AUDIO.whistle(1); return true;
        }
        if(!b.owner && Math.hypot(b.vx,b.vz)<.45 && b.y<=SIM.BR+.08){
          if(T.comboSeen)this.fail(t("tr_status_off"));
          else this.fail(t("tr_status_nocombo"));
          this.placeBall(1.2,0); T.comboSeen=false;
        }
        return false;
      } },
    { key:"switchdrill", frozen:true, need:1,
      setup:function(){
        this.hideBall(false);
        var T=this;
        T.trainee.pos.x=-4;T.trainee.pos.z=0;T.trainee.vel.x=T.trainee.vel.z=0;T.trainee.face=0;
        T.mate.pos.x=16;T.mate.pos.z=4;T.mate.vel.x=T.mate.vel.z=0;T.mate.face=Math.PI;
        T.gk.pos.x=HL-2;T.gk.pos.z=0;T.dummy.pos.x=-HL+2;T.dummy.pos.z=-18;
        T.cones.forEach(function(c){c.visible=false;});
        T.rings.forEach(function(r,i){r.visible=i<1;});
        T.ring(0,10,0,false);
        var b=SIM.ball;
        b.owner=null;b.cushion=null;b.receiver=null;b.route=null;b.flight="";b.shotTeam=null;b.lastKicker=null;
        b.lock=.12;b.vx=b.vy=b.vz=0;b.x=10;b.z=0;b.y=SIM.BR;b.release=null;
        SIM.control(0,T.trainee);
        T.status=t("tr_status_switch");
      },
      check:function(){
        var T=this,team=SIM.teams[0];
        if(team.user===T.mate){ team.switchCd=0; T.phase=1; this.status=t("tr_status_switch2"); return false; }
        if(T.phase===1 && team.user===T.trainee)return true;
        return false;
      } },
    { key:"tackle", frozen:true, need:1,
      setup:function(){
        this.hideBall(false);
        var T=this;
        T.trainee.pos.x=14;T.trainee.pos.z=0;T.trainee.vel.x=T.trainee.vel.z=0;T.trainee.face=Math.PI/2;
        T.dummy.pos.x=24;T.dummy.pos.z=0;T.dummy.vel.x=T.dummy.vel.z=0;T.dummy.face=0;
        T.mate.pos.x=8;T.mate.pos.z=-12;T.gk.pos.x=HL-2;T.gk.pos.z=0;
        T.cones.forEach(function(c){c.visible=false;});
        T.rings.forEach(function(r){r.visible=false;});
        this.giveBall(T.dummy);
        T.status=t("tr_status_tackle");
      },
      check:function(){
        var b=SIM.ball;
        if(b.owner===this.trainee){ AUDIO.whistle(1); return true; }
        return false;
      } }
  ],

  /* ---------- pomocnicze ---------- */
  hideBall: function(off){ WORLD.ball.visible=!off; WORLD.blob.visible=!off; },
  giveBall: function(p){
    var b=SIM.ball;
    b.owner=p;b.ownerAge=0;b.cushion=null;b.receiver=null;b.route=null;b.flight="";
    b.shotTeam=null;b.lastKicker=null;b.lock=.12;b.release=null;b.nextTouch=0;b.rollDrag=2.1;
    b.vx=p.vel.x;b.vz=p.vel.z;b.vy=0;b.y=SIM.BR;b.x=p.pos.x+.36;b.z=p.pos.z;
  },
  crossed: function(){
    var b=SIM.ball;
    if(b.prevX===undefined || !(b.prevX<=HL && b.x>HL))return false;
    var f=(HL-b.prevX)/((b.x-b.prevX)||1e-6);
    var z=b.prevZ+(b.z-b.prevZ)*f, y=(b.prevY!=null?b.prevY:b.y)+(b.y-(b.prevY!=null?b.prevY:b.y))*f;
    return Math.abs(z)<3.85 && y<2.55;
  },
  fail: function(msg){ this.attempts++; this.attemptsTotal++; this.status=msg; AUDIO.ui(); },

  applyDrill: function(){
    var d=this.DRILLS[this.step];
    this.t=0; this.hits=0; this.attempts=0; this.power=0; this.need=d?d.need||1:1;
    this.finesseSeen=false; this.comboSeen=false; this.goalDelay=0; this.phase=0;
    if(this.trainee){ HUMAN.clear(this.trainee); this.trainee.challenge=null; this.trainee.moveTarget=null; }
    if(this.mate)this.mate.moveTarget=null;
    if(this.dummy)this.dummy.moveTarget=null;
    if(d){
      d.setup.call(this);
      this.statusKey="";
    }
    this.render();
  },
  advance: function(){
    this.completed++;
    AUDIO.whistle(1);
    this.step++;
    if(this.step>=this.DRILLS.length){
      this.step=this.DRILLS.length;    /* ekran końcowy */
      this.hideBall(true);
      this.cones.forEach(function(c){c.visible=false;});
      this.rings.forEach(function(r){r.visible=false;});
    }
    this.applyDrill();
  },

  /* ---------- klatka ---------- */
  frame: function(dt){
    if(!this.ready)return;
    var inp=INPUT.slots[0]||INPUT._empty();
    var field=CAM.fieldInput(inp.mx,inp.mz);
    var team=SIM.teams[0], user=team.user;
    if(user){
      if(user.isUser!==0)SIM.control(0,user);
      var next=HUMAN.select(team,user,inp,null,dt);
      if(next!==user)SIM.control(0,next);
      user=team.user;
    }
    if(user){
      var st=user.ctl||(user.ctl=HUMAN.newState());
      HUMAN.drive(0,user,inp,field,st,dt,null);
      this.power=Math.max(st.chargeP,st.chargeS);
      /* łapemy modyfikator także przy samym wciśnięciu lub gdy charge już ruszył */
      if(inp.finesse && (st.chargeS>.01 || st.finesse))this.finesseSeen=true;
      if(inp.switchL && (st.chargeP>.01 || st.combo))this.comboSeen=true;
      if(st.finesse)this.finesseSeen=true;
      if(st.combo)this.comboSeen=true;
    }else this.power=0;
    var d=this.DRILLS[this.step];
    AI.frozen=!!(d&&d.frozen);
    /* małe kroki jak w meczu — piłka nie przelatuje przez zawodników */
    var n=Math.ceil(dt*60),h=dt/n;
    for(var i=0;i<n;i++){
      AI.update(h);
      if(this.dummy)this.dummy.moveTarget=null;
      SIM.step(h);
      RULES.state="play";RULES.stateT=0;
    }
    if(RULES.lastFoul){ RULES.lastFoul=null; BROADCAST.clear(); HUD.hideEvent(); }
    this.t+=dt;
    if(this.step<0){
      if(inp.passP||inp.shootP||inp.throughP||inp.tackleP||inp.switchP){this.step=0;this.applyDrill();}
    }
    else if(this.step>=0 && this.step<this.DRILLS.length){
      if(this.DRILLS[this.step].check.call(this,dt))this.advance();
    }
    SIM.syncMeshes(dt);
    if(this.meRing && user)this.meRing.position.set(user.pos.x,.05,user.pos.z);
    CAM.update(dt,"play");
    WORLD.tick(dt); WORLD.tickStaff(dt,"play");
    WORLD.renderer.render(WORLD.scene,WORLD.cam);
    this.ui(dt);
  },

  /* ---------- nakładka ---------- */
  render: function(){
    var dots=this.el("trDots"), n=this.DRILLS.length;
    dots.replaceChildren();
    for(var i=0;i<n;i++){
      var s=document.createElement("i");
      if(i<this.completed)s.className="on";
      else if(i===this.step)s.className="cur";
      dots.appendChild(s);
    }
    var d=this.DRILLS[this.step];
    if(this.step<0){
      this.el("trLesson").textContent=t("tr_intro");
      this.el("trDesc").textContent=this.fill(t("tr_intro_desc"));
    }else if(this.step>=n){
      this.el("trLesson").textContent=t("tr_outro");
      this.el("trDesc").textContent=t("tr_outro_desc")
        .replace("{D}",String(this.completed)).replace("{N}",String(n))
        .replace("{A}",String(this.attemptsTotal));
    }else{
      this.el("trLesson").textContent=t("tr_"+d.key);
      this.el("trDesc").textContent=this.fill(t("tr_"+d.key+"_desc"));
    }
    this.statusKey="";
  },
  ui: function(dt){
    if(this.flashT>0){
      this.flashT-=dt;
      this.el("trCard").classList.toggle("flash",this.flashT>0);
    }
    var st=this.status||"", key=st+"#"+this.step;
    if(this.statusKey!==key){
      this.statusKey=key;
      this.el("trStatus").textContent=st;
    }
    this.el("trPower").style.width=Math.round(this.power*100)+"%";
    this.el("trCount").textContent=this.step>=0&&this.step<this.DRILLS.length
      ? (this.need>1?t("tr_count").replace("{n}",String(this.hits)).replace("{m}",String(this.need))+" · "+t("tr_attempts").replace("{n}",String(this.attempts)) : t("tr_attempts").replace("{n}",String(this.attempts)))
      : (this.step>=this.DRILLS.length?t("tr_attempts").replace("{n}",String(this.attemptsTotal)):"");
  }
};
