/* Dane turniejowe są w osobnym pliku JSON, wspólnym dla gry i serwera. */
var SQUADS=/*SQUADS*/null;
var TEAMS={
  data:SQUADS.teams,
  selected:function(team){return this.data[SET[team?"nationA":"nationH"]]||this.data.club;},
  rosters:function(team){
    var country=this.selected(team);
    if(country.players)return country.players;
    var reserve=team?["Cis","Jagła","Szeliga","Wąs","Kania","Leśny","Witek"]:["Dąb","Kozioł","Bal","Lech","Rudy","Biel","Rak"];
    return LINEUP.names[team].concat(reserve).map(function(n,i){return {name:n,num:LINEUP.numbers[i]||i+1,role:i<11?LINEUP.roles[LINEUP.formation(team)][i]:["GK","DF","DF","MF","MF","FW","FW"][i-11]};});
  },
  label:function(person){var bits=person.name.split(" ");return bits.length===1?bits[0]:bits.slice(1).join(" ");},
  kits:function(){
    return [0,1].map(function(team){
      var c=TEAMS.selected(team),alternate=SET[team?"stripA":"stripH"]==="away";
      var palette=c.colors||(team?["2456e0","f5f5f2","2456e0","232d40","c3def6","232d40","2a6df0"]:["f5f5f2","d21f2b","d21f2b","af2941","f2eddf","af2941","b32843"]);
      var offset=alternate?3:0,shirt=parseInt(palette[offset],16);
      return {shirt:shirt,shorts:parseInt(palette[offset+1],16),socks:parseInt(palette[offset+2],16),tag:parseInt(palette[6],16),
        ink:((shirt>>16)*.299+((shirt>>8)&255)*.587+(shirt&255)*.114)>154?"#1e2c37":"#fff8e9",
        gk:team?0x36b77d:0xffbb38,gkShorts:0x243137,nation:SET[team?"nationA":"nationH"],alternate:alternate};
    });
  },
  apply:function(){
    WORLD.kit=this.kits();
    if(SHOWROOM.renderer){
      Object.values(SHOWROOM.models).forEach(ATHLETE.dispose);SHOWROOM.models={};
      ["kitH","kitA"].forEach(function(id){delete document.getElementById(id).dataset.drawn;});
    }
    if(WORLD.benchPlayers)WORLD.benchPlayers.forEach(function(slot){
      var parent=slot.mesh.parent,pos=slot.mesh.position.clone(),rot=slot.mesh.rotation.clone();ATHLETE.dispose(slot.mesh);
      slot.mesh=WORLD.makePlayer(slot.team,false,slot.num,parent);slot.mesh.position.copy(pos);slot.mesh.rotation.copy(rot);MOTION.sit(slot.mesh);
    });
    if(STADIUM.cloth.length){STADIUM.names=[];WORLD.refreshAds(SET.home,SET.away);}
  }
};
