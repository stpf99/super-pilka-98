/* Odwrotna kinematyka nogi w płaszczyźnie strzałkowej i płynne przejścia między pozami. */
var MOTION = {
  clamp: function(x,a,b){return Math.min(b,Math.max(a,x));},
  strideRate:function(speed){return speed>.18?1.10+Math.min(10,speed)*.131:.28;},
  animate: function(group,speed,dt,action,time,turn,look,diveSide,sideSpeed,forwardSpeed,phase){
    var u=group.userData, clamp=this.clamp, tau=Math.PI*2;
    var stride=clamp(speed/7.7,0,1.25), sprint=clamp((speed-5)/4,0,1);
    var freq=this.strideRate(speed);
    u.phase=phase===undefined?(u.phase+dt*freq)%1:phase;u.poseT+=dt;
    var breath=Math.sin(u.poseT*2.9),cycle=Math.sin(u.phase*tau), gait=clamp(speed*1.6,0,1);
    var x=0,y=.925+.006*breath+(.012+.024*sprint)*Math.cos(u.phase*tau*2)*gait,z=0;
    var tilt=.025+stride*.135,twist=-cycle*.13*stride,roll=0,bank=clamp(turn||0,-1,1)*.105;
    var running=action==="run" || action==="dribble" || action==="goalrun";
    var rootPitch=running?(.035*stride+.052*sprint):0,rootRoll=0;
    if(running){tilt+=.035*stride+.035*sprint;bank+=clamp(turn||0,-1,1)*.11;
      roll-=bank*.32;twist-=cycle*.052*stride;}
    var trick=action==="goalflip" || action==="kneeslide";
    var showTime=action==="goalflip"?1.45-time:1.70-time;
    var air=clamp((showTime-.23)/.85,0,1),tuck=trick?Math.sin(Math.PI*air):0;
    var ease=dt>0?1-Math.exp(-dt*24):1;
    if(u.motionMode!==action){u.motionMode=action;u.transition=0;}
    u.transition+=dt;
    var plantedEase=(action==="run" || action==="jockey") && u.transition>.15?1:ease;
    var pace=speed/freq, stance=clamp(.97/Math.max(.05,pace),.27,.62);
    var reach=Math.min(.52,pace*stance/2);
    if(action==="jockey"){y-=.105;tilt+=.075;twist+=clamp(look||0,-1,1)*.15;}
    var clip=RECEPTION.clips[action],control=0,give=0,impact=0,neckPitch=0,headRoll=0;
    var activeLeg=clip && u.receiveLeg!==undefined?u.receiveLeg:u.kickLeg;
    var direction=activeLeg===0?-1:1;
    var height=clip?(u.contactHeight || clip.height):0;
    if(clip){
      var after=clip.follow-time;
      control=after<0?1-FACE.smooth(0,clip.wind,-after):1-FACE.smooth(.03,clip.follow,after);
      give=after>0?Math.sin(Math.PI*clamp(after/clip.follow,0,1)):0;
      impact=(1-FACE.smooth(.02,.16,Math.abs(after)))*(action==="trapHead"?1:action==="trapChest"?.30:.08);
      if(action==="trapHead"){
        y+=control*clamp(height-1.83,-.14,.23)-.047*give;
        tilt-=.10*control+.07*give;neckPitch+=-.14*control+.39*give;
      }else if(action==="trapChest"){
        y+=control*clamp((height-1.36)*.58,-.12,.09)-.042*give;
        tilt-=.24*control+.12*give;z+=.045*control-.065*give;
        twist+=direction*(.06*control+.16*give);neckPitch+=.22*control;
      }else{
        var thighControl=action==="trapThigh";
        y-=control*(thighControl?.044:.055);x-=direction*(thighControl?.046:.026)*control;
        tilt+=(thighControl?.075:.13)*control;twist-=direction*.14*control;
        roll+=direction*.095*control;neckPitch+=.24*control;headRoll=direction*.06*control;
      }
    }
    FACE.animate(u,speed,action,impact);
    if(action==="windup" || action==="passload"){twist=-direction*.25;tilt=.12;y-=.025;}
    if(["kick","crosskick","passkick"].includes(action)){twist=direction*.29;tilt=.105;bank+=direction*.055;}
    if(action==="sidevolley" || action==="turnstrike"){
      var swing=Math.sin(Math.PI*clamp(.32+.68*(1-time/.38),0,1));
      twist+=direction*(action==="sidevolley"?.76:1.10)*swing;
      tilt+=.12*swing;roll-=direction*(action==="sidevolley"?.31:.15)*swing;y-=.055*swing;
    }
    if(action==="slide"){
      var low=FACE.smooth(0,.17,.72-time)*(1-FACE.smooth(.46,.72,.72-time));
      y-=.62*low;z-=.10*low;rootPitch=-.73*low;rootRoll=.23*low;tilt=.11;
    }
    if(action==="goalflip"){
      var crouch=Math.sin(Math.PI*clamp(showTime/.23,0,1))+Math.sin(Math.PI*clamp((showTime-1.08)/.33,0,1));
      y=.93-.24*crouch+1.08*4*air*(1-air);
      rootPitch=-tau*FACE.smooth(0,1,air);tilt=.13+.33*tuck;twist=0;
    }else if(action==="kneeslide"){
      var kneel=FACE.smooth(0,.26,showTime)*(1-FACE.smooth(1.22,1.70,showTime));
      y-=.48*kneel;rootPitch=-.25*kneel;tilt=-.10*kneel;
    }
    if(action==="fallen"){y=.17;rootPitch=1.33;rootRoll=.24;}
    if(action==="dive"){
      var flight=clamp((.65-time)/.65,0,1),side=diveSide||1;
      rootRoll=-side*Math.sin(Math.min(1,flight*2)*1.61);
      y=.58+.51*Math.sin(Math.PI*flight);tilt=.07;twist=.12*side;
    }
    if(action==="header"){y+=.41*Math.sin(Math.PI*clamp(1-time/.45,0,1));tilt=.23*Math.cos(time*10);}
    if(action==="throw"){tilt=-.25+.65*clamp(1-time/.52,0,1);}
    if(action==="celebrate"){y+=Math.max(0,Math.sin(u.poseT*5.2))*.19;tilt=-.09;}
    if(action==="goalrun"){tilt=.095;twist+=.14;}
    if(action==="goalarm"){tilt=-.035;roll=-.09;}
    if(action==="booked"){tilt=-.055;twist=.16;}
    if(action==="bend"){tilt=.83;y-=.14;}
    if(action==="showcard"){twist=-.19;tilt=-.06;}
    u.hips.position.set(x+.024*cycle*gait,y,z);
    if(action==="goalflip")u.hips.rotation.x=rootPitch;
    else u.hips.rotation.x+=SIM._angDelta(u.hips.rotation.x,rootPitch)*ease;u.hips.rotation.z+=(rootRoll-bank-u.hips.rotation.z)*ease;
    u.hips.rotation.y+=(cycle*.06*stride-u.hips.rotation.y)*ease;
    u.spine.rotation.x+=(tilt-u.spine.rotation.x)*ease;
    u.spine.rotation.y+=(twist-u.spine.rotation.y)*ease;
    u.spine.rotation.z+=(roll+.025*cycle*gait-u.spine.rotation.z)*ease;
    u.head.rotation.y+=(clamp(look||0,-.64,.64)-twist*.65-u.head.rotation.y)*ease;
    u.neck.rotation.x+=(-tilt*.72-.025+neckPitch-u.neck.rotation.x)*ease;
    u.head.rotation.z+=(headRoll-u.head.rotation.z)*ease;
    u.limbs.forEach(function(l,i){
      var phase=(u.phase+i*.5)%1,swing=clamp((phase-stance)/(1-stance),0,1);
      var swingBlend=swing*swing*(3-2*swing);
      var footZ=phase<stance?reach*(1-2*phase/stance):reach*(2*swingBlend-1);
      var lift=phase<stance?0:Math.sin(Math.PI*swing)*(.065+.30*stride)*gait;
      var lateral=0;
      if(action==="jockey"){
        lateral=(sideSpeed===undefined ? 0.85:sideSpeed)*footZ;
        footZ*=forwardSpeed===undefined ? 0.35:forwardSpeed;
      }
      var flat=phase<stance?(phase/stance>.67 ? 0.34*(phase/stance-.67)/.33:-.14*Math.max(0,1-phase/stance*4)) : 0.38*Math.sin(swing*tau)*stride;
      var down=y-.005-.084-lift-Math.max(0,Math.sin(flat)*.17);
      var dist=clamp(Math.hypot(down,footZ,lateral),.16,.8429);
      var a=.426,b=.417;
      var thigh=-(Math.atan2(footZ,down)+Math.acos(clamp((a*a+dist*dist-b*b)/(2*a*dist),-1,1)));
      var knee=Math.PI-Math.acos(clamp((a*a+b*b-dist*dist)/(2*a*b),-1,1));
      var ankle=-thigh-knee+flat*gait, toe=-Math.max(0,flat)*gait;
      var arm=Math.cos(phase*tau)*(.33+.45*sprint)*gait-.11;
      var elbow=-.22-(.46+.45*sprint)*gait-.23*gait*Math.cos(phase*tau);
      var spread=l.side*(.12+.045*stride), hipSide=0, hipYaw=0, palm=l.side*.10;
      if(running){arm+=.11*cycle*l.side*stride;elbow-=.18*sprint;spread+=l.side*(.06*stride+.08*Math.abs(turn||0));}
      if(action==="dribble" && i===u.receiveLeg){
        var tap=Math.sin(Math.PI*clamp(1-time/.18,0,1));thigh-=.30*tap;knee+=.10*tap;ankle-=.18*tap;hipYaw-=l.side*.12*tap;
      }
      if(action==="goalflip"){thigh=-.18-1.66*tuck;knee=.38+1.69*tuck;ankle=-.22;arm=-2.13+1.04*tuck;elbow=-.39-.98*tuck;spread=l.side*.27;}
      if(action==="kneeslide"){thigh=-.05-.18*kneel;knee=.28+1.71*kneel;ankle=-.20;arm=-1.19-.62*kneel;elbow=-.38;spread=l.side*(.34+.87*kneel);}
      if(action==="anthem" && i===1){arm=-.79;elbow=-1.75;spread=-.36;palm=.33;}
      if(action==="presentcup"){arm=-.85;elbow=-.85;spread=-l.side*.12;palm=-l.side*.30;}
      if(action==="liftcup"){var raise=FACE.smooth(0,1.15,time);arm=-.87-1.55*raise;elbow=-1.10+.65*raise;spread=l.side*.14;}
      if(action==="sidevolley" || action==="turnstrike"){
        var sideKick=action==="sidevolley",strike=i===u.kickLeg;
        if(strike){thigh=-(sideKick?1.44:.88)*swing;knee=.25+.37*(1-swing);hipSide=l.side*(sideKick?.76:.38)*swing;hipYaw=-l.side*.65*swing;ankle=-.18;}
        else{thigh=-.24;knee=.47;hipYaw=l.side*.33*swing;}
        arm=-.4-.52*swing;elbow=-.51;spread=l.side*(.24+.86*swing);
      }
      if(action==="armblock"){arm=-1.14;spread=l.side*.88;elbow=-.28;}
      if(action==="volley"){thigh=i===u.kickLeg?-1.39:-.3;knee=i===u.kickLeg?.24:.48;hipSide=l.side*.36;spread=l.side*.89;elbow=-.67;ankle=-.24;}
      if(action==="advSignal"){spread=l.side*.40;arm=-1.42;elbow=-.11;palm=l.side*.14;}
      if(action==="jockey"){spread=l.side*.40;elbow=-.70;hipSide=l.side*.12+Math.atan2(lateral,down);}
      if(action==="windup" || action==="passload" || action==="kick" || action==="passkick" || action==="crosskick"){
        var hard=action!=="passkick" && action!=="passload";
        var loading=action==="windup" || action==="passload";
        var follow=loading?0 : 0.77+.23*clamp((1-time/(hard ? 0.40 : 0.30))/.23,0,1);
        var settle=loading?0:clamp((.15-time)/.15,0,1);
        if(i===u.kickLeg){
          thigh=((hard ? 0.46 : 0.19)-(hard?1.64:1.15)*follow)*(1-settle);
          knee=((hard?1.43 : 0.84)*(1-follow))*(1-settle)+.13;
          ankle=-.18+follow*.28;hipYaw=(hard?-.13:-.62)*direction;
        }else{thigh=-.27;knee=.39;ankle=-.12;hipSide=.08;}
        spread=l.side*(.51+(1-follow)*.24);arm=i!==u.kickLeg?-.43 : 0.34;elbow=-.51;
      }else if(clip){
        var receiving=i===activeLeg;
        if((action==="trapThigh" || action==="trapFoot") && receiving){
          var highKnee=action==="trapThigh";
          var raise=highKnee?clamp(1.29+(height-.85)*1.85,.90,1.73):clamp(.64+(height-.32)*2,.35,1.18);
          var h=-raise+.32*give;
          thigh+=(h-thigh)*control;
          knee+=((highKnee?1.47:.96)+.15*give-knee)*control;
          ankle+=((highKnee?-.36:-.38)-ankle)*control;
          hipYaw-=direction*(highKnee?.12:.47)*control;hipSide+=l.side*.12*control;
        }
        var arms=action==="trapChest"?.77:action==="trapHead"?.62:.51;
        spread+=(l.side*arms-spread)*control;
        arm+=((receiving?.10:-.29)-arm)*control;elbow+=(-.78-elbow)*control;
      }else if(action==="slide" || action==="fallen"){
        var extend=action==="slide"?low:1;
        thigh+=((i===1?-1.35:-.76)-thigh)*extend;knee+=((i===1?.12:1.55)-knee)*extend;ankle=-.1;
        spread=l.side*(action==="slide" ? 0.84:1.12);arm=-.32;elbow=-.44;
      }else if(action==="standtackle"){
        thigh=i===1?-.90:-.31;knee=i===1 ? 0.25 : 0.64;ankle=-.09;spread=l.side*.56;
      }else if(action==="throw"){
        arm=-2.86+clamp(1-time/.52,0,1)*1.50;elbow=-.78+clamp(1-time/.52,0,1)*.60;
        spread=l.side*.15;thigh=i===1?-.26 : 0.06;knee=.30;ankle=-.21;
      }else if(action==="keeperhold"){arm=-.64;elbow=-1.03;spread=-l.side*.13;palm=-l.side*.27;}
      else if(action==="header"){spread=l.side*.78;arm=-.57;elbow=-.87;knee=.57;ankle=-.3;}
      else if(action==="dive"){arm=-2.45;spread=l.side*.24;elbow=-.15;thigh=i===1?-.34 : 0.26;knee=i===1 ? 0.58 : 0.32;ankle=-.23;}
      else if(action==="goalrun" && i===1){arm=-2.69+.10*cycle;spread=.32;elbow=-.30;}
      else if(action==="goalarm"){spread=i===0?-1.60:.71;arm=i===0?-.19:-.51;elbow=i===0?-.48:-1.53;}
      else if(action==="booked"){spread=l.side*(.41+.1*breath);arm=-.43;elbow=-1.20+.15*breath;palm=-l.side*.59;}
      else if(action==="bend"){arm=-.57;elbow=-.19;spread=l.side*.11;thigh=-.46;knee=.76;ankle=-.28;}
      else if((action==="showcard" || action==="signalIndirect") && i===1){
        var raise=clamp((time-.08)/.40,0,1);arm=-.68-2.30*raise;spread=.26;elbow=-1.08+.96*raise;palm=.15;
      }
      else if(action==="celebrate"){
        spread=l.side*(.72+.18*Math.sin(u.poseT*4+i));arm=-2.25-.26*Math.sin(u.poseT*5+i*.6);
        elbow=-.69+.23*breath;thigh=-.20-.11*i;knee=.38+.08*i;ankle=-.17;
      }
      l.hip.rotation.x+=(thigh-l.hip.rotation.x)*plantedEase;l.hip.rotation.z+=(hipSide-l.hip.rotation.z)*plantedEase;
      l.hip.rotation.y+=(hipYaw-l.hip.rotation.y)*ease;l.knee.rotation.x+=(knee-l.knee.rotation.x)*plantedEase;
      l.ankle.rotation.x+=(ankle-l.ankle.rotation.x)*plantedEase;l.toe.rotation.x+=(toe-l.toe.rotation.x)*plantedEase;
      l.arm.rotation.x+=(arm-l.arm.rotation.x)*ease;l.arm.rotation.z+=(spread-l.arm.rotation.z)*ease;
      l.elbow.rotation.x+=(elbow-l.elbow.rotation.x)*ease;l.hand.rotation.z+=(palm-l.hand.rotation.z)*ease;
      var fist=trick || action==="celebrate" || action==="goalrun" || action==="goalarm";
      var fingerCurl=action==="signalIndirect" && i===1?-.05:fist?-1.68:action==="showcard"&&i===1?-.94:action==="dive"||action==="booked"?-.13:-.42-.21*gait;
      l.knuckles.rotation.x+=(fingerCurl-l.knuckles.rotation.x)*ease;
      var open=action==="dive" || action==="advSignal" || action==="signalIndirect";
      l.tips.rotation.x+=((open?-.06:fist?-.99:action==="showcard"&&i===1?-.62:-.26-.12*gait)-l.tips.rotation.x)*ease;
      l.thumb.rotation.z+=((l.side*(fist || action==="showcard"&&i===1?.54:open?-.25:-.08))-l.thumb.rotation.z)*ease;
      l.thumb.rotation.x+=((fist?-.47:-.12)-l.thumb.rotation.x)*ease;
      l.hand.rotation.y+=((l.side*(open?.15:running?.58:.28))-l.hand.rotation.y)*ease;
      var wristCurl=fist?-.16:action==="dive"?-.20 : .12+.11*gait;
      l.hand.rotation.x+=(wristCurl-l.hand.rotation.x)*ease;
    });
  },
  sit: function(group){
    var u=group.userData;u.hips.position.y=.67;u.spine.rotation.x=.09;
    u.limbs.forEach(function(l){l.hip.rotation.x=-1.50;l.knee.rotation.x=1.49;l.arm.rotation.x=-.32;l.elbow.rotation.x=-.91;});
  }
};
