/* ============================================================
   SUPER PILKA '98 · 08-rules.js — przepływ meczu i przepisy
   Stany: kickoff, play, throwin, goalkick, corner, freekick,
          penalty, goal, booking, replay, halftime, fulltime
   ============================================================ */
var RULES = {
  state: "menu",
  half: 1, elapsed: 0, displayMin: 0,
  restartTeam: 0, restartPos: {x:0,z:0}, taker: null,
  stateT: 0, celebT: 0,
  offsideSet: [], offsideArmTeam: -1,
  charge: -1, chargeKind: null, _charging: null,
  kickTeamFirst: 0,
  passPending: null,
  headerDone: false,
  freeIndirect:false,indirectTaker:null,

  /* ---------- start / restart meczu ---------- */
  newMatch: function(){
    this.half = 1; this.elapsed = 0; this.displayMin = 0;
    this.kickTeamFirst = 0;
    this.lastFoul=null;this.passPending=null; this.charge=-1; this._charging=null;this.lastScorer=null;
    MATCHDAY.reset();BROADCAST.clear();REC.reset();
    SIM.resetMatch();
    HUD.refreshTeams();
    this.setupKickoff(0,true);CEREMONY.prepare(false);
  },
  setupKickoff: function(team, first){
    this.state = "kickoff"; this.stateT = 0; REC.reset();
    this.restartTeam = team; this.restartPos = {x:0, z:0};
    var d0 = SIM.teams[team].dir;
    var available=SIM.teamPlayers(team).filter(function(p){return p.role!=="GK";});
    this.taker=available.find(function(p){return p.idx===9;})||available[available.length-1]||SIM.teamPlayers(team)[0];
    var support=available.find(function(p){return p.idx===10 && p!==RULES.taker;})||available.find(function(p){return p!==RULES.taker;});
    /* wszyscy do formacji */
    for(var i=0;i<SIM.players.length;i++){
      var pl = SIM.players[i];
      if(pl.off) continue;
      var dt2 = SIM.teams[pl.team].dir;
      var fx = pl.home.x*dt2, fz = pl.home.z*dt2;
      if(pl.team===team){
        if(pl===this.taker){ fx=-.13*dt2;fz=-.48*dt2; }
        else if(pl===support){ fx=-.64*dt2;fz=1.73*dt2; }
        else if(pl.role==="FW"){ fx = -2.5*dt2; fz = pl.home.z*dt2; }
      } else {
        /* przeciwnik: we własnej połowie, poza kołem środkowym */
        if(fx*dt2 > -9.6) fx = -9.6*dt2;
      }
      if(pl.team===team && pl!==this.taker) fx=Math.min(-.6,fx*dt2)*dt2;
      pl.pos.x = fx; pl.pos.z = fz; pl.vel.x = 0; pl.vel.z = 0;
      pl.face = Math.atan2(-fx, -fz) || 0;
      pl.moveTarget = null; pl.action = "run"; pl.actionT = 0;
    }
    var b = SIM.ball;
    b.x = 0; b.z = 0; b.y = SIM.BR; b.vx = b.vy = b.vz = 0; b.curve = 0;
    b.owner = null; b.lastTouchTeam = -1; b.lastKicker = null;
    this.offsideSet = []; this.offsideArmTeam = -1;
    this.assignTakerControl();
    AI.frozen = true;
    AUDIO.whistle(first ? 1 : 1);
    if(first && WORLD.teleMsg) WORLD.teleMsg(t("tv_kick"), 3.5);
    HUD.restartTagShow(t("rst_kick"));
    HUD.event("kickoff",t("friendly"),t(this.half===1?"first_half":"second_half"),SET.home,SET.away);
    this.hintFor(team, "hint_kick");
    HUD.commentary(first ? tPick("c_kick") : "");
  },
  teamName: function(team){ return team===0 ? SET.home : SET.away; },

  /* czy wykonawca wznowienia jest sterowany przez człowieka (zależnie od trybu) */
  humanTaker: function(team){
    if(SET.mode===2) return false;                 /* oglądanie: tylko AI */
    if(SET.mode===0 && team!==0) return false;     /* 1 gracz: gość to komputer */
    return true;
  },
  hintFor: function(team, key){
    var pad=INPUT.padSeen[team];
    HUD.hint(this.humanTaker(team)?t(key).replace("{T}",this.teamName(team))
      .replace("{A}",pad?"A / ✕":team===0?"K":",").replace("{B}",pad?"B / ◯":team===0?"L":"."):t("hint_cpu"));
  },

  assignTakerControl: function(){
    MATCHDAY.lastArm=null;MATCHDAY.penaltyFlight=false;this.indirectTaker=null;this.runUp=null;
    this.charge=-1;this._charging=null;this.passPending=null;this.headerDone=false;
    SIM.events.length=0;
    var b=SIM.ball;b.release=null;b.nextTouch=0;b.cushion=null;b.receiver=null;b.route=null;b.lock=0;b.flight="";b.shotTeam=null;b.lastShotBy=null;b.live=false;
    for(var i=0;i<SIM.players.length;i++){
      var p=SIM.players[i];p.firstTouch=null;p.readyAction=null;p.challenge=null;p.trackingBall=false;p.moveTarget=null;p.closeControl=false;p.runT=0;p.vel.x=p.vel.z=0;
      if(!p.off){
        p.action="run";p.actionT=0;
        p.face=Math.atan2(this.restartPos.x-p.pos.x,this.restartPos.z-p.pos.z);
      }
    }
    if(this.taker){
      var dir=SIM.dirX(this.restartTeam),spot=this.restartPos;
      var tx=dir*HL,tz=0;
      if(this.state==="corner")tx=dir*(HL-10.5);
      if(this.state==="goalkick"){tx=0;tz=spot.z;}
      if(this.state==="throwin"){tx=spot.x+dir*4;tz=spot.z-Math.sign(spot.z)*9;}
      if(this.state==="kickoff"){
        var partner=this.nearestOutfield(this.restartTeam,this.taker.pos,false);
        if(partner){tx=partner.pos.x;tz=partner.pos.z;}
      }
      this.aimBase=Math.atan2(tx-spot.x,tz-spot.z);this.aimOffset=0;
      this.taker.face=this.aimBase;
      if(["corner","freekick","goalkick","penalty"].includes(this.state)){
        var behind=this.state==="penalty"?1.45:.67;
        this.taker.pos.x=spot.x-Math.sin(this.aimBase)*behind;
        this.taker.pos.z=spot.z-Math.cos(this.aimBase)*behind;
      }
    }
    if(!this.humanTaker(this.restartTeam)) return; /* CPU wykonuje sam — bez slotu gracza */
    var slot = this.restartTeam;   // P1 = drużyna 0, P2 = drużyna 1
    if(this.taker)SIM.control(slot,this.taker);
  },
  clearTakerControl: function(){
    if(this.taker && SIM.teams[this.taker.team].user===this.taker)SIM.control(this.taker.team,null);
  },

  /* ---------- wznowienia ---------- */
  setupThrow: function(team, x, z){
    this.state = "throwin"; this.stateT = 0;
    this.restartTeam = team;
    this.restartPos = { x: Math.max(-HL+1, Math.min(HL-1, x)), z: z > 0 ? HW : -HW };
    var b = SIM.ball;
    b.x = this.restartPos.x; b.z = this.restartPos.z; b.y = 1.7;
    b.vx = b.vy = b.vz = 0; b.owner = null; b.curve = 0;
    this.offsideSet = []; this.offsideArmTeam = -1;
    this.taker = this.nearestOutfield(team, this.restartPos, true);
    this.taker.pos.x = this.restartPos.x;
    this.taker.pos.z = this.restartPos.z + (z>0 ? -0.5 : 0.5);
    this.taker.vel.x = this.taker.vel.z = 0;
    this.taker.face = Math.atan2(-this.taker.pos.x, -this.taker.pos.z);
    this._pushOpponents(team, this.restartPos, 3);
    this.assignTakerControl();
    AI.frozen = true; this.headerDone = false;
    HUD.restartTagShow(t("rst_throw"));
    this.hintFor(team, "hint_throw");
    HUD.commentary(tPick("c_throw").replace("{T}", this.teamName(team)));
  },
  setupGoalkick: function(team, sideX){
    this.state = "goalkick"; this.stateT = 0;
    this.restartTeam = team;
    var dirX = SIM.teams[team].dir;
    this.restartPos = { x: -dirX*(HL-5.5), z: 0 };
    var b = SIM.ball;
    b.x = this.restartPos.x; b.z = 0; b.y = SIM.BR;
    b.vx = b.vy = b.vz = 0; b.owner = null; b.curve = 0;
    this.offsideSet = []; this.offsideArmTeam = -1;
    var gks = SIM.playersOf(team, "GK");
    this.taker = gks[0] || SIM.players[team*11];
    this.taker.pos.x = this.restartPos.x; this.taker.pos.z = 2;
    this._pushOpponents(team, this.restartPos, 10);
    this.assignTakerControl();
    AI.frozen = true; this.headerDone = false;
    HUD.restartTagShow(t("rst_goalkick"));
    this.hintFor(team, "hint_generic");
    HUD.commentary(tPick("c_gk").replace("{T}", this.teamName(team)));
  },
  setupCorner: function(team, sideX, sideZ){
    this.state = "corner"; this.stateT = 0;
    this.restartTeam = team;
    this.restartPos = { x: sideX*(HL-0.4), z: sideZ*(HW-0.4) };
    var b = SIM.ball;
    b.x = this.restartPos.x; b.z = this.restartPos.z; b.y = SIM.BR;
    b.vx = b.vy = b.vz = 0; b.owner = null; b.curve = 0;
    this.offsideSet = []; this.offsideArmTeam = -1;
    this.taker = this.nearestOutfield(team, this.restartPos, true);
    this.taker.pos.x = this.restartPos.x - Math.sign(sideX)*0.6;
    this.taker.pos.z = this.restartPos.z - Math.sign(sideZ)*0.6;
    SIM.teams[team].stats.corr++;
    this._boxCrowd(team, sideX);
    this._pushOpponents(team, this.restartPos, 9.15);
    this.assignTakerControl();
    AI.frozen = true; this.headerDone = false;
    HUD.restartTagShow(t("rst_corner"));
    this.hintFor(team, "hint_generic");
    HUD.commentary(tPick("c_corner"));
  },
  setupFree: function(team, x, z, indirect){
    this.freeIndirect=!!indirect;
    this.state = "freekick"; this.stateT = 0;
    this.restartTeam = team;
    this.restartPos = { x: x, z: z };
    var b = SIM.ball;
    b.x = x; b.z = z; b.y = SIM.BR;
    b.vx = b.vy = b.vz = 0; b.owner = null; b.curve = 0;
    this.offsideSet = []; this.offsideArmTeam = -1;
    this.taker = this.nearestOutfield(team, this.restartPos, true);
    this.taker.pos.x = x; this.taker.pos.z = z + (z>0?-0.7:0.7);
    var dirX = SIM.teams[team].dir;
    var goalD = Math.hypot(dirX*HL-x, z);
    if(goalD < 30 && Math.abs(z) < 22){
      /* mur od 9.15 m */
      var gdx = dirX*HL-x, gdz = 0-z, gl = Math.hypot(gdx, gdz)||1;
      var opps = SIM.teamPlayers(1-team);
      opps = opps.filter(function(o){ return o.role!=="GK"; })
                .sort(function(a,c){
                  var da = Math.hypot(a.pos.x-x, a.pos.z-z), dc = Math.hypot(c.pos.x-x, c.pos.z-z);
                  return da-dc;
                });
      for(var w=0; w<Math.min(3, opps.length); w++){
        var o = opps[w];
        o.pos.x = x + gdx/gl*9.15 + (-gdz/gl)*(w-1)*1.1;
        o.pos.z = z + gdz/gl*9.15 + (gdx/gl)*(w-1)*1.1;
        o.moveTarget = null;
      }
    }
    this._pushOpponents(team, this.restartPos, 9.15);
    this.assignTakerControl();
    AI.frozen = true; this.headerDone = false;
    HUD.restartTagShow(t(indirect?"rst_indirect":"rst_free"));
    this.hintFor(team, "hint_generic");
    HUD.commentary(tPick("c_free").replace("{T}", this.teamName(team)));
  },
  setupPenalty: function(team){
    this.state = "penalty"; this.stateT = 0;
    this.restartTeam = team;
    var dirX = SIM.teams[team].dir;
    this.restartPos = { x: dirX*(HL-11), z: 0 };
    var b = SIM.ball;
    b.x = this.restartPos.x; b.z = 0; b.y = SIM.BR;
    b.vx = b.vy = b.vz = 0; b.owner = null; b.curve = 0;
    this.offsideSet = []; this.offsideArmTeam = -1;
    var fws = SIM.playersOf(team, "FW");
    this.taker = fws[0] || this.nearestOutfield(team, this.restartPos, true);
    this.taker.pos.x = this.restartPos.x - dirX*3;
    this.taker.pos.z = 0;
    var gks = SIM.playersOf(1-team, "GK");
    if(gks[0]){ gks[0].pos.x = dirX*(HL-0.4); gks[0].pos.z = 0; }
    /* wszyscy przed piłką, poza polem karnym */
    for(var i=0;i<SIM.players.length;i++){
      var pl = SIM.players[i];
      if(pl.off || pl===this.taker || pl.role==="GK") continue;
      pl.pos.x = dirX*(HL-23) - dirX*Math.abs(pl.home.z)*0.3;
      pl.pos.z = pl.home.z*1.4;
      pl.vel.x = 0; pl.vel.z = 0;
      pl.moveTarget = null;
    }
    this.assignTakerControl();
    AI.frozen = true; this.headerDone = false;
    HUD.restartTagShow(t("rst_pen"));
    this.keeperChoice=0;this.hintFor(team, "hint_pen");
    HUD.commentary(tPick("c_pen"));
    AUDIO.whistle(2);
    if(WORLD.teleMsg) WORLD.teleMsg(t("tv_pen").replace("{T}", this.teamName(team)), 4, "card");
  },
  nearestOutfield: function(team, pos, move){
    var ps = SIM.teamPlayers(team), best = null, bd = 1e9;
    for(var i=0;i<ps.length;i++){
      var pl = ps[i];
      if(pl.role==="GK" || (!move && pl===this.taker)) continue;
      var d = Math.hypot(pl.pos.x-pos.x, pl.pos.z-pos.z);
      if(d < bd){ bd = d; best = pl; }
    }
    return best;
  },
  _pushOpponents: function(team, pos, dist){
    var opps = SIM.teamPlayers(1-team);
    for(var i=0;i<opps.length;i++){
      var o = opps[i];
      if(o.role==="GK") continue;
      var dx = o.pos.x-pos.x, dz = o.pos.z-pos.z;
      var d = Math.hypot(dx, dz);
      if(d < dist){
        if(d < 0.01){ dx = 1; dz = 0; d = 1; }
        o.pos.x = pos.x + dx/d*dist;
        o.pos.z = pos.z + dz/d*dist;
        o.moveTarget = null;
      }
    }
  },
  _boxCrowd: function(team, sideX){
    var sideZ=Math.sign(this.restartPos.z)||1;
    var attack=SIM.teamPlayers(team).filter(function(p){return p.role!=="GK" && p!==RULES.taker;});
    var defence=SIM.teamPlayers(1-team).filter(function(p){return p.role!=="GK";});
    // Głębokość liczona od linii bramkowej i odchylenie względem bliższego słupka.
    var runs=[[5.2,3.3],[7.7,-3.1],[10.3,5.4],[12.8,-7.2],[15.7,.8]];
    attack.sort(function(p,q){return q.home.x-p.home.x;});
    defence.sort(function(p,q){return p.home.x-q.home.x;});
    runs.forEach(function(mark,i){
      var a=attack[i],d=defence[i];
      if(a){a.pos.x=sideX*(HL-mark[0]);a.pos.z=sideZ*mark[1];}
      if(d){d.pos.x=sideX*(HL-mark[0]+.65+(i%2)*.36);d.pos.z=sideZ*(mark[1]-.95+(i%2)*1.75);}
    });
    if(attack[5]){attack[5].pos.x=sideX*(HL-4.6);attack[5].pos.z=sideZ*(HW-6.1);}
    if(defence[5]){defence[5].pos.x=sideX*(HL-1.3);defence[5].pos.z=sideZ*3.05;}
  },

  /* ---------- zdarzenia z symulacji ---------- */
  onPass: function(pl, mate){
    VOICE.speak(["pass",pl.fullName],false);
    var st = SIM.teams[pl.team].stats;
    st.attempt++;this.passPending = {team:pl.team,kicker:pl,t:5};
    /* armowanie spalonego (nie przy autach/rożnych/karnych/golach od bramki) */
    if(this.state==="play" || this.state==="freekick"){
      var dirX = SIM.teams[pl.team].dir;
      var ballX = SIM.ball.x*dirX;
      var defs = SIM.teamPlayers(1-pl.team);
      var xs = defs.map(function(d){ return d.pos.x*dirX; }).sort(function(a,b){ return b-a; });
      var secondLast = xs.length>1 ? xs[1] : -HL;
      this.offsideSet = [];
      for(var i=0;i<SIM.players.length;i++){
        var a = SIM.players[i];
        if(a.team!==pl.team || a.off || a===pl) continue;
        var ax = a.pos.x*dirX;
        if(ax > 0 && ax > ballX && ax > secondLast) this.offsideSet.push(a);
      }
      this.offsideArmTeam = pl.team;
    }
  },
  onShot: function(pl){
    this.passPending=null; SIM.teams[pl.team].stats.shots++;VOICE.speak(["shot",pl.fullName],false);
    AUDIO.excitementSet(0.75);
  },
  onSave: function(gk, caught){
    if(SIM.ball.shotTeam===1-gk.team)SIM.teams[1-gk.team].stats.onT++;
    HUD.commentary(tPick("c_save"));
    AUDIO.excitementSet(0.8);
  },

  /* ---------- faule i kartki ---------- */
  foul: function(tk,victim,incident){
    if(this.state!=="play" || tk.off || victim.off || tk.team===victim.team)return;
    incident=incident || {kind:"trip",severity:"careless",attempt:true};
    var dir=SIM.dirX(victim.team),x=Math.max(-HL,Math.min(HL,incident.x??victim.pos.x)),z=Math.max(-HW,Math.min(HW,incident.z??victim.pos.z));
    var inBox=x*dir>=HL-16.5 && Math.abs(z)<=20.16;
    var verdict=OFFICIAL.decision(tk,victim,incident,inBox),spot={team:victim.team,x:x,z:z,penalty:inBox};
    var detail=t("f_"+incident.kind);
    if(verdict.reason!==incident.kind)detail+=" · "+t("f_"+verdict.reason);
    this.lastFoul={offender:tk,victim:victim,incident:incident,reason:verdict.reason,spot:spot};
    SIM.teams[tk.team].stats.fouls++;
    MATCHDAY.decide({deadBall:!!incident.afterGoal,tk:tk,victim:victim,verdict:verdict,spot:spot,detail:detail});
  },
  giveCard: function(pl, kind){
    if(kind==="yellow"){
      pl.yellows++;
      SIM.teams[pl.team].stats.yel++;
      if(pl.yellows >= 2){this.giveCard(pl,"red");return "secondYellow";}
      HUD.cardFlash(pl, false);
      if(WORLD.teleMsg) WORLD.teleMsg(t("tv_yel").replace("{N}", pl.num).replace("{T}", this.teamName(pl.team)), 4.5, "card");
    } else {
      pl.off=true;
      if(pl.role==="GK"){
        var standIn=SIM.teamPlayers(pl.team).find(function(p){return p.role==="DF";})||SIM.teamPlayers(pl.team)[0];
        if(standIn){
          standIn.emergencyGK=true;standIn.role="GK";standIn.home={x:-50,z:0};
          standIn.pos.x=pl.pos.x;standIn.pos.z=pl.pos.z;
          WORLD.removePlayer(standIn.mesh);
          standIn.mesh=WORLD.makePlayer(standIn.team,true,standIn.num,null,null,standIn.name);
        }
      }
      SIM.teams[pl.team].stats.red++;
      WORLD.removePlayer(pl.mesh); pl.mesh = null;
      HUD.cardFlash(pl, true);
      AUDIO.whistle(2);
      if(WORLD.teleMsg) WORLD.teleMsg(t("tv_red").replace("{N}", pl.num).replace("{T}", this.teamName(pl.team)), 5, "card");
    }
    return kind;
  },

  /* ---------- spalony ---------- */
  checkOffsideTouch: function(pl){
    if(this.offsideArmTeam !== pl.team) return false;
    var idx = this.offsideSet.indexOf(pl);
    if(idx < 0) return false;
    this.offsideSet = []; this.offsideArmTeam = -1;
    AUDIO.whistle(2);
    HUD.commentary(tPick("c_off"));
    HUD.banner(t("rst_free"), t("offside"), 1.4);
    if(WORLD.teleMsg) WORLD.teleMsg(t("tv_off"), 3, "info");
    this.setupFree(1-pl.team,pl.pos.x,pl.pos.z,true);
    HUD.banner(t("rst_indirect"),t("offside"),1.7);
    return true;
  },

  /* ---------- gol ---------- */
  checkGoal: function(){
    var b = SIM.ball;
    if(this.indirectTaker && b.lastKicker!==this.indirectTaker)this.indirectTaker=null;
    if(Math.abs(b.z) < GOAL_W/2 && b.y < GOAL_H){
      if(this.indirectTaker && Math.abs(b.x)>HL+SIM.BR){
        var side=Math.sign(b.x),restart=1-this.indirectTaker.team;
        if(side===SIM.dirX(this.indirectTaker.team))this.setupGoalkick(restart,side);
        else this.setupCorner(restart,side,Math.sign(b.z)||1);
        return true;
      }
      if(b.x > HL + SIM.BR){
        var t0 = SIM.teams[0].dir > 0 ? 0 : 1;
        this._goal(t0); return true;
      }
      if(b.x < -HL - SIM.BR){
        var t1 = SIM.teams[0].dir < 0 ? 0 : 1;
        this._goal(t1); return true;
      }
    }
    return false;
  },
  _goal: function(team){
    var arm=MATCHDAY.lastArm,b=SIM.ball;
    if(arm && arm.p.team===team && b.lastKicker===arm.p && (arm.direct || RULES.elapsed-arm.time<2.3)){
      MATCHDAY.lastArm=null;var defending=SIM.nearestToBall(1-team,false);
      if(defending)this.foul(arm.p,defending,{afterGoal:true,kind:"handball",severity:"careless",attempt:false,x:arm.p.pos.x,z:arm.p.pos.z});
      return;
    }
    if(MATCHDAY.adv){if(MATCHDAY.adv.spot.team!==team){MATCHDAY.recall();return;}MATCHDAY.realise();}
    SIM.teams[team].score++;
    STADIUM.goal(team);PITCH.hit(SIM.ball);VOICE.speak(["goal",(SIM.ball.lastShotBy||SIM.ball.lastKicker)?.fullName],true);
    this._goalTeam = team;this.stateT=0;
    this._lastConceded = 1-team;
    var last=SIM.ball.lastShotBy || SIM.ball.lastKicker;
    var scorer=last && last.team===team?last:null;
    var own=last && last.team!==team?last:null;
    if(scorer)scorer.goals++;
    if(SIM.ball.shotTeam===team)SIM.teams[team].stats.onT++;
    this.lastScorer=(scorer?scorer.name:own?own.name+" ("+t("own_goal")+")":t("goal_title"))+" · "+MATCHDAY.minute();
    this.state="goal";this.celebT=3.9;AI.frozen=true;
    BROADCAST.goal(team,scorer,own);
    this.offsideSet = []; this.offsideArmTeam = -1;
    AUDIO.roar(1.2); AUDIO.horn(); AUDIO.whistle(1);
    AUDIO.excitementSet(1);

    HUD.commentary(tPick("c_goal"));
    HUD.setScore();
    if(WORLD.teleMsg) WORLD.teleMsg(t("tv_goal").replace("{M}", this.displayMin)
      .replace("{T}", this.teamName(team)).replace("{S}", SIM.teams[0].score + ":" + SIM.teams[1].score), 5, "goal");
    WORLD.aimArrow.visible = false;
  },

  /* ---------- auty / rożne / wykop ---------- */
  checkBounds: function(){
    var b = SIM.ball;
    if(Math.abs(b.z)>HW+SIM.BR){
      var team = b.lastTouchTeam===0 ? 1 : 0;
      if(b.lastTouchTeam < 0) team = Math.random()<0.5?0:1;
      this.setupThrow(team, b.x, b.z);
      return true;
    }
    if(Math.abs(b.x)>HL+SIM.BR){
      var side = Math.sign(b.x);
      var attacker = SIM.teams[0].dir===side ? 0 : 1;
      if(b.lastTouchTeam === attacker){
        this.setupGoalkick(1-attacker, side);
      } else {
        this.setupCorner(attacker, side, Math.sign(b.z)||1);
      }
      return true;
    }
    return false;
  },

  /* ---------- wykonywanie wznowień przez człowieka / AI ---------- */
  startRestart:function(kind,power,automatic){
    if(!["corner","goalkick","freekick","penalty"].includes(kind)){
      this.execRestart(kind,power,automatic);return;
    }
    var p=this.taker,b=SIM.ball,dx=Math.sin(p.face),dz=Math.cos(p.face);
    var foot=p.mesh.userData.kickLeg===0?-1:1;
    var contactX=b.x-dx*.32-dz*foot*.085,contactZ=b.z-dz*.32+dx*foot*.085;
    this.runUp={kind:kind,power:power,automatic:automatic,x:p.pos.x,z:p.pos.z,
      endX:contactX,endZ:contactZ,t:0,length:kind==="penalty"?.42:.20};
    p.action="run";HUD.showPower(null);WORLD.aimArrow.visible=false;
  },
  approachRestart:function(dt){
    var run=this.runUp,p=this.taker;
    run.t=Math.min(run.length,run.t+dt);
    var t=run.t/run.length,weight=t*t*(3-2*t);
    var x=run.x+(run.endX-run.x)*weight,z=run.z+(run.endZ-run.z)*weight;
    p.vel.x=(x-p.pos.x)/dt;p.vel.z=(z-p.pos.z)/dt;p.pos.x=x;p.pos.z=z;
    if(t<1)return;
    p.vel.x=p.vel.z=0;this.runUp=null;this.execRestart(run.kind,run.power,run.automatic);
  },
  execRestart: function(kind, power, automatic){
    var pl = this.taker, team = this.restartTeam;
    var b = SIM.ball;
    var dirX = SIM.teams[team].dir;
    var manual=pl.isUser!==null && !automatic;
    var skill=AI.profile(team),error=manual?0:skill.passErr;
    var aim=manual?{x:Math.sin(pl.face),z:Math.cos(pl.face)}:null;
    this.clearTakerControl();
    if(kind==="freekick" && this.freeIndirect)this.indirectTaker=pl;
    AI.frozen = false;
    if(kind==="kickoff"){
      var mate = this.nearestOutfield(team,pl.pos,false);
      if(mate && mate!==pl){
        SIM.deliver(pl,mate,"pass",.3,dirX,0);
      } else {
        SIM.kick(pl, dirX, 0.2, 0.4, "pass");
      }
    }
    else if(kind==="throw"){
      var near=this.nearestOutfield(team,pl.pos,false);
      var a2=aim || (near?{x:near.pos.x-pl.pos.x,z:near.pos.z-pl.pos.z}:{x:dirX,z:-Math.sign(pl.pos.z)});
      a2={x:a2.x,z:-Math.sign(pl.pos.z)*Math.max(.38,Math.abs(a2.z))};
      SIM.throwBall(pl, a2.x, a2.z, Math.max(0.2, power||0.4));
      this.onPass(pl,null);
    }
    else if(kind==="goalkick"){
      if(power!==undefined && power>0.05){ /* B: długie */
        SIM.kick(pl, aim?aim.x:dirX*.9, aim?aim.z:(Math.random()*2-1)*.35, Math.max(0.5,power), "gklong");
      } else {
        var df=aim?SIM.pickPassTarget(team,aim.x,aim.z,false,pl):this.nearestOutfield(team,pl.pos,false);
        if(df) SIM.deliver(pl,df,"pass",.5,dirX,0,null,error);
        else SIM.kick(pl, dirX, 0, 0.7, "gklong");
      }
    }
    else if(kind==="corner"){
      var sideX = Math.sign(pl.pos.x||1), sideZ = Math.sign(pl.pos.z||1);
      if(power!==undefined && power>0.05){
        var box=SIM.teamPlayers(team).filter(function(p){return p!==pl && p.role!=="GK";});
        box.sort(function(a,c){return Math.hypot(a.pos.x-sideX*(HL-10),a.pos.z)-Math.hypot(c.pos.x-sideX*(HL-10),c.pos.z);});
        if(aim){
          var target={x:b.x+aim.x*(22+16*power),z:b.z+aim.z*(22+16*power)};
          box.sort(function(p,q){return Math.hypot(p.pos.x-target.x,p.pos.z-target.z)-Math.hypot(q.pos.x-target.x,q.pos.z-target.z);});
          SIM.deliver(pl,box[0]||null,"cross",power,aim.x,aim.z,target);
        }else SIM.deliver(pl,box[0]||null,"cross",power,-sideX*.4,-sideZ,null,error);
      } else {
        var mate2=aim?SIM.pickPassTarget(team,aim.x,aim.z,false,pl):this.nearestOutfield(team,pl.pos,false);
        if(mate2){
          SIM.deliver(pl,mate2,"pass",.4,dirX,0,null,error);
        } else {
          SIM.kick(pl, sideX*-1, -sideZ*0.6, 0.8, "cross");
          SIM.ball.curve = -sideZ*2.0;
        }
      }
    }
    else if(kind==="freekick"){
      var goalD = Math.hypot(dirX*HL-pl.pos.x, pl.pos.z);
      if(power!==undefined && power>0.05){
        if(goalD < 32 && Math.abs(pl.pos.z) < 24){
          var tz2=(Math.random()<.5?-1:1)*2.1+(Math.random()*2-1)*skill.shotErr;
          SIM.kick(pl, aim?aim.x:dirX*HL-pl.pos.x, aim?aim.z:tz2-pl.pos.z, Math.min(1,power), "shot");
          SIM.ball.curve = -Math.sign(pl.pos.z||1)*2.4;
          this.onShot(pl);
        } else {
          SIM.kick(pl, aim?aim.x:dirX, aim?aim.z:(Math.random()*2-1)*.5, Math.max(.6,power), "clear");
        }
      } else {
        var mate3=aim?SIM.pickPassTarget(team,aim.x,aim.z,false,pl):this.nearestOutfield(team,pl.pos,false);
        if(mate3) SIM.deliver(pl,mate3,"pass",.5,dirX,0,null,error);
        else SIM.kick(pl, dirX, 0, 0.7, "pass");

      }
    }
    else if(kind==="penalty"){
      /* karny: celowanie gałką w szerokość, siła = wysokość */
      var high=Math.min(1,power||.6);
      var tz3=aim?11*aim.z/Math.max(.1,Math.abs(aim.x)):(Math.random()<.5?-1:1)*2.6+(Math.random()*2-1)*skill.shotErr*.64;
      var gk = SIM.playersOf(1-team, "GK")[0];
      var dive = (Math.random()<.30+.52*AI.profile(1-team).gk ? Math.sign(tz3||1) : -Math.sign(tz3||1)) * (1.6+Math.random()*1.6);
      SIM.kick(pl, dirX*HL-b.x, tz3-b.z, .85, "shot");
      SIM.ball.vy = 1.2 + high*3.2;
      SIM.ball.vx *= 0.92; SIM.ball.vz *= 0.92;
      if(gk){
        if(this.keeperChoice){dive=this.keeperChoice*2.8;gk.vel.z=Math.sign(dive)*5.4;gk.diveSide=Math.sign(dive)*dirX;gk.action="dive";gk.actionT=.53;}
        gk.moveTarget={x:gk.pos.x,z:dive,sprint:true};gk.challengeCd=.06;
      }
      this.onShot(pl);
    }
    HUD.restartTagHide();
    HUD.hideEvent();HUD.hint("");
    HUD.showPower(null);
    WORLD.aimArrow.visible = false;
    this.charge = -1; this._charging = null;
    MATCHDAY.started=true;if(kind==="penalty")MATCHDAY.penaltyFlight=pl;
    this.state = "play";
    this.headerDone = false;
    b.live = true;
  },

  /* ---------- AI wykonuje wznowienie ---------- */
  aiRestart: function(){
    var kind = this.state, pl = this.taker;
    if(!pl || pl.off){ this.startRestart("kickoff", 0.3, true); return; }
    var r = Math.random();
    if(kind==="kickoff") this.startRestart("kickoff", 0.3, true);
    else if(kind==="throwin") this.startRestart("throw", 0.35+Math.random()*0.3, true);
    else if(kind==="goalkick") this.startRestart("goalkick", r<0.5 ? 0 : 0.8, true);
    else if(kind==="corner") this.startRestart("corner", r<0.25 ? 0 : 0.55+Math.random()*0.35, true);
    else if(kind==="freekick")this.startRestart("freekick",this.freeIndirect || r<.4?0:.6+Math.random()*.4,true);
    else if(kind==="penalty") this.startRestart("penalty", 0.45+Math.random()*0.4, true);
  },

  /* ---------- nagłówki (dośrodkowania) ---------- */
  checkHeader: function(){
    if(this.headerDone) return;
    var b = SIM.ball;
    if(b.owner || b.flight!=="cross" || b.y<1.52 || b.y>2.35 || b.vy>1.5) return;
    if(Math.hypot(b.vx, b.vz) < 6) return;
    var dirSide = Math.sign(b.x)||1;
    if(Math.abs(b.x) < HL-18) return;
    var atk = null, def = null, abd = 1e9, dbd = 1e9;
    for(var i=0;i<SIM.players.length;i++){
      var pl = SIM.players[i];
      if(pl.off) continue;
      if(pl.role==="GK" || pl.action==="fallen" || pl.action==="slide" || (pl===b.lastKicker && b.lock>0))continue;
      if(pl.firstTouch || pl.isUser!==null && pl.closeControl)continue;
      if(b.y<1.57*pl.mesh.scale.y || b.y>2.20*pl.mesh.scale.y)continue;
      var d = Math.hypot(pl.pos.x-b.x, pl.pos.z-b.z);
      if(d < .45*pl.mesh.scale.y){
        if(pl.team === (SIM.teams[0].dir===dirSide ? 0 : 1)){ if(d<abd){ abd=d; atk=pl; } }
        else { if(d<dbd){ dbd=d; def=pl; } }
      }
    }
    if(atk && (!def || abd <= dbd)){
      this.headerDone = true;
      var gdir = dirSide;
      var tz = (Math.random()*2-1)*2.8;
      if(this.checkOffsideTouch(atk))return;
      if(this.passPending && this.passPending.team===atk.team && this.passPending.kicker!==atk)SIM.teams[atk.team].stats.pass++;
      SIM.kick(atk, gdir*HL-atk.pos.x, tz-atk.pos.z, 0.55, "header");
      SIM.ball.vy = 1.6;
      this.onShot(atk);
      HUD.commentary(t("c_header"));
    } else if(def){
      this.headerDone = true;
      var ang = Math.random()*6.28;
      SIM.kick(def, Math.sin(ang), Math.cos(ang), 0.7, "headclear");
      def.action="header";def.actionT=.45;
    }
  },

  /* ---------- główna aktualizacja zasad ---------- */
  update: function(dt){
    var b = SIM.ball;
    this.stateT += dt;
    MATCHDAY.clock(dt);
    if(this.state==="substitution"){
      if(this.stateT>=1.7){this.state=MATCHDAY.resumeState;this.stateT=MATCHDAY.resumeTime;HUD.hideEvent();}
      return;
    }
    var ordinaryRestart=["kickoff","throwin","goalkick","corner","freekick"].includes(this.state);
    if(ordinaryRestart && MATCHDAY.started && MATCHDAY.expired() && !MATCHDAY.cards.length){this.endHalf();return;}
    if(MATCHDAY.stopped())return;
    if(this.state==="penalty"){
      var defending=1-this.restartTeam,gk=SIM.playersOf(defending,"GK")[0];
      var keep=gk && (gk.netHuman || (SET.mode!==2 && this.humanTaker(defending)))?INPUT.slots[defending]:null;
      if(keep && Math.abs(keep.mx||0)>.25)this.keeperChoice=Math.sign(keep.mx)*SIM.dirX(this.restartTeam);
    }
    if(this.passPending){
      this.passPending.t -= dt;
      if(this.passPending.t <= 0) this.passPending = null;
    }

    var skip=INPUT.slots[0].camP || INPUT.slots[1].camP;
    if(this.state==="opening" || this.state==="closing"){CEREMONY.step(dt,skip);return;}
    if(this.state==="booking"){
      BROADCAST.bookingStep(dt);
      if(this.stateT>=BROADCAST.scene.duration || (skip && (!BROADCAST.scene.second || BROADCAST.scene.stage==="red"))){
        var spot=BROADCAST.scene.restart;
        BROADCAST.clear();
        if(SIM.teamPlayers(0).length<7 || SIM.teamPlayers(1).length<7){this.fullTime();return;}
        if(spot.resume)MATCHDAY.restoreRestart(spot.resume);
        else if(spot.penalty)this.setupPenalty(spot.team);
        else this.setupFree(spot.team,spot.x,spot.z);
      }
      return;
    }
    if(this.state==="goal"){
      BROADCAST.goalStep(dt,this.stateT);
      this.celebT=skip?0:this.celebT-dt;
      if(this.celebT <= 0){
        BROADCAST.clear();this.clearTakerControl();
        /* po golu: powtórka akcji (jeśli mamy materiał), potem wznowienie */
        if(REC.canReplay() && REPLAY.begin()){
          this.state = "replay";
        } else {
          this.setupKickoff(this._lastConceded, false);
        }
      }
      return;
    }
    if(this.state==="replay"){
      if(REPLAY.update(dt)) this.setupKickoff(this._lastConceded, false);
      return;
    }
    if(this.state==="halftime"){
      if(this.stateT > 3.0){
        this.half = 2;
        SIM.teams[0].dir *= -1; SIM.teams[1].dir *= -1;
        this.elapsed=0;MATCHDAY.resetHalf();
        this.setupKickoff(1-this.kickTeamFirst, false);
      }
      return;
    }
    if(this.state==="fulltime") return;

    /* wznowienia oczekujące na wykonanie */
    if(this.state!=="play"){
      if(this.runUp){this.approachRestart(dt);return;}
      if(this.taker && !b.owner){
        /* piłka trzymana/przy zawodniku */
        if(this.state==="throwin"){
          b.x = this.taker.pos.x + Math.sin(this.taker.face)*0.35;
          b.z = this.taker.pos.z + Math.cos(this.taker.face)*0.35;
          b.y = 1.7;
        } else {
          b.x=this.restartPos.x;b.z=this.restartPos.z;
          b.y = SIM.BR;
        }
        b.vx = b.vy = b.vz = 0;
      }
      /* człowiek wykonuje */
      if(this.taker && this.taker.isUser!==null){
        var slot = this.taker.isUser;
        var inp = INPUT.slots[slot];
        /* zabezpieczenie: bezczynny człowiek nie blokuje meczu (karny — dłużej, bo celowanie) */
        if(this.stateT > (this.state==="penalty" ? 12 : 7)){ this.aiRestart(); return; }
        var aimed=["penalty","corner","freekick","goalkick"].includes(this.state);
        if(aimed){
          var limit=this.state==="penalty"?.35:this.state==="corner"?.58:1.03;
          this.aimOffset=Math.max(-limit,Math.min(limit,this.aimOffset-inp.mx*dt*(this.state==="penalty"?.53:1.5)));
          this.taker.face=this.aimBase+this.aimOffset;
        }else if(this.state==="throwin" && inp.moveLen>.3){
          var field=CAM.fieldInput(inp.mx,inp.mz);
          this.taker.face=Math.atan2(field.x,-Math.sign(this.restartPos.z)*Math.max(.38,Math.abs(field.z)));
        }
        WORLD.aimArrow.visible=aimed;
        WORLD.aimArrow.position.set(this.restartPos.x,.04,this.restartPos.z);
        WORLD.aimArrow.rotation.y=this.taker.face;
        if(this.state==="penalty" || this.state==="corner" || this.state==="freekick" || this.state==="goalkick"){
          if(inp.shoot){ this.charge = Math.min(1, (this.charge<0?0:this.charge)+dt/0.9); HUD.showPower(this.charge); this._charging = "B"; }
          else if(this._charging==="B" && !inp.shoot){ var pw = Math.max(0.15, this.charge); this.charge = -1; this._charging = null; HUD.showPower(null); this.startRestart(this.state, pw); return; }
          if(inp.passP && this.state!=="penalty"){ this.charge = -1; this._charging = null; HUD.showPower(null); this.startRestart(this.state, 0); return; }
        } else if(this.state==="throwin"){
          if(inp.pass){ this.charge = Math.min(1, (this.charge<0?0:this.charge)+dt/0.8); HUD.showPower(this.charge); this._charging="A"; }
          else if(this._charging==="A" && !inp.pass){ var pw2 = Math.max(0.15, this.charge); this.charge=-1; this._charging=null; HUD.showPower(null); this.startRestart("throw", pw2); return; }
        } else if(this.state==="kickoff"){
          if(inp.passP){ this.startRestart("kickoff", 0.3); return; }
        }
      } else {
        /* AI czeka chwilę i wykonuje */
        WORLD.aimArrow.visible = false;
        if(this.stateT > (this.state==="penalty" ? 1.6 : 1.1)) this.aiRestart();
      }
      return;
    }

    /* ============ GRA WLASCIWA ============ */
    if(MATCHDAY.advance(dt))return;
    MATCHDAY.coach();
    if(b.owner) SIM.teams[b.owner.team].stats.poss += dt;
    else if(b.lastTouchTeam >= 0) SIM.teams[b.lastTouchTeam].stats.poss += dt*0.4;

    AI.frozen = false;
    this.checkHeader();
    if(this.state!=="play")return;

    /* zdarzenia styku: spalony, podania */
    for(var e=0;e<SIM.events.length;e++){
      var ev = SIM.events[e];
      if(ev.type==="touch"){
        var tp=ev.player;if(MATCHDAY.lastArm && MATCHDAY.lastArm.p!==tp)MATCHDAY.lastArm=null;
        if(this.checkOffsideTouch(tp)){ SIM.events.length=0;return; }
        if(this.passPending && tp.team===this.passPending.team && tp!==this.passPending.kicker)
          SIM.teams[tp.team].stats.pass++;
        this.passPending=null;this.offsideSet=[];this.offsideArmTeam=-1;
        AUDIO.excitementSet(Math.max(0.2, 0.5 - Math.abs(tp.pos.x)*0.006));
      }
      else if(ev.type==="post"){
        HUD.commentary(tPick("c_post"));
        AUDIO.excitementSet(0.85);
      }
    }
    SIM.events.length = 0;

    /* gol / auty */
    if(this.checkGoal()) return;
    if(this.checkBounds()){
      if(MATCHDAY.expired() && !MATCHDAY.cards.length)this.endHalf();
      return;
    }

    /* koniec połowy */
    if(MATCHDAY.penaltyFlight && (b.lastShotBy!==MATCHDAY.penaltyFlight || b.shotTeam===null || b.owner || Math.hypot(b.vx,b.vz)<=1))MATCHDAY.penaltyFlight=false;
    if(MATCHDAY.expired() && !MATCHDAY.adv && !MATCHDAY.penaltyFlight){
      this.endHalf();
    }
  },
  endHalf:function(){
    if(MATCHDAY.cards.length && MATCHDAY.pendingCard({state:"endHalf",team:this.restartTeam}))return;
    this.runUp=null;this.passPending=null;WORLD.aimArrow.visible=false;HUD.restartTagHide();HUD.hideEvent();HUD.hint("");
    if(this.half===1){
        this.state = "halftime"; this.stateT = 0;
        AUDIO.whistle(2);
        HUD.banner(t("half_title"), SET.home + "  " + SIM.teams[0].score + " : " + SIM.teams[1].score + "  " + SET.away, 3.0);
        HUD.commentary(tPick("c_half"));
        HUD.showPower(null);
        if(WORLD.teleMsg) WORLD.teleMsg(t("tv_half") + "  " + SIM.teams[0].score + " : " + SIM.teams[1].score, 4, "info");
      } else {
        this.fullTime();
      }
  },
  fullTime: function(){
    AUDIO.whistle(4);CEREMONY.prepare(true);
    if(WORLD.teleMsg) WORLD.teleMsg(t("tv_full") + "  " + SIM.teams[0].score + " : " + SIM.teams[1].score, 8, "info");
  },
  _goalTeam: -1,
  _lastConceded: 0
};
