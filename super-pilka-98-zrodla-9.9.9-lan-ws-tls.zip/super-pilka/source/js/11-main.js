/* ============================================================
   SUPER PILKA '98 · 11-main.js — bootstrap, pętla, sterowanie
   ============================================================ */
var MAIN = {
  lastT: 0, fps: 60, fpsAcc: 0, fpsN: 0, fpsT: 0,
  chargeP:[0,0], chargeS:[0,0], combo:[false,false], finesse:[false,false],
  paused: false, running: false,

  boot: function(){
    var canvas = document.getElementById("c");
    try{ WORLD.init(canvas); }catch(e){
      document.getElementById("splash").lastElementChild.textContent="Brak dostępu do WebGL. Włącz akcelerację grafiki w przeglądarce.";
      console.error(e);return;
    }
    SET_bindAll();
    INPUT.init();          /* najpierw mapy sterowania — pomoc i szkołka czytają INPUT.maps */
    SET_applyLang();
    HUD.refreshTeams();
    this.bindUI(); DESK.init(); STADIUM_TOUR.init(); LAN.init();
    window.addEventListener("resize", function(){ WORLD.resize(); });
    document.getElementById("splash").style.display = "none";
    this.state = "menu";
    BROADCAST.clear();RULES.state = "menu";
    requestAnimationFrame(function(t){ MAIN.loop(t); });
  },

  bindUI: function(){
    var self = this;
    document.getElementById("btnPlay").addEventListener("click", function(){
      if(DESK.editingMatch){document.getElementById("ovMenu").classList.add("hide");DESK.editing(false);self.togglePause(false);}
      else self.startMatch();
    });
    document.getElementById("btnHelp").addEventListener("click", function(){
      VOICE.stopMusic();VOICE.stopSpeech();AUDIO.init(); AUDIO.resume(); AUDIO.ui();
      document.getElementById("ovMenu").classList.add("hide");
      document.getElementById("ovHelp").classList.remove("hide");
      if(HUD.buildHelp) HUD.buildHelp();
      if(INPUT.bindRemapUI) INPUT.bindRemapUI();
      var tabView=document.getElementById("helpTabView");
      if(tabView) tabView.click();
    });
    document.getElementById("btnHelpBack").addEventListener("click", function(){
      AUDIO.ui();
      INPUT.listening=null;
      document.getElementById("ovHelp").classList.add("hide");
      document.getElementById("ovMenu").classList.remove("hide");
    });
    document.getElementById("btnTrainer").addEventListener("click", function(){
      VOICE.stopMusic();VOICE.stopSpeech();AUDIO.init(); AUDIO.resume(); AUDIO.ui();
      TRAINER.open();
    });
    document.getElementById("btnTrainerBack").addEventListener("click", function(){
      AUDIO.ui(); TRAINER.close();
    });
    document.getElementById("btnResume").addEventListener("click", function(){ self.togglePause(false); });
    document.getElementById("btnSet").addEventListener("click", function(){
      AUDIO.ui();
      document.getElementById("ovPause").classList.add("hide");
      document.getElementById("ovMenu").classList.remove("hide");
      DESK.select("tactics"); DESK.editing(true);
    });
    document.getElementById("btnRestart").addEventListener("click", function(){ self.startMatch(); });
    document.getElementById("btnQuit").addEventListener("click", function(){ self.toMenu(); });
    document.getElementById("btnRematch").addEventListener("click", function(){ self.startMatch(); });
    document.getElementById("btnEndMenu").addEventListener("click", function(){ self.toMenu(); });
  },

  startMatch: function(){
    VOICE.stopMusic();VOICE.stopSpeech();AUDIO.init(); AUDIO.resume(); AUDIO.ui();
    document.getElementById("ovMenu").classList.add("hide");
    document.getElementById("ovHelp").classList.add("hide");
    document.getElementById("ovPause").classList.add("hide");
    HUD.hideEnd();
    if(REPLAY.active)REPLAY.finish();
    HUD.replayUI(false);HUD.showPower(null);HUD.el("banner").classList.remove("show");
    HUD.commentary("");this.chargeS=[0,0];this.chargeP=[0,0];this.combo=[false,false];this.finesse=[false,false];
    DESK.editing(false); CAM._last=null;
    PITCH.reset();STADIUM.goalTeam=-1;STADIUM.goalLeft=0;
    RULES.newMatch();
    WORLD.refreshAds(SET.home, SET.away);
    HUD.refreshTeams();
    /* podpowiedź kick-offu zostaje — nie nadpisuj jej „ESC — pauza” */
    document.getElementById("hud").classList.add("show");
    this.paused = false;
    this.state = "match";
  },
  toMenu: function(){
    if(WORLD.cup)WORLD.cup.visible=false;
    VOICE.stopMusic();VOICE.stopSpeech();AUDIO.ui();
    document.getElementById("ovPause").classList.add("hide");
    HUD.hideEnd();
    document.getElementById("ovMenu").classList.remove("hide");
    document.getElementById("hud").classList.remove("show");
    WORLD.m1.visible = false; WORLD.m2.visible = false;
    WORLD.aimArrow.visible = false;
    BROADCAST.clear();RULES.state = "menu";
    this.state = "menu";
    if(REPLAY.active)REPLAY.finish();
    DESK.editing(false);this.paused=false;
  },
  togglePause: function(on){
    if(on === undefined) on = !this.paused;
    this.paused = on;
    document.getElementById("ovPause").classList.toggle("hide", !on);
    if(on){
      this.el2("pScore").textContent = SET.home + "  " + SIM.teams[0].score + " : " + SIM.teams[1].score + "  " + SET.away;
      MATCH_MENU.subs();HUD.stats("pauseStats");AUDIO.ui();
    }
  },
  el2: function(id){ return document.getElementById(id); },

  /* ---------- sterowanie człowieka — wspólny moduł HUMAN (06-human.js) ----------
     Ta sama ścieżka działa lokalnie i na serwerze LAN, a ładowanie podania,
     strzału i combo jest trzymane per zawodnik, nie per drużyna. */
  humanControl: function(dt){
    var power = 0;
    for(var s=0;s<2;s++){
      if(!RULES.humanTaker(s))continue;
      var inp = INPUT.slots[s], team = SIM.teams[s];
      var next = HUMAN.select(team, team.user, inp, null, dt);
      if(next !== team.user) SIM.control(s, next);
      var user = team.user;
      if(!user) continue;
      if(user.isUser !== s) SIM.control(s, user);
      var field = CAM.fieldInput(inp.mx, inp.mz);
      var st = user.ctl || (user.ctl = HUMAN.newState());
      power = Math.max(power, HUMAN.drive(s, user, inp, field, st, dt,
        { handoff: function(mate){ if(mate && !mate.off) SIM.control(s, mate); } }) || 0);
    }
    HUD.showPower(power || null);
  },

  markers: function(){
    var m1 = WORLD.m1, m2 = WORLD.m2;
    if(["replay","goal","booking","halftime","fulltime","opening","closing"].includes(RULES.state)){ m1.visible = false; m2.visible = false; return; }
    var u0 = SIM.teams[0] && SIM.teams[0].user, u1 = SIM.teams[1] && SIM.teams[1].user;
    if(this.state==="match" && u0 && !u0.off){
      m1.visible = true;
      m1.position.set(u0.pos.x, 0, u0.pos.z);
      m1.userData.arrow.rotation.y=performance.now()*.0018;
      m1.userData.arrow.position.y = 2.18 + Math.sin(performance.now()/300)*0.06;
    } else m1.visible = false;
    if(this.state==="match" && u1 && !u1.off){
      m2.visible = true;
      m2.position.set(u1.pos.x, 0, u1.pos.z);
      m2.userData.arrow.rotation.y=performance.now()*.0018;
      m2.userData.arrow.position.y = 2.18 + Math.cos(performance.now()/300)*0.06;
    } else m2.visible = false;
  },

  /* ---------- główna pętla ---------- */
  loop: function(tms){
    var self = this;
    requestAnimationFrame(function(t){ self.loop(t); });
    var rawDt = (tms - this.lastT)/1000;
    var dt = Math.min(0.1, Math.max(0.001, rawDt));
    this.lastT = tms;
    /* prawdziwy fps liczony z nieograniczonego odstępu */
    this.fpsAcc += rawDt; this.fpsN++;
    if(this.fpsAcc > 0.5){
      this.fps = Math.round(this.fpsN/this.fpsAcc);
      this.fpsAcc = 0; this.fpsN = 0;

    }

    INPUT.update();
    if(TRAINER.active){
      if(INPUT.slots[0].pauseP || INPUT.slots[1].pauseP)TRAINER.close();
      else TRAINER.frame(dt);
      INPUT.consumeEdges();
      return;
    }
    if(LAN.active){LAN.frame(dt,tms);return;}

    if(STADIUM_TOUR.active){
      if(INPUT.slots[0].pauseP||INPUT.slots[1].pauseP)STADIUM_TOUR.close();
      else{STADIUM_TOUR.camera(dt);WORLD.tick(dt);WORLD.renderer.render(WORLD.scene,WORLD.cam);}
      return;
    }
    if(SHOWROOM.active){
      if(INPUT.slots[0].pauseP || INPUT.slots[1].pauseP)SHOWROOM.close();
      else SHOWROOM.update(dt);
      return;
    }
    /* pauza / menu — klawisze */
    if(this.state==="match" && !DESK.editingMatch){
      var s1 = INPUT.slots[0], s2 = INPUT.slots[1];
      if((s1.pauseP || s2.pauseP) && RULES.state!=="fulltime") this.togglePause();
      if(!this.paused && !["replay","goal","booking","opening","closing"].includes(RULES.state) && (s1.camP || s2.camP)){
        CAM.setMode(SET.cam+1);syncCameraMenu();SET_save();AUDIO.ui();
      }
      /* interaktywny zoom kamery: kółko myszy / klucze + − (poza powtórką) */
      if(RULES.state !== "replay"){
        if(INPUT.wheelAcc){ CAM.zoomBy(INPUT.wheelAcc * 0.0011); }
        var zk = INPUT.zoomKey();
        if(zk) CAM.zoomBy(-zk * dt * 1.3);
      }
      INPUT.wheelAcc = 0;
    }

    if(this.state==="menu"){
      /* tryb attract: pusta arena (flagi, kibice i telebim żyją też w menu) */
      CAM.update(dt, "menu");
      WORLD.tick(dt);
      WORLD.renderer.render(WORLD.scene, WORLD.cam);
      return;
    }
    if(this.paused){
      WORLD.renderer.render(WORLD.scene, WORLD.cam);
      return;
    }

    // Małe kroki zapobiegają przelatywaniu piłki przez zawodników przy niskim FPS.
    var n=Math.ceil(dt*60), step=dt/n;
    for(var tick=0;tick<n;tick++){
      var was=RULES.state;
      RULES.update(step);
      if(RULES.state==="play"){
        if(was!=="play")INPUT.consumeEdges();
        this.humanControl(step);AI.update(step);SIM.step(step);if(RULES.state==="play")REC.push(step);
      }
      INPUT.consumeEdges();
    }
    if(RULES.state!=="replay")SIM.syncMeshes(dt);
    CAM.update(dt, RULES.state==="menu" ? "menu" : RULES.state);
    this.markers();
    HUD.update(dt);

    /* emocje tłumu */
    var b = SIM.ball;
    var prox = Math.max(0, 1 - Math.min(Math.abs(b.x-HL), Math.abs(b.x+HL))/40);
    AUDIO.excitementSet(0.12 + prox*0.3 + (b.owner?0.06:0.1));
    AUDIO.update(dt);
    /* trybuny: podskok tłumu przy golu, cichy szum w trakcie gry */
    if(RULES.state==="goal") WORLD.crowdPulse = 1;
    else if(RULES.state==="replay") WORLD.crowdPulse = 0.35;
    else WORLD.crowdPulse = Math.max(0, (WORLD.crowdPulse||0) - dt*0.5);
    WORLD.tick(dt);
    WORLD.tickStaff(dt, RULES.state);

    WORLD.renderer.render(WORLD.scene, WORLD.cam);
  }
};

/* przycisk pauzy = powrót do gry; ustawienia w pauzie pokazują menu */

window.addEventListener("load", function(){
  MAIN.boot();
  /* pad w menu = szybki start */
  var padWatch = setInterval(function(){
    if(!SHOWROOM.active && MAIN.state==="menu" && document.getElementById("ovMenu") && !document.getElementById("ovMenu").classList.contains("hide")){
      if(INPUT.anyPadButton()){
        INPUT.update();
        MAIN.startMatch();
      }
    }
  }, 300);
});
