var FIRST_TOUCH={
  intent:function(p,kind,dx,dz){p.firstTouch={kind:kind,x:dx,z:dz,life:.90};},
  try:function(p,b,speed){
    if(p.closeControl || speed<2.6 || p===b.lastKicker && b.lock>0)return false;
    var h=b.y/p.mesh.scale.y,dir=SIM.dirX(p.team),range=Math.hypot(dir*HL-b.x,b.z),header=h>1.47;
    if(h>2.15 || (!header && h>1.22))return false;
    var dx=b.x-p.pos.x,dz=b.z-p.pos.z;
    if(Math.hypot(dx,dz)>(header?.54:.76) || dx*(b.vx-p.vel.x)+dz*(b.vz-p.vel.z)>.45)return false;
    var choice=p.firstTouch,kind=choice?.kind;
    if(!kind){
      if(p.isUser!==null || p.netHuman)return false;
      if(range<18 && (b.receiver===p || b.flight==="cross") && speed>4)kind="shoot";
      else if(header || b.receiver===p && b.flightAge>.23 && AI.nearestOppDist(p,SIM.teamPlayers(1-p.team))<3.15)kind="pass";
      else return false;
    }
    if(RULES.checkOffsideTouch(p))return true;
    var ax=choice?choice.x:dir,az=choice?choice.z:0;
    var other=SIM.pickPassTarget(p.team,ax,az,false,p);
    if(kind==="pass" && !other)return false;
    if(RULES.passPending?.team===p.team && RULES.passPending.kicker!==p)SIM.teams[p.team].stats.pass++;
    RULES.offsideSet=[];RULES.offsideArmTeam=-1;p.firstTouch=null;
    var side=dx*Math.cos(p.face)-dz*Math.sin(p.face);
    var incomingSide=(b.vx*Math.cos(p.face)-b.vz*Math.sin(p.face))/(speed||1);
    var fromBehind=(b.vx*Math.sin(p.face)+b.vz*Math.cos(p.face))/(speed||1)>.48;p.mesh.userData.kickLeg=side>0?1:0;
    if(kind==="shoot"){
      var shot=header?"header":h>.42?"volley":"shot";
      SIM.shoot(p,dir*HL-b.x,(choice?az*3.4:-Math.sign(b.z||1)*2.2)-b.z,.65,shot);
      if(header)b.vy=1.55;else if(h>.42)b.vy=1.8;
    }else if(header){
      var reach=Math.hypot(other.pos.x-b.x,other.pos.z-b.z);
      SIM.kick(p,other.pos.x-b.x,other.pos.z-b.z,.55,"headpass");
      var time=Math.max(.58,Math.min(1.62,reach/12));b.vy=SIM.G*time*.5+(1.67-b.y)/time;
      var d=Math.hypot(b.vx,b.vz)||1,sp=reach*.13/(1-Math.exp(-.13*time));b.vx*=sp/d;b.vz*=sp/d;
      b.receiver=other;b.route={x:other.pos.x,z:other.pos.z};RULES.onPass(p,other);
    }else SIM.deliver(p,other,"pass",.52,ax,az);
    p.action=header?"header":h>.42?(Math.abs(incomingSide)>.52?"sidevolley":"volley"):fromBehind?"turnstrike":kind==="shoot"?"kick":"passkick";
    p.actionT=header?.45:.38;
    RULES.headerDone=false;return true;
  }
};
