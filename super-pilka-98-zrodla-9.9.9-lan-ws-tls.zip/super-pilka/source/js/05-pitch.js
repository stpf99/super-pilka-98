var PITCH={
  nets:[],
  goals:function(world){
    var steel=new ArenaGeometry();
    [-1,1].forEach(function(sign){
      function at(depth,y,z){return [sign*(HL+depth),y,z];}
      var w=GOAL_W*.5,h=GOAL_H;
      [-w,w].forEach(function(z){
        steel.rod(at(0,.015,z),at(0,h+.038,z),GK_R,GK_R,0xf4f0df,14);
        steel.rod(at(0,.055,z),at(1.99,.055,z),.038,.038,0xd1d5cb,8);
        steel.rod(at(0,h-.035,z),at(.97,h-.055,z),.034,.031,0xb9c3bf,8);
        steel.rod(at(.97,h-.055,z),at(1.99,.055,z),.028,.033,0xa9bab6,8);
      });
      steel.rod(at(0,h,-w-.058),at(0,h,w+.058),GK_R,GK_R,0xf4f1e5,16);
      steel.rod(at(1.99,.055,-w),at(1.99,.055,w),.037,.037,0xd5d7cc,8);
      var lines=[];
      // Dach, tylna ściana i oba boki współdzielą krawędzie. Sznur lekko zwisa między punktami mocowania.
      function grid(nx,ny,fn){
        function segment(a,b){lines.push(a[0],a[1],a[2],b[0],b[1],b[2]);}
        for(var y=0;y<=ny;y++)for(var x=0;x<=nx;x++){
          var p=fn(x/nx,y/ny);
          if(x<nx)segment(p,fn((x+1)/nx,y/ny));
          if(y<ny)segment(p,fn(x/nx,(y+1)/ny));
        }
      }
      function rear(v){return 1.99-v*1.02;}
      grid(36,5,function(u,v){return at(v*.97,h-.055*v-.064*Math.sin(Math.PI*v)*Math.sin(Math.PI*u),(2*u-1)*w);});
      grid(36,12,function(u,v){return at(rear(v)+.074*Math.sin(Math.PI*u)*Math.sin(Math.PI*v),.055+(h-.11)*v,(2*u-1)*w);});
      [-1,1].forEach(function(side){grid(9,12,function(u,v){return at(u*rear(v),.055+(h-.055)*v-.055*u*v,side*(w+.023*Math.sin(Math.PI*u)*Math.sin(Math.PI*v)));});});
      var g=new THREE.BufferGeometry(),pos=new THREE.Float32BufferAttribute(lines,3);
      pos.setUsage(THREE.DynamicDrawUsage);g.setAttribute("position",pos);
      var mesh=new THREE.LineSegments(g,new THREE.LineBasicMaterial({color:0xd5ded7,transparent:true,opacity:.54,depthWrite:false}));
      g.computeBoundingSphere();g.boundingSphere.radius+=.5;mesh.name="Siatka bramki";world.scene.add(mesh);
      PITCH.nets.push({sign:sign,mesh:mesh,rest:new Float32Array(pos.array),timer:0,z:0,y:0});
    });
    var frame=new THREE.Mesh(steel.build(false),new THREE.MeshLambertMaterial({vertexColors:true}));frame.castShadow=true;world.scene.add(frame);
  },
  hit:function(ball){
    var net=this.nets[ball.x>0?1:0];net.timer=1.22;net.y=ball.y;net.z=ball.z;
  },
  reset:function(){
    this.nets.forEach(function(n){n.timer=0;var p=n.mesh.geometry.attributes.position;p.array.set(n.rest);p.needsUpdate=true;});
  },
  tick:function(dt){
    this.nets.forEach(function(n){
      if(n.timer<=0)return;
      n.timer=Math.max(0,n.timer-dt);
      var p=n.mesh.geometry.attributes.position,rest=n.rest,t=1.22-n.timer;
      for(var i=0;i<p.count;i++){
        var k=i*3,x=rest[k],y=rest[k+1],z=rest[k+2],deep=Math.abs(x)-HL;
        var distance=Math.hypot((z-n.z)*.74,(y-n.y)*.86),age=t-distance*.06;
        var pulse=age<=0||n.timer===0?0:Math.sin(age*19)*Math.exp(-age*4.2)*Math.exp(-distance*1.05);
        p.array[k]=x+n.sign*.54*pulse*Math.min(1,Math.max(0,deep))*Math.min(1,y*4);
      }
      p.needsUpdate=true;
    });
  },
  ball:function(){
    // Ścięcie dwudziestościanu daje 12 pięciokątów i 20 sześciokątów bez szwu na biegunach.
    var source=new THREE.IcosahedronGeometry(1,0),attrs=source.attributes.position,verts=[],ids=new Map(),tri=[];
    for(var i=0;i<attrs.count;i++){
      var v=new THREE.Vector3().fromBufferAttribute(attrs,i),key=[v.x,v.y,v.z].map(function(x){return Math.round(x*10000);}).join(",");
      if(!ids.has(key)){ids.set(key,verts.length);verts.push(v);}
      tri.push(ids.get(key));
    }
    source.dispose();
    var neighbors=verts.map(function(){return new Set();}),panels=[],builder=new ArenaGeometry();
    function corner(a,b){return verts[a].clone().lerp(verts[b],1/3).normalize();}
    for(var k=0;k<tri.length;k+=3){
      var a=tri[k],b=tri[k+1],c=tri[k+2];
      neighbors[a].add(b).add(c);neighbors[b].add(a).add(c);neighbors[c].add(a).add(b);
      panels.push({edge:[corner(a,b),corner(b,a),corner(b,c),corner(c,b),corner(c,a),corner(a,c)],tint:SET.ballStyle==="winter"?0xff861c:0xedece3});
    }
    verts.forEach(function(v,i){
      var axes=Array.from(neighbors[i]).map(function(j){return corner(i,j);});
      var right=axes[0].clone().addScaledVector(v,-axes[0].dot(v)).normalize(),up=v.clone().cross(right);
      axes.sort(function(a,b){return Math.atan2(a.dot(up),a.dot(right))-Math.atan2(b.dot(up),b.dot(right));});
      panels.push({edge:axes,tint:SET.ballStyle==="wave"?0x2176a5:SET.ballStyle==="winter"?0x483269:0x29323d});
    });
    panels.forEach(function(p){
      var points=p.edge,center=points.reduce(function(sum,v){return sum.add(v);},new THREE.Vector3()).normalize();
      if(points[1].clone().sub(points[0]).cross(points[2].clone().sub(points[0])).dot(center)<0)points.reverse();
      var rings=[[0,.1477,0x566068],[.041,.1494,p.tint],[.48,.1500,p.tint]];
      if(SET.ballStyle==="wave" && points.length===6)rings=[[0,.1477,0x394958],[.05,.1494,0x2f84a3],[.17,.1498,0x85c6d3],[.38,.15,p.tint]];
      var previous=[];
      rings.forEach(function(r){
        var current=points.map(function(v){return builder.vertex(v.clone().lerp(center,r[0]).normalize().multiplyScalar(r[1]).toArray(),r[2]);});
        for(var j=0;j<current.length&&previous.length;j++){var next=(j+1)%current.length;builder.face(previous[j],previous[next],current[next],current[j]);}
        previous=current;
      });
      var top=builder.vertex(center.clone().multiplyScalar(.15).toArray(),p.tint);
      for(var j=0;j<previous.length;j++)builder.face(previous[j],previous[(j+1)%previous.length],top);
    });
    var geo=builder.build(false),norm=geo.attributes.normal,pos=geo.attributes.position;
    for(var j=0;j<pos.count;j++){var n=new THREE.Vector3().fromBufferAttribute(pos,j).normalize();norm.setXYZ(j,n.x,n.y,n.z);}
    var m=new THREE.Mesh(geo,new THREE.MeshPhongMaterial({vertexColors:true,shininess:28,specular:0x393d40}));
    m.castShadow=true;return m;
  },
  grass:function(world){
    var w=2048,h=1024,spanX=134,spanZ=96,seed=5401;
    function rand(){seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;}
    var tex=arenaTexture(w,h,function(g){
      g.fillStyle="#48723b";g.fillRect(0,0,w,h);
      var bw=PL/12*w/spanX,origin=(spanX-PL)*w/(2*spanX);
      for(var i=-2;i<=14;i++){
        var x=origin+bw*i,gradient=g.createLinearGradient(x,0,x+bw,0);
        gradient.addColorStop(0,i%2?"#3d6534":"#4b723c");gradient.addColorStop(1,i%2?"#456c3a":"#537b40");
        g.fillStyle=gradient;g.fillRect(Math.floor(x),0,Math.ceil(bw)+1,h);
      }
      for(var j=0;j<10;j++){g.fillStyle=j%2?"rgba(18,55,34,.037)":"rgba(218,229,152,.026)";g.fillRect(0,(h/2-PW/2*h/spanZ)+j*PW/10*h/spanZ,w,PW/10*h/spanZ);}
      // Gęste, niskokontrastowe kępki i szerokie przejścia koloru między fragmentami darni.
      for(var cloud=0;cloud<64;cloud++){
        var cx=rand()*w,cy=rand()*h,rad=32+rand()*125,patch=g.createRadialGradient(cx,cy,0,cx,cy,rad);
        patch.addColorStop(0,cloud%2?"rgba(131,131,65,.12)":"rgba(24,51,39,.12)");patch.addColorStop(1,"rgba(69,102,55,0)");
        g.fillStyle=patch;g.fillRect(cx-rad,cy-rad,rad*2,rad*2);
      }
      var colors=["rgba(152,181,113,.105)","rgba(26,67,40,.14)","rgba(107,150,79,.14)","rgba(71,102,49,.14)"];
      for(var l=0;l<colors.length;l++){
        g.fillStyle=colors[l];
        for(var k=0;k<8000;k++)g.fillRect(rand()*w,rand()*h,.62+rand()*.92,.55+rand()*1.13);
      }
      // Kępki o różnym ułożeniu pozostają widoczne również w szerokim ujęciu.
      for(var c=0;c<3;c++){
        g.strokeStyle=["rgba(27,54,32,.16)","rgba(162,163,96,.14)","rgba(91,119,58,.14)"][c];
        g.lineWidth=1.25;g.beginPath();
        for(var tuft=0;tuft<4800;tuft++){
          var gx=rand()*w,gz=rand()*h,lean=rand()*6-3;
          g.moveTo(gx,gz);g.lineTo(gx+lean,gz-1-rand()*1.6);
        }
        g.stroke();
      }
      function worn(mx,mz,rx,rz,count){
        for(var i=0;i<count;i++){
          var dx=(rand()+rand()+rand()-1.5)*rx,dz=(rand()+rand()+rand()-1.5)*rz;
          g.fillStyle=i%3?"rgba(116,112,63,.16)":"rgba(134,124,73,.22)";
          g.fillRect((.5+(mx+dx)/spanX)*w,(.5+(mz+dz)/spanZ)*h,.9+rand()*1.94,.7+rand()*1.23);
        }
      }
      worn(0,0,2.6,2.1,360);[-1,1].forEach(function(s){worn(s*(HL-1),0,1.88,3.48,1200);worn(s*(HL-11),0,1.0,.80,220);});
    });
    tex.anisotropy=world.renderer.capabilities?Math.min(8,world.renderer.capabilities.getMaxAnisotropy()):4;
    var blades=arenaTexture(128,128,function(g){
      g.fillStyle="#b7b7b7";g.fillRect(0,0,128,128);
      for(var k=0;k<4300;k++){var val=Math.floor(112+rand()*105);g.fillStyle="rgb("+val+","+val+","+val+")";g.fillRect(rand()*128,rand()*128,.8,1.26+rand()*2.1);}
    });blades.wrapS=blades.wrapT=THREE.RepeatWrapping;
    var turf=new THREE.MeshLambertMaterial({map:tex});
    this.surfaceWeather={value:0};
    turf.onBeforeCompile=function(shader){
      shader.uniforms.blades={value:blades};shader.uniforms.surfaceWeather=PITCH.surfaceWeather;shader.fragmentShader="uniform float surfaceWeather; uniform sampler2D blades;\n"+shader.fragmentShader.replace("#include <map_fragment>",
        "#include <map_fragment>\nfloat grain=texture2D(blades,vUv*vec2(84.0,60.0)).r;diffuseColor.rgb*=.91+.16*grain;float cover=clamp(surfaceWeather,0.,1.)*(.38+.36*grain+.12*sin(vUv.x*91.+sin(vUv.y*42.)));diffuseColor.rgb=mix(diffuseColor.rgb,vec3(.82,.85,.82),cover);diffuseColor.rgb*=1.+min(0.,surfaceWeather)*(.20-.09*grain);");
    };
    var pitch=world._plane(spanX,spanZ,turf);pitch.receiveShadow=true;world.scene.add(pitch);
    var outer=world._plane(440,400,new THREE.MeshLambertMaterial({color:0x354644}));outer.position.y=-.06;world.scene.add(outer);
    var walk=new ArenaGeometry();
    [-1,1].forEach(function(s){
      walk.quad([-56,.012,s*38],[56,.012,s*38],[56,.012,s*42.6],[-56,.012,s*42.6],0x536266);
      for(var x=-51;x<=51;x+=4)walk.quad([x,.013,s*38.15],[x+.045,.013,s*38.15],[x+.045,.013,s*42.6],[x,.013,s*42.6],0x3f4d50);
    });world.scene.add(new THREE.Mesh(walk.build(false),new THREE.MeshLambertMaterial({vertexColors:true,side:THREE.DoubleSide})));
  }
};
