/* ============================================================
   SUPER PILKA '98 · 02-settings.js — ustawienia zapisywane lokalnie
   ============================================================ */
var SET = {
  mode: 0,        // 0 = 1 gracz vs komputer, 1 = 2 graczy, 2 = oglądaj (AI vs AI)
  half: 120,      // sekundy na połowę: 60/120/180/300
  diff: 3,        // 3 początkujący, 0 łatwy, 1 normalny, 2 trudny
  ref:  1,        // 0 łagodny, 1 normalny, 2 surowy
  cam:  4,        // 0 TV, 1 góra, 2 za piłką, 3 za graczem
  night: 0,       // 1 = noc pod reflektorami, 0 = dzień
  q:    1,        // 0 niska, 1 średnia, 2 wysoka
  snd:  0.6,      // głośność 0..1
  lang:"pl",
  cameraChosen:0, nationH:"club",nationA:"club",stripH:"home",stripA:"home",
  stadium:"classic",ballStyle:"classic",weather:"clear",
  home:"KS SOKÓŁ", away:"TS ORZEŁ",
  formH:"4-3-3", formA:"4-4-2", tacticH:"balanced", tacticA:"balanced"
};
var SET_KEY = "sp98_v1";
try{
  var _saved = JSON.parse(localStorage.getItem(SET_KEY) || "{}");
  var choices = {mode:[0,1,2],half:[60,120,180,300,2700],diff:[0,1,2,3],ref:[0,1,2],cam:[0,1,2,3,4],
    cameraChosen:[0,1],nationH:Object.keys(TEAMS.data),nationA:Object.keys(TEAMS.data),
    stripH:["home","away"],stripA:["home","away"],stadium:["classic","terrace","arena"],ballStyle:["classic","wave","winter"],
    weather:["clear","rain","snow","fog"],night:[0,1],q:[0,1,2],snd:[0,0.6,1],lang:["pl","en"],formH:Object.keys(LINEUP.forms),
    formA:Object.keys(LINEUP.forms),tacticH:["balanced","press","counter"],tacticA:["balanced","press","counter"]};
  Object.keys(SET).forEach(function(key){
    if(key==="home" || key==="away"){
      if(typeof _saved[key]==="string" && _saved[key].trim()) SET[key]=_saved[key].trim().slice(0,14);
    } else if(choices[key].includes(_saved[key])) SET[key]=_saved[key];
  });
  if(!_saved.cameraChosen && _saved.cam===0)SET.cam=4;
}catch(e){ /* file:// bez localStorage — ignoruj */ }

function SET_save(){
  try{ localStorage.setItem(SET_KEY, JSON.stringify(SET)); }catch(e){}
}
function SET_applyLang(){ I18N_cur = SET.lang; applyI18n(); }

/* segment menu: klik + odczyt wartości */
function SET_bindSeg(id, key, parse, after){
  var seg = document.getElementById(id);
  function sync(){
    seg.querySelectorAll("button").forEach(function(b){
      var on = String(b.dataset.v) === String(SET[key]);
      b.classList.toggle("on", on); b.setAttribute("aria-pressed", String(on));
    });
  }
  seg.addEventListener("click", function(e){
    var b = e.target.closest("button"); if(!b) return;
    SET[key] = parse ? parse(b.dataset.v) : b.dataset.v;
    SET_save(); sync(); UI_click();
    if(after) after();
    DESK.refresh();
  });
  sync();
  return sync;
}
function SET_updateModeUI(){
  var tg = document.getElementById("tagAway");
  if(tg) tg.textContent = SET.mode===1 ? "P2" : "CPU";
  document.getElementById("tagHome").textContent = SET.mode===2 ? "CPU" : "P1";
}
var syncCameraMenu;
function SET_bindAll(){
  SET_bindSeg("segMode","mode", Number, function(){ SET_updateModeUI(); });
  SET_bindSeg("segHalf","half", Number);
  SET_bindSeg("segDiff","diff", Number);
  SET_bindSeg("segRef","ref", Number);
  syncCameraMenu = SET_bindSeg("segCam","cam",Number,function(){SET.cameraChosen=1;SET_save();});
  SET_bindSeg("segNight","night", Number, function(){ if(WORLD.setNight) WORLD.setNight(SET.night===1); });
  SET_bindSeg("segQ","q", Number, function(){ WORLD.quality(); });
  SET_bindSeg("segSnd","snd", Number, function(){ AUDIO.setVolume(); });
  SET_bindSeg("segLang","lang", String, function(){
    SET_applyLang(); UI_click();
  });
  ["H","A"].forEach(function(side, team){
    SET_bindSeg("form"+side,"form"+side,String,function(){ if(SIM.teams.length) LINEUP.apply(team); });
    SET_bindSeg("tactic"+side,"tactic"+side,String);
  });
  var ih = document.getElementById("inHome"), ia = document.getElementById("inAway");
  ih.value = SET.home; ia.value = SET.away;
  ih.addEventListener("change", function(){ SET.home = ih.value.trim() || "KS SOKÓŁ"; ih.value=SET.home; WORLD.refreshAds(SET.home,SET.away); SET_save(); DESK.refresh(); });
  ia.addEventListener("change", function(){ SET.away = ia.value.trim() || "TS ORZEŁ"; ia.value=SET.away; WORLD.refreshAds(SET.home,SET.away); SET_save(); DESK.refresh(); });
  SET_updateModeUI();
}

/* parametry rozgrywki wynikające z ustawień */
var DIFF = [
  {react:.90,press:10,delay:.95,space:2.5,spd:.83,passErr:2.1,shotErr:3.55,range:18,gk:.47,aiIQ:.47},
  {react:.61,press:15,delay:.64,space:1.75,spd:.92,passErr:1.32,shotErr:2.32,range:21,gk:.60,aiIQ:.63},
  {react:.37,press:20,delay:.36,space:1.12,spd:.99,passErr:.73,shotErr:1.32,range:24,gk:.73,aiIQ:.80},
  {react:1.26,press:7,delay:1.55,space:3.50,spd:.71,passErr:3.25,shotErr:4.8,range:15,gk:.33,aiIQ:.33}
];
var REFSTRICT = [0.7, 1.0, 1.45];
