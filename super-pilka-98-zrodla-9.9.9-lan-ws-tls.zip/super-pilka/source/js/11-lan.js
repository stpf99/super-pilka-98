/* LAN transmits football state and inputs. Every browser renders its own scene.
   Transport: jeden WebSocket dla stanu, wejść, czatu i lobby (poz. 6);
   przy braku WebSocket klient wraca do odpytywania HTTP. */
var LAN={
  active:false,token:"",room:null,slot:-1,generation:0,mode:"fan",seq:Date.now()*1000,turn:0,tilt:0,fanFov:47,
  /* bufor interpolacji (poz. 10): render wstecz względem najnowszej migawki, Hermite dla piłki */
  buf:[], bufDelay:.085, clockOff:0, clockSamples:0,
  /* WebSocket: wsOk = kanał potwierdzony przez serwer; rtt w ms (poz. 6) */
  ws:null, wsOk:false, wsResolve:null, rtt:70, pingTimer:null, hz:20, watchers:[], fans:0,
  fanLook:{x:0,y:1,z:0}, fanLookV:{x:0,y:0,z:0}, fanPitchT:0,
  el:function(id){return document.getElementById(id);},
  num:function(id,min,max){return Math.min(max,Math.max(min,Number(this.el(id).value)||min));},
  msg:function(message){this.el(this.active?"lanStatus":"lanMessage").textContent=message;},
  api:async function(path,body){
    var opts={headers:{},cache:"no-store"};
    if(this.token)opts.headers.Authorization="Bearer "+this.token;
    if(body!==undefined){opts.method="POST";opts.headers["Content-Type"]="application/json";opts.body=JSON.stringify(body);}
    var res=await fetch("/api/"+path,opts),data;
    try{data=await res.json();}catch(e){throw Error("Uruchom serwer poleceniem python3 serve.py --port 8906.");}
    if(!res.ok)throw Error(data.error||("HTTP "+res.status));return data;
  },
  sayNick:function(nick){
    if(!SET.snd || !nick || typeof Audio==="undefined")return;
    if(this.nickAudio)this.nickAudio.pause();
    this.nickAudio=new Audio("/api/nick.wav?lang="+SET.lang+"&nick="+encodeURIComponent(nick));
    this.nickAudio.volume=Math.min(1,SET.snd*.8);this.nickAudio.play().catch(()=>{});
  },
  /* ---------- WebSocket (poz. 6): stan, wejścia, czat i lobby jednym kanałem ---------- */
  wsUrl:function(){
    return (location.protocol==="https:"?"wss":"ws")+"://"+location.host+"/ws";
  },
  connect:function(){
    var self=this;
    if(this.ws && this.ws.readyState<=1 && this.wsOk)return Promise.resolve(true);
    if(this.ws){try{this.ws.onclose=this.ws.onerror=this.ws.onmessage=null;this.ws.close();}catch(e){}this.ws=null;}
    this.wsOk=false;
    if(!window.WebSocket || location.protocol==="file:")return Promise.resolve(false);
    return new Promise(function(resolve){
      var settled=false;
      self.wsResolve=function(ok){if(!settled){settled=true;self.wsResolve=null;resolve(ok);}};
      var guard=setTimeout(function(){self.wsResolve&&self.wsResolve(false);},4000);
      var ws;
      try{ws=self.ws=new WebSocket(self.wsUrl());}catch(e){clearTimeout(guard);self.wsResolve&&self.wsResolve(false);return;}
      ws.onopen=function(){self.hello();};
      ws.onerror=function(){};
      ws.onclose=function(){
        clearTimeout(guard);
        var had=self.wsOk;self.wsOk=false;
        self.wsResolve&&self.wsResolve(false);
        if(!had)return;
        /* powrót do HTTP przy zerwaniu kanału */
        var g=self.generation;
        if(self.active&&g===self.generation){
          self.msg("Połączenie WebSocket przerwane — wracam do odpytywania HTTP.");
          self.poll(g);self.pollChat(g);
        }else if(!self.el("ovLan").classList.contains("hide")){
          self.startLobbyTimer();
        }
      };
      ws.onmessage=function(ev){self.wire(ev.data);};
    });
  },
  hello:function(){
    if(!this.ws||this.ws.readyState!==1)return;
    var fan={sector:this.num("lanSector",0,7),row:this.num("lanRow",1,14),seat:this.num("lanSeatNo",1,40)};
    var packet={op:"hello",room:this.active&&this.room?this.room.id:0,mode:this.active?this.mode:"lobby",fan:fan};
    if(this.token)packet.token=this.token;
    this.ws.send(JSON.stringify(packet));
  },
  wire:function(text){
    var m;try{m=JSON.parse(text);}catch(e){return;}
    if(!m||typeof m!=="object")return;
    if(m.op==="welcome"){
      this.wsOk=true;this.hz=m.hz||20;
      if(this.active)this.bufDelay=Math.max(.06,Math.min(.14,.05+this.rtt/1000*.75));
      this.wsResolve&&this.wsResolve(true);
      return;
    }
    if(m.op==="state"){if(this.active)this.accept(m.state);return;}
    if(m.op==="chat"){this._appendChat(m.message);return;}
    if(m.op==="lobby"){this._lobby(m.rooms||[]);return;}
    if(m.op==="watchers"){this._watchers(m.watchers||[],m.fans|0);return;}
    if(m.op==="pong"){this.rtt=Math.max(1,Math.round(performance.now()-m.t));return;}
    if(m.op==="bye"){this.msg(m.reason||"Rozłączono.");return;}
  },
  startPing:function(){
    var self=this;clearInterval(this.pingTimer);
    this.pingTimer=setInterval(function(){
      if(self.ws&&self.ws.readyState===1)self.ws.send(JSON.stringify({op:"ping",t:performance.now()}));
    },2500);
  },
  fanSeat:function(){
    if(this.ws&&this.ws.readyState===1&&this.active&&this.mode==="fan")
      this.ws.send(JSON.stringify({op:"fanseat",fan:{sector:this.num("lanSector",0,7),row:this.num("lanRow",1,14),seat:this.num("lanSeatNo",1,40)}}));
  },
  startLobbyTimer:function(){
    var self=this;clearInterval(this.lobbyTimer);
    this.lobbyTimer=setInterval(function(){
      if(self.wsOk||self.active||self.el("ovLan").classList.contains("hide"))return;
      self.refresh(self.el("lanRooms").value).catch(function(){});
    },4000);
  },
  _lobby:function(rooms){
    /* serwer wypchnął świeżą listę meczów — nie potrzebujemy timera HTTP */
    if(this.active)return;
    if(!this.info||!this.info.rooms)return;
    this.info.rooms=rooms;
    if(!this.el("ovLan").classList.contains("hide"))this.renderRooms();
  },
  options:function(id,items,value){
    var sel=this.el(id),prev=value===undefined?sel.value:String(value);
    sel.replaceChildren();items.forEach(function(item){var o=document.createElement("option");o.value=item[0];o.textContent=item[1];o.disabled=!!item[2];sel.add(o);});
    var choice=items.find(function(i){return String(i[0])===prev && !i[2];})||items.find(function(i){return !i[2];});
    if(choice)sel.value=choice[0];
  },
  config:function(){
    var c={};["nationH","nationA","home","away","stripH","stripA","stadium","weather","half","diff","ballStyle","night","lang","formH","formA","tacticH","tacticA","ref"].forEach(function(k){c[k]=SET[k];});return c;
  },
  init:function(){
    var self=this;try{this.token=localStorage.getItem("sp98.lan.session")||"";}catch(e){}
    function button(id,fn){self.el(id).onclick=async function(){try{await fn();}catch(e){self.msg(e.message);}};}
    button("btnLan",()=>self.open());button("lanBack",()=>{self.el("ovLan").classList.add("hide");self.el("ovMenu").classList.remove("hide");});
    ["Login","Register"].forEach(k=>button("lan"+k,async()=>{
      var p=await self.api(k.toLowerCase(),{nick:self.el("lanNick").value,password:self.el("lanPassword").value,admin:self.el("lanKey").value});
      self.token=p.token;try{localStorage.setItem("sp98.lan.session",p.token);}catch(e){}
      self.el("lanPassword").value=self.el("lanKey").value="";await self.refresh();self.msg("Zalogowano jako "+p.nick);self.sayNick(p.nick);
    }));
    button("lanLogout",async()=>{await self.api("logout",{});self.token="";try{localStorage.removeItem("sp98.lan.session");}catch(e){}await self.refresh();});
    button("lanRefresh",()=>self.refresh());self.el("lanRooms").onchange=()=>self.pick();
    button("lanNewClan",async()=>{await self.api("clan",{name:self.el("lanClanName").value});await self.refresh();self.msg("Utworzono klan.");});
    button("lanJoin",async()=>{await self.api("join-clan",{clan:+self.el("lanJoinId").value});self.msg("Dołączono do klanu.");});
    button("lanNewRoom",async()=>{var r=await self.api("room",{name:self.el("lanRoomName").value,config:self.config(),h:+self.el("lanHomeClan").value,a:+self.el("lanAwayClan").value});await self.refresh(r.id);self.msg("Mecz gotowy do rozpoczęcia.");});
    button("lanNewCup",async()=>{var ids=Array.from(self.el("lanCupClans").selectedOptions,o=>+o.value);var ret=await self.api("cup",{name:self.el("lanCupName").value,scope:self.el("lanScope").value,clans:ids,config:self.config()});await self.refresh();self.el("lanHistoryCup").value=ret.id;await self.history(false);self.msg("Utworzono terminarz turnieju.");});
    button("lanStart",async()=>{var r=self.picked();await self.api("start",{room:r.id});await self.refresh(r.id);self.msg("Mecz rozpoczęty.");});
    button("lanReady",()=>self.toggleReady());
    button("lanPlay",()=>self.enter("play"));button("lanWatch",()=>self.enter("fan"));button("lanDirect",()=>self.enter("director"));
    button("lanHistory",()=>self.history(false));button("lanMatchStats",()=>self.history(true));button("lanExit",()=>self.exit());
    button("lanPause",()=>self.api("pause",{room:self.room.id,value:!self.last?.paused}));
    button("lanManageSubs",()=>{self.el("lanSubTools").hidden=!self.el("lanSubTools").hidden;self.subOptions();});
    self.el("lanSubOut").onchange=()=>self.subOptions();button("lanSubSend",async()=>{var i=+self.el("lanSubOut").value;await self.api("sub",{room:self.room.id,team:Math.floor(i/11),idx:i%11,num:+self.el("lanSubIn").value});self.el("lanSubTools").hidden=true;self.msg("Zgłoszono zmianę na najbliższą przerwę.");});
    this.el("lanView").onchange=()=>self.view(self.el("lanView").value);
    var chatForm=this.el("lanChatForm");
    if(chatForm)chatForm.addEventListener("submit",function(e){e.preventDefault();self.sendChat();});
    ["lanGroup","lanTrack","lanCols"].forEach(id=>self.el(id).onchange=()=>{self.layoutKey="";});
    this.options("lanSector",["Południe","Południowy wschód","Wschód","Północny wschód","Północ","Północny zachód","Zachód","Południowy zachód"].map((n,i)=>[i,n]));
    ["lanSector","lanRow","lanSeatNo","lanFollow"].forEach(id=>self.el(id).onchange=()=>{self.turn=self.tilt=0;self.fixed=null;self.fanSeat();});
    var canvas=this.el("c");canvas.addEventListener("pointerdown",function(e){
      if(self.active && self.mode==="fan"){self.drag=[e.clientX,e.clientY];canvas.setPointerCapture(e.pointerId);}
    });
    canvas.addEventListener("pointermove",function(e){if(self.drag){self.turn-=(e.clientX-self.drag[0])*.006;self.tilt=Math.min(1.2,Math.max(-1.2,self.tilt+(e.clientY-self.drag[1])*.004));self.drag=[e.clientX,e.clientY];}});
    canvas.addEventListener("lostpointercapture",()=>{self.drag=null;});canvas.addEventListener("pointerup",()=>{self.drag=null;});
  },
  open:async function(){
    this.el("ovMenu").classList.add("hide");this.el("ovLan").classList.remove("hide");this.el("lanOnline").hidden=true;
    if(location.protocol==="file:"){this.msg("Tryb LAN uruchom z pełnych źródeł: python3 serve.py --port 8906. Otwórz adres gospodarza w przeglądarce.");return;}
    this.msg("Łączenie z serwerem…");
    /* lista meczów na żywo (poz. 15): najpierw WebSocket, w razie braku odpytywanie HTTP */
    clearInterval(this.lobbyTimer);
    var self=this;
    this.connect().then(function(ws){if(!ws)self.startLobbyTimer();});
    await this.refresh();
  },
  refresh:async function(selectRoom){
    this.info=await this.api("info");this.profile=this.info.profile;
    this.renderRooms();
    if(!this.info.rooms.length)this.msg("Brak meczów. Organizator może utworzyć pierwszy mecz.");
    else if(!this.profile)this.msg("Jesteś gościem — możesz tylko oglądać. Zaloguj się, żeby grać.");
    else this.msg("Wybierz mecz i pozycję, potem Zagraj. Na trybuny można wejść bez loginu.");
  },
  renderRooms:function(){
    var selectRoom=this.el("lanRooms").value;
    this.el("lanOnline").hidden=false;this.el("lanOrganize").hidden=!this.profile;
    this.el("lanWho").textContent=this.profile?" · "+this.profile.nick+" · Mecze: "+(this.profile.played||0):" · gość";this.el("lanAccount").open=!this.profile;
    this.el("lanLogout").hidden=!this.profile;this.el("lanLogin").hidden=this.el("lanRegister").hidden=!!this.profile;
    this.options("lanRooms",this.info.rooms.map(r=>{
      var taken=Object.keys(r.seats||{}).length,free=22-taken;
      var st={ready:"przed meczem",live:"w grze",done:"zakończony"}[r.status]||r.status;
      var fans=r.fans?" · widzowie: "+r.fans:"";
      return [r.id,r.name+"  ·  "+st+"  ·  "+r.score.join("–")+"  ·  wolne: "+free+fans];
    }),selectRoom);
    var clans=this.info.clans.map(c=>[c.id,c.name]);this.options("lanJoinId",clans);this.options("lanCupClans",clans);
    ["lanHomeClan","lanAwayClan","lanHistoryClan"].forEach(id=>this.options(id,[[0,id==="lanHistoryClan"?"Wszystkie klany":"Otwarta drużyna"]].concat(clans)));
    this.options("lanHistoryCup",[[0,"Wszystkie turnieje"]].concat(this.info.cups.map(c=>[c.id,c.name+" · "+(c.scope==="world"?"światowy":"klasowy")])));
    this.pick();
  },
  picked:function(){return this.info.rooms.find(r=>r.id===+this.el("lanRooms").value);},
  canManage:function(r){return !!(r && this.profile && (this.profile.admin||this.profile.id===r.owner));},
  pick:function(){
    var r=this.picked(),manage=this.canManage(r),ready=r?.status==="ready",done=r?.status==="done",live=r?.status==="live";
    this.el("lanStart").disabled=!manage||!ready;this.el("lanPlay").disabled=!this.profile||!r||done;
    this.el("lanDirect").disabled=!manage;this.el("lanWatch").disabled=!r;
    var info=(r&&r.seatInfo)||{},items=[];
    if(r)[0,1].forEach(team=>{
      var code=r.config[team?"nationA":"nationH"],roster=TEAMS.data[code]?.players;
      for(var j=0;j<11;j++){
        var i=11*team+j,n=roster?roster[j]:{num:LINEUP.numbers[j],name:LINEUP.names[team][j]};
        var s=info[i]||info[String(i)],nick=s?s.nick:(r.seats[i]||r.seats[String(i)]);
        var mark=s&&s.ready?" ✓":"";
        items.push([i,r.config[team?"away":"home"]+"  #"+n.num+" "+TEAMS.label(n)+(nick?" · "+nick+mark:""),!!nick && nick!==this.profile?.nick]);
      }
    });this.options("lanSlot",items);
    var readyBtn=this.el("lanReady"),readyInfo=this.el("lanReadyInfo");
    if(readyBtn){
      var mySlot=r&&this.profile?Object.keys(info).find(k=>info[k].nick===this.profile.nick):null;
      var myReady=mySlot!=null&&info[mySlot]&&info[mySlot].ready;
      readyBtn.disabled=!this.profile||!r||done||live;readyBtn.textContent=myReady?"Niegotowy":"Gotowy";
      this._myReady=!!myReady;
      if(readyInfo){
        var taken=Object.keys(info),rdy=taken.filter(k=>info[k].ready).length;
        readyInfo.textContent=r?(taken.length?"Gotowi: "+rdy+"/"+taken.length:"Brak zajętych pozycji"):"";
      }
    }
    if(r && !this.profile)this.msg("Zaloguj się, żeby zająć pozycję. Jako gość możesz tylko Wejdź na trybuny.");
    else if(r && ready && !manage)this.msg("Mecz czeka na start organizatora. Zajmij pozycję i oznacz Gotowy.");
    else if(r && live)this.msg("Mecz w toku — wybierz wolną pozycję i Zagraj, albo Wejdź na trybuny.");
    else if(r && done)this.msg("Mecz zakończony. Możesz obejrzeć wynik w historii.");
  },
  toggleReady:async function(){
    var r=this.picked();if(!r||!this.profile)return;
    /* najpierw upewnij się, że mamy miejsce — seat przy zajętej pozycji */
    var slot=+this.el("lanSlot").value;
    if(!(slot>=0)){this.msg("Wybierz pozycję.");return;}
    try{
      await this.api("seat",{room:r.id,slot:slot});
      var ret=await this.api("ready",{room:r.id,value:!this._myReady});
      await this.refresh(r.id);
      this.msg(ret.ready?"Jesteś gotowy.":"Cofnięto gotowość.");
    }catch(e){this.msg(e.message);}
  },
  sendChat:async function(){
    if(!this.active||!this.room)return;
    var input=this.el("lanChatInput"),body=(input.value||"").trim();if(!body)return;
    /* czat przez WebSocket (poz. 6); odpowiedź wraca rozsiewaniem do pokoju */
    if(this.wsOk&&this.ws&&this.ws.readyState===1){
      if(this.profile){this.ws.send(JSON.stringify({op:"chat",body:body,scope:"room"}));input.value="";return;}
      this.msg("Zaloguj się, żeby pisać na czacie.");return;
    }
    if(!this.profile)return;
    input.value="";
    try{
      var m=await this.api("chat",{room:this.room.id,body:body,scope:"room"});
      this._appendChat(m);
    }catch(e){this.msg(e.message);}
  },
  _appendChat:function(m){
    var log=this.el("lanChatLog");if(!log||!m)return;
    if(m.id && this.chatId>=m.id)return;
    if(m.id)this.chatId=m.id;
    var row=document.createElement("div");
    row.innerHTML="<b></b> <span></span>";
    row.querySelector("b").textContent=m.nick||"?";
    row.querySelector("span").textContent=m.body||"";
    log.appendChild(row);log.scrollTop=log.scrollHeight;
    while(log.children.length>40)log.removeChild(log.firstChild);
  },
  pollChat:async function(g){
    while(this.active&&g===this.generation){
      try{
        var data=await this.api("chat?room="+this.room.id+"&after="+(this.chatId||0));
        (data.messages||[]).forEach(m=>this._appendChat(m));
      }catch(e){}
      await new Promise(r=>setTimeout(r,1800));
    }
  },
  showPause:function(on,s){
    var ov=this.el("lanPauseOv");if(!ov)return;
    if(!on){ov.hidden=true;ov.classList.add("hide");return;}
    ov.hidden=false;ov.classList.remove("hide");
    var score=this.el("lanPauseScore"),stats=this.el("lanPauseStats");
    if(score&&s)score.textContent=(SET.home||"Gosp.")+"  "+(s.score||[0,0]).join(" – ")+"  "+(SET.away||"Goście");
    if(stats&&s&&s.stats){
      var a=s.stats[0]||{},b=s.stats[1]||{};
      stats.textContent="Strzały "+(a.shots||0)+"–"+(b.shots||0)+" · Podania "+(a.pass||0)+"–"+(b.pass||0)+" · Faule "+(a.fouls||0)+"–"+(b.fouls||0);
    }
  },
  history:async function(single){
    var params=new URLSearchParams();if(single){if(!this.picked())return;params.set("room",this.picked().id);}else{
      params.set("clan",this.el("lanHistoryClan").value||0);params.set("cup",this.el("lanHistoryCup").value||0);}
    var data=await this.api("history?"+params),box=this.el("lanRecords");box.replaceChildren();
    function table(head,rows){var tab=document.createElement("table");[head].concat(rows).forEach((row,i)=>{var tr=tab.insertRow();row.forEach(value=>{var td=document.createElement(i?"td":"th");td.textContent=value;tr.appendChild(td);});});box.appendChild(tab);}
    if(data.champions?.length){var title=document.createElement("strong");title.textContent="Zwycięzca turnieju · "+data.champions.map(id=>this.info.clans.find(c=>c.id===id)?.name||"—").join(", ");box.appendChild(title);}
    if(data.table.length)table(["Klan","M","Punkty","Bramki"],data.table.map(a=>[this.info.clans.find(c=>c.id===a.clan)?.name||"—",a.played,a.points,a.gf+"–"+a.ga]));
    table(["Mecz","Wynik","Stan"],data.matches.map(m=>[m.name,m.score.join(" – "),{ready:"Zaplanowany",live:"W toku",done:"Zakończony"}[m.status]]));
    if(!single && data.matches.length){var results=box.lastElementChild;
      Array.from(results.rows).slice(1).forEach((row,i)=>{var m=data.matches[i],a=document.createElement("button"),cell=document.createElement("td");
        a.textContent="Wybierz mecz";a.onclick=()=>{this.el("lanRooms").value=m.id;this.pick();this.msg(m.name);this.el("lanRooms").focus();};cell.appendChild(a);row.appendChild(cell);});
    }
    if(data.summary){var c=data.summary;table(["Mecze","Wygrane","Remisy","Porażki","Bramki","Punkty"],[[c.played,c.wins,c.draws,c.losses,c.gf+"–"+c.ga,c.points]]);}
    if(single && data.matches[0]?.record.stats){var rec=data.matches[0].record,stats=rec.stats;
      table(["Statystyka","Gospodarze","Goście"],Object.entries({shots:"Strzały",onT:"Celne",attempt:"Próby podań",pass:"Udane podania",corr:"Rożne",fouls:"Faule",yel:"Żółte kartki",red:"Czerwone kartki"}).map(([k,v])=>[v,stats[0][k],stats[1][k]]));
      table(["Minuta","Akcja","Uczestnik / wynik"],(rec.events||[]).map(e=>[e.minute,({goal:"Gol",booking:"Kartka",penalty:"Karny",substitution:"Zmiana",fulltime:"Koniec",halftime:"Przerwa"})[e.state]||e.state,e.detail||e.score.join(" – ")]));
      var people=(rec.players||[]).concat((rec.departed||[]).flat().map(p=>[p.name,p.goals,p.yellows]));
      table(["Zawodnik","Gole","Żółte kartki"],people);
    }
  },
  enter:async function(mode){
    var r=this.picked();
    if(!r){this.msg("Najpierw wybierz mecz z listy.");return;}
    if(mode==="play" && !this.profile){this.msg("Zaloguj się, żeby grać. Jako gość możesz tylko oglądać.");return;}
    if(r.status==="done" && mode==="play"){this.msg("Ten mecz już się zakończył.");return;}
    var slot=mode==="play"?+this.el("lanSlot").value:-1;
    if(mode==="play" && !(slot>=0)){this.msg("Wybierz wolną pozycję na liście.");return;}
    if(slot>=0)await this.api("seat",{room:r.id,slot:slot});
    AUDIO.init();AUDIO.resume();VOICE.stopMusic();VOICE.stopSpeech();this.backup=Object.assign({},SET);
    this.room=r;this.slot=slot;this.active=true;this.previous=this.last=this.fixed=null;this.rev=-1;this.eventId=0;this.generation++;
    this.buf=[];this.clockOff=0;this.clockSamples=0;this.chatId=0;
    this.fanLook={x:0,y:1,z:0};this.fanLookV={x:0,y:0,z:0};this.fanPitchT=0;
    this.edges={};this.inputBusy=false;this.sentAt=-9999;this.passAt=this.shotAt=null;this.turn=this.tilt=0;this.layoutKey="";this.hudKey="";this.namesKey="";
    var log=this.el("lanChatLog");if(log)log.replaceChildren();
    this.showPause(false);
    this._watchKey="";this._watchers([],0);
    var lang=SET.lang;Object.assign(SET,r.config);SET.lang=lang;SET.cam=4;SET.mode=slot<0?2:slot<11?0:1;
    TEAMS.apply();WORLD.setNight(!!SET.night);CONDITIONS.venue();CONDITIONS.ball();PITCH.reset();SIM.resetMatch();MATCHDAY.reset();
    BROADCAST.clear();RULES.state="kickoff";RULES.half=1;RULES.elapsed=0;CAM._last=null;MAIN.state="match";MAIN.paused=false;
    HUD.hideEnd();HUD.hideEvent();HUD.hint("");HUD.refreshTeams();this.el("ovLan").classList.add("hide");this.el("hud").classList.add("show");this.el("lanBar").hidden=false;
    var manage=this.canManage(r);this.el("lanPause").hidden=this.el("lanManageSubs").hidden=!manage;
    this.el("lanSubTools").hidden=true;this.options("lanView",(slot>=0?[["play","Mecz"]]:[]).concat([["fan","Trybuny"]],manage?[["director","Reżyserka"]]:[]),mode);
    this.view(mode);this.msg(r.status==="ready"?"Czekasz na rozpoczęcie meczu.":r.name);
    /* transport: WebSocket, a przy braku — odpytywanie HTTP (poz. 6) */
    var self=this,g=this.generation;
    this.connect().then(function(ok){
      if(g!==self.generation)return;
      if(ok){self.hello();self.startPing();if(self.mode==="fan")self.fanSeat();}
      else{self.poll(g);self.pollChat(g);}
    });
    if(r.status==="ready" && manage){try{await this.api("start",{room:r.id});}catch(e){this.msg(e.message);}}
  },
  exit:async function(){
    var room=this.room,slot=this.slot;this.active=false;this.generation++;this.room=null;this.slot=-1;this.drag=null;
    clearInterval(this.pingTimer);
    clearTimeout(this.nickTimer);if(this.nickAudio){this.nickAudio.pause();this.nickAudio=null;}
    if(this.atlas){this.atlas.dispose();this.atlas=null;}
    this.hideGuests();
    this.showPause(false);
    this.el("lanBar").hidden=this.el("lanTiles").hidden=true;document.body.classList.remove("lanGrid");if(WORLD.cup)WORLD.cup.visible=false;
    Object.assign(SET,this.backup);TEAMS.apply();CONDITIONS.venue();CONDITIONS.ball();WORLD.setNight(!!SET.night);
    MAIN.toMenu();DESK.refresh();if(slot>=0)try{await this.api("leave",{room:room.id});}catch(e){}
    /* kanał Wraca do subskrypcji lobby */
    if(this.ws&&this.ws.readyState===1&&this.wsOk)this.hello();
    await this.open();
  },
  view:function(mode){
    if(mode!=="director" && this.atlas){this.atlas.dispose();this.atlas=null;}
    this.mode=mode;this.el("lanView").value=mode;this.el("lanFanTools").hidden=mode!=="fan";this.el("lanDirectorTools").hidden=mode!=="director";
    this.el("lanTiles").hidden=mode!=="director";document.body.classList.toggle("lanGrid",mode==="director");
    this.layoutKey="";this.fixed=null;this.lastGrid=-1000;this.drag=null;
    this.fanLookV={x:0,y:0,z:0};this.fanPitchT=0;
    if(mode==="fan")this.fanSeat();
    if(this.last){var b=this.last.ball;this.fanLook={x:b[0],y:b[1]+.4,z:b[2]};}
  },
  /* ---------- widzowie na trybunach (poz. 7) ---------- */
  _watchers:function(list,fans){
    var key=(fans||0)+"|"+JSON.stringify(list||[]);
    if(key===this._watchKey)return;
    this._watchKey=key;this.watchers=list||[];this.fans=fans||0;
    this.renderWatchers();
    if(this.last)this.msg(this.statusLine(this.last));
  },
  statusLine:function(s){
    var who=s.paused?"Pauza":s.state==="fulltime"?"Koniec meczu":this.slot>=0?(s.seats[this.slot]||this.profile.nick)+" #"+s.players[this.slot][8]:"Widz";
    return this.room.name+" · "+who+" · "+Object.keys(s.seats).length+"/22 · widzowie: "+(this.fans||0);
  },
  renderWatchers:function(){
    var list=this.watchers||[],el=this.el("lanWatchList");
    if(el){
      var names=list.map(function(w){return w.nick||"gość";});
      el.textContent=list.length?("Na trybunach ("+list.length+"): "+names.slice(0,14).join(", ")+(names.length>14?" i inni":"")):"";
    }
    /* awatary widzów na własnych miejscach (maks. 48, własny nie zasłania widoku) */
    if(!WORLD.scene||!STADIUM.sides||!STADIUM.sides.length)return;
    var self=this,items=[],jewels=[];
    list.forEach(function(w){
      if(self.mode==="fan" && self.profile && w.nick===self.profile.nick)return;
      var side=STADIUM.sides[Math.max(0,Math.min(7,w.sector|0))],row=STADIUM.row(Math.max(0,Math.min(13,(w.row|0)-1)));
      if(!side||!row)return;
      var t=Math.max(.012,Math.min(.988,((w.seat|0)-.5)/40));
      var p=side.at(t,row.d+.45,row.y+.018);
      var seed=7,nick=w.nick||"";
      for(var i=0;i<nick.length;i++)seed=(seed*31+nick.charCodeAt(i))%360;
      items.push({p:p,yaw:side.yaw,tint:new THREE.Color(.93,.93,.93)});
      jewels.push({p:p,y:row.y+1.74,col:new THREE.Color().setHSL(seed/360,.62,.55)});
    });
    if(!items.length){this.hideGuests();return;}
    this._guestEnsure();
    var m=new THREE.Matrix4(),q=new THREE.Quaternion(),up=new THREE.Vector3(0,1,0),one=new THREE.Vector3(.92,.92,.92),pos=new THREE.Vector3();
    for(var j=0;j<items.length;j++){
      var it=items[j];pos.set(it.p[0],it.p[1],it.p[2]);q.setFromAxisAngle(up,it.yaw);
      m.compose(pos,q,one);this.guests.setMatrixAt(j,m);this.guests.setColorAt(j,it.tint);
      pos.set(it.p[0],jewels[j].y,it.p[2]);q.setFromAxisAngle(up,it.yaw*0);m.compose(pos,q,one);
      this.guestJewels.setMatrixAt(j,m);this.guestJewels.setColorAt(j,jewels[j].col);
    }
    this.guests.count=items.length;this.guests.instanceMatrix.needsUpdate=true;
    if(this.guests.instanceColor)this.guests.instanceColor.needsUpdate=true;
    this.guestJewels.count=items.length;this.guestJewels.instanceMatrix.needsUpdate=true;
    if(this.guestJewels.instanceColor)this.guestJewels.instanceColor.needsUpdate=true;
    this.guests.visible=this.guestJewels.visible=this.active;
  },
  _guestEnsure:function(){
    if(this.guests)return;
    var geo=SUPPORTERS.person(0,3,"seat",true),faces=SUPPORTERS.faceAtlas();
    var mat=SUPPORTERS.material(0,faces);mat.side=THREE.FrontSide;
    this.guests=new THREE.InstancedMesh(geo,mat,48);
    this.guests.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    this.guests.frustumCulled=false;this.guests.count=0;
    this.guestJewels=new THREE.InstancedMesh(new THREE.OctahedronGeometry(.12),new THREE.MeshBasicMaterial({color:0xffffff}),48);
    this.guestJewels.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    this.guestJewels.frustumCulled=false;this.guestJewels.count=0;
    WORLD.scene.add(this.guests,this.guestJewels);
  },
  hideGuests:function(){
    if(this.guests){this.guests.count=0;this.guests.visible=false;this.guests.instanceMatrix.needsUpdate=true;}
    if(this.guestJewels){this.guestJewels.count=0;this.guestJewels.visible=false;this.guestJewels.instanceMatrix.needsUpdate=true;}
    var el=this.el("lanWatchList");if(el)el.textContent="";
  },
  poll:async function(g){
    while(this.active && g===this.generation){
      try{
        var data=await this.api("state?room="+this.room.id+"&after="+this.rev);if(!this.active||g!==this.generation)return;
        if(data.revision!==this.rev){this.rev=data.revision;this.accept(data);}
        if(data.paused||data.state==="fulltime")await new Promise(r=>setTimeout(r,250));
      }catch(e){if(g!==this.generation)return;this.msg(e.message);await new Promise(r=>setTimeout(r,700));}
    }
  },
  accept:function(s){
    if(s.revision!==undefined)this.rev=s.revision;   /* WS i HTTP z jednoźnaczną rewizją (poz. 6) */
    this.previous=this.last && this.last.state===s.state && s.t-this.last.t<.35?this.last:s;this.last=s;this.arrived=performance.now();
    /* synchronizacja zegara serwer→klient (EMA) i bufor migawek */
    var localT=this.arrived/1000, off=s.t-localT;
    if(this.clockSamples<1){this.clockOff=off;this.clockSamples=1;}
    else{this.clockOff+=(off-this.clockOff)*.12;this.clockSamples++;}
    s._local=localT;
    this.buf.push(s);
    while(this.buf.length>24)this.buf.shift();
    while(this.buf.length>2 && this.buf[1].t < (localT+this.clockOff)-.45)this.buf.shift();
    RULES.state=s.state;RULES.stateT=s.stateT;RULES.elapsed=s.clock;RULES.half=s.half;RULES.restartTeam=s.team;RULES.taker=SIM.players[s.taker];MATCHDAY.added=s.added;
    CEREMONY.stage=s.ce;CEREMONY.winner=s.winner;SIM.teams.forEach((t,i)=>{t.score=s.score[i];t.stats=s.stats[i];t.dir=i?-s.dir:s.dir;t.bench=s.bench[i];t.changes=s.changes[i];t.user=null;});
    s.players.forEach((v,i)=>{var p=SIM.players[i];if(p.num!==v[8] || p.name!==v[9] || p.role!==v[14]){if(p.mesh)WORLD.removePlayer(p.mesh);p.mesh=WORLD.makePlayer(p.team,v[14]==="GK",v[8],null,null,v[9]);}
      Object.assign(p,{num:v[8],name:v[9],stamina:v[10],off:!!v[11],goals:v[12],yellows:v[13],role:v[14],fullName:v[15],trapLeg:v[16],dribbleFoot:v[16],trapHeight:v[17],isUser:i===this.slot?p.team:null,diveSide:v[18]||1,turn:v[19]||0});
    });if(this.slot>=0){var local=SIM.players[this.slot];SIM.teams[local.team].user=local;}
    var b=SIM.ball;b.owner=SIM.players[s.ball[6]]||null;b.receiver=SIM.players[s.ball[7]]||null;b.lastTouchTeam=s.ball[8];b.vx=s.ball[3];b.vy=s.ball[4];b.vz=s.ball[5];
    var scoreKey=s.score.join()+"|"+s.players.map(p=>p[11]+":"+p[13]).join();if(this.scoreKey!==scoreKey){this.scoreKey=scoreKey;HUD.setScore();}
    var old=BROADCAST.scene,hero=SIM.players[s.hero];
    if(hero && (s.state==="booking" || s.state==="goal")){
      if(!old || old.type!==s.state || old.hero!==hero){
        BROADCAST.clear();BROADCAST.scene={type:s.state,hero:hero,actors:s.actors.map(i=>SIM.players[i]),extra:null};
        if(s.state==="booking" && hero.off)BROADCAST.scene.extra=WORLD.makePlayer(hero.team,hero.role==="GK",hero.num,WORLD.gFx,null,hero.name);
      }
      Object.assign(BROADCAST.scene,{ref:s.ref,stage:s.card,stageTime:s.cardTime||0,second:s.second,forward:s.forward || {x:SIM.dirX(hero.team),z:0}});
      if(s.state==="booking"){WORLD.staff.card.visible=true;WORLD.staff.card.material.color.setHex(s.card==="red"?0xf02b28:0xffdf23);
        var extra=BROADCAST.scene.extra;if(extra){var v=s.players[s.hero];extra.position.set(v[0],0,v[1]);extra.rotation.y=v[2];}}
    }else if(old){BROADCAST.clear();this.hudKey="";}
    MATCHDAY.adv=s.adv;RULES.freeIndirect=s.indirect;
    WORLD.aimArrow.visible=this.mode==="play" && this.slot===s.taker && ["corner","freekick","penalty","goalkick"].includes(s.state);
    if(WORLD.aimArrow.visible){WORLD.aimArrow.position.set(s.ball[0],.04,s.ball[2]);WORLD.aimArrow.rotation.y=s.aim;}
    var hk=JSON.stringify(s.hud);if(this.hudKey!==hk){this.hudKey=hk;if(s.hud){var h=s.hud;HUD.event(h.type,h.title,h.min,h.name,h.team,h.reason);}else HUD.hideEvent();}
    if(s.tag)HUD.restartTagShow(s.tag);else HUD.restartTagHide();HUD.showPower(s.power||null);
    var nk=s.players.map((p,i)=>p[8]+"/"+(s.seats[i]||"")).join();if(nk!==this.namesKey){this.namesKey=nk;this.options("lanTrack",s.players.map((p,i)=>[i,(i<11?SET.home:SET.away)+" #"+p[8]+" "+p[9]]));this.layoutKey="";}
    if(s.watchers)this._watchers(s.watchers,s.fans);
    this.msg(this.statusLine(s));
    this.showPause(!!s.paused,s);
    (s.events||[]).forEach(e=>{if(e.id<=this.eventId)return;this.eventId=e.id;if(s.t-e.t>4 && !(e.type==="anthem" && ["opening","closing"].includes(s.state)))return;
      if(e.type==="voice")VOICE.speak(e.data.keys,e.data.urgent);
      if(e.type==="anthem")VOICE.anthem(e.data);
      if(e.type==="musicStop")VOICE.stopMusic();
      if(e.type==="banner")HUD.banner(e.data.title,e.data.detail,2);
      if(e.type==="event" && e.data.type==="goal"){
        WORLD.crowdPulse=1;AUDIO.roar(1.0);AUDIO.horn();var nick=s.seats[s.hero];if(nick && SET.snd && typeof Audio!=="undefined"){
          clearTimeout(this.nickTimer);this.nickTimer=setTimeout(()=>{if(this.active)this.sayNick(nick);},2200);}
      }
    });
  },
  subOptions:function(){
    if(!this.last)return;var s=this.last;
    this.options("lanSubOut",s.players.flatMap((p,i)=>p[11]?[]:[[i,(i<11?SET.home:SET.away)+" #"+p[8]+" "+p[9]]]));
    var i=+this.el("lanSubOut").value;this.options("lanSubIn",s.bench[Math.floor(i/11)].filter(r=>(r.role==="GK")===(s.players[i][14]==="GK")).map(r=>[r.num,"#"+r.num+" "+r.name]));
    this.el("lanSubSend").disabled=!this.el("lanSubIn").options.length;
  },
  input:function(now){
    if(this.slot<0)return;var d=INPUT.slots[0],map={pass:"passP",shot:"shootP",cross:"tackleP",through:"throughP",skip:"camP"};
    for(var k in map)if(d[map[k]])this.edges[k+"Edge"]=true;
    /* czasy przytrzymania mierzone u klienta: siła podania/strzału nie zależy od jittera sieci */
    if(d.passP)this.passAt=now;
    if(d.shootP)this.shotAt=now;
    if(d.passR && this.passAt!=null){this.edges.passUp=true;this.edges.passHold=Math.min(1.6,Math.max(.02,(now-this.passAt)/1000));this.passAt=null;}
    if(d.shootR){this.edges.shotUp=true;if(this.shotAt!=null)this.edges.shotHold=Math.min(1.6,Math.max(.02,(now-this.shotAt)/1000));this.shotAt=null;}
    var overWs=this.wsOk&&this.ws&&this.ws.readyState===1;
    /* WebSocket: do 30 Hz wejść (poz. 6); HTTP: 15 Hz z blokadą na odpowiedź */
    if(this.inputBusy||now-this.sentAt<(overWs?33:65))return;
    var g=this.generation,field=CAM.fieldInput(d.mx,d.mz),payload=Object.assign({seq:++this.seq,x:field.x*d.moveLen,z:field.z*d.moveLen,mx:d.mx,mz:d.mz,pass:d.pass,shot:d.shoot,cross:d.tackle,through:d.through,close:d.jockey,sprint:d.sprint,skip:d.camL,finesse:d.finesse,combo:d.switchL},this.edges);
    this.edges={};this.sentAt=now;
    if(overWs){this.ws.send(JSON.stringify({op:"input",input:payload}));return;}
    this.inputBusy=true;
    this.api("input",{room:this.room.id,input:payload}).catch(e=>{if(this.generation===g)this.msg(e.message);}).finally(()=>{if(this.generation===g)this.inputBusy=false;});
  },
  /* wybór pary migawek dla czasu renderu (serwerowy) */
  _pair:function(rt){
    var buf=this.buf;if(!buf.length)return null;
    if(buf.length===1||rt<=buf[0].t)return {a:buf[0],b:buf[0],k:0};
    for(var i=0;i<buf.length-1;i++){
      if(rt<=buf[i+1].t){
        var span=buf[i+1].t-buf[i].t;return {a:buf[i],b:buf[i+1],k:span>1e-4?Math.max(0,Math.min(1,(rt-buf[i].t)/span)):1};
      }
    }
    /* krótka ekstrapolacja po ostatniej migawce (max ~80 ms) */
    var a=buf[buf.length-2],b=buf[buf.length-1],span=Math.max(1e-3,b.t-a.t);
    var k=1+Math.min(.08,rt-b.t)/span;return {a:a,b:b,k:k};
  },
  frame:function(dt,now){
    this.input(now);var s=this.last;if(!s)return;
    var localT=now/1000, rt=s.paused?s.t:(localT+this.clockOff)-this.bufDelay;
    var pair=this._pair(rt), a=pair?pair.a:this.previous, b=pair?pair.b:s, alpha=pair?pair.k:1;
    if(s.paused){a=b=s;alpha=1;}
    function lerp(x,y){return x+(y-x)*alpha;}
    /* Hermite dla piłki z prędkością z migawek */
    function hermite(p0,v0,p1,v1,t,dtSpan){
      if(dtSpan<1e-4||t<=0)return p0;if(t>=1)return p1;
      var t2=t*t,t3=t2*t,h00=2*t3-3*t2+1,h10=t3-2*t2+t,h01=-2*t3+3*t2,h11=t3-t2;
      return h00*p0+h10*(v0*dtSpan)+h01*p1+h11*(v1*dtSpan);
    }
    var dtSpan=Math.max(1e-3,b.t-a.t);
    for(var i=0;i<s.players.length;i++){
      var u=a.players[i],v=b.players[i],p=SIM.players[i];
      p.pos.x=lerp(u[0],v[0]);p.pos.z=lerp(u[1],v[1]);
      p.face=u[2]+SIM._angDelta(u[2],v[2])*alpha;
      p.vel.x=v[3];p.vel.z=v[4];
      p.stridePhase=u[5]+(((v[5]-u[5]+1.5)%1)-.5)*alpha;
      p.action=v[6];p.actionT=u[6]===v[6]?lerp(u[7],v[7]):v[7];
    }
    var ball=SIM.ball,ab=a.ball,bb=b.ball;
    ball.x=hermite(ab[0],ab[3],bb[0],bb[3],alpha,dtSpan);
    ball.y=hermite(ab[1],ab[4],bb[1],bb[4],alpha,dtSpan);
    ball.z=hermite(ab[2],ab[5],bb[2],bb[5],alpha,dtSpan);
    ball.vx=lerp(ab[3],bb[3]);ball.vy=lerp(ab[4],bb[4]);ball.vz=lerp(ab[5],bb[5]);
    SIM.syncMeshes(s.paused?0:dt);
    if(WORLD.cup){var cap=s.state==="closing"?SIM.players.find(p=>p.action==="liftcup"):null;WORLD.cup.visible=!!cap;if(cap)WORLD.cup.position.set(cap.pos.x,1.25+.76*FACE.smooth(0,1.15,cap.actionT),cap.pos.z+.32);}

    WORLD.tick(dt);WORLD.tickStaff(dt,s.state);HUD.update(dt);MAIN.markers();
    if(this.mode==="director"){if(now-this.lastGrid>42){this.lastGrid=now;this.grid();}}
    else{
      if(this.mode==="fan")this.fan(dt);else{
        if(INPUT.wheelAcc)CAM.zoomBy(INPUT.wheelAcc*.0011);
        CAM.update(dt,s.state);
      }
      WORLD.renderer.render(WORLD.scene,WORLD.cam);
    }
    INPUT.wheelAcc=0;
  },
  /* kamera trybun: sprężyna celu + ograniczenie skoków pitch (poz. 37) */
  fan:function(dt){
    dt=Math.min(.05,dt||.016);
    var side=STADIUM.sides[this.num("lanSector",0,7)],row=STADIUM.row(this.num("lanRow",1,14)-1);
    var seat=side.at((this.num("lanSeatNo",1,40)-.5)/40,row.d-.13,row.y+1.68),eye=WORLD.cam.position;eye.set(...seat);
    var b=SIM.ball,want=this.el("lanFollow").checked?{x:b.x,y:b.y+.4,z:b.z}:(this.fixed||(this.fixed={x:b.x,y:b.y+.4,z:b.z}));
    /* sprężyna 2. rzędu na punkt celowania — tłumi skoki piłki i jitter sieci */
    var stiffness=18,damping=2*Math.sqrt(stiffness)*1.1,fl=this.fanLook,fv=this.fanLookV;
    var ax=(want.x-fl.x)*stiffness-fv.x*damping;
    var ay=(want.y-fl.y)*stiffness-fv.y*damping;
    var az=(want.z-fl.z)*stiffness-fv.z*damping;
    fv.x+=ax*dt;fv.y+=ay*dt;fv.z+=az*dt;
    fl.x+=fv.x*dt;fl.y+=fv.y*dt;fl.z+=fv.z*dt;
    var dx=fl.x-eye.x,dy=fl.y-eye.y,dz=fl.z-eye.z;
    var yaw=Math.atan2(dx,dz)+this.turn;
    var rawPitch=Math.atan2(dy,Math.hypot(dx,dz))+this.tilt;
    /* ograniczenie zmian pochylenia (max ~1.2 rad/s) */
    var maxDp=1.2*dt;
    this.fanPitchT+=(Math.max(-maxDp,Math.min(maxDp,rawPitch-this.fanPitchT)));
    var pitch=Math.min(1.35,Math.max(-1.25,this.fanPitchT));
    this.fanFov=Math.max(16,Math.min(82,this.fanFov+INPUT.wheelAcc*.029));
    var cam=WORLD.cam;cam.fov=this.fanFov;cam.updateProjectionMatrix();
    cam.lookAt(eye.x+Math.sin(yaw)*Math.cos(pitch),eye.y+Math.sin(pitch),eye.z+Math.cos(yaw)*Math.cos(pitch));
  },
  playerCamera:function(cam,i,aspect){
    var p=SIM.players[i],b=SIM.ball,dir=SIM.dirX(p.team),dx=b.x-p.pos.x,dz=b.z-p.pos.z;
    var length=Math.hypot(dx,dz),x=length>2?dx/length:Math.sin(p.face),z=length>2?dz/length:Math.cos(p.face);
    cam.aspect=aspect;cam.fov=aspect<.85?73:57;cam.updateProjectionMatrix();
    cam.position.set(p.pos.x-x*6+z*1.0,3.2,p.pos.z-z*6-x*1.0);cam.lookAt(p.pos.x+x*5,1.0,p.pos.z+z*5);
  },
  grid:function(){
    var group=this.el("lanGroup").value,order=this.monitorOrder||(this.monitorOrder=SIM.players.map((p,i)=>i));
    var indices=group==="one"?[+this.el("lanTrack").value]:order.filter(i=>group==="both"||Math.floor(i/11)===(group==="home"?0:1));
    var cols=Math.min(indices.length,this.num("lanCols",1,22)),rows=Math.ceil(indices.length/cols),r=WORLD.renderer,box=this.el("lanTiles");
    var id=indices.join()+"|"+cols+"|"+this.namesKey,layoutChanged=this.layoutKey!==id;
    if(layoutChanged){
      box.replaceChildren();box.style.gridTemplateColumns="repeat("+cols+",minmax(0,1fr))";box.style.gridTemplateRows="repeat("+rows+",minmax(0,1fr))";
      indices.forEach(i=>{var p=SIM.players[i],label=document.createElement("span");label.textContent="#"+p.num+" "+(this.last.seats[i]||p.name);
        label.draggable=true;label.title="Przeciągnij na inne okno, aby zamienić miejsca. Dwuklik otwiera zawodnika.";
        label.ondragstart=ev=>ev.dataTransfer.setData("text/plain",String(i));label.ondragover=ev=>ev.preventDefault();
        label.ondrop=ev=>{ev.preventDefault();var from=order.indexOf(Number(ev.dataTransfer.getData("text/plain"))),to=order.indexOf(i);
          if(from>=0 && to>=0){[order[from],order[to]]=[order[to],order[from]];this.layoutKey="";}};
        label.ondblclick=()=>{this.el("lanTrack").value=i;this.el("lanGroup").value="one";this.layoutKey="";};
        box.appendChild(label);});
      this.layoutKey=id;this.tileCursor=0;
    }
    var cam=this.monitorCam||(this.monitorCam=new THREE.PerspectiveCamera(55,1,.15,350)),size=r.getSize(this.screenSize||(this.screenSize=new THREE.Vector2()));
    var scale=Math.min(1,1500/size.x,950/size.y),w=Math.max(1,Math.round(size.x*scale)),h=Math.max(1,Math.round(size.y*scale));
    if(!this.atlas || this.atlas.width!==w || this.atlas.height!==h){
      if(this.atlas)this.atlas.dispose();
      this.atlas=new THREE.WebGLRenderTarget(w,h,{minFilter:THREE.LinearFilter,magFilter:THREE.LinearFilter,generateMipmaps:false});
      this.atlas.texture.encoding=r.outputEncoding;layoutChanged=true;
    }
    if(!this.screenScene){
      this.screenScene=new THREE.Scene();this.screenCam=new THREE.OrthographicCamera(-1,1,1,-1,0,2);this.screenCam.position.z=1;
      this.screenMaterial=new THREE.MeshBasicMaterial({map:this.atlas.texture,depthTest:false,depthWrite:false,toneMapped:false});
      this.screenScene.add(new THREE.Mesh(new THREE.PlaneGeometry(2,2),this.screenMaterial));
    }
    this.screenMaterial.map=this.atlas.texture;
    var atlas=this.atlas,auto=r.shadowMap.autoUpdate;r.shadowMap.autoUpdate=false;
    try{
      if(layoutChanged){atlas.scissorTest=false;atlas.viewport.set(0,0,w,h);r.setRenderTarget(atlas);r.clear();}
      atlas.scissorTest=true;
      var batch=Math.min(indices.length,SET.q===0?3:5);
      for(var j=0;j<batch;j++){
        var n=this.tileCursor++%indices.length,i=indices[n],col=n%cols,row=Math.floor(n/cols);
        var x=Math.floor(col*w/cols),y=Math.floor((rows-row-1)*h/rows);
        var sw=Math.floor((col+1)*w/cols)-x,sh=Math.floor((rows-row)*h/rows)-y;
        this.playerCamera(cam,i,sw/sh);atlas.viewport.set(x,y,sw,sh);atlas.scissor.copy(atlas.viewport);r.setRenderTarget(atlas);r.render(WORLD.scene,cam);
      }
    }finally{r.setRenderTarget(null);r.setScissorTest(false);r.setViewport(0,0,size.x,size.y);r.shadowMap.autoUpdate=auto;}
    r.render(this.screenScene,this.screenCam);
  }
};
