var VOICE={
  bank:/*AUDIOBANK*/null, clips:{}, generation:0, nextCall:0,
  speak:function(keys,urgent){
    if(!this.bank || !AUDIO.ctx || !SET.snd)return;
    var ctx=AUDIO.ctx,lang=SET.lang,self=this,generation=this.generation;
    if(!urgent && ctx.currentTime<this.nextCall)return;
    if(urgent)this.stopSpeech();
    generation=this.generation;this.nextCall=ctx.currentTime+(urgent?2.8:5.0);
    var selected=keys.map(function(k){return self.bank.index[lang][k];}).filter(Boolean);
    if(!selected.length)return;
    if(!this.clips[lang])this.clips[lang]=fetch(this.bank[lang]).then(function(r){return r.arrayBuffer();}).then(function(b){return ctx.decodeAudioData(b);}).catch(function(){delete self.clips[lang];return null;});
    this.clips[lang].then(function(buffer){
      if(!buffer || generation!==self.generation)return;
      var at=ctx.currentTime+.025;
      selected.forEach(function(span){
        var src=ctx.createBufferSource(),gain=ctx.createGain();gain.gain.value=.80;
        src.buffer=buffer;src.connect(gain);gain.connect(AUDIO.master);src.start(at,span[0],span[1]);
        (self.active||(self.active=[])).push(src);src.onended=function(){self.active=self.active.filter(function(s){return s!==src;});gain.disconnect();};
        at+=span[1]+.08;
      });
    });
  },
  stopSpeech:function(){this.generation++;(this.active||[]).forEach(function(s){try{s.stop();}catch(e){}});this.active=[];},
  anthem:function(team){
    this.stopMusic();if(!this.bank || typeof Audio==="undefined" || !SET.snd)return;
    var code=SET[team?"nationA":"nationH"];var url=this.bank[code]||this.bank.club;
    var song=new Audio(url);song.volume=Math.min(1,SET.snd*.86);this.music=song;song.play().catch(function(){});
  },
  stopMusic:function(){if(this.music){this.music.pause();this.music=null;}}
};
