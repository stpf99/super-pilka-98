/* ============================================================
   SUPER PIŁKA '98 · 06-human.js — wspólny moduł sterowania zawodnikiem
   Jedna implementacja dla gry lokalnej (MAIN.humanControl) i dla silnika
   LAN (lan/engine.cjs), więc gracz sieciowy ma dokładnie te same akcje co
   lokalny: podanie o sile zależnej od przytrzymania, strzał z ładowaniem,
   strzał techniczny, „podaj i wyjdź", prostopadłe i dośrodkowanie, wślizg,
   odbiór na stojąco, pressing i pierwszy kontakt.
   Pozycje z listy przebudowy: 1 (wspólny moduł), 2 (pełne akcje w LAN),
   3 (rdzeń dla trybu lokalnego), 4 (przełączanie przy 1–2 ludziach).
   Stan ładowania podania, strzału i combo jest trzymany NA ZAWODNIKU
   (st z HUMAN.newState), a nie per drużyna — dwóch ludzi w jednej drużynie
   nie psuje sobie ładowania.
   ============================================================ */
var HUMAN = {
  /* czasy pełnego naładowania podania i strzału [s] */
  PASS_TIME: .65, SHOT_TIME: .78,

  /* Stan ładowania jednego gracza. W grze lokalnej trzymany na zawodniku
     (p.ctl), w LAN tak samo — dzięki temu przetrwa zapis/odczyt stanu meczu. */
  newState: function(){ return { chargeP:0, chargeS:0, combo:false, finesse:false }; },
  clear: function(p){
    if(p && p.ctl){ p.ctl.chargeP = p.ctl.chargeS = 0; p.ctl.combo = p.ctl.finesse = false; }
  },

  /* ---------- wybór sterowanego zawodnika (drużyny z 1–2 ludźmi) ---------- */
  nearest: function(team, taken, exclGK){
    var b = SIM.ball, best = null, bd = 1e9, ps = SIM.players;
    for(var i=0;i<ps.length;i++){
      var p = ps[i];
      if(p.off || p.team!==team || (exclGK && p.role==="GK") || (taken && taken(p))) continue;
      var d = (p.pos.x-b.x)*(p.pos.x-b.x)+(p.pos.z-b.z)*(p.pos.z-b.z);
      if(d < bd){ bd = d; best = p; }
    }
    return best;
  },
  /* cur: aktualnie sterowany; team: obiekt drużyny (switchCd); taken(p): zajęty przez innego człowieka */
  select: function(team, cur, inp, taken, dt){
    var b = SIM.ball, id = team.id;
    team.switchCd = Math.max(0, (team.switchCd||0) - dt);
    var forced = b.owner && b.owner.team===id && !(taken && taken(b.owner)) ? b.owner
      : (!b.owner && b.receiver && b.receiver.team===id && !(taken && taken(b.receiver)) ? b.receiver : null);
    var near = this.nearest(id, taken, true);
    if(forced && !forced.off && forced!==cur){ team.switchCd = .3; return forced; }
    if(!cur || cur.off) return near || cur;
    if(!forced && team.switchCd===0 && near && near!==cur){
      var gap = Math.hypot(cur.pos.x-b.x, cur.pos.z-b.z) - Math.hypot(near.pos.x-b.x, near.pos.z-b.z);
      if(gap > 8){ team.switchCd = .35; return near; }
    }
    if(inp.switchP && !forced && team.switchCd<=0){
      var cand = SIM.teamPlayers(id).filter(function(p){ return p!==cur && p.role!=="GK" && !(taken && taken(p)); });
      cand.sort(function(a,c){ return Math.hypot(a.pos.x-b.x,a.pos.z-b.z) - Math.hypot(c.pos.x-b.x,c.pos.z-b.z); });
      if(cand.length){ team.switchCd = .8; return cand[0]; }
    }
    return cur;
  },

  /* ---------- sterowanie jednym zawodnikiem ---------- */
  /* s     – numer drużyny;  user – zawodnik;  st – stan z newState (per zawodnik)
     inp   – wejście w formacie INPUT.slots[]: mx, mz, moveLen, pass, shoot, passP, shootP,
             throughP, tackleP, jockey, sprint, finesse, switchL
     field – kierunek ruchu w układzie boiska {x,z} (lokalnie z CAM.fieldInput,
             w sieci przeliczony już u klienta)
     opts  – { handoff:function(mate) } – przejęcie kontroli przez adresata podania
             (tylko gra lokalna; w LAN każdy człowiek ma stałego zawodnika).
     Zwraca poziom ładowania 0..1 do paska siły albo null. */
  drive: function(s, user, inp, field, st, dt, opts){
    var r = this._drive(s, user, inp, field, st, dt, opts);
    user.hP = st.chargeP; user.hS = st.chargeS;   /* animacje „zamach"/„podanie" czytają ładowanie per zawodnik */
    return r;
  },
  _drive: function(s, user, inp, field, st, dt, opts){
    var b = SIM.ball, handoff = opts && opts.handoff;
    user.closeControl = !!inp.jockey;
    var dx = inp.moveLen > .15 ? field.x : Math.sin(user.face),
        dz = inp.moveLen > .15 ? field.z : Math.cos(user.face);
    user.moveTarget = inp.moveLen > .15
      ? { x:user.pos.x + dx*5, z:user.pos.z + dz*5, amount:inp.moveLen, sprint:inp.sprint && !inp.jockey }
      : null;
    if(user.action === "fallen" || user.action === "slide" || user.action === "dive"){
      st.chargeP = st.chargeS = 0; return null;
    }
    if(b.owner !== user){
      if(!b.owner && (inp.passP || inp.shootP) && Math.hypot(b.x - user.pos.x, b.z - user.pos.z) < 12){
        FIRST_TOUCH.intent(user, inp.shootP ? "shoot" : "pass", dx, dz); return null;
      }
      st.chargeP = st.chargeS = 0; st.combo = st.finesse = false;
      if(!b.owner && b.receiver === user && !user.moveTarget) user.moveTarget = AI.receiveTarget(user);
      /* pressing: trzymanie podania, gdy piłkę ma rywal */
      if(b.owner && b.owner.team !== s && inp.pass && !inp.moveLen)
        user.moveTarget = { x:b.x + b.owner.vel.x*.10, z:b.z + b.owner.vel.z*.10, sprint:!inp.jockey };
      /* bramkarz człowiek chwyta piłkę we własnym polu karnym */
      if(user.role === "GK" && !b.owner && Math.abs(user.pos.x + SIM.dirX(s)*HL) < 16.5 && Math.abs(user.pos.z) < 20
         && Math.hypot(user.pos.x - b.x, user.pos.z - b.z) < 1.3 && b.y < 2.5){
        SIM.takeBall(user); user.keeperHold = true; return null;
      }
      if(inp.tackleP) SIM.startSlide(user);
      else if(inp.shootP) SIM.standingTackle(user);
      return null;
    }
    if(b.release) return null;
    if(inp.pass){
      st.chargeP = Math.min(1, st.chargeP + dt/this.PASS_TIME);
      st.combo = st.combo || !!inp.switchL;
    } else if(st.chargeP > 0){
      var passing = Math.max(.16, st.chargeP), mate = SIM.pickPassTarget(s, dx, dz, false, user);
      SIM.deliver(user, mate, "pass", passing, dx, dz);
      if(st.combo && mate) user.runT = 2.7;
      st.chargeP = st.chargeS = 0; st.combo = false;
      if(handoff && mate && !b.release) handoff(mate);
      return null;
    }
    if(inp.throughP || inp.tackleP){
      var cross = inp.tackleP, target = SIM.pickPassTarget(s, dx, dz, true, user);
      if(cross){
        var goalX = SIM.dirX(s)*(HL - 10),
            mates = SIM.teamPlayers(s).filter(function(p){ return p !== user && p.role !== "GK"; });
        mates.sort(function(a, c){ return Math.hypot(a.pos.x-goalX, a.pos.z*.84) - Math.hypot(c.pos.x-goalX, c.pos.z*.84); });
        target = mates[0] || target;
      }
      SIM.deliver(user, target, cross ? "cross" : "through", .73, dx, dz);
      if(handoff && target && !b.release) handoff(target);
      st.chargeP = st.chargeS = 0; st.combo = false; return null;
    }
    if(inp.shoot){
      st.chargeS = Math.min(1, st.chargeS + dt/this.SHOT_TIME);
      st.finesse = st.finesse || !!inp.finesse;
    } else if(st.chargeS > 0){
      var dir = SIM.dirX(s), finesse = st.finesse || !!inp.finesse, pw = Math.max(.23, st.chargeS);
      var targetZ = inp.moveLen > .15 ? dz*3.50 : -Math.sign(user.pos.z || 1)*(finesse ? 2.65 : 1.25);
      var gx = dir*HL - b.x, gz = targetZ - b.z, curve = 0;
      if(finesse){
        curve = -(Math.sign(user.pos.z) || dir)*dir*(4 + pw*1.5);
        var travel = Math.min(1.35, Math.hypot(gx, gz)/(17 + 11*pw));
        gz -= dir*curve*travel*travel*.5;
      }
      SIM.shoot(user, gx, gz, pw, finesse ? "finesse" : "shot", curve);
      st.chargeS = st.chargeP = 0; st.finesse = false;
    }
    return Math.max(st.chargeP, st.chargeS);
  },

  /* Zamiana wejścia sieciowego (rekord serwera: poziomy, zbocza, czasy przytrzymania)
     na format INPUT.slots[]. Krótkie kliknięcie, które mieści się w jednym pakiecie
     (wciśnięcie i puszczenie bez stanu „wciśnięty"), też daje podanie/strzał,
     a siła bierze się z czasu przytrzymania zmierzonego u klienta, nie z jittera sieci. */
  fromNet: function(d, st){
    var len = Math.min(1, Math.hypot(d.x || 0, d.z || 0));
    var inp = { mx:d.mx || 0, mz:d.mz || 0, moveLen:len, jockey:!!d.close, sprint:!!d.sprint,
      finesse:!!d.finesse, switchL:!!d.combo,
      pass:!!d.pass, passP:!!d.passEdge, shoot:!!d.shot, shootP:!!d.shotEdge,
      throughP:!!d.throughEdge, tackleP:!!d.crossEdge };
    if(!inp.pass && d.passUp){
      st.chargeP = Math.max(1e-4, d.passHold != null ? Math.min(1, d.passHold/this.PASS_TIME) : st.chargeP);
      if(d.combo) st.combo = true;
    }
    if(!inp.shoot && d.shotUp){
      st.chargeS = Math.max(1e-4, d.shotHold != null ? Math.min(1, d.shotHold/this.SHOT_TIME) : st.chargeS);
      if(d.finesse) st.finesse = true;
    }
    return inp;
  }
};
