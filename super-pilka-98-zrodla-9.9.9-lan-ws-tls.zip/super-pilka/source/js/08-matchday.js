var MATCHDAY={
  reset:function(){
    this.adv=null;this.cards=[];this.hand=null;this.lastArm=null;this.armLock=0;this.queued=[[],[]];this.resetHalf();
  },
  resetHalf:function(){this.lost=0;this.added=null;this.extraLoss=0;this.started=false;this.penaltyFlight=false;this.window=0;},
  minute:function(){
    var end=45*RULES.half,minute=Math.floor(RULES.elapsed/SET.half*45)+1;
    return minute>45?end+"+"+(minute-45)+"′":((RULES.half-1)*45+minute)+"′";
  },
  clock:function(dt){
    var s=RULES.state;
    if(!this.started || ["opening","halftime","closing","fulltime","menu","replay"].includes(s))return;
    RULES.elapsed+=dt;
    var lost=s==="booking" || s==="goal" || s==="substitution" || (["freekick","penalty","throwin","corner","goalkick","kickoff"].includes(s) && RULES.stateT>1.2);
    if(lost){if(this.added===null)this.lost+=dt;else this.extraLoss+=dt;}
    RULES.displayMin=(RULES.half-1)*45+Math.floor(RULES.elapsed*45/SET.half);
    if(RULES.elapsed>=SET.half && this.added===null){
      this.added=Math.ceil(Math.max(0,this.lost-.02)*45/SET.half);
      if(this.added){HUD.banner("+"+this.added+"′",t("added"),2.1);VOICE.speak(["added"],false);}
    }
  },
  expired:function(){
    return this.added!==null && RULES.elapsed+.00001>=SET.half+this.added*SET.half/45+this.extraLoss;
  },
  advantageFor:function(record){
    var b=SIM.ball,team=record.spot.team,owner=b.owner,receiver=b.receiver,dir=SIM.dirX(team);
    if(record.deadBall || this.adv || record.spot.penalty || record.verdict.card==="red" || (record.verdict.card && record.tk.yellows))return false;
    if(owner && owner.team===team && owner!==record.victim && (owner.pos.x-record.spot.x)*dir>-1)return true;
    if(!owner && b.lastTouchTeam===team && b.vx*dir>1 && (b.shotTeam===team || receiver && receiver!==record.victim && receiver.team===team))return true;
    return owner===record.victim && owner.action!=="fallen" && Math.hypot(owner.vel.x,owner.vel.z)>2.6 &&
      owner.vel.x*dir>1.4 && Math.hypot(b.x-record.tk.pos.x,b.z-record.tk.pos.z)>1.0;
  },
  decide:function(record){
    if(this.adv && this.adv.spot.team!==record.spot.team){this.recall();return;}
    if(this.adv)this.realise();
    if(this.advantageFor(record)){
      this.adv=record;record.age=0;VOICE.speak(["advantage"],true);HUD.banner(t("advantage"),RULES.teamName(record.spot.team),1.65);
      HUD.commentary(t("advantage"));return;
    }
    this.stop(record);
  },
  realise:function(){
    var r=this.adv;if(!r)return;
    if(r.verdict.card && r.verdict.reason!=="promising")this.cards.push(r);
    this.adv=null;
  },
  recall:function(){var r=this.adv;if(!r)return;this.adv=null;this.stop(r);},
  advance:function(dt){
    var a=this.adv;if(!a)return false;var b=SIM.ball,team=a.spot.team;
    a.age+=dt;
    var overGoal=b.x*SIM.dirX(team)>HL+SIM.BR && Math.abs(b.z)<GOAL_W/2 && b.y<GOAL_H;
    if(overGoal || b.shotTeam===team || b.owner?.team===team && (b.x-a.spot.x)*SIM.dirX(team)>3.4){this.realise();return false;}
    if((b.owner && b.owner.team!==team) || (!b.owner && b.lastTouchTeam!==team) || Math.abs(b.x)>HL+SIM.BR || Math.abs(b.z)>HW+SIM.BR || a.age>2.6 && b.owner?.team!==team){
      this.recall();return true;
    }
    if(a.age>2.6)this.realise();
    return false;
  },
  stop:function(r){
    var spot=r.spot;VOICE.speak(r.verdict.reason==="handball"?["handball",spot.penalty?"penalty":"free"]:[spot.penalty?"penalty":"free"],true);
    AUDIO.whistle(2);AUDIO.fanWhistle(1);
    if(r.verdict.card){
      var kind=RULES.giveCard(r.tk,r.verdict.card);
      RULES.state="booking";RULES.stateT=0;AI.frozen=true;BROADCAST.booking(r.tk,r.victim,kind,spot,r.detail);
    }else{
      if(spot.penalty)RULES.setupPenalty(spot.team);else RULES.setupFree(spot.team,spot.x,spot.z);
      HUD.banner(t(spot.penalty?"rst_pen":"rst_free"),r.detail,2);
    }
    HUD.commentary(r.tk.name+" · "+r.detail);
  },
  stopped:function(){
    var state=RULES.state;
    if(!["kickoff","goalkick","corner","throwin","freekick","penalty"].includes(state) || RULES.runUp)return false;
    if(this.cards.length && this.pendingCard({state:state,team:RULES.restartTeam,x:RULES.restartPos.x,z:RULES.restartPos.z,indirect:RULES.freeIndirect}))return true;
    if(this.queued.some(function(q){return q.length;})){
      var changes=this.commit();if(changes.length){
        this.resumeState=state;this.resumeTime=RULES.stateT;RULES.state="substitution";RULES.stateT=0;
        HUD.event("substitution",t("subs"),this.minute(),changes.join("   ·   "),t("freshPlayers"));return true;
      }
    }
    return false;
  },
  pendingCard:function(resume){
    while(this.cards.length){
      var r=this.cards.shift();if(r.tk.off)continue;
      var card=RULES.giveCard(r.tk,r.verdict.card);RULES.state="booking";RULES.stateT=0;
      BROADCAST.booking(r.tk,r.victim,card,{team:resume.team,resume:resume},r.detail);return true;
    }
    return false;
  },
  restoreRestart:function(s){
    if(s.state==="endHalf"){RULES.endHalf();return;}
    if(s.state==="kickoff")RULES.setupKickoff(s.team,false);
    if(s.state==="throwin")RULES.setupThrow(s.team,s.x,s.z);
    if(s.state==="corner"){SIM.teams[s.team].stats.corr--;RULES.setupCorner(s.team,Math.sign(s.x),Math.sign(s.z));}
    if(s.state==="goalkick")RULES.setupGoalkick(s.team,Math.sign(s.x));
    if(s.state==="freekick")RULES.setupFree(s.team,s.x,s.z,s.indirect);
    if(s.state==="penalty")RULES.setupPenalty(s.team);
  },
  queue:function(team,idx,num){
    var tm=SIM.teams[team],q=this.queued[team],p=SIM.players[team*11+idx],r=tm?.bench.find(function(m){return m.num===num;});
    if(!r || !p || p.team!==team || p.off || (p.role==="GK")!==(r.role==="GK") || tm.changes+q.length>=5 || q.some(function(c){return c.idx===idx||c.num===num;}))return false;
    q.push({idx:idx,num:num});return true;
  },
  commit:function(){
    var done=[];
    for(var team=0;team<2;team++){
      var tm=SIM.teams[team],queue=this.queued[team].splice(0);
      for(var change of queue){
        var p=SIM.players[team*11+change.idx],j=tm.bench.findIndex(function(r){return r.num===change.num;});
        if(j<0 || p.off || tm.changes>=5)continue;
        var r=tm.bench.splice(j,1)[0];tm.departed.push({name:p.name,num:p.num,goals:p.goals,yellows:p.yellows});
        this.lastIn=r.name;done.push(p.name+" → "+TEAMS.label(r));WORLD.removePlayer(p.mesh);
        Object.assign(p,{name:TEAMS.label(r),fullName:r.name,num:r.num,goals:0,yellows:0,foulCount:0,foulLoad:0,lastFoulMinute:0,
          pace:p.role==="GK"?6.3:7.15+(r.num%7)*.11,stamina:1,action:"run",actionT:0,challenge:null,keeperHold:false,dribbleAnim:0});
        p.mesh=WORLD.makePlayer(team,p.role==="GK",r.num,null,null,p.name);tm.changes++;
      }
    }
    if(done.length){REC.reset();VOICE.speak(["subs",this.lastIn],true);}return done;
  },
  coach:function(){
    for(var t=0;t<2;t++){
      var team=SIM.teams[t];if(RULES.humanTaker(t)||team.changes>=5||this.queued[t].length)continue;
      var p=SIM.teamPlayers(t).filter(function(q){return q.role!=="GK";}).sort(function(a,b){return a.stamina-b.stamina;})[0];
      if(!p || RULES.displayMin<48+team.changes*7 || p.stamina>.88 && RULES.displayMin<62+team.changes*7)continue;
      var r=team.bench.find(function(m){return m.role===p.role;})||team.bench.find(function(m){return m.role!=="GK";});
      if(r)this.queue(t,p.idx,r.num);
    }
  },
  armContact:function(dt){
    var b=SIM.ball;this.armLock=Math.max(0,this.armLock-dt);
    if(b.owner || this.armLock || b.y<.32 || b.y>2.05 || b.flight==="throw" && b.flightAge<.18)return false;
    var bx=b.x-b.prevX,by=b.y-b.prevY,bz=b.z-b.prevZ;
    for(var p of SIM.players){
      if(p.off || p===b.lastKicker && b.lock>0 || Math.hypot(p.pos.x-b.x,p.pos.z-b.z)>1.45)continue;
      var ownBox=-SIM.dirX(p.team)*p.pos.x>=HL-16.5 && Math.abs(p.pos.z)<=20.16;
      if(p.role==="GK" && ownBox)continue;
      var stretched=p.action==="armblock" || p.action==="standtackle" || p.action==="jockey" || p.action==="dive" || p.closeControl;
      var intentional=p.action==="armblock",running=Math.min(1,Math.hypot(p.vel.x,p.vel.z)/8);
      for(var sign of [-1,1]){
        var lateral=sign*(stretched?.45:.25),y=(p.action==="slide"?.45:stretched?1.20:1.11)*p.mesh.scale.y;
        var forward=stretched?.19:.09+.14*running*Math.sin((p.stridePhase+(sign>0?.5:0))*Math.PI*2);
        var x=p.pos.x+Math.cos(p.face)*lateral+Math.sin(p.face)*forward,z=p.pos.z-Math.sin(p.face)*lateral+Math.cos(p.face)*forward;
        var k=Math.max(0,Math.min(1,((x-b.prevX)*bx+(y-b.prevY)*by+(z-b.prevZ)*bz)/(bx*bx+by*by+bz*bz||1)));
        if(Math.hypot(b.prevX+k*bx-x,b.prevY+k*by-y,b.prevZ+k*bz-z)>SIM.BR+.069)continue;
        this.armLock=.32;this.lastArm={p:p,time:RULES.elapsed,direct:true};
        if(stretched && (intentional || p.action!=="slide")){
          var victim=SIM.nearestToBall(1-p.team,false);if(!victim)return false;
          RULES.foul(p,victim,{kind:"handball",severity:"careless",attempt:false,x:x,z:z,deliberate:intentional});
          return RULES.state!=="play";
        }
        b.vx*=.72;b.vy*=.66;b.vz+=sign*.65;b.lastTouchTeam=p.team;b.lastKicker=p;
        SIM.events.push({type:"touch",player:p});return false;
      }
    }
    return false;
  }
};
