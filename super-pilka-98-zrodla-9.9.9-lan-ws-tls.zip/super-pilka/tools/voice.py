"""Offline speech and sung phrases. Stdlib fallback uses voiced formants and consonant noise."""
import array
import io
import math
import random
import re
import shutil
import subprocess
import unicodedata
import wave

RATE=16000
FORM={'a':(730,1120,2570),'e':(520,1770,2470),'i':(300,2150,2980),'o':(490,900,2410),'u':(300,760,2240),'y':(375,1650,2340),'@':(460,1450,2400),'m':(255,970,1970),'n':(285,1490,2160),'l':(340,1260,2560),'r':(410,1390,2100),'w':(310,690,2080),'j':(276,2090,2980)}
PL={'dź':'Dj','dzi':'Dji','dż':'D','dzw':'dzv','cz':'C','sz':'S','rz':'Z','ch':'h','dz':'dz','ci':'cji','si':'sji','zi':'zji','ni':'nji','ie':'je','ia':'ja','io':'jo','iu':'ju','ą':'on','ę':'en','ć':'cj','ś':'sj','ź':'zj','ń':'nj','ż':'Z','ł':'w','ó':'u','w':'v','c':'ts','q':'k','x':'ks','v':'v'}
EN={'tion':'Sen','ough':'o','igh':'aj','ee':'i','ea':'i','oo':'u','ow':'au','oi':'oj','ai':'ej','ay':'ej','ou':'au','th':'f','sh':'S','ch':'C','ph':'f','wh':'w','ck':'k','ng':'n','qu':'kw','c':'k','x':'ks','y':'i','j':'D'}
NOISE={'s':.48,'S':.53,'z':.25,'Z':.34,'f':.35,'v':.21,'h':.27,'C':.42,'D':.32,'t':.52,'d':.31,'p':.43,'b':.26,'k':.53,'g':.29,'c':.35}
def phones(text,lang):
    digits=('zero jeden dwa trzy cztery pięć sześć siedem osiem dziewięć' if lang=='pl' else 'zero one two three four five six seven eight nine').split()
    text=re.sub(r'[0-9]',lambda m:' '+digits[int(m.group())]+' ',text).replace('_',' ').replace('@',' at ' if lang=='en' else ' małpa ')
    table=PL if lang=='pl' else EN
    out=[]
    for word in re.findall(r"[^\W_]+|[ ,.!?–-]",text.lower(),re.UNICODE):
        while word:
            for n in (3,2,1):
                key=word[:n]
                if len(key)==n and key in table:
                    out.extend(table[key]);word=word[n:];break
            else:
                ch=word[0];letter=unicodedata.normalize('NFKD',ch)[0]
                out.append(letter if letter.isalpha() else ' ');word=word[1:]
    return out
def sound(text,lang='pl',pitch=None,duration=None):
    units=phones(text,lang) or [' '];out=array.array('h');rng=random.Random(42);phase=0;prev=0
    times=[.118 if u in 'aeiouy@' else .075 if u in FORM else .075 if u==' ' else .059 for u in units]
    if duration:
        vowels=sum(d for u,d in zip(units,times) if u in 'aeiouy@')
        if vowels:times=[d*(1+max(0,duration-sum(times))/vowels) if u in 'aeiouy@' else d for u,d in zip(units,times)]
        ratio=duration/sum(times);times=[d*ratio for d in times]
    for pos,(u,dur) in enumerate(zip(units,times)):
        n=max(2,round(RATE*dur));vowel=u in FORM
        form=FORM.get(u,FORM['@'])
        hz=pitch or (126+12*math.sin(pos*1.47)-15*pos/len(units))
        harmonics=[]
        if vowel:
            for k in range(1,min(47,int(6500/hz))):
                f=k*hz
                gain=(.12/(1+k*.24)+sum(w*math.exp(-.5*((f-c)/bw)**2) for c,bw,w in zip(form,(82,115,175),(1,.64,.29))))/(1+.085*k)
                harmonics.append((k,gain))
            period=max(12,round(RATE/hz));buf=[sum(g*math.sin(2*math.pi*k*j/period) for k,g in harmonics) for j in range(period)]
            norm=1/max(1,max(abs(x) for x in buf))
        for j in range(n):
            env=min(1,j/(RATE*.008),(n-j)/(RATE*.009));noise=rng.uniform(-1,1)
            if vowel:
                val=buf[(phase+j)%period]*norm*(.57 if u in 'mnrlwj' else .86)
                if u=='r':val*=.62+.38*math.sin(j*.012)
            elif u in NOISE:
                val=(noise-prev*.73)*NOISE[u]
                if u in 'tdpbkg':val*=min(1,j/(n*.17))*math.exp(-j/(n*.22))
                if u in 'zbvZDdg':val+=.14*math.sin(2*math.pi*hz*j/RATE)
            else:val=0
            out.append(int(max(-1,min(1,val*env)) * 25500));prev=noise
        phase+=n
    return out
def wav(pcm,rate=RATE):
    target=io.BytesIO()
    with wave.open(target,'wb') as w:w.setparams((1,2,rate,0,'NONE','not compressed'));w.writeframes(pcm.tobytes())
    return target.getvalue()
def speech(text,lang):
    engine=shutil.which('espeak-ng') or shutil.which('espeak')
    if engine:
        p=subprocess.run([engine,'--stdout','-v','pl' if lang=='pl' else 'en-gb','-s','155','--',text],capture_output=True)
        if p.returncode==0 and len(p.stdout)>1000:return p.stdout
    return wav(sound(text,lang))

if __name__=='__main__':
    import argparse
    from pathlib import Path
    cli=argparse.ArgumentParser(description='Lokalna synteza nazwiska lub pseudonimu do WAV')
    cli.add_argument('text');cli.add_argument('--lang',choices=['pl','en'],default='pl')
    cli.add_argument('-o','--output',type=Path,required=True)
    args=cli.parse_args();args.output.write_bytes(speech(args.text,args.lang))
