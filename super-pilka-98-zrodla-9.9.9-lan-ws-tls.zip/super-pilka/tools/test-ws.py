#!/usr/bin/env python3
"""Test serwera LAN po WebSocket (poz. 6) i widzów (poz. 7).

Sprawdza: uścisk WS, welcome, migawki ~20 Hz, wejścia gracza, czat,
miejsce widza (fanseat) i listę widzów, lobby push, fallback HTTP
oraz tryb TLS (--tls auto → https/wss)."""
import base64
import hashlib
import json
import os
import secrets
import socket
import ssl
import struct
import subprocess
import sys
import tempfile
import threading
import time
import urllib.request
from pathlib import Path

ROOT=Path(__file__).resolve().parent.parent
PORT=8931
TLSPORT=8932
GUID='258EAFA5-E914-47DA-95CA-C5AB0DC85B11'
fails=[]

def ok(name,cond,detail=""):
    print(("OK   " if cond else "FAIL ")+name+((" — "+str(detail)) if detail and not cond else ""))
    if not cond:fails.append(name)

class WS:
    def __init__(self,port,token=None,room=0,mode="fan",fan=None,use_tls=False,timeout=8):
        self.raw=socket.create_connection(("127.0.0.1",port),timeout=timeout)
        if use_tls:
            ctx=ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT);ctx.check_hostname=False;ctx.verify_mode=ssl.CERT_NONE
            self.raw=ctx.wrap_socket(self.raw,server_hostname="localhost")
        key=base64.b64encode(secrets.token_bytes(16)).decode()
        req=(f"GET /ws HTTP/1.1\r\nHost: 127.0.0.1:{port}\r\nUpgrade: websocket\r\n"
             f"Connection: Upgrade\r\nSec-WebSocket-Key: {key}\r\nSec-WebSocket-Version: 13\r\n\r\n")
        self.raw.sendall(req.encode())
        self.buf=b""
        status=self._http_head()
        assert "101" in status.split("\r\n")[0],status
        hello={"op":"hello","room":room,"mode":mode}
        if token:hello["token"]=token
        if fan:hello["fan"]=fan
        self.send(hello)
    def _http_head(self):
        while b"\r\n\r\n" not in self.buf:self.buf+=self.raw.recv(4096)
        head,self.buf=self.buf.split(b"\r\n\r\n",1)
        return head.decode()
    def send(self,obj):
        data=json.dumps(obj).encode();mask=os.urandom(4)
        h=bytearray([0x81]);n=len(data)
        if n<126:h.append(0x80|n)
        elif n<65536:h.append(0x80|126);h+=struct.pack("!H",n)
        else:h.append(0x80|127);h+=struct.pack("!Q",n)
        masked=bytes(b^mask[i%4] for i,b in enumerate(data))
        self.raw.sendall(bytes(h)+mask+masked)
    def _need(self,n):
        while len(self.buf)<n:
            chunk=self.raw.recv(4096)
            if not chunk:raise ConnectionError("eof")
            self.buf+=chunk
        out,self.buf=self.buf[:n],self.buf[n:]
        return out
    def recv(self,timeout=5):
        self.raw.settimeout(timeout)
        while True:
            b1,b2=self._need(2)
            ln=b2&0x7f;masked=b2&0x80;op=b1&0x0f
            if ln==126:ln=struct.unpack("!H",self._need(2))[0]
            elif ln==127:ln=struct.unpack("!Q",self._need(8))[0]
            mask=self._need(4) if masked else None
            data=self._need(ln) if ln else b""
            if mask:data=bytes(b^mask[i%4] for i,b in enumerate(data))
            if op==8:raise ConnectionError("closed")
            if op in (9,10):continue
            return json.loads(data.decode())
    def drain(self,seconds=1.0,op=None):
        out=[]
        end=time.time()+seconds
        while time.time()<end:
            try:
                m=self.recv(timeout=max(.05,end-time.time()))
            except (socket.timeout,ConnectionError):
                break
            out.append(m)
            if op and m.get("op")==op:break
        return out
    def close(self):
        try:self.raw.close()
        except OSError:pass

def http(port,path,body=None,token=None,method=None):
    url=f"http://127.0.0.1:{port}{path}"
    data=json.dumps(body).encode() if body is not None else None
    req=urllib.request.Request(url,data=data,method=method or ("POST" if data else "GET"))
    if data:req.add_header("Content-Type","application/json")
    if token:req.add_header("Authorization","Bearer "+token)
    with urllib.request.urlopen(req,timeout=10) as r:
        return json.loads(r.read())

def main():
    datadir=tempfile.mkdtemp(prefix="sp98-ws-")
    env=dict(os.environ)
    proc=subprocess.Popen([sys.executable,"serve.py","--port",str(PORT),"--data",datadir],
                          cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
    try:
        for _ in range(80):
            try:
                http(PORT,"/api/info");break
            except Exception:time.sleep(.25)
        else:raise RuntimeError("serwer nie wstał:\n"+proc.stdout.read() if proc.stdout else "")

        # rejestracja gospodarza i widza
        org=http(PORT,"/api/register",{"nick":"Organizator","password":"tajnehaslo1"})
        fan=http(PORT,"/api/register",{"nick":"WidzOla","password":"tajnehaslo1"})
        room=http(PORT,"/api/room",{"config":{"nationH":"club","nationA":"eng","home":"KS SOKÓŁ","away":"TS ORZEŁ","half":60},"name":"Test WS"},token=org["token"])
        rid=room["id"]
        http(PORT,"/api/seat",{"room":rid,"slot":9},token=org["token"])
        http(PORT,"/api/start",{"room":rid},token=org["token"])

        # --- gracz przez WS ---
        player=WS(PORT,token=org["token"],room=rid,mode="play")
        welcome=None
        for m in player.drain(4,op="welcome"):welcome=m
        ok("WS: welcome dla gracza",welcome and welcome.get("mode")=="play",welcome)
        ok("WS: welcome podaje Hz",welcome and welcome.get("hz")==20,welcome)
        states=[m for m in player.drain(2.5) if m.get("op")=="state"]
        ok("WS: migawki płyną",len(states)>20,len(states))
        hz=len(states)/2.5
        ok("WS: częstość migawek ~20 Hz",17<hz<23,round(hz,1))
        ok("WS: migawka zawiera widzów","watchers" in (states[0]["state"] if states else {}),states[0] if states else None)

        # pominięcie ceremonii otwarcia (klawisz C), potem kickoff podaniem — jak w szkółce
        seq=100;state=states[-1]["state"]["state"] if states else None
        for _ in range(100):
            if state in ("kickoff","play"):break
            player.send({"op":"input","input":{"seq":seq,"skipEdge":True,"skip":True}});seq+=1
            got=player.drain(.25,op="state")
            if got:state=got[-1]["state"]["state"]
        for _ in range(40):
            if state=="play":break
            if state=="kickoff":
                player.send({"op":"input","input":{"seq":seq,"x":-.22,"z":.97,"pass":True,"passEdge":True}});seq+=1
                time.sleep(.25)
                player.send({"op":"input","input":{"seq":seq,"x":-.22,"z":.97,"pass":False,"passUp":True,"passHold":.3}});seq+=1
            else:
                player.send({"op":"input","input":{"seq":seq,"skipEdge":True,"skip":True}});seq+=1
            got=player.drain(.3,op="state")
            if got:state=got[-1]["state"]["state"]
        ok("WS: przejście do gry (skip ceremonii + kickoff)",state=="play",state)

        # wejście przez WS — gracz rusza w bok
        x0=None
        for m in player.drain(.4,op="state"):
            if m.get("op")=="state":x0=m["state"]["players"][9][0]
        for _ in range(30):
            player.send({"op":"input","input":{"seq":seq,"x":1,"z":0,"mx":1,"mz":0,"sprint":True}});seq+=1
            time.sleep(.05)
        states2=[m for m in player.drain(1.5) if m.get("op")=="state"]
        moved=False
        if states2 and x0 is not None:
            x1=states2[-1]["state"]["players"][9][0]
            moved=(x1-x0)>1.0
        ok("WS: wejścia sterują zawodnikiem",moved,(x0,states2[-1]["state"]["players"][9][0] if states2 else None))

        # czat przez WS
        player.send({"op":"chat","body":"Cześć z boiska!"})
        chat=None
        for m in player.drain(2,op="chat"):chat=m
        ok("WS: czat rozesłany",chat and chat["message"]["body"]=="Cześć z boiska!" and chat["message"]["nick"]=="Organizator",chat)

        # --- widz przez WS ---
        watcher=WS(PORT,token=fan["token"],room=rid,mode="fan",fan={"sector":2,"row":5,"seat":12})
        wfirst=watcher.drain(2)
        wstates=[m for m in wfirst if m.get("op")=="state"]
        ok("WS: widz dostaje stan",len(wstates)>5,len(wstates))
        payload=next((m for m in reversed(wfirst) if m.get("op")=="watchers"),None)
        if payload is None:
            for m in watcher.drain(1.5,op="watchers"):payload=m
        ok("WS: lista widzów rozesłana",payload is not None and payload.get("fans",0)>=1,payload)
        if payload and payload["watchers"]:
            w=payload["watchers"][0]
            ok("WS: widz ma nick i miejsce",w.get("nick")=="WidzOla" and w.get("sector")==2 and w.get("row")==5 and w.get("seat")==12,w)

        # zmiana miejsca widza → aktualizacja
        watcher.send({"op":"fanseat","fan":{"sector":6,"row":9,"seat":33}})
        upd=None
        for m in watcher.drain(2,op="watchers"):upd=m
        ok("WS: fanseat aktualizuje listę",upd and upd["watchers"] and upd["watchers"][0]["sector"]==6 and upd["watchers"][0]["seat"]==33,upd)

        # gracz widzi widza w migawce
        ps=[m for m in player.drain(1.2) if m.get("op")=="state"]
        if ps:
            wl=ps[-1]["state"].get("watchers",[])
            ok("WS: widz widoczny w stanie dla gracza",any(w.get("nick")=="WidzOla" for w in wl),wl)
            ok("WS: licznik widzów w stanie",ps[-1]["state"].get("fans",0)>=1,ps[-1]["state"].get("fans"))

        # lobby push po nowym połączeniu w tle
        lobby=WS(PORT,room=0,mode="lobby")
        lobby.send({"op":"lobby","on":True})
        pushed=None
        for m in lobby.drain(3.5,op="lobby"):pushed=m
        ok("WS: lobby push listy meczów",pushed and any(r["id"]==rid for r in pushed.get("rooms",[])),pushed and [r.get("id") for r in pushed.get("rooms",[])])
        if pushed:
            entry=[r for r in pushed["rooms"] if r["id"]==rid][0]
            ok("WS: lobby pokazuje widzów",entry.get("fans",0)>=1,entry.get("fans"))

        # HTTP fallback nadal działa
        st=http(PORT,f"/api/state?room={rid}&after=-1")
        ok("HTTP: /api/state działa obok WS","players" in st and "watchers" in st)
        info=http(PORT,"/api/info")
        ok("HTTP: /api/info z licznikiem widzów",info["rooms"][0].get("fans",0)>=1,info["rooms"][0].get("fans"))

        # rozłączenie widza zdejmuje go z listy
        watcher.close()
        time.sleep(1.0)
        ps=[m for m in player.drain(1.2) if m.get("op")=="state"]
        gone=ps and not any(w.get("nick")=="WidzOla" for w in ps[-1]["state"].get("watchers",[]))
        ok("WS: rozłączenie usuwa widza",gone)

        player.close();lobby.close()
        time.sleep(.3)
    finally:
        proc.terminate()
        try:proc.wait(timeout=6)
        except subprocess.TimeoutExpired:proc.kill()

    # --- TLS: https + wss (poz. 6) ---
    datadir2=tempfile.mkdtemp(prefix="sp98-tls-")
    tls=subprocess.Popen([sys.executable,"serve.py","--port",str(TLSPORT),"--data",datadir2,"--tls","auto"],
                         cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
    try:
        ctx=ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT);ctx.check_hostname=False;ctx.verify_mode=ssl.CERT_NONE
        up=False
        for _ in range(120):
            try:
                with urllib.request.urlopen(f"https://127.0.0.1:{TLSPORT}/api/info",context=ctx,timeout=3) as r:
                    json.loads(r.read());up=True;break
            except Exception:time.sleep(.25)
        ok("TLS: https działa (certyfikat self-signed)",up)
        if up:
            w=WS(TLSPORT,room=0,mode="lobby",use_tls=True)
            got=None
            for m in w.drain(4,op="welcome"):got=m
            ok("TLS: wss handshake i welcome",got is not None,got)
            w.close()
        cert=Path(datadir2)/"tls.crt"
        ok("TLS: certyfikat zapisany w conf/",cert.is_file())
    finally:
        tls.terminate()
        try:tls.wait(timeout=6)
        except subprocess.TimeoutExpired:tls.kill()

    print()
    if fails:
        print("NIEPOWODZENIA:",", ".join(fails));sys.exit(1)
    print("WYNIK: OK — WebSocket, 20 Hz, widzowie, czat, lobby, TLS działają")
    sys.exit(0)

if __name__=="__main__":main()
