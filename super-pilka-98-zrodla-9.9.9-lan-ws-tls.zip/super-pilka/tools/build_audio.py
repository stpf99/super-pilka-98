"""Rebuild the Polish and English cue/name banks and the ceremonial excerpts."""
import array, io, json, math, subprocess, shutil, tempfile, wave
from pathlib import Path
from voice import RATE, sound, speech, wav
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'source/audio'
CUES={'opening':('Witamy na meczu','Welcome to the match'),'goal':('Gol! Strzela','Goal! The scorer is'),'pass':('Podaje','Pass from'),'shot':('Strzela','Shot by'),'handball':('Zagranie ręką','Handball'),'advantage':('Gramy dalej','Advantage, play on'),'subs':('Zmiana zawodnika','Substitution'),'penalty':('Rzut karny','Penalty kick'),'winner':('Puchar zdobywa','The cup goes to'),'coach':('Trener','Head coach'),'ref':('Sędzia','Referee'),'free':('Rzut wolny','Free kick'),'added':('Czas doliczony','Added time'),'full':('Koniec meczu','Full time')}
# Syllables, semitone number (MIDI) and beat length. Short sung opening phrases.
SONGS={
'pol':(116,'pl', [('Jesz',70,.75),('cze',70,.25),('Pol',74,.75),('ska',74,.25),('nie',72,.5),('zgi',74,.5),('nę',70,1),('ła',67,1),(' ',67,1),('kie',72,.75),('dy',72,.25),('my',75,1),('ży',74,.5),('je',72,.5),('my',70,2.5)]),
'eng':(84,'en',[('God',60,1),('save',60,1),('our',62,1),('gra',59,1.5),('cious',60,.5),('King',62,1),('Long',64,1),('live',64,1),('our',65,1),('no',64,1.5),('ble',62,.5),('King',60,1)]),
'fra':(108,'pl',[('A',60,.25),('lon',57,.75),('zan',60,.25),('fan',65,1),('de',65,1),('la',67,1),('pa',67,1),('tri',72,1.5),('i',70,.5),('e',69,1)]),
'ger':(90,'pl',[('Ajn',67,1),('ich',69,.75),('kajt',71,.25),('unt',69,1),('recht',72,1),('unt',71,.75),('fraj',69,.25),('hajt',67,2)])}
SONGS["club"]=(108,"pl",[("Do",60,1),("bo",64,.75),("ju",67,1.25),("dru",69,1),("ży",67,1),("no",64,2),("hej",60,2)])
def anthem(code):
    bpm,lang,notes=SONGS[code];out=array.array('h')
    for syllable,note,beats in notes:
        dur=beats*60/bpm;f=440*2**((note-69)/12)
        a=sound(syllable,lang,f,dur);b=sound(syllable,lang,f*.501,dur)
        for j,(v,w) in enumerate(zip(a,b)):
            env=min(1,j/(RATE*.024),(len(a)-j)/(RATE*.045))
            brass=env*(math.sin(2*math.pi*f*j/RATE)+.28*math.sin(4*math.pi*f*j/RATE))
            out.append(int(max(-31000,min(31000,.56*v+.23*w+3600*brass))))
    return out
def export_cues(index):
    for lang,clips in index.items():
        dest=OUT/'cues'/lang;dest.mkdir(exist_ok=True,parents=True)
        for key in CUES:
            start,duration=clips[key]
            subprocess.run(['ffmpeg','-loglevel','error','-y','-ss',str(start),'-i',str(OUT/(lang+'.mp3')),'-t',str(duration),'-b:a','40k',str(dest/(key+'.mp3'))],check=True)
def main():
    OUT.mkdir(exist_ok=True);db=json.loads((ROOT/'source/data/teams.json').read_text());people=set(db['officials']+db['clubCoaches'])
    for c in db['teams'].values():
        if 'players' in c:people.add(c['coach']);people.update(p['name'] for p in c['players'])
    people.update('Wrona Sikora Zając Górski Kruk Lis Mazur Kowal Borek Wilk Duda Mróz Brzoza Wolski Nowicki Latoń Sowa Kurek Urban Drozd Sarna Lasota Dąb Kozioł Bal Lech Rudy Biel Rak Cis Jagła Szeliga Wąs Kania Leśny Witek'.split())
    index={}
    for lang in ('pl','en'):
        bank=array.array('h');entries={}
        phrases={k:value[lang=='en'] for k,value in CUES.items()};phrases.update({n:n for n in sorted(people)})
        phrases.update({'team_'+code:c[lang] for code,c in db['teams'].items() if code!='club'})
        phrases.update({'club_h':'Klub Sportowy Sokół','club_a':'Towarzystwo Sportowe Orzeł'})
        from concurrent.futures import ThreadPoolExecutor
        def render(item):
            key,txt=item
            if lang=='en' and not (shutil.which('espeak') or shutil.which('espeak-ng')):
                with tempfile.TemporaryDirectory() as temp:
                    src=Path(temp)/'text.txt';src.write_text(txt)
                    args=['ffmpeg','-loglevel','error','-f','lavfi','-i','flite=textfile='+str(src)+':voice=slt','-ar',str(RATE),'-ac','1','-f','wav','pipe:1']
                    proc=subprocess.run(args,capture_output=True)
                    if proc.returncode==0 and len(proc.stdout)>500:return key,proc.stdout
            return key,speech(txt,lang)
        with ThreadPoolExecutor(4) as pool:clips=list(pool.map(render,phrases.items()))
        for key,raw in clips:
            with wave.open(io.BytesIO(raw)) as w:
                pcm=w.readframes(w.getnframes())
                if w.getframerate()!=RATE:
                    pcm=subprocess.run(['ffmpeg','-loglevel','error','-i','pipe:0','-f','s16le','-ar',str(RATE),'-ac','1','pipe:1'],input=raw,capture_output=True,check=True).stdout
            piece=array.array('h');piece.frombytes(pcm);start=len(bank)/RATE;bank.extend(piece);entries[key]=[round(start,4),round(len(piece)/RATE,4)];bank.extend([0]*1440)
        index[lang]=entries
        subprocess.run(['ffmpeg','-loglevel','error','-y','-i','pipe:0','-codec:a','libmp3lame','-b:a','32k',str(OUT/(lang+'.mp3'))],input=wav(bank),check=True)
    for code in SONGS:
        subprocess.run(['ffmpeg','-loglevel','error','-y','-i','pipe:0','-codec:a','libmp3lame','-b:a','48k',str(OUT/(code+'.mp3'))],input=wav(anthem(code)),check=True)
    (OUT/'index.json').write_text(json.dumps(index,ensure_ascii=False,separators=(',',':')));print('Generated',len(index['pl']),'cues per language')
    export_cues(index)
if __name__=='__main__':main()
