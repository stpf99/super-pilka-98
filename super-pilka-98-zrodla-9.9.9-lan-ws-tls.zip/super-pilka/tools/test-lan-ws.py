#!/usr/bin/env python3
"""Test LAN w przeglądarce (poz. 6 i 7): gracz i widz przez WebSocket.

Dwie strony Chromium (SwiftShader): obie ładują się najpierw w lekkim lobby,
dopiero potem organizator rozpoczyna mecz, a widz wchodzi na trybuny.
Sprawdza: kanał WS (LAN.wsOk), migawki, licznik i awatary widzów, czat
przez WS, zmianę miejsca widza oraz efekty graficzne (cząstki, smuga).

Uwaga: scena pod SwiftShader mocno obciąża wątek strony, więc obie strony
ładujemy ZANIM ruszy symulacja, viewporty są małe, a wszystkie interakcje
idą przez page.evaluate zamiast fill/click Playwrighta."""
from playwright.sync_api import sync_playwright
import json
import subprocess
import sys
import tempfile
import time
import urllib.request
from pathlib import Path

ROOT=Path(__file__).resolve().parent.parent
PORT=8941
fails=[]

def ok(name,cond,detail=""):
    print(("OK   " if cond else "FAIL ")+name+((" — "+str(detail)[:160]) if detail and not cond else ""),flush=True)
    if not cond:fails.append(name)

def http(path,body=None,token=None):
    data=json.dumps(body).encode() if body is not None else None
    req=urllib.request.Request(f"http://127.0.0.1:{PORT}{path}",data=data,method="POST" if data else "GET")
    if data:req.add_header("Content-Type","application/json")
    if token:req.add_header("Authorization","Bearer "+token)
    with urllib.request.urlopen(req,timeout=10) as r:return json.loads(r.read())

def js(page,code):
    return page.evaluate("()=>{"+code+"}")

def freeze(page):
    """zatrzymuje pętlę renderowania strony (SwiftShader zjada CPU drugiej strony)"""
    page.evaluate("()=>{if(!window.__rafHold){window.__rafHold=window.requestAnimationFrame;window.requestAnimationFrame=function(){return 0;};}}")

def throttle(page,fps):
    """przywraca pętlę z ograniczeniem do fps klatek/s — test sprawdza funkcje, nie wydajność"""
    page.evaluate("()=>{var fps=%d;"
                  "if(window.__rafHold){window.requestAnimationFrame=window.__rafHold;window.__rafHold=null;}"
                  "if(!window.__rafTh){var orig=window.requestAnimationFrame,last=0,int=1000/fps;"
                  "window.__rafTh=true;window.requestAnimationFrame=function(f){return orig(function(t){if(t-last>=int){last=t;f(t);}});};"
                  "orig(function(t){MAIN.loop(t);});}}"%fps)

def goto(page,url,label):
    for attempt in range(3):
        try:page.goto(url,timeout=120000);return
        except Exception as e:
            if attempt==2:raise
            print("  (ponawiam wejście %s: %s)"%(label,str(e)[:80]),flush=True);time.sleep(2)

def open_lan(page):
    js(page,"document.getElementById('btnLan').click()")
    page.wait_for_function("()=>LAN.info && Array.isArray(LAN.info.rooms)",timeout=60000,polling=100)

def register(page,nick,pw):
    js(page,"document.getElementById('lanNick').value='%s';document.getElementById('lanPassword').value='%s';document.getElementById('lanRegister').click()"%(nick,pw))
    page.wait_for_function("()=>LAN.profile && LAN.profile.nick==='%s'"%nick,timeout=60000,polling=100)

def pick_room(page,index=0):
    page.wait_for_function("()=>LAN.info && LAN.info.rooms.length>%d"%index,timeout=60000,polling=100)
    js(page,"var s=document.getElementById('lanRooms');s.selectedIndex=%d;s.dispatchEvent(new Event('change'));"%index)

def click(page,ident):
    js(page,"document.getElementById('%s').click()"%ident)

def menu(page,label,con,errs):
    try:
        page.wait_for_function("()=>!document.getElementById('ovMenu').classList.contains('hide')",timeout=150000,polling=100)
    except Exception:
        print("  %s console: %s pageerrors: %s"%(label,con[:5],errs[:3]),flush=True);raise

def main():
    datadir=tempfile.mkdtemp(prefix="sp98-lan-")
    proc=subprocess.Popen([sys.executable,"serve.py","--port",str(PORT),"--data",datadir],
                          cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
    try:
        for _ in range(80):
            try:http("/api/info");break
            except Exception:time.sleep(.25)
        else:raise RuntimeError("serwer nie wstał")

        with sync_playwright() as pw:
            browser=pw.chromium.launch(args=["--use-gl=swiftshader","--enable-unsafe-swiftshader"])
            ctxA=browser.new_context(viewport={"width":200,"height":140})
            ctxB=browser.new_context(viewport={"width":200,"height":140})
            A=ctxA.new_page();B=ctxB.new_page()
            errsA=[];errsB=[];conA=[];conB=[]
            A.on("pageerror",lambda e:errsA.append(str(e)[:200]))
            B.on("pageerror",lambda e:errsB.append(str(e)[:200]))
            A.on("console",lambda m:conA.append(m.text[:200]) if m.type=="error" else None)
            B.on("console",lambda m:conB.append(m.text[:200]) if m.type=="error" else None)

            # ---- 1. obie strony ładują się w lekkim lobby (mecz jeszcze nie ruszył) ----
            goto(A,f"http://127.0.0.1:{PORT}/","A")
            menu(A,"A",conA,errsA)
            ok("A: strona i menu",True)
            open_lan(A)
            register(A,"Organizator","tajnehaslo1")
            js(A,"document.getElementById('lanRoomName').value='Mecz testowy'")
            click(A,"lanNewRoom")
            print("  A: mecz utworzony",flush=True)
            freeze(A)   # A czeka w lobby — oddaje CPU na start strony B

            goto(B,f"http://127.0.0.1:{PORT}/","B")
            menu(B,"B",conB,errsB)
            ok("B: strona i menu",True)
            open_lan(B)
            register(B,"WidzOla","tajnehaslo1")
            pick_room(B,0)
            print("  B: profil gotowy",flush=True)

            # B zamrożony — czytanie WS nie wymaga renderowania, a SwiftShader
            # przy pełnej pętli głodzi kolejkę WebSocket strony
            freeze(B)

            # ---- 2. organizator wchodzi na pozycję (start meczu) ----
            pick_room(A,0)
            A.wait_for_function("()=>{const s=document.getElementById('lanSlot');return s.options.length>0&&s.options.length===22;}",timeout=60000,polling=100)
            js(A,"var s=document.getElementById('lanSlot');var f=[...s.options].find(o=>!o.disabled);if(f)s.value=f.value;")
            click(A,"lanPlay")
            A.wait_for_function("()=>LAN.active && LAN.wsOk && LAN.last",timeout=120000,polling=100)
            time.sleep(2)
            stA=js(A,"return ({ws:LAN.wsOk,state:LAN.last&&LAN.last.state,rev:LAN.rev,mode:LAN.mode,paused:LAN.last&&LAN.last.paused})")
            ok("A: WebSocket połączony",stA["ws"],stA)
            ok("A: migawki płyną",stA["rev"]>0 and stA["state"],stA)
            print("  A: stan=%s rev=%s"%(stA["state"],stA["rev"]),flush=True)

            # ---- 3. widz wchodzi na trybuny do trwającego meczu ----
            time.sleep(.5)
            click(B,"lanWatch")
            B.wait_for_function("()=>LAN.active && LAN.wsOk && LAN.last",timeout=120000,polling=100)
            time.sleep(2)
            stB=js(B,"return ({ws:LAN.wsOk,mode:LAN.mode,rev:LAN.rev})")
            ok("B: widz po WebSocket",stB["ws"] and stB["mode"]=="fan",stB)
            ok("B: widz dostaje stan",stB["rev"]>0,stB)

            # ---- 4. licznik widzów i awatary (A dogania strumień WS w swoim tempie) ----
            A.wait_for_function("()=>LAN.fans>=1",timeout=90000,polling=100)
            time.sleep(1)
            wA=js(A,"return ({fans:LAN.fans,count:LAN.guests?LAN.guests.count:0,status:document.getElementById('lanStatus').textContent,watch:JSON.stringify(LAN.watchers)})")
            if not ("widzowie: 1" in wA["status"] and wA["count"]>=1):
                info=http("/api/info")
                print("  diag: rooms=%s | A.wsReady=%s A.wsOk=%s | B.watchers=%s"%(
                    [(r["id"],r.get("fans")) for r in info["rooms"]],
                    js(A,"return LAN.ws?LAN.ws.readyState:-1"),js(A,"return LAN.wsOk"),
                    js(B,"return JSON.stringify(LAN.watchers)")),flush=True)
            ok("A: licznik widzów w pasku","widzowie: 1" in wA["status"],wA["status"])
            ok("A: awatar widza na trybunach",wA["count"]>=1,wA)
            ok("B: własny awatar ukryty",js(B,"return ((!LAN.guests||LAN.guests.count===0)===true)"))

            # ---- 5. czat przez WS: B pisze, A czyta ----
            js(B,"document.getElementById('lanChatInput').value='Halo z trybun!';document.getElementById('lanChatForm').dispatchEvent(new Event('submit'))")
            A.wait_for_function("()=>document.getElementById('lanChatLog').textContent.indexOf('Halo z trybun!')>=0",timeout=60000,polling=100)
            ok("A: czat od widza dotarł",True)

            # ---- 6. zmiana miejsca widza → aktualizacja u gracza ----
            before=js(A,"return JSON.stringify(LAN.watchers)")
            js(B,"var s=document.getElementById('lanSector');s.value='5';s.dispatchEvent(new Event('change'));var r=document.getElementById('lanRow');r.value='11';r.dispatchEvent(new Event('change'));")
            try:
                A.wait_for_function("()=>JSON.stringify(LAN.watchers)!=='%s'"%before.replace("'","\\'"),timeout=30000,polling=100)
                ok("A: widz zmienił sektor",True)
            except Exception:
                ok("A: widz zmienił sektor",False,js(A,"return JSON.stringify(LAN.watchers)"))

            # ---- 7. efekty graficzne (poz. 7) ----
            fx=js(B,"return ({soft:!!WORLD.fxSoft,conf:!!WORLD.fxConf,trail:!!WORLD.trail,guests:!!LAN.guests})")
            ok("grafika: pule cząstek i smuga istnieją",fx["soft"] and fx["conf"] and fx["trail"],fx)
            fxrun=js(B,"return WORLD.fxConfetti(1),WORLD.fxDust(0,0,0),WORLD.fxSplash(3,4),WORLD.fxConf.list.length+'/'+WORLD.fxSoft.list.length")
            ok("grafika: cząstki żyją po zdarzeniach",fxrun.startswith("120/") and int(fxrun.split("/")[1])>=9,fxrun)
            # smuga: segment zapisuje się przy przesunięciu >0,55 m; ogon (kolor 0)
            # jest najjaśniejszy, głowa smugi celowo gaśnie do czerni pod piłką
            trail=js(B,"return SIM.ball.vx=20,SIM.ball.x=5,SIM.ball.z=5,WORLD.fxUpdate(0.016),SIM.ball.x=8,SIM.ball.z=5,WORLD.fxUpdate(0.016),WORLD.trailCol[0]+WORLD.trailCol[1]>0")
            ok("grafika: smuga piłki świeci przy prędkości",trail is True,trail)

            ok("A: brak błędów strony",not errsA,errsA[:3])
            ok("B: brak błędów strony",not errsB,errsB[:3])
            ok("A: brak błędów konsoli",not conA,conA[:3])
            ok("B: brak błędów konsoli",not conB,conB[:3])
            browser.close()
    finally:
        proc.terminate()
        try:proc.wait(timeout=6)
        except subprocess.TimeoutExpired:proc.kill()

    print()
    if fails:
        print("NIEPOWODZENIA:",", ".join(fails));sys.exit(1)
    print("WYNIK: OK — gracz i widz działają przez WebSocket, widzowie widoczni, czat i efekty działają")
    sys.exit(0)

if __name__=="__main__":main()
