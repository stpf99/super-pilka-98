/* Test dymny silnika LAN: rozgrywa mecz przez nowy wspólny moduł sterowania.
   Dwa miejsca w jednej drużynie (poz. 4 z listy): rozpoczynający (slot 9)
   podaje do wsparcia (slot 10), który dalej sprintuje z piłką, robi zwrot
   180° i podaje z przytrzymaniem. Akceptacja: brak błędów, właściciel nie
   gubi piłki (smycza < 3,2 m), podanie opuszcza zawodnika. */
const { spawn } = require('node:child_process');
const path = require('node:path');

const eng = spawn('node', [path.join(__dirname, '..', 'lan', 'engine.cjs')], { cwd: path.join(__dirname, '..') });
let frames = 0, errors = [], last = null;
let maxGapRun = 0, maxGapTurn = 0, lostRun = false, lostTurn = false, passGone = false, passSpeed = 0, passSkipped = false;

eng.stdout.on('data', d => {
  for (const line of d.toString().split('\n')) {
    if (!line.trim()) continue;
    try {
      const m = JSON.parse(line);
      if (m.state) {
        frames++; 
        if (last) {
          if (m.state.state !== last.state) console.log('  [stan] %s -> %s (f=%d)', last.state, m.state.state, frames);
          if (m.state.ball[6] !== last.ball[6]) console.log('  [owner] %s -> %s (f=%d, ballX=%s, gracz10X=%s)', last.ball[6], m.state.ball[6], frames, m.state.ball[0].toFixed(1), m.state.players[10][0].toFixed(1));
          if (m.state.state === 'freekick' || m.state.state === 'goal') console.log('  [zdarzenie] %s hud=%s taker=%s', m.state.state, JSON.stringify(m.state.hud), m.state.taker);
        }
        last = m.state;
      }
    } catch (e) { errors.push('bad json'); }
  }
});
eng.stderr.on('data', d => { errors.push('engine: ' + d.toString().slice(0, 300)); });
eng.on('exit', c => { if (c) errors.push('exit code ' + c); });

function send(o) { eng.stdin.write(JSON.stringify(o) + '\n'); }
const sleep = ms => new Promise(r => setTimeout(r, ms));

(async () => {
  send({ op: 'start', config: { nationH: 'club', nationA: 'club', home: 'KS SOKÓŁ', away: 'TS ORZEŁ', half: 60, diff: 3, form: '4-4-2', tactic: 'balanced', weather: 'clear', night: 1, ballStyle: 'classic', stadium: 0, stripH: 0, stripA: 1, lang: 'pl', ref: 0 }, saved: null, seats: { 9: 'GraczA', 10: 'GraczB' } });
  /* pomijaj ceremonię otwarcia (skipEdge = klawisz C) aż do kickoff */
  let seq = 1, waited = 0;
  while ((!last || last.state !== 'kickoff') && waited < 20000) {
    send({ op: 'input', slot: 9, input: { seq: seq++, skipEdge: true } });
    await sleep(200); waited += 200;
  }
  if (!last || last.state !== 'kickoff') { console.log('stan po starcie:', last && last.state); errors.push('brak kickoff po pominięciu ceremonii'); }
  else console.log('kickoff po %d ms', waited);

  /* kickoff: podanie w kierunku wsparcia (idx 10 stoi ~2,5 m od wykonawcy) */
  send({ op: 'input', slot: 9, input: { seq: seq++, x: -0.22, z: 0.97, passEdge: true } });
  await sleep(800);
  send({ op: 'input', slot: 9, input: { seq: seq++, x: -0.22, z: 0.97, pass: true, passEdge: true } });
  await sleep(400);
  send({ op: 'input', slot: 9, input: { seq: seq++, x: -0.22, z: 0.97, pass: false, passUp: true, passHold: 0.3 } });
  waited = 0;
  while (waited < 8000) {
    await sleep(150); waited += 150;
    if (last && last.state === 'play' && last.ball[6] === 10) break;
  }
  const slot = last && last.ball[6] === 10 ? 10 : (last && last.ball[6] === 9 ? 9 : -1);
  console.log('stan gry: %s, piłkę ma slot %s (klatki %d)', last && last.state, slot, frames);
  if (slot < 0) errors.push('po rozpoczęciu żaden z ludzi nie ma piłki (owner=' + (last && last.ball[6]) + ')');

  const gapOf = s => (s && s.ball[6] === slot ? Math.hypot(s.ball[0] - s.players[slot][0], s.ball[2] - s.players[slot][1]) : null);

  if (slot >= 0) {
    const sample = (phase) => {   /* zwraca: 'ok' | 'przerwana' (restart/gol) | 'strata' (przejęcie rywala w grze) */
      if (!last || last.state !== 'play') return 'przerwana';
      if (last.ball[6] === slot) return 'ok';
      if (last.ball[6] === -1) return 'ok';                      /* piłka w locie/luźna */
      if (last.ball[6] === (slot === 9 ? 10 : 9)) return 'ok';   /* drugi człowiek */
      return 'strata';
    };

    /* sprint z piłką w prawo przez ~2,6 s — pomiar smyczy */
    const t0 = frames;
    let phase1 = 'ok';
    while (frames - t0 < 170) {
      send({ op: 'input', slot: slot, input: { seq: seq++, x: 1, z: 0, sprint: true } });
      const r = sample();
      if (r === 'przerwana') { phase1 = 'przerwana'; break; }
      if (r === 'strata') { phase1 = 'strata'; lostRun = true; break; }
      const g = gapOf(last);
      if (g !== null) maxGapRun = Math.max(maxGapRun, g);
      await sleep(50);
    }
    console.log('sprint: maxGap=%s m (%s)', maxGapRun ? maxGapRun.toFixed(2) : '—', phase1);

    /* ostry zwrot 180° przez ~1,3 s — tylko wtedy, gdy nadal mamy piłkę */
    if (phase1 === 'ok' && last && last.state === 'play' && last.ball[6] === slot) {
      const t1 = frames;
      while (frames - t1 < 85) {
        send({ op: 'input', slot: slot, input: { seq: seq++, x: -1, z: 0, sprint: true } });
        const r = sample();
        if (r === 'przerwana') { phase1 = 'przerwana'; break; }
        if (r === 'strata') { lostTurn = true; break; }
        const g = gapOf(last);
        if (g !== null) maxGapTurn = Math.max(maxGapTurn, g);
        await sleep(50);
      }
      console.log('zwrot: maxGap=%s m', maxGapTurn ? maxGapTurn.toFixed(2) : '—');
    } else console.log('zwrot: pominięty (faza sprintu: %s)', phase1);

    /* podanie z przytrzymaniem 0,8 s — piłka ma opuścić zawodnika (tylko gdy ją mamy) */
    if (!(last && last.state === 'play' && last.ball[6] === slot)) {
      passSkipped = true;
      console.log('podanie: pominięte (piłkę ma slot %s, stan %s)', last && last.ball[6], last && last.state);
    } else {
    send({ op: 'input', slot: slot, input: { seq: seq++, x: 1, z: 0, pass: true, passEdge: true } });
    await sleep(850);
    send({ op: 'input', slot: slot, input: { seq: seq++, x: 1, z: 0, pass: false, passUp: true, passHold: 0.8 } });
    let seenLoose = false;
    for (let i = 0; i < 25; i++) {
      await sleep(50);
      if (last && last.state === 'play') {
        const sp = Math.hypot(last.ball[3], last.ball[5]);
        if (sp > passSpeed) passSpeed = sp;
        if (last.ball[6] === -1 || last.ball[7] >= 0) seenLoose = true;
        if (sp > 8 && (last.ball[6] === -1 || last.ball[6] !== slot)) passGone = true;
      }
    }
    if (!passGone && seenLoose && passSpeed > 6) passGone = true;
    console.log('podanie: owner=%s, adresat=%s, max prędkość=%s m/s, odeszło=%s', last && last.ball[6], last && last.ball[7], passSpeed ? passSpeed.toFixed(1) : '—', passGone);
    }
  }

  send({ op: 'stop' });
  await sleep(300);
  eng.kill();

  const fail = [];
  if (errors.length) fail.push(...errors.slice(0, 6));
  if (lostRun) fail.push('utrata piłki przy prostym sprincie (max ' + maxGapRun.toFixed(2) + ' m)');
  if (lostTurn) fail.push('utrata piłki przy zwrocie 180° (max ' + (maxGapTurn || 0).toFixed(2) + ' m)');
  if (maxGapRun > 3.2) fail.push('smycza przekroczona przy sprincie: ' + maxGapRun.toFixed(2));
  if (!passGone && !passSkipped) fail.push('podanie z przytrzymaniem nie opuściło zawodnika');
  if (fail.length) { console.log('FAIL:'); fail.forEach(f => console.log(' -', f)); process.exit(1); }
  console.log('SMOKE OK — kontakt utrzymany (max ' + Math.max(maxGapRun, maxGapTurn).toFixed(2) + ' m), podanie działa, błędów brak, klatki=' + frames);
  process.exit(0);
})().catch(e => { console.error('test fail', e); eng.kill(); process.exit(1); });
