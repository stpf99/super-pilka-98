#!/usr/bin/env python3
"""Test wizualny szkołki w przeglądarce — wersja oszczędna (SwiftShader).
Weryfikuje: menu, otwarcie szkołki, intro + wykrycie urządzenia, start lekcji
z klawiatury, sterowanie ruchem (INPUT), renderer 3D (liczba trójkątów),
powrót do menu przez Esc."""
from playwright.sync_api import sync_playwright
import sys
from pathlib import Path

GAME=Path(__file__).resolve().parent.parent/"super-pilka-98.html"

errs, console_errs = [], []
ok_flags = []

with sync_playwright() as pw:
    browser = pw.chromium.launch(args=["--use-gl=swiftshader", "--enable-unsafe-swiftshader"])
    page = browser.new_page(viewport={"width": 800, "height": 520})
    page.on("pageerror", lambda e: errs.append(str(e)[:300]))
    page.on("console", lambda m: console_errs.append(m.text[:200]) if m.type == "error" else None)
    page.set_default_timeout(30000)
    page.goto(GAME.as_uri())
    page.wait_for_timeout(8000)

    vis = page.evaluate("() => !document.getElementById('ovMenu').classList.contains('hide')")
    ok_flags.append(("menu po starcie", vis))
    page.evaluate("() => document.getElementById('btnTrainer').click()")
    page.wait_for_timeout(1500)
    lesson = page.text_content("#trLesson")
    dev = page.evaluate("() => TRAINER && TRAINER.fill('{dev}')")
    ok_flags.append(("szkołka otwarta (intro)", (lesson or "").startswith("Witaj")))
    ok_flags.append(("wykryto urządzenie", dev in ("klawiatury", "pada")))
    print("intro:", lesson, "| urządzenie:", dev, flush=True)

    # start lekcji 1 przyciskiem podania
    page.keyboard.down("k"); page.wait_for_timeout(250); page.keyboard.up("k")
    page.wait_for_timeout(900)
    lesson1 = page.text_content("#trLesson")
    ok_flags.append(("lekcja 1 wystartowała", (lesson1 or "").startswith("Lekcja 1")))
    print("lekcja:", lesson1, flush=True)

    # ruch w prawo — INPUT musi zareagować
    page.keyboard.down("d"); page.wait_for_timeout(700)
    mv = page.evaluate("() => ({len: INPUT.slots[0].moveLen, dev: INPUT.slots[0].device})")
    page.keyboard.up("d")
    ok_flags.append(("ruch sterowany działa", mv and mv.get("len", 0) > 0.5))
    print("input ruchu:", mv, flush=True)

    # renderer 3D faktycznie renderuje scenę
    info = page.evaluate("() => WORLD.renderer.info.render")
    ok_flags.append(("scena 3D renderowana", info and info.get("triangles", 0) > 10000))
    print("renderer:", info, flush=True)

    # stan rdzenia w przeglądarce
    st = page.evaluate("() => ({step: TRAINER.step, players: SIM.players.length, rules: RULES.state, trainee: !!TRAINER.trainee})")
    ok_flags.append(("rdzeń w szkółce", st and st.get("players") == 4 and st.get("trainee") and st.get("rules") == "play"))
    print("stan:", st, flush=True)

    # powrót do menu
    page.keyboard.down("Escape"); page.wait_for_timeout(150); page.keyboard.up("Escape")
    page.wait_for_timeout(1200)
    back = page.evaluate("() => !document.getElementById('ovMenu').classList.contains('hide') && !TRAINER.active")
    ok_flags.append(("Esc wraca do menu", back))
    print("menu po Esc:", back, flush=True)

    browser.close()

print("pageerrors:", errs[:3] if errs else "brak")
print("console errors:", console_errs[:5] if console_errs else "brak")
for name, v in ok_flags:
    print(("OK  " if v else "FAIL") + " " + name)
allok = all(v for _, v in ok_flags) and not errs
print("WYNIK:", "OK" if allok else "PROBLEMY")
sys.exit(0 if allok else 1)
