/* Test jednostkowy wspólnego modułu sterowania + smyczy piłki w izolowanym VM.
   Scenariusze: sprint prosty, zwrot 180°, podanie z przytrzymaniem, strzał
   techniczny, fromNet (czasy przytrzymania), wybór zawodnika, chwyty bramkarza. */
const fs = require('node:fs'), path = require('node:path'), vm = require('node:vm');
const root = path.join(__dirname, '..', 'source');
const database = fs.readFileSync(path.join(root, 'data/teams.json'), 'utf8');
let seed = 19780321;
const math = Object.create(Math); math.random = () => ((seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0) / 4294967296);
const noop = () => {}, xyz = () => ({ x: 0, y: 0, z: 0, set(x, y, z) { Object.assign(this, { x, y, z }); } });
const stubs = new Proxy({}, { get: () => noop });
function actor(team, gk, n) { return { scale: { y: .97 }, position: xyz(), rotation: xyz(), userData: { phase: 0, kickLeg: 0 } }; }
const W = { makePlayer: actor, removePlayer: noop, aimArrow: { position: xyz(), rotation: xyz() } };
const HUD = new Proxy({ showPower: noop, hint: noop, event: noop, hideEvent: noop, banner: noop, restartTagShow: noop, restartTagHide: noop }, { get: (o, k) => k in o ? o[k] : noop });
const ctx = { Math: math, console, HL: 52.5, HW: 34, GOAL_H: 2.44, GOAL_W: 7.32, GK_R: .06,
  WORLD: W, HUD, AUDIO: stubs, STADIUM: stubs, PITCH: stubs, REC: { reset: noop, canReplay: () => false }, REPLAY: stubs,
  VOICE: { speak: noop, anthem: noop, stopMusic: noop }, MAIN: { chargeS: [0, 0], chargeP: [0, 0] },
  INPUT: { slots: [{}, {}], padSeen: [false, false] }, CAM: { fieldInput: (x, z) => ({ x, z }) },
  localStorage: { getItem: () => null }, window: {}, document: { getElementById: () => null } };
vm.createContext(ctx);
for (const f of ['01-i18n', '02-countries', '02-lineups', '02-settings', '05-conditions', '05-face', '05-motion', '06-first-touch', '06-human', '06-reception', '06-sim', '07-ai', '07-officiating', '08-broadcast', '08-ceremony', '08-matchday', '08-rules']) {
  let code = fs.readFileSync(path.join(root, 'js', f + '.js'), 'utf8').replace('/*SQUADS*/null', () => database);
  vm.runInContext(code, ctx, { filename: f });
}
const { SIM: S, RULES: R, HUMAN, AI, SET } = ctx;
S.syncMeshes = noop;
let fails = 0;
function ok(cond, label) { console.log((cond ? '  OK  ' : '  FAIL') + ' ' + label); if (!cond) fails++; }

SET.mode = 0; SET.diff = 1; SET.nationH = 'club'; SET.nationA = 'club'; SET.home = 'A'; SET.away = 'B';
R.newMatch(); R.state = 'play';
const p = S.players[9];           /* napastnik gospodarzy */
const mate = S.players[10];
const gk = S.players[11];         /* bramkarz gości */
const b = S.ball;

function resetOwner(px, pz, vx, vz) {
  p.pos.x = px; p.pos.z = pz; p.vel.x = vx; p.vel.z = vz; p.face = Math.PI / 2;
  p.off = false; p.action = 'run'; p.actionT = 0; p.challenge = null; p.keeperHold = false;
  mate.pos.x = -46; mate.pos.z = -12; mate.vel.x = mate.vel.z = 0;
  gk.pos.x = -52.5 + 2; gk.pos.z = 0; gk.vel.x = gk.vel.z = 0;
  for (const q of S.players) { if (q !== p && q !== mate && q !== gk) { q.off = true; } }
  b.owner = p; b.ownerAge = 0; b.release = null; b.cushion = null; b.receiver = null; b.route = null;
  b.flight = ''; b.shotTeam = null; b.lastKicker = p; b.lock = 0; b.curve = 0;
  b.vx = p.vel.x; b.vz = p.vel.z; b.vy = 0; b.y = S.BR; b.x = p.pos.x + .36; b.z = p.pos.z;
  b.nextTouch = 0; p.ctl = HUMAN.newState(); p.straightT = 0;
}
function sprintInp() { return { mx: 0, mz: 0, moveLen: 1, sprint: true, jockey: false, finesse: false, pass: false, shoot: false, passP: false, shootP: false, throughP: false, tackleP: false, switchP: false, switchL: false }; }

/* 1) prosty sprint 4 s — smycz i właściciel */
resetOwner(-20, 0, 0, 0);
let maxGap = 0, lost = null;
for (let i = 0; i < 240; i++) {
  HUMAN.drive(0, p, sprintInp(), { x: 1, z: 0 }, p.ctl, 1 / 60, null);
  S.step(1 / 60);
  if (b.owner !== p) { lost = i / 60; break; }
  maxGap = Math.max(maxGap, Math.hypot(b.x - p.pos.x, b.z - p.pos.z));
}
console.log('sprint 4 s: maxGap=%s m, prędkość=%s m/s, utrata=%s', maxGap.toFixed(2), Math.hypot(p.vel.x, p.vel.z).toFixed(1), lost);
ok(!lost && maxGap < 3.0, 'kontakt przy prostym sprincie (max ' + maxGap.toFixed(2) + ' m)');

/* 1b) to samo, ale z R.update w pętli (dokładnie tak jak robi to silnik LAN) */
resetOwner(-20, 0, 0, 0);
let vx0 = null;
for (let i = 0; i < 60; i++) {
  R.update(1 / 60);
  HUMAN.drive(0, p, sprintInp(), { x: 1, z: 0 }, p.ctl, 1 / 60, null);
  S.step(1 / 60);
  if (i === 3) vx0 = Math.hypot(b.vx, b.vz);
}
console.log('z R.update: v0 piłki=%s m/s, owner=%s, ballX=%s, graczX=%s, stan=%s',
  vx0 === null ? '—' : vx0.toFixed(2), b.owner === p ? 'zawodnik' : 'inny', b.x.toFixed(2), p.pos.x.toFixed(2), R.state);
ok(vx0 !== null && vx0 > 4, 'piłka rusza razem z zawodnikiem także przy R.update');

/* 2) zwrot 180° po 2 s biegu */
resetOwner(-20, 0, 0, 0);
let maxGapT = 0, lostT = null;
for (let i = 0; i < 120; i++) { HUMAN.drive(0, p, sprintInp(), { x: 1, z: 0 }, p.ctl, 1 / 60, null); S.step(1 / 60); }
for (let i = 0; i < 90; i++) {
  HUMAN.drive(0, p, sprintInp(), { x: -1, z: 0 }, p.ctl, 1 / 60, null);
  S.step(1 / 60);
  if (b.owner !== p) { lostT = i / 60; break; }
  maxGapT = Math.max(maxGapT, Math.hypot(b.x - p.pos.x, b.z - p.pos.z));
}
console.log('zwrot 180°: maxGap=%s m, utrata=%s', maxGapT.toFixed(2), lostT);
ok(!lostT && maxGapT < 3.0, 'kontakt przy zwrocie (max ' + maxGapT.toFixed(2) + ' m)');

/* 3) podanie z przytrzymaniem 0,65 s → pełna siła */
resetOwner(0, 0, 0, 0);
for (let i = 0; i < 39; i++) HUMAN.drive(0, p, Object.assign(sprintInp(), { pass: true, moveLen: 0 }), { x: 1, z: 0 }, p.ctl, 1 / 60, null);
const pw = HUMAN.drive(0, p, Object.assign(sprintInp(), { pass: false, moveLen: 0 }), { x: 1, z: 0 }, p.ctl, 1 / 60, null);
const sp0 = Math.hypot(b.vx, b.vz);
console.log('podanie: v0=%s m/s, owner=%s, flight=%s', sp0.toFixed(1), b.owner === p ? 'zawodnik' : 'luźna', b.flight);
ok(b.owner !== p && sp0 > 18, 'podanie o pełnej sile opuściło zawodnika (v0=' + sp0.toFixed(1) + ')');

/* 4) krótkie kliknięcie podania (fromNet, jeden pakiet) */
const st1 = HUMAN.newState();
const inp1 = HUMAN.fromNet({ x: 0, z: 0, pass: false, passUp: true, passHold: 0.3 }, st1);
ok(Math.abs(st1.chargeP - 0.3 / 0.65) < 0.02, 'fromNet: przytrzymanie 0,3 s → ładunek ' + st1.chargeP.toFixed(2));

/* 5) strzał techniczny — krzywizna */
resetOwner(38, 8, 0, 0);
for (let i = 0; i < 30; i++) HUMAN.drive(0, p, Object.assign(sprintInp(), { shoot: true, finesse: true, moveLen: 0 }), { x: 1, z: 0 }, p.ctl, 1 / 60, null);
HUMAN.drive(0, p, Object.assign(sprintInp(), { shoot: false, finesse: true, moveLen: 0 }), { x: 1, z: 0 }, p.ctl, 1 / 60, null);
console.log('strzał techniczny: flight=%s, curve=%s', b.flight, (b.curve || 0).toFixed(2));
ok(b.flight === 'finesse' && Math.abs(b.curve || 0) > 1, 'strzał techniczny ma krzywiznę');

/* 6) bramkarz człowiek chwyta piłkę w polu karnym */
const gkState = HUMAN.newState();
gk.pos.x = 45; gk.pos.z = 0; gk.vel.x = gk.vel.z = 0; gk.isUser = 1; gk.off = false;
b.owner = null; b.x = 45.6; b.z = .4; b.y = S.BR; b.vx = 0; b.vz = 0; b.vy = 0; b.shotTeam = null; b.lock = 0;
HUMAN.drive(1, gk, { mx: 0, mz: 0, moveLen: 0, pass: false, shoot: false, passP: false, shootP: false, throughP: false, tackleP: false }, { x: 0, z: 0 }, gkState, 1 / 60, null);
console.log('bramkarz: owner=%s, keeperHold=%s', b.owner === gk ? 'bramkarz' : '—', gk.keeperHold);
ok(b.owner === gk && gk.keeperHold, 'bramkarz-człowiek chwycił piłkę');

/* 7) wybór zawodnika: switchP zmienia na najbliższego kandydata */
resetOwner(0, 0, 0, 0);
b.owner = null; b.x = 10; b.z = 0; b.vx = b.vz = 0;
mate.pos.x = 16; mate.pos.z = 4; mate.off = false;
const team = S.teams[0]; team.user = p; team.switchCd = 0; p.isUser = 0; mate.isUser = null;
const pick = HUMAN.select(team, p, { switchP: true, switchL: false, passP: false, shootP: false, throughP: false, tackleP: false }, null, 1 / 60);
console.log('zmiana: wybrano %s', pick === mate ? 'kolegę' : pick === p ? 'bez zmiany' : 'innego');
ok(pick === mate, 'switchP przejął najbliższego kolegę');

/* 8) wysuwanie po czasie biegu: krótki bieg vs długi bieg */
resetOwner(-20, 0, 0, 0);
let gapShort = 0;
for (let i = 0; i < 30; i++) { HUMAN.drive(0, p, sprintInp(), { x: 1, z: 0 }, p.ctl, 1 / 60, null); S.step(1 / 60); if (b.owner === p) gapShort = Math.max(gapShort, Math.hypot(b.x - p.pos.x, b.z - p.pos.z)); }
resetOwner(-20, 0, 0, 0);
let gapLong = 0;
for (let i = 0; i < 240; i++) { HUMAN.drive(0, p, sprintInp(), { x: 1, z: 0 }, p.ctl, 1 / 60, null); S.step(1 / 60); if (b.owner === p && i > 90) gapLong = Math.max(gapLong, Math.hypot(b.x - p.pos.x, b.z - p.pos.z)); }
console.log('wysuwanie: świeży bieg max %s m, po 1,5 s biegu max %s m', gapShort.toFixed(2), gapLong.toFixed(2));
ok(gapLong > gapShort + 0.15, 'dłuższy bieg w jednym kierunku wysuwa piłkę dalej');

process.exit(fails ? 1 : 0);
