#!/usr/bin/env python3
"""Super Piłka 98 LAN. python3 serve.py --port 8906"""
import argparse
import hashlib
import hmac
import json
import math
import os
from pathlib import Path
import secrets
import shutil
import signal
import sqlite3
import subprocess
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit, parse_qs
from build import build
from tools.voice import speech

ROOT=Path(__file__).resolve().parent
DATA=json.loads((ROOT/'source/data/teams.json').read_text())
LOCK=threading.RLock()
workers={}
def js(x):return json.dumps(x,ensure_ascii=False,separators=(',',':'))
def query(sql,*args):
    with LOCK:return [dict(row) for row in db.execute(sql,args)]
def one(sql,*args):
    rows=query(sql,*args)
    return rows[0] if rows else None
def run(sql,*args):
    with LOCK,db:return db.execute(sql,args).lastrowid
def require(ok,message='Odmowa',code=400):
    if not ok:raise ApiError(code,message)
class ApiError(Exception):
    def __init__(self,code,message):self.code=code;super().__init__(message)
def label(value,limit=42):
    text=' '.join(str(value or '').split());require(1<=len(text)<=limit,'Nieprawidłowa nazwa')
    return text
def tokenhash(token):return hashlib.sha256(token.encode()).hexdigest()
def password(p,s):return hashlib.scrypt(p.encode(),salt=bytes.fromhex(s),n=16384,r=8,p=1).hex()
def init_database(folder):
    global db,conf,admin_key
    conf=folder;folder.mkdir(parents=True,exist_ok=True);(folder/'voices').mkdir(exist_ok=True)
    db=sqlite3.connect(folder/'liga.sqlite3',check_same_thread=False);db.row_factory=sqlite3.Row
    db.executescript("""
    PRAGMA journal_mode=WAL;
    CREATE TABLE IF NOT EXISTS profiles(id INTEGER PRIMARY KEY,nick TEXT NOT NULL,key TEXT UNIQUE,salt TEXT,pw TEXT);
    CREATE TABLE IF NOT EXISTS appearances(uid INTEGER,room INTEGER,slot INTEGER,PRIMARY KEY(uid,room));
    CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY,uid INTEGER,admin INTEGER DEFAULT 0,until INTEGER);
    CREATE TABLE IF NOT EXISTS clans(id INTEGER PRIMARY KEY,name TEXT UNIQUE,owner INTEGER);
    CREATE TABLE IF NOT EXISTS members(clan INTEGER,uid INTEGER,PRIMARY KEY(clan,uid));
    CREATE TABLE IF NOT EXISTS cups(id INTEGER PRIMARY KEY,name TEXT,scope TEXT,owner INTEGER);
    CREATE TABLE IF NOT EXISTS rooms(id INTEGER PRIMARY KEY,name TEXT,owner INTEGER,config TEXT,cup INTEGER DEFAULT 0,h INTEGER DEFAULT 0,a INTEGER DEFAULT 0,status TEXT DEFAULT 'ready',save TEXT,result TEXT);
    CREATE TABLE IF NOT EXISTS seats(room INTEGER,slot INTEGER,uid INTEGER,seen REAL,PRIMARY KEY(room,slot),UNIQUE(room,uid));
    """)
    key=folder/'admin.key'
    if not key.exists():
        with open(os.open(key,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600),'w') as f:f.write(secrets.token_urlsafe(12))
    admin_key=key.read_text().strip()
def formation(code):
    team=DATA['teams'].get(code);require(team,'Nieznana reprezentacja')
    return team
def spec(m):
    nh=m.get('nationH','pol');na=m.get('nationA','eng')
    h,a=formation(nh),formation(na)
    def option(k,values,default):
        value=m.get(k,default);return value if value in values else default
    return dict(nationH=nh,nationA=na,home=label(m.get('home') or h['pl'],32),away=label(m.get('away') or a['pl'],32),
       half=option('half',[60,120,180,300,2700],120),diff=option('diff',[0,1,2,3],3),ref=option('ref',[0,1,2],1),mode=2,lang=option('lang',['pl','en'],'pl'),
       weather=option('weather',['clear','rain','snow','fog'],'clear'),stadium=option('stadium',['classic','arena','terrace'],'classic'),
       formH=option('formH',['4-3-3','4-4-2','4-2-3-1'],'4-3-3'),formA=option('formA',['4-3-3','4-4-2','4-2-3-1'],'4-4-2'),
       tacticH=option('tacticH',['balanced','press','counter'],'balanced'),tacticA=option('tacticA',['balanced','press','counter'],'balanced'),
       stripH=option('stripH',['home','away'],'home'),stripA=option('stripA',['home','away'],'away' if na==nh else 'home'),
       ballStyle=option('ballStyle',['classic','winter','wave'],'classic'),night=option('night',[0,1],0))
def roomrow(r):
    result=one('SELECT * FROM rooms WHERE id=?',r);require(result,'Brak meczu',404);return result
def seat_map(room,active=False):
    rows=query('SELECT s.slot,p.nick,s.seen FROM seats s JOIN profiles p ON p.id=s.uid WHERE room=?',room)
    return {str(r['slot']):r['nick'] for r in rows if not active or time.time()-r['seen']<6}
class Worker:
    def __init__(self,row):
        self.id=row['id'];self.condition=threading.Condition();self.frame=None;self.sequence=0;self.failed=False
        self.write_lock=threading.Lock();self.seats=seat_map(self.id,True)
        node=shutil.which('node') or shutil.which('nodejs');require(node,'Zainstaluj Node.js na gospodarzu',503)
        self.proc=subprocess.Popen([node,str(ROOT/'lan/engine.cjs')],cwd=ROOT,stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True,bufsize=1)
        self.thread=threading.Thread(target=self.read,daemon=True);self.thread.start()
        self.send(dict(op='start',config=json.loads(row['config']),saved=json.loads(row['save']) if row['save'] else None,seats=self.seats))
    def send(self,obj):
        try:
            with self.write_lock:self.proc.stdin.write(js(obj)+'\n');self.proc.stdin.flush()
        except (BrokenPipeError,ValueError):self.failed=True
    def read(self):
        try:
            for line in self.proc.stdout:
                packet=json.loads(line)
                if 'state' in packet:
                    with self.condition:
                        self.sequence+=1;self.frame=packet['state'];self.frame['revision']=self.sequence;self.frame['seats']=self.seats;self.condition.notify_all()
                if 'save' in packet:
                    state=packet['state'];finished=state['state']=='fulltime'
                    result=dict(score=state['score'],stats=state['stats'],events=packet['save']['records'],players=[[p[9],p[12],p[13]] for p in state['players']],departed=[t['departed'] for t in packet['save']['teams']])
                    run('UPDATE rooms SET save=?,status=?,result=? WHERE id=?',js(packet['save']),'done' if finished else 'live',js(result),self.id)
        finally:
            with self.condition:self.failed=True;self.condition.notify_all()
    def wait(self,after):
        with self.condition:
            self.condition.wait_for(lambda:self.frame is not None and self.sequence!=after or self.failed,1.5)
            require(self.frame is not None,'Silnik meczu nie odpowiedział',503)
            return self.frame
    def update_seats(self):
        m=seat_map(self.id,True)
        if m!=self.seats:self.seats=m;self.send(dict(op='seat',seats=m))
def worker(room):
    with LOCK:
        w=workers.get(room)
        if not w or w.failed:
            row=roomrow(room);w=workers[room]=Worker(row)
        return w
def roomlist():
    out=query('SELECT id,name,owner,cup,h,a,status,config,result FROM rooms ORDER BY id DESC')
    for r in out:r['config']=json.loads(r['config']);r['score']=json.loads(r.pop('result') or '{}').get('score',[0,0]);r['seats']=seat_map(r['id'],True)
    return out
def standings(rows,which):
    scores={}
    for r in rows:
        if r['cup']!=which:continue
        for side in [r['h'],r['a']]:scores.setdefault(side,dict(clan=side,played=0,points=0,gf=0,ga=0))
        if r['status']!='done':continue
        a,b=r['score']
        for side,x,y in [(r['h'],a,b),(r['a'],b,a)]:
            s=scores[side];s['played']+=1;s['gf']+=x;s['ga']+=y;s['points']+=3 if x>y else 1 if x==y else 0
    return sorted(scores.values(),key=lambda r:(r['points'],r['gf']-r['ga'],r['gf']),reverse=True)
class Handler(BaseHTTPRequestHandler):
    server_version='SuperPilkaLAN/1'
    def log_message(self,*args):pass
    def reply(self,data,status=200,mime='application/json; charset=utf-8'):
        if not isinstance(data,bytes):data=js(data).encode()
        self.send_response(status);self.send_header('Content-Type',mime);self.send_header('Content-Length',str(len(data)));self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff');self.end_headers();self.wfile.write(data)
    def auth(self,needed=True):
        token=self.headers.get('Authorization','').removeprefix('Bearer ')
        u=one('SELECT p.id,p.nick,s.admin FROM sessions s JOIN profiles p ON p.id=s.uid WHERE token=? AND until>?',tokenhash(token),int(time.time())) if token else None
        if needed:require(u,'Zaloguj się',401)
        return u
    def handle_one(self,post):
        try:
            parts=urlsplit(self.path);path=parts.path;args={k:v[-1] for k,v in parse_qs(parts.query).items()}
            if post:
                origin=self.headers.get('Origin')
                require(not origin or urlsplit(origin).netloc==self.headers.get('Host'),'Nieprawidłowe pochodzenie',403)
                size=int(self.headers.get('Content-Length','0'));require(0<size<=32768,'Nieprawidłowy rozmiar')
                args=json.loads(self.rfile.read(size));require(isinstance(args,dict),'Nieprawidłowy JSON')
            if not post and path in ('/','/index.html','/super-pilka-98.html'):
                return self.reply((ROOT/'super-pilka-98.html').read_bytes(),mime='text/html; charset=utf-8')
            if not post and path=='/api/info':
                profile=self.auth(False)
                if profile:profile['played']=one("SELECT COUNT(*) n FROM appearances a JOIN rooms r ON r.id=a.room WHERE a.uid=? AND r.status!='ready'",profile['id'])['n']
                return self.reply(dict(lan=True,profile=profile,clans=query('SELECT id,name,owner FROM clans'),cups=query('SELECT * FROM cups'),rooms=roomlist()))
            if not post and path=='/api/state':
                r=int(args['room']);row=one('SELECT status FROM rooms WHERE id=?',r);require(row,'Brak meczu',404);require(row['status']!='ready','Organizator jeszcze nie rozpoczął meczu',409)
                return self.reply(worker(r).wait(int(args.get('after',-1))))
            if not post and path=='/api/history':
                rooms=roomlist();c=int(args.get('clan',0));cup=int(args.get('cup',0));r=int(args.get('room',0))
                matches=[a for a in rooms if (not c or c in (a['h'],a['a'])) and (not cup or cup==a['cup']) and (not r or r==a['id'])]
                for m in matches:m['record']=json.loads(roomrow(m['id'])['result'] or '{}')
                summary=None
                if c:
                    summary=dict(played=0,wins=0,draws=0,losses=0,gf=0,ga=0,points=0)
                    for m in matches:
                        if m['status']!='done':continue
                        gf,ga=m['score'] if m['h']==c else m['score'][::-1]
                        summary['played']+=1;summary['gf']+=gf;summary['ga']+=ga
                        summary['wins' if gf>ga else 'draws' if gf==ga else 'losses']+=1
                    summary['points']=3*summary['wins']+summary['draws']
                table=standings(rooms,cup) if cup else [];champions=[]
                if table and all(m['status']=='done' for m in rooms if m['cup']==cup):
                    def rank(t):return t['points'],t['gf']-t['ga'],t['gf']
                    champions=[row['clan'] for row in table if rank(row)==rank(table[0])]
                return self.reply(dict(matches=matches,table=table,summary=summary,champions=champions))
            if not post and path=='/api/nick.wav':
                nick=label(args['nick'],28);lang=args.get('lang','pl');require(lang in ['pl','en'] and one('SELECT id FROM profiles WHERE nick=?',nick),'Brak profilu',404)
                dst=conf/'voices'/(tokenhash(lang+nick)+'.wav')
                if not dst.is_file():
                    raw=speech(nick,lang);tmp=dst.with_suffix('.'+secrets.token_hex(5));tmp.write_bytes(raw);os.replace(tmp,dst)
                return self.reply(dst.read_bytes(),mime='audio/wav')
            require(post,'Nie znaleziono',404)
            if path in ('/api/register','/api/login'):
                nick=label(args['nick'],28);pw=str(args['password']);require(6<=len(pw)<=180,'Hasło musi mieć od 6 do 180 znaków')
                if path.endswith('register'):
                    salt=secrets.token_hex(16);hashed=password(pw,salt);run('INSERT INTO profiles(nick,key,salt,pw) VALUES(?,?,?,?)',nick,nick.casefold(),salt,hashed)
                profile=one('SELECT * FROM profiles WHERE key=?',nick.casefold())
                require(profile and hmac.compare_digest(profile['pw'],password(pw,profile['salt'])),'Błędny login lub hasło',401)
                token=secrets.token_urlsafe(32);admin=bool(args.get('admin')) and hmac.compare_digest(str(args['admin']),admin_key)
                run('INSERT INTO sessions VALUES(?,?,?,?)',tokenhash(token),profile['id'],int(admin),int(time.time())+30*86400)
                return self.reply(dict(token=token,nick=profile['nick'],id=profile['id'],admin=admin))
            u=self.auth();uid=u['id']
            if path=='/api/logout':
                run('DELETE FROM sessions WHERE token=?',tokenhash(self.headers['Authorization'].removeprefix('Bearer ')));return self.reply({})
            if path=='/api/clan':
                name=label(args['name']);clan=run('INSERT INTO clans(name,owner) VALUES(?,?)',name,uid);run('INSERT INTO members VALUES(?,?)',clan,uid);return self.reply({'id':clan})
            if path=='/api/join-clan':
                clan=int(args['clan']);require(one('SELECT id FROM clans WHERE id=?',clan),'Nieznany klan');run('INSERT OR IGNORE INTO members VALUES(?,?)',clan,uid);return self.reply({})
            if path=='/api/cup':
                name=label(args['name']);ids=list(dict.fromkeys(map(int,args['clans'])));require(2<=len(ids)<=16,'Wybierz 2–16 klanów')
                clubs={c['id']:c['name'] for c in query('SELECT id,name FROM clans')};require(all(i in clubs for i in ids),'Nieznany klan')
                scope=args.get('scope','class');require(scope in ('class','world'),'Nieznany rodzaj turnieju')
                config=spec(args.get('config',{}))
                with LOCK,db:
                    cup=db.execute('INSERT INTO cups(name,scope,owner) VALUES(?,?,?)',(name,scope,uid)).lastrowid
                    for j,h in enumerate(ids):
                        for a in ids[j+1:]:
                            db.execute('INSERT INTO rooms(name,owner,config,cup,h,a) VALUES(?,?,?,?,?,?)',(clubs[h]+' – '+clubs[a],uid,js(dict(config,home=clubs[h],away=clubs[a])),cup,h,a))
                return self.reply({'id':cup})
            if path=='/api/room':
                config=spec(args.get('config',{}));h=int(args.get('h',0));a=int(args.get('a',0))
                require(not h or h!=a,'Wybierz dwa różne klany')
                for k,team in [(h,'home'),(a,'away')]:
                    if k:
                        clan=one('SELECT name FROM clans WHERE id=?',k);require(clan,'Nieznany klan');config[team]=clan['name']
                room=run('INSERT INTO rooms(name,owner,config,h,a) VALUES(?,?,?,?,?)',label(args.get('name') or config['home']+' – '+config['away']),uid,js(config),h,a)
                return self.reply({'id':room})
            r=int(args['room']);row=one('SELECT status,owner,h,a FROM rooms WHERE id=?',r);require(row,'Brak meczu',404)
            if path in ('/api/start','/api/pause','/api/sub'):
                require(u['admin'] or row['owner']==uid,'Tylko organizator',403)
                if path=='/api/start':
                    require(row['status']!='done','Mecz zakończony',409);run("UPDATE rooms SET status='live' WHERE id=?",r);worker(r)
                elif path=='/api/pause':
                    require(row['status']=='live','Mecz nie jest w toku',409);worker(r).send(dict(op='pause',value=bool(args.get('value'))))
                else:
                    team,idx,num=map(int,[args['team'],args['idx'],args['num']])
                    require(row['status']=='live' and team in (0,1) and 0<=idx<11 and 1<=num<=99,'Nieprawidłowa zmiana')
                    w=worker(r);current=w.wait(-1);player=current['players'][team*11+idx]
                    require(not player[11] and current['changes'][team]<5 and any(n['num']==num and (n['role']=='GK')==(player[14]=='GK') for n in current['bench'][team]),'Zmiana niedostępna')
                    w.send(dict(op='sub',team=team,idx=idx,num=num))
                return self.reply({})
            if path=='/api/seat':
                slot=int(args['slot']);require(0<=slot<22,'Pozycja poza składem');require(row['status']!='done','Mecz zakończony')
                clan=row['h'] if slot<11 else row['a']
                if clan:require(one('SELECT uid FROM members WHERE uid=? AND clan=?',uid,clan),'Najpierw dołącz do klanu',403)
                with LOCK,db:
                    occupied=db.execute('SELECT uid,seen FROM seats WHERE room=? AND slot=?',(r,slot)).fetchone()
                    require(not occupied or occupied['uid']==uid or time.time()-occupied['seen']>20,'Miejsce zajęte',409)
                    db.execute('DELETE FROM seats WHERE room=? AND (uid=? OR slot=?)',(r,uid,slot));db.execute('INSERT INTO seats VALUES(?,?,?,?)',(r,slot,uid,time.time()))
                    db.execute('INSERT OR REPLACE INTO appearances VALUES(?,?,?)',(uid,r,slot))
                if r in workers:workers[r].update_seats()
                return self.reply({'slot':slot})
            if path=='/api/leave':
                run('DELETE FROM seats WHERE room=? AND uid=?',r,uid)
                if r in workers:workers[r].update_seats()
                return self.reply({})
            if path=='/api/input':
                n=args.get('input',{});ctrl={k:bool(n.get(k)) for k in ('pass','shot','cross','through','skip','passEdge','shotEdge','crossEdge','throughEdge','skipEdge','shotUp','sprint','close')}
                for k in ('x','z','mx','mz'):
                    v=float(n.get(k,0));require(math.isfinite(v),'Nieprawidłowy kierunek');ctrl[k]=max(-1,min(1,v))
                ctrl['seq']=int(n.get('seq',0))
                with LOCK:
                    seat=one('SELECT slot,seen FROM seats WHERE room=? AND uid=?',r,uid);require(seat,'Wybierz zawodnika',403)
                    if time.time()-seat['seen']>=.65:run('UPDATE seats SET seen=? WHERE room=? AND uid=?',time.time(),r,uid)
                    if row['status']=='live':
                        w=worker(r)
                        if str(seat['slot']) not in w.seats:w.update_seats()
                        w.send(dict(op='input',slot=seat['slot'],input=ctrl))
                return self.reply({})
            raise ApiError(404,'Nie znaleziono')
        except (BrokenPipeError,ConnectionResetError):pass
        except ApiError as e:self.reply({'error':str(e)},e.code)
        except sqlite3.IntegrityError:self.reply({'error':'Ta nazwa lub pozycja jest już zajęta'},409)
        except (KeyError,TypeError,ValueError,OverflowError):self.reply({'error':'Nieprawidłowe dane'},400)
        except Exception as e:
            print('Błąd serwera:',repr(e),file=sys.stderr);self.reply({'error':'Błąd serwera'},500)
    def do_GET(self):self.handle_one(False)
    def do_POST(self):self.handle_one(True)
class Server(ThreadingHTTPServer):
    daemon_threads=True
    request_queue_size=96
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--port',type=int,default=8906);parser.add_argument('--bind',default='0.0.0.0');parser.add_argument('--data',type=Path,default=ROOT/'conf');a=parser.parse_args()
    if not shutil.which('node') and not shutil.which('nodejs'):parser.error('Serwer wymaga Node.js 18 lub nowszego.')
    build();init_database(a.data);srv=Server((a.bind,a.port),Handler)
    print('Super Piłka LAN: http://localhost:'+str(srv.server_port)+' · klucz administratora w '+str(conf/'admin.key'),flush=True)
    for r in query("SELECT id FROM rooms WHERE status='live'"):worker(r['id'])
    def maintain():
        while True:
            time.sleep(2)
            for w in list(workers.values()):
                if not w.failed:w.update_seats()
    threading.Thread(target=maintain,daemon=True).start()
    def shut(*_):threading.Thread(target=srv.shutdown,daemon=True).start()
    signal.signal(signal.SIGTERM,shut);signal.signal(signal.SIGINT,shut)
    try:srv.serve_forever()
    finally:
        srv.server_close()
        for w in list(workers.values()):
            if not w.failed:w.send({'op':'stop'})
        for w in list(workers.values()):
            try:w.proc.wait(timeout=3);w.thread.join(1)
            except subprocess.TimeoutExpired:w.proc.terminate()
if __name__=='__main__':main()
