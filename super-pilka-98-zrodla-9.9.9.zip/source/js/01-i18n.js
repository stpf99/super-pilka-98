/* ============================================================
   SUPER PILKA '98 · 01-i18n.js — teksty PL/EN
   ============================================================ */
var I18N = {
pl: {
  /* menu */
  s_match:"Mecz", s_look:"Wygląd", s_teams:"Drużyny",
  s_mode:"Tryb gry", m0:"Solo", m1:"Dwie osoby", m2:"Obserwator",
  s_half:"Czas połowy", s_diff:"Poziom AI", s_ref:"Sędzia (faule)",
  s_cam:"Kamera", s_gfx:"Jakość grafiki", s_sfx:"Dźwięk",
  s_lang:"Język", s_home:"Gospodarze", s_away:"Goście",
  d3:"Początkujący", d0:"Łatwy", d1:"Normalny", d2:"Trudny",
  r0:"Łagodny", r1:"Normalny", r2:"Surowy",
  c0:"TV 2000", c1:"Góra '98", c2:"Za piłką",
  s_light:"Oświetlenie", n0:"Dzień", n1:"Reflektory",
  rep:"POWTÓRKA", rep_skip:"C / Select — pomiń powtórkę",
  q0:"Niska", q1:"Średnia", q2:"Wysoka",
  off0:"Wyłącz", on06:"60%", on1:"100%",
  b_play:"Rozpocznij mecz", b_help:"Sterowanie", b_back:"Wróć",
  note_pads:"Podłącz pady i naciśnij dowolny przycisk, aby je wykryć. Bez padów: gracz 1 — lewa strona klawiatury, gracz 2 — strzałki.",
  menuSub:"Mecz 11 na 11 · dwa pady · pełne zasady",
  /* pomoc */
  h_controls:"Sterowanie", h_p1:"Gracz 1 · klawiatura", h_p2:"Gracz 2 · klawiatura",
  h_pad1:"PAD 1 — GRACZ 1", h_pad2:"PAD 2 — GRACZ 2", h_pad:"Pad · Xbox / PlayStation",
  h_note:"Przytrzymaj podanie lub strzał, aby ustalić siłę. Po podaniu sterowanie przechodzi na adresata. Lewa gałka lub klawisze ruchu wskazują kierunek na ekranie.",
  h_note_kb:"Gracz 1 bez pada: WASD + K L J I O. Gracz 2 bez pada 2: strzałki + , . / M N.",
  /* pauza / koniec */
  p_title:"Pauza", p_resume:"Wznów mecz", p_set:"Ustawienia", p_restart:"Od początku",
  p_quit:"Menu główne", p_note:"ESC lub START — pauza. Zmiany ustawień działają od razu.",
  e_full:"Koniec meczu", e_re:"Rewanż", e_menu:"Menu", e_win:"WYGRYWA", e_draw:"REMIS",
  /* HUD / restarty */
  k1p:"1P", k2p:"2P", k1p_done:"KONIEC", pen:"karne",
  rst_kick:"Rozpoczęcie gry", rst_corner:"RZUT ROŻNY", rst_throw:"AUT",
  rst_goalkick:"WYKOP OD BRAMKI", rst_free:"Rzut wolny", rst_pen:"RZUT KARNY",
  hint_kick:"{T} · {A} aby rozpocząć",
  hint_generic:"Lewo/prawo: cel · {A} krótko · przytrzymaj {B} i puść",
  hint_throw:"{T} · wyceluj, przytrzymaj {A} i puść",
  hint_pen:"Lewo/prawo: cel · przytrzymaj {B} i puść",
  hint_cpu:"Wznowienie komputera",
  hint_pause:"",
  /* komentator */
  c_goal:["GOOOOL! Świetne uderzenie!","GOOOL! Trybuna szaleje!","GOL! Idealne podanie i wykończenie!","Gol! Piłka w siatce!"],
  c_rep:["Obejrzyjmy powtórkę tej akcji.","Powtórka z drugiej kamery — patrzcie na to!","Zwolnione tempo — co za moment!"],
  c_foul:["Faul! Sędzia nic nie pomylił.","Przerwanie gry — faul.","Ostre wejście! Faul."],
  c_yellow:["Żółta kartka!","Spóźnione wejście i żółta kartka.","Zagrożenie zdrowia? Sędzia pokazuje żółty."],
  c_red:["CZERWONA KARTKA! Gra w dziesiątkę!","Feralne wejście — czerwona kartka!","Sędzia nie miał wątpliwości — czerwona!"],
  c_off:["Spalony! Linia była czujna.","Spalony! Chorągiewka podniesiona.","Spalony — chwilę za wcześnie ruszył."],
  c_corner:["Rzut rożny!","Piłka za bramką — rożny."],
  c_throw:["Aut dla {T}.","Wrzut z autu dla {T}."],
  c_gk:["Wykop od bramki dla {T}.","Piłka wybita — od bramki {T}."],
  c_free:["Rzut wolny dla {T}.","Przerwanie — wolny dla {T}."],
  c_pen:["RZUT KARNY! Piłka na jedenastym metrze.","Karny! Decyzja bez wahania!"],
  c_half:["Koniec połowy."], c_full:["Koniec meczu!"],
  c_kick:["Zaczynamy!","Piłka w grze — do dzieła!"],
  c_save:["Świetna obrona bramkarza!","Paruje! Piłka odbita!"],
  c_post:["Rama! Piłka trafia w poprzeczkę!","Żelazna rama!"],
  c_header:"Główka!",
  c_miss:["Nad poprzeczką!","Próba niecelna."],
  h_m_move:"Bieg", h_m_pass:"Podanie / pressing", h_m_shoot:"Strzał / odbiór na stojąco", h_m_tackle:"Dośrodkowanie / wślizg",
  h_m_through:"Podanie prostopadłe", h_m_sprint:"Sprint", h_m_switch:"Zmiana gracza w obronie",
  h_m_cam:"Zmiana kamery", h_m_pause:"Pauza", h_m_zoom:"Zoom kamery (mysz)",
  b_yellow:"ŻÓŁTA KARTKA", b_red:"CZERWONA KARTKA",
  /* statystyki */
  st_poss:"Posiadanie", st_shots:"Strzały", st_target:"Strzały celne",
  st_corr:"Rożne", st_fouls:"Faule", st_yel:"Żółte kartki", st_red:"Czerwone kartki",
  st_pass:"Podania celne",
  /* telebim */
  tv_kick:"MECZ ROZPOCZĘTY", tv_goal:"GOL! {M}' — {T}  {S}",
  tv_yel:"ŻÓŁTA KARTKA · nr {N} — {T}", tv_red:"CZERWONA KARTKA · nr {N} — {T}",
  tv_pen:"RZUT KARNY — {T}", tv_off:"SPALONY",
  tv_half:"PRZERWA", tv_full:"KONIEC MECZU",
  lag:"klatek/s: {V} · pad1:{A} pad2:{B}",
  friendly:"Mecz towarzyski",
  stadium:"Stadion Miejski",
  hero1:"Szybki",
  hero2:"mecz",
  s_tactics:"Taktyka",
  s_form:"Formacja",
  s_plan:"Plan gry",
  plan_balanced:"Balans",
  plan_press:"Pressing",
  plan_counter:"Kontra",
  mode0:"Gracz kontra komputer",
  mode1:"Dwóch graczy lokalnie",
  mode2:"Komputer kontra komputer",
  roleGK:"BR",
  roleDF:"OBR",
  roleMF:"POM",
  roleFW:"NAP",
  own_goal:"Gol samobójczy",
  goal_title:"Gol!",
  half_title:"Przerwa",
  st_accuracy:"Celność podań",
  h_m_finesse:"Strzał techniczny",
  h_m_jockey:"Bliski drybling / obrona bokiem",
  h_m_oneTwo:"Podaj i wyjdź na pozycję",
  offside:"Spalony"
},
en: {
  s_match:"Match", s_look:"Visuals", s_teams:"Teams",
  s_mode:"Game mode", m0:"Solo", m1:"Two players", m2:"Watch",
  s_half:"Half length", s_diff:"AI level", s_ref:"Referee (fouls)",
  s_cam:"Camera", s_gfx:"Graphics quality", s_sfx:"Sound",
  s_lang:"Language", s_home:"Home", s_away:"Away",
  d3:"Beginner", d0:"Easy", d1:"Normal", d2:"Hard",
  r0:"Lenient", r1:"Normal", r2:"Strict",
  c0:"TV 2000", c1:"Top '98", c2:"Behind ball",
  s_light:"Lighting", n0:"Day", n1:"Floodlights",
  rep:"REPLAY", rep_skip:"C / Select — skip replay",
  q0:"Low", q1:"Medium", q2:"High",
  off0:"Off", on06:"60%", on1:"100%",
  b_play:"Kick off", b_help:"Controls", b_back:"Back",
  note_pads:"Plug in gamepads and press any button to detect them. Without pads: player 1 — left keyboard, player 2 — arrow keys.",
  menuSub:"11 vs 11 match · two gamepads · full rules",
  h_controls:"Controls", h_p1:"Player 1 · keyboard", h_p2:"Player 2 · keyboard",
  h_pad1:"PAD 1 — PLAYER 1", h_pad2:"PAD 2 — PLAYER 2", h_pad:"Controller · Xbox / PlayStation",
  h_note:"Hold pass or shoot to set power. After passing, control transfers to the receiver. Aim with the left stick or movement keys relative to the screen.",
  h_note_kb:"Player 1 without a pad: WASD + K L J I O. Player 2 without pad 2: arrows + , . / M N keys.",
  p_title:"Paused", p_resume:"Resume match", p_set:"Settings", p_restart:"Restart",
  p_quit:"Main menu", p_note:"ESC or START — pause. Settings apply immediately.",
  e_full:"Full time", e_re:"Rematch", e_menu:"Menu", e_win:"WINS", e_draw:"DRAW",
  k1p:"1H", k2p:"2H", k1p_done:"FT", pen:"pen",
  rst_kick:"Kick-off", rst_corner:"CORNER", rst_throw:"THROW-IN",
  rst_goalkick:"GOAL KICK", rst_free:"Free kick", rst_pen:"PENALTY",
  hint_kick:"{T} · {A} to kick off",
  hint_generic:"Left/right to aim · {A} short · hold and release {B}",
  hint_throw:"{T} · aim, hold {A} and release",
  hint_pen:"Left/right to aim · hold and release {B}",
  hint_cpu:"Computer restart",
  hint_pause:"",
  c_goal:["GOOOAL! What a strike!","GOAL! The stands erupt!","GOL! Perfect pass and finish!","GOAL! Brilliant play!"],
  c_rep:["Let's watch that one again.","Replay from the second camera — enjoy!","Slow motion — what a moment!"],
  c_foul:["Foul! The referee spotted it.","Play stopped — foul.","Rough tackle! Foul."],
  c_yellow:["Yellow card!","Careless challenge — yellow card.","The referee shows yellow."],
  c_red:["RED CARD! Down to ten men!","Fateful tackle — red card!","No doubt from the referee — red!"],
  c_off:["Offside! The line was alert.","Offside! Flag is up.","Offside — moved a moment too early."],
  c_corner:["Corner kick!","Ball behind the goal — corner."],
  c_throw:["Throw-in for {T}.","Throw-in for {T}."],
  c_gk:["Goal kick for {T}.","Ball cleared — goal kick {T}."],
  c_free:["Free kick for {T}.","Stopped — free kick for {T}."],
  c_pen:["PENALTY! A big decision!","Penalty! No hesitation!"],
  c_half:["End of the half."], c_full:["Full time!"],
  c_kick:["We're underway!","Ball in play — let's go!"],
  c_save:["Brilliant save by the keeper!","He parries it away!"],
  c_post:["The woodwork! Off the crossbar!","Iron frame saves the day!"],
  c_header:"Header!",
  c_miss:["Over the bar!","Off target."],
  h_m_move:"Run", h_m_pass:"Pass / contain", h_m_shoot:"Shoot / standing tackle", h_m_tackle:"Cross / slide tackle",
  h_m_through:"Through ball", h_m_sprint:"Sprint", h_m_switch:"Switch defender",
  h_m_cam:"Change camera", h_m_pause:"Pause", h_m_zoom:"Camera zoom (mouse)",
  b_yellow:"YELLOW CARD", b_red:"RED CARD",
  st_poss:"Possession", st_shots:"Shots", st_target:"Shots on target",
  st_corr:"Corners", st_fouls:"Fouls", st_yel:"Yellow cards", st_red:"Red cards",
  st_pass:"Completed passes",
  /* jumbotron */
  tv_kick:"KICK-OFF", tv_goal:"GOAL! {M}' — {T}  {S}",
  tv_yel:"YELLOW CARD · no. {N} — {T}", tv_red:"RED CARD · no. {N} — {T}",
  tv_pen:"PENALTY — {T}", tv_off:"OFFSIDE",
  tv_half:"HALF-TIME", tv_full:"FULL-TIME",
  lag:"fps: {V} · pad1:{A} pad2:{B}",
  friendly:"Friendly match",
  stadium:"City Stadium",
  hero1:"Kick",
  hero2:"off",
  s_tactics:"Tactics",
  s_form:"Formation",
  s_plan:"Game plan",
  plan_balanced:"Balanced",
  plan_press:"Press",
  plan_counter:"Counter",
  mode0:"Player vs computer",
  mode1:"Local head-to-head",
  mode2:"Computer vs computer",
  roleGK:"GK",
  roleDF:"DEF",
  roleMF:"MID",
  roleFW:"FWD",
  own_goal:"Own goal",
  goal_title:"Goal!",
  half_title:"Half-time",
  st_accuracy:"Pass accuracy",
  h_m_finesse:"Finesse shot",
  h_m_jockey:"Close control / jockey",
  h_m_oneTwo:"Pass and go",
  offside:"Offside"
}};
Object.assign(I18N.pl,{
  c3:"Za graczem",see_model:"Obejrzyj model 3D", player_view:"Podgląd zawodnika", anim:"Ruch", frame:"Kadr",
  frame_face:"Zbliżenie twarzy",faceAnim:"Mimika",trapHead:"Przyjęcie głową",trapChest:"Przyjęcie klatką piersiową",
  trapThigh:"Przyjęcie udem / kolanem",trapFoot:"Przyjęcie stopą",
  frame_body:"Cała sylwetka",frame_upper:"Twarz i dłonie",frame_feet:"Kolana i buty",
  idle:"Postawa", jog:"Trucht", sprint:"Sprint", shootAnim:"Strzał", passAnim:"Podanie", slideAnim:"Wślizg",
  diveAnim:"Parada bramkarza", throwAnim:"Wrzut z autu", headAnim:"Główka", jockeyAnim:"Obrona bokiem"
});
Object.assign(I18N.en,{
  c3:"Player cam",see_model:"Inspect 3D player",player_view:"Player preview",anim:"Movement",frame:"Framing",
  frame_face:"Face close-up",faceAnim:"Facial expressions",trapHead:"Head control",trapChest:"Chest control",
  trapThigh:"Thigh / knee control",trapFoot:"Instep control",
  frame_body:"Full body",frame_upper:"Face and hands",frame_feet:"Knees and boots",
  idle:"Idle",jog:"Jog",sprint:"Sprint",shootAnim:"Shot",passAnim:"Pass",slideAnim:"Slide tackle",
  diveAnim:"Goalkeeper dive",throwAnim:"Throw-in",headAnim:"Header",jockeyAnim:"Jockey"
});
Object.assign(I18N.pl,{tour_open:"Zwiedź stadion",tour_pan:"Panorama",tour_pitch:"Z murawy",tour_drum:"Bęben",tour_brass:"Trąbka"});
Object.assign(I18N.en,{tour_open:"Explore stadium",tour_pan:"Panorama",tour_pitch:"Pitchside",tour_drum:"Drum",tour_brass:"Trumpet"});
Object.assign(I18N.pl,{goalCount:"{N}. gol",friendly:"Mecz towarzyski",first_half:"Pierwsza połowa",second_half:"Druga połowa",
  scene_skip:"C / Select · pomiń",goalRunAnim:"Bieg po golu",goalAnim:"Wyskok po golu",protestAnim:"Reakcja na kartkę"});
Object.assign(I18N.en,{goalCount:"Goal No. {N}",friendly:"Friendly match",first_half:"First half",second_half:"Second half",
  scene_skip:"C / Select · skip",goalRunAnim:"Celebration run",goalAnim:"Goal jump",protestAnim:"Booking reaction"});
Object.assign(I18N.pl,{
  rst_indirect:"Rzut wolny pośredni",f_trip:"Podstawienie nogi",f_lateTackle:"Spóźnione wejście",f_charge:"Niedozwolone szarżowanie",
  f_slidingFoul:"Wślizg w nogi",f_keeperContact:"Atak na bramkarza trzymającego piłkę",
  f_serious:"Poważny, rażący faul",f_reckless:"Nierozważny atak",f_persistent:"Uporczywe przewinienia",
  f_promising:"Przerwanie korzystnej akcji",f_dogso:"Pozbawienie realnej szansy na bramkę",
  secondCaution:"Druga żółta kartka",secondSent:"Czerwona po drugiej żółtej"
});
Object.assign(I18N.en,{
  rst_indirect:"Indirect free kick",f_trip:"Tripping",f_lateTackle:"Late challenge",f_charge:"Illegal charge",f_slidingFoul:"Foul sliding tackle",
  f_keeperContact:"Challenge on a keeper holding the ball",f_serious:"Serious foul play",f_reckless:"Reckless challenge",
  f_persistent:"Persistent offences",f_promising:"Stopping a promising attack",f_dogso:"Denying an obvious goal-scoring opportunity",
  secondCaution:"Second yellow card",secondSent:"Sent off after a second caution"
});
Object.assign(I18N.pl,{national:"Reprezentacja",strip:"Strój",homeKit:"Podstawowy",awayKit:"Wyjazdowy",venuePick:"Stadion",ballPick:"Piłka",weatherPick:"Pogoda",classicBall:"Klasyczna",waveBall:"Błękitna fala",winterBall:"Pomarańczowa",clear:"Pogodnie",rain:"Deszcz",snow:"Śnieg",fog:"Mgła",subs:"Zmiany zawodników",freshPlayers:"Zmiana przy przerwie w grze",leave:"Schodzi",enter:"Wchodzi",sidePick:"Drużyna",queueSub:"Zgłoś zmianę",pending:"Oczekujące",advantage:"Korzyść • grać dalej",f_handball:"Zagranie ręką",added:"Czas doliczony",c4:"Inteligentna",anthem:"Hymn drużyny",cupLift:"Wręczenie pucharu",opening:"Ceremonia otwarcia",flipAnim:"Salto po golu",kneeSlideAnim:"Ślizg na kolanach"});
Object.assign(I18N.en,{national:"National team",strip:"Kit",homeKit:"Home",awayKit:"Away",venuePick:"Stadium",ballPick:"Ball",weatherPick:"Weather",classicBall:"Classic",waveBall:"Blue wave",winterBall:"Winter orange",clear:"Clear",rain:"Rain",snow:"Snow",fog:"Fog",subs:"Substitutions",freshPlayers:"Change at a stoppage",leave:"Coming off",enter:"Coming on",sidePick:"Team",queueSub:"Request change",pending:"Pending",advantage:"Advantage • play on",f_handball:"Handball",added:"Added time",c4:"Auto director",anthem:"Team anthem",cupLift:"Trophy presentation",opening:"Opening ceremony",flipAnim:"Goal somersault",kneeSlideAnim:"Knee slide"});
var I18N_cur = "pl";
function t(k){ var d=I18N[I18N_cur]||I18N.pl; return (d[k]!==undefined)?d[k]:(I18N.pl[k]!==undefined?I18N.pl[k]:k); }
function tPick(k){ var a=t(k); return a[Math.floor(Math.random()*a.length)]; }
function applyI18n(){
  document.querySelectorAll("[data-i18n]").forEach(function(el){
    var v=I18N[I18N_cur]&&I18N[I18N_cur][el.getAttribute("data-i18n")];
    if(v!==undefined) el.textContent=v;
  });
  document.documentElement.lang = I18N_cur;
  if(typeof HUD !== "undefined" && HUD.buildHelp) HUD.buildHelp();
}

Object.assign(I18N.pl,{squadList:"Kadra i sztab",coachLabel:"Trener",refLabel:"Sędzia",benchLabel:"Rezerwowi"});
Object.assign(I18N.en,{squadList:"Squad and staff",coachLabel:"Coach",refLabel:"Match official",benchLabel:"Substitutes"});

Object.assign(I18N.pl,{volleyAnim:"Wolej z boku",turnStrikeAnim:"Uderzenie z półobrotu"});
Object.assign(I18N.en,{volleyAnim:"Side volley",turnStrikeAnim:"Turning strike"});
