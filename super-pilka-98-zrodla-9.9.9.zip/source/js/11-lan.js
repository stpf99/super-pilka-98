/* LAN transmits football state and inputs. Every browser renders its own scene. */
var LAN={
  active:false,token:"",room:null,slot:-1,generation:0,mode:"fan",seq:Date.now()*1000,turn:0,tilt:0,fanFov:47,
  el:function(id){return document.getElementById(id);},
  num:function(id,min,max){return Math.min(max,Math.max(min,Number(this.el(id).value)||min));},
  msg:function(message){this.el(this.active?"lanStatus":"lanMessage").textContent=message;},
  api:async function(path,body){
    var opts={headers:{},cache:"no-store"};
    if(this.token)opts.headers.Authorization="Bearer "+this.token;
    if(body!==undefined){opts.method="POST";opts.headers["Content-Type"]="application/json";opts.body=JSON.stringify(body);}
    var res=await fetch("/api/"+path,opts),data;
    try{data=await res.json();}catch(e){throw Error("Uruchom serwer poleceniem python3 serve.py --port 8906.");}
    if(!res.ok)throw Error(data.error||("HTTP "+res.status));return data;
  },
  sayNick:function(nick){
    if(!SET.snd || !nick || typeof Audio==="undefined")return;
    if(this.nickAudio)this.nickAudio.pause();
    this.nickAudio=new Audio("/api/nick.wav?lang="+SET.lang+"&nick="+encodeURIComponent(nick));
    this.nickAudio.volume=Math.min(1,SET.snd*.8);this.nickAudio.play().catch(()=>{});
  },
  options:function(id,items,value){
    var sel=this.el(id),prev=value===undefined?sel.value:String(value);
    sel.replaceChildren();items.forEach(function(item){var o=document.createElement("option");o.value=item[0];o.textContent=item[1];o.disabled=!!item[2];sel.add(o);});
    var choice=items.find(function(i){return String(i[0])===prev && !i[2];})||items.find(function(i){return !i[2];});
    if(choice)sel.value=choice[0];
  },
  config:function(){
    var c={};["nationH","nationA","home","away","stripH","stripA","stadium","weather","half","diff","ballStyle","night","lang","formH","formA","tacticH","tacticA","ref"].forEach(function(k){c[k]=SET[k];});return c;
  },
  init:function(){
    var self=this;try{this.token=localStorage.getItem("sp98.lan.session")||"";}catch(e){}
    function button(id,fn){self.el(id).onclick=async function(){try{await fn();}catch(e){self.msg(e.message);}};}
    button("btnLan",()=>self.open());button("lanBack",()=>{self.el("ovLan").classList.add("hide");self.el("ovMenu").classList.remove("hide");});
    ["Login","Register"].forEach(k=>button("lan"+k,async()=>{
      var p=await self.api(k.toLowerCase(),{nick:self.el("lanNick").value,password:self.el("lanPassword").value,admin:self.el("lanKey").value});
      self.token=p.token;try{localStorage.setItem("sp98.lan.session",p.token);}catch(e){}
      self.el("lanPassword").value=self.el("lanKey").value="";await self.refresh();self.msg("Zalogowano jako "+p.nick);self.sayNick(p.nick);
    }));
    button("lanLogout",async()=>{await self.api("logout",{});self.token="";try{localStorage.removeItem("sp98.lan.session");}catch(e){}await self.refresh();});
    button("lanRefresh",()=>self.refresh());self.el("lanRooms").onchange=()=>self.pick();
    button("lanNewClan",async()=>{await self.api("clan",{name:self.el("lanClanName").value});await self.refresh();self.msg("Utworzono klan.");});
    button("lanJoin",async()=>{await self.api("join-clan",{clan:+self.el("lanJoinId").value});self.msg("Dołączono do klanu.");});
    button("lanNewRoom",async()=>{var r=await self.api("room",{name:self.el("lanRoomName").value,config:self.config(),h:+self.el("lanHomeClan").value,a:+self.el("lanAwayClan").value});await self.refresh(r.id);self.msg("Mecz gotowy do rozpoczęcia.");});
    button("lanNewCup",async()=>{var ids=Array.from(self.el("lanCupClans").selectedOptions,o=>+o.value);var ret=await self.api("cup",{name:self.el("lanCupName").value,scope:self.el("lanScope").value,clans:ids,config:self.config()});await self.refresh();self.el("lanHistoryCup").value=ret.id;await self.history(false);self.msg("Utworzono terminarz turnieju.");});
    button("lanStart",async()=>{var r=self.picked();await self.api("start",{room:r.id});await self.refresh(r.id);self.msg("Mecz rozpoczęty.");});
    button("lanPlay",()=>self.enter("play"));button("lanWatch",()=>self.enter("fan"));button("lanDirect",()=>self.enter("director"));
    button("lanHistory",()=>self.history(false));button("lanMatchStats",()=>self.history(true));button("lanExit",()=>self.exit());
    button("lanPause",()=>self.api("pause",{room:self.room.id,value:!self.last?.paused}));
    button("lanManageSubs",()=>{self.el("lanSubTools").hidden=!self.el("lanSubTools").hidden;self.subOptions();});
    self.el("lanSubOut").onchange=()=>self.subOptions();button("lanSubSend",async()=>{var i=+self.el("lanSubOut").value;await self.api("sub",{room:self.room.id,team:Math.floor(i/11),idx:i%11,num:+self.el("lanSubIn").value});self.el("lanSubTools").hidden=true;self.msg("Zgłoszono zmianę na najbliższą przerwę.");});
    this.el("lanView").onchange=()=>self.view(self.el("lanView").value);
    ["lanGroup","lanTrack","lanCols"].forEach(id=>self.el(id).onchange=()=>{self.layoutKey="";});
    this.options("lanSector",["Południe","Południowy wschód","Wschód","Północny wschód","Północ","Północny zachód","Zachód","Południowy zachód"].map((n,i)=>[i,n]));
    ["lanSector","lanRow","lanSeatNo","lanFollow"].forEach(id=>self.el(id).onchange=()=>{self.turn=self.tilt=0;self.fixed=null;});
    var canvas=this.el("c");canvas.addEventListener("pointerdown",function(e){
      if(self.active && self.mode==="fan"){self.drag=[e.clientX,e.clientY];canvas.setPointerCapture(e.pointerId);}
    });
    canvas.addEventListener("pointermove",function(e){if(self.drag){self.turn-=(e.clientX-self.drag[0])*.006;self.tilt=Math.min(1.2,Math.max(-1.2,self.tilt+(e.clientY-self.drag[1])*.004));self.drag=[e.clientX,e.clientY];}});
    canvas.addEventListener("lostpointercapture",()=>{self.drag=null;});canvas.addEventListener("pointerup",()=>{self.drag=null;});
  },
  open:async function(){
    this.el("ovMenu").classList.add("hide");this.el("ovLan").classList.remove("hide");this.el("lanOnline").hidden=true;
    if(location.protocol==="file:"){this.msg("Tryb LAN uruchom z pełnych źródeł: python3 serve.py --port 8906. Otwórz adres gospodarza w przeglądarce.");return;}
    this.msg("Łączenie z serwerem…");await this.refresh();
  },
  refresh:async function(selectRoom){
    this.info=await this.api("info");this.profile=this.info.profile;this.el("lanOnline").hidden=false;this.el("lanOrganize").hidden=!this.profile;
    this.el("lanWho").textContent=this.profile?" · "+this.profile.nick+" · Mecze: "+(this.profile.played||0):" · gość";this.el("lanAccount").open=!this.profile;
    this.el("lanLogout").hidden=!this.profile;this.el("lanLogin").hidden=this.el("lanRegister").hidden=!!this.profile;
    this.options("lanRooms",this.info.rooms.map(r=>[r.id,r.name+"  ·  "+({ready:"przed meczem",live:"w grze",done:"zakończony"}[r.status])+"  ·  "+r.score.join("–")]),selectRoom);
    var clans=this.info.clans.map(c=>[c.id,c.name]);this.options("lanJoinId",clans);this.options("lanCupClans",clans);
    ["lanHomeClan","lanAwayClan","lanHistoryClan"].forEach(id=>this.options(id,[[0,id==="lanHistoryClan"?"Wszystkie klany":"Otwarta drużyna"]].concat(clans)));
    this.options("lanHistoryCup",[[0,"Wszystkie turnieje"]].concat(this.info.cups.map(c=>[c.id,c.name+" · "+(c.scope==="world"?"światowy":"klasowy")])));
    this.pick();this.msg(this.info.rooms.length?"Wybierz mecz. Na trybuny można wejść jako gość.":"Brak meczów. Organizator może utworzyć pierwszy mecz.");
  },
  picked:function(){return this.info.rooms.find(r=>r.id===+this.el("lanRooms").value);},
  canManage:function(r){return !!(r && this.profile && (this.profile.admin||this.profile.id===r.owner));},
  pick:function(){
    var r=this.picked(),manage=this.canManage(r),ready=r?.status==="ready",done=r?.status==="done";
    this.el("lanStart").disabled=!manage||!ready;this.el("lanPlay").disabled=!this.profile||!r||done;
    this.el("lanDirect").disabled=!manage;this.el("lanWatch").disabled=!r;
    var items=[];if(r)[0,1].forEach(team=>{
      var code=r.config[team?"nationA":"nationH"],roster=TEAMS.data[code]?.players;
      for(var j=0;j<11;j++){var i=11*team+j,n=roster?roster[j]:{num:LINEUP.numbers[j],name:LINEUP.names[team][j]},nick=r.seats[i];
        items.push([i,r.config[team?"away":"home"]+"  #"+n.num+" "+TEAMS.label(n)+(nick?" · "+nick:""),!!nick && nick!==this.profile?.nick]);}
    });this.options("lanSlot",items);
  },
  history:async function(single){
    var params=new URLSearchParams();if(single){if(!this.picked())return;params.set("room",this.picked().id);}else{
      params.set("clan",this.el("lanHistoryClan").value||0);params.set("cup",this.el("lanHistoryCup").value||0);}
    var data=await this.api("history?"+params),box=this.el("lanRecords");box.replaceChildren();
    function table(head,rows){var tab=document.createElement("table");[head].concat(rows).forEach((row,i)=>{var tr=tab.insertRow();row.forEach(value=>{var td=document.createElement(i?"td":"th");td.textContent=value;tr.appendChild(td);});});box.appendChild(tab);}
    if(data.champions?.length){var title=document.createElement("strong");title.textContent="Zwycięzca turnieju · "+data.champions.map(id=>this.info.clans.find(c=>c.id===id)?.name||"—").join(", ");box.appendChild(title);}
    if(data.table.length)table(["Klan","M","Punkty","Bramki"],data.table.map(a=>[this.info.clans.find(c=>c.id===a.clan)?.name||"—",a.played,a.points,a.gf+"–"+a.ga]));
    table(["Mecz","Wynik","Stan"],data.matches.map(m=>[m.name,m.score.join(" – "),{ready:"Zaplanowany",live:"W toku",done:"Zakończony"}[m.status]]));
    if(!single && data.matches.length){var results=box.lastElementChild;
      Array.from(results.rows).slice(1).forEach((row,i)=>{var m=data.matches[i],a=document.createElement("button"),cell=document.createElement("td");
        a.textContent="Wybierz mecz";a.onclick=()=>{this.el("lanRooms").value=m.id;this.pick();this.msg(m.name);this.el("lanRooms").focus();};cell.appendChild(a);row.appendChild(cell);});
    }
    if(data.summary){var c=data.summary;table(["Mecze","Wygrane","Remisy","Porażki","Bramki","Punkty"],[[c.played,c.wins,c.draws,c.losses,c.gf+"–"+c.ga,c.points]]);}
    if(single && data.matches[0]?.record.stats){var rec=data.matches[0].record,stats=rec.stats;
      table(["Statystyka","Gospodarze","Goście"],Object.entries({shots:"Strzały",onT:"Celne",attempt:"Próby podań",pass:"Udane podania",corr:"Rożne",fouls:"Faule",yel:"Żółte kartki",red:"Czerwone kartki"}).map(([k,v])=>[v,stats[0][k],stats[1][k]]));
      table(["Minuta","Akcja","Uczestnik / wynik"],(rec.events||[]).map(e=>[e.minute,({goal:"Gol",booking:"Kartka",penalty:"Karny",substitution:"Zmiana",fulltime:"Koniec",halftime:"Przerwa"})[e.state]||e.state,e.detail||e.score.join(" – ")]));
      var people=(rec.players||[]).concat((rec.departed||[]).flat().map(p=>[p.name,p.goals,p.yellows]));
      table(["Zawodnik","Gole","Żółte kartki"],people);
    }
  },
  enter:async function(mode){
    var r=this.picked();if(!r)return;
    var slot=mode==="play"?+this.el("lanSlot").value:-1;
    if(slot>=0)await this.api("seat",{room:r.id,slot:slot});
    AUDIO.init();AUDIO.resume();VOICE.stopMusic();VOICE.stopSpeech();this.backup=Object.assign({},SET);
    this.room=r;this.slot=slot;this.active=true;this.previous=this.last=this.fixed=null;this.rev=-1;this.eventId=0;this.generation++;
    this.edges={};this.inputBusy=false;this.sentAt=-9999;this.turn=this.tilt=0;this.layoutKey="";this.hudKey="";this.namesKey="";
    var lang=SET.lang;Object.assign(SET,r.config);SET.lang=lang;SET.cam=4;SET.mode=slot<0?2:slot<11?0:1;
    TEAMS.apply();WORLD.setNight(!!SET.night);CONDITIONS.venue();CONDITIONS.ball();PITCH.reset();SIM.resetMatch();MATCHDAY.reset();
    BROADCAST.clear();RULES.state="kickoff";RULES.half=1;RULES.elapsed=0;CAM._last=null;MAIN.state="match";MAIN.paused=false;
    HUD.hideEnd();HUD.hideEvent();HUD.hint("");HUD.refreshTeams();this.el("ovLan").classList.add("hide");this.el("hud").classList.add("show");this.el("lanBar").hidden=false;
    var manage=this.canManage(r);this.el("lanPause").hidden=this.el("lanManageSubs").hidden=!manage;
    this.el("lanSubTools").hidden=true;this.options("lanView",(slot>=0?[["play","Mecz"]]:[]).concat([["fan","Trybuny"]],manage?[["director","Reżyserka"]]:[]),mode);
    this.view(mode);this.msg(r.status==="ready"?"Czekasz na rozpoczęcie meczu.":r.name);this.poll(this.generation);
    if(r.status==="ready" && manage){try{await this.api("start",{room:r.id});}catch(e){this.msg(e.message);}}
  },
  exit:async function(){
    var room=this.room,slot=this.slot;this.active=false;this.generation++;this.room=null;this.slot=-1;this.drag=null;
    clearTimeout(this.nickTimer);if(this.nickAudio){this.nickAudio.pause();this.nickAudio=null;}
    if(this.atlas){this.atlas.dispose();this.atlas=null;}
    this.el("lanBar").hidden=this.el("lanTiles").hidden=true;document.body.classList.remove("lanGrid");if(WORLD.cup)WORLD.cup.visible=false;
    Object.assign(SET,this.backup);TEAMS.apply();CONDITIONS.venue();CONDITIONS.ball();WORLD.setNight(!!SET.night);
    MAIN.toMenu();DESK.refresh();if(slot>=0)try{await this.api("leave",{room:room.id});}catch(e){}
    await this.open();
  },
  view:function(mode){
    if(mode!=="director" && this.atlas){this.atlas.dispose();this.atlas=null;}
    this.mode=mode;this.el("lanView").value=mode;this.el("lanFanTools").hidden=mode!=="fan";this.el("lanDirectorTools").hidden=mode!=="director";
    this.el("lanTiles").hidden=mode!=="director";document.body.classList.toggle("lanGrid",mode==="director");
    this.layoutKey="";this.fixed=null;this.lastGrid=-1000;this.drag=null;
  },
  poll:async function(g){
    while(this.active && g===this.generation){
      try{
        var data=await this.api("state?room="+this.room.id+"&after="+this.rev);if(!this.active||g!==this.generation)return;
        if(data.revision!==this.rev){this.rev=data.revision;this.accept(data);}
        if(data.paused||data.state==="fulltime")await new Promise(r=>setTimeout(r,250));
      }catch(e){if(g!==this.generation)return;this.msg(e.message);await new Promise(r=>setTimeout(r,700));}
    }
  },
  accept:function(s){
    this.previous=this.last && this.last.state===s.state && s.t-this.last.t<.35?this.last:s;this.last=s;this.arrived=performance.now();
    RULES.state=s.state;RULES.stateT=s.stateT;RULES.elapsed=s.clock;RULES.half=s.half;RULES.restartTeam=s.team;RULES.taker=SIM.players[s.taker];MATCHDAY.added=s.added;
    CEREMONY.stage=s.ce;CEREMONY.winner=s.winner;SIM.teams.forEach((t,i)=>{t.score=s.score[i];t.stats=s.stats[i];t.dir=i?-s.dir:s.dir;t.bench=s.bench[i];t.changes=s.changes[i];t.user=null;});
    s.players.forEach((v,i)=>{var p=SIM.players[i];if(p.num!==v[8] || p.name!==v[9] || p.role!==v[14]){if(p.mesh)WORLD.removePlayer(p.mesh);p.mesh=WORLD.makePlayer(p.team,v[14]==="GK",v[8],null,null,v[9]);}
      Object.assign(p,{num:v[8],name:v[9],stamina:v[10],off:!!v[11],goals:v[12],yellows:v[13],role:v[14],fullName:v[15],trapLeg:v[16],dribbleFoot:v[16],trapHeight:v[17],isUser:i===this.slot?p.team:null,diveSide:v[18]||1,turn:v[19]||0});
    });if(this.slot>=0){var local=SIM.players[this.slot];SIM.teams[local.team].user=local;}
    var b=SIM.ball;b.owner=SIM.players[s.ball[6]]||null;b.receiver=SIM.players[s.ball[7]]||null;b.lastTouchTeam=s.ball[8];b.vx=s.ball[3];b.vy=s.ball[4];b.vz=s.ball[5];
    var scoreKey=s.score.join()+"|"+s.players.map(p=>p[11]+":"+p[13]).join();if(this.scoreKey!==scoreKey){this.scoreKey=scoreKey;HUD.setScore();}
    var old=BROADCAST.scene,hero=SIM.players[s.hero];
    if(hero && (s.state==="booking" || s.state==="goal")){
      if(!old || old.type!==s.state || old.hero!==hero){
        BROADCAST.clear();BROADCAST.scene={type:s.state,hero:hero,actors:s.actors.map(i=>SIM.players[i]),extra:null};
        if(s.state==="booking" && hero.off)BROADCAST.scene.extra=WORLD.makePlayer(hero.team,hero.role==="GK",hero.num,WORLD.gFx,null,hero.name);
      }
      Object.assign(BROADCAST.scene,{ref:s.ref,stage:s.card,stageTime:s.cardTime||0,second:s.second,forward:s.forward || {x:SIM.dirX(hero.team),z:0}});
      if(s.state==="booking"){WORLD.staff.card.visible=true;WORLD.staff.card.material.color.setHex(s.card==="red"?0xf02b28:0xffdf23);
        var extra=BROADCAST.scene.extra;if(extra){var v=s.players[s.hero];extra.position.set(v[0],0,v[1]);extra.rotation.y=v[2];}}
    }else if(old){BROADCAST.clear();this.hudKey="";}
    MATCHDAY.adv=s.adv;RULES.freeIndirect=s.indirect;
    WORLD.aimArrow.visible=this.mode==="play" && this.slot===s.taker && ["corner","freekick","penalty","goalkick"].includes(s.state);
    if(WORLD.aimArrow.visible){WORLD.aimArrow.position.set(s.ball[0],.04,s.ball[2]);WORLD.aimArrow.rotation.y=s.aim;}
    var hk=JSON.stringify(s.hud);if(this.hudKey!==hk){this.hudKey=hk;if(s.hud){var h=s.hud;HUD.event(h.type,h.title,h.min,h.name,h.team,h.reason);}else HUD.hideEvent();}
    if(s.tag)HUD.restartTagShow(s.tag);else HUD.restartTagHide();HUD.showPower(s.power||null);
    var nk=s.players.map((p,i)=>p[8]+"/"+(s.seats[i]||"")).join();if(nk!==this.namesKey){this.namesKey=nk;this.options("lanTrack",s.players.map((p,i)=>[i,(i<11?SET.home:SET.away)+" #"+p[8]+" "+p[9]]));this.layoutKey="";}
    this.msg(this.room.name+" · "+(s.paused?"Pauza":s.state==="fulltime"?"Koniec meczu":this.slot>=0?(s.seats[this.slot]||this.profile.nick)+" #"+s.players[this.slot][8]:"Widz")+" · "+Object.keys(s.seats).length+"/22");
    (s.events||[]).forEach(e=>{if(e.id<=this.eventId)return;this.eventId=e.id;if(s.t-e.t>4 && !(e.type==="anthem" && ["opening","closing"].includes(s.state)))return;
      if(e.type==="voice")VOICE.speak(e.data.keys,e.data.urgent);
      if(e.type==="anthem")VOICE.anthem(e.data);
      if(e.type==="musicStop")VOICE.stopMusic();
      if(e.type==="banner")HUD.banner(e.data.title,e.data.detail,2);
      if(e.type==="event" && e.data.type==="goal"){
        WORLD.crowdPulse=1;AUDIO.roar(1.0);AUDIO.horn();var nick=s.seats[s.hero];if(nick && SET.snd && typeof Audio!=="undefined"){
          clearTimeout(this.nickTimer);this.nickTimer=setTimeout(()=>{if(this.active)this.sayNick(nick);},2200);}
      }
    });
  },
  subOptions:function(){
    if(!this.last)return;var s=this.last;
    this.options("lanSubOut",s.players.flatMap((p,i)=>p[11]?[]:[[i,(i<11?SET.home:SET.away)+" #"+p[8]+" "+p[9]]]));
    var i=+this.el("lanSubOut").value;this.options("lanSubIn",s.bench[Math.floor(i/11)].filter(r=>(r.role==="GK")===(s.players[i][14]==="GK")).map(r=>[r.num,"#"+r.num+" "+r.name]));
    this.el("lanSubSend").disabled=!this.el("lanSubIn").options.length;
  },
  input:function(now){
    if(this.slot<0)return;var d=INPUT.slots[0],map={pass:"passP",shot:"shootP",cross:"tackleP",through:"throughP",skip:"camP"};
    for(var k in map)if(d[map[k]])this.edges[k+"Edge"]=true;
    if(d.shootR)this.edges.shotUp=true;
    if(this.inputBusy||now-this.sentAt<(this.last?.paused||!this.last?650:65))return;
    var g=this.generation,field=CAM.fieldInput(d.mx,d.mz),payload=Object.assign({seq:++this.seq,x:field.x*d.moveLen,z:field.z*d.moveLen,mx:d.mx,mz:d.mz,pass:d.pass,shot:d.shoot,cross:d.tackle,through:d.through,close:d.jockey,sprint:d.sprint,skip:d.camL},this.edges);
    this.edges={};this.sentAt=now;this.inputBusy=true;
    this.api("input",{room:this.room.id,input:payload}).catch(e=>{if(this.generation===g)this.msg(e.message);}).finally(()=>{if(this.generation===g)this.inputBusy=false;});
  },
  frame:function(dt,now){
    this.input(now);var s=this.last;if(!s)return;var a=this.previous;
    var alpha=s.paused?1:Math.min(1,(now-this.arrived)/(Math.max(1/60,Math.min(.13,s.t-a.t))*1000));alpha=Math.max(0,alpha);
    function lerp(x,y){return x+(y-x)*alpha;}
    for(var i=0;i<s.players.length;i++){
      var u=a.players[i],v=s.players[i],p=SIM.players[i];p.pos.x=lerp(u[0],v[0]);p.pos.z=lerp(u[1],v[1]);p.face=u[2]+SIM._angDelta(u[2],v[2])*alpha;
      p.vel.x=v[3];p.vel.z=v[4];p.stridePhase=u[5]+(((v[5]-u[5]+1.5)%1)-.5)*alpha;p.action=v[6];p.actionT=u[6]===v[6]?lerp(u[7],v[7]):v[7];
    }
    var b=SIM.ball;b.x=lerp(a.ball[0],s.ball[0]);b.y=lerp(a.ball[1],s.ball[1]);b.z=lerp(a.ball[2],s.ball[2]);SIM.syncMeshes(s.paused?0:dt);
    if(WORLD.cup){var cap=s.state==="closing"?SIM.players.find(p=>p.action==="liftcup"):null;WORLD.cup.visible=!!cap;if(cap)WORLD.cup.position.set(cap.pos.x,1.25+.76*FACE.smooth(0,1.15,cap.actionT),cap.pos.z+.32);}

    WORLD.tick(dt);WORLD.tickStaff(dt,s.state);HUD.update(dt);MAIN.markers();
    if(this.mode==="director"){if(now-this.lastGrid>42){this.lastGrid=now;this.grid();}}
    else{
      if(this.mode==="fan")this.fan();else{
        if(INPUT.wheelAcc)CAM.zoomBy(INPUT.wheelAcc*.0011);
        CAM.update(dt,s.state);
      }
      WORLD.renderer.render(WORLD.scene,WORLD.cam);
    }
    INPUT.wheelAcc=0;
  },
  fan:function(){
    var side=STADIUM.sides[this.num("lanSector",0,7)],row=STADIUM.row(this.num("lanRow",1,14)-1);
    var seat=side.at((this.num("lanSeatNo",1,40)-.5)/40,row.d-.13,row.y+1.68),eye=WORLD.cam.position;eye.set(...seat);
    var b=SIM.ball,base=this.el("lanFollow").checked?{x:b.x,y:b.y+.4,z:b.z}:(this.fixed||(this.fixed={x:b.x,y:b.y+.4,z:b.z}));
    var dx=base.x-eye.x,dy=base.y-eye.y,dz=base.z-eye.z,yaw=Math.atan2(dx,dz)+this.turn;
    var pitch=Math.min(1.46,Math.max(-1.46,Math.atan2(dy,Math.hypot(dx,dz))+this.tilt));
    this.fanFov=Math.max(16,Math.min(82,this.fanFov+INPUT.wheelAcc*.029));
    var cam=WORLD.cam;cam.fov=this.fanFov;cam.updateProjectionMatrix();cam.lookAt(eye.x+Math.sin(yaw)*Math.cos(pitch),eye.y+Math.sin(pitch),eye.z+Math.cos(yaw)*Math.cos(pitch));
  },
  playerCamera:function(cam,i,aspect){
    var p=SIM.players[i],b=SIM.ball,dir=SIM.dirX(p.team),dx=b.x-p.pos.x,dz=b.z-p.pos.z;
    var length=Math.hypot(dx,dz),x=length>2?dx/length:Math.sin(p.face),z=length>2?dz/length:Math.cos(p.face);
    cam.aspect=aspect;cam.fov=aspect<.85?73:57;cam.updateProjectionMatrix();
    cam.position.set(p.pos.x-x*6+z*1.0,3.2,p.pos.z-z*6-x*1.0);cam.lookAt(p.pos.x+x*5,1.0,p.pos.z+z*5);
  },
  grid:function(){
    var group=this.el("lanGroup").value,order=this.monitorOrder||(this.monitorOrder=SIM.players.map((p,i)=>i));
    var indices=group==="one"?[+this.el("lanTrack").value]:order.filter(i=>group==="both"||Math.floor(i/11)===(group==="home"?0:1));
    var cols=Math.min(indices.length,this.num("lanCols",1,22)),rows=Math.ceil(indices.length/cols),r=WORLD.renderer,box=this.el("lanTiles");
    var id=indices.join()+"|"+cols+"|"+this.namesKey,layoutChanged=this.layoutKey!==id;
    if(layoutChanged){
      box.replaceChildren();box.style.gridTemplateColumns="repeat("+cols+",minmax(0,1fr))";box.style.gridTemplateRows="repeat("+rows+",minmax(0,1fr))";
      indices.forEach(i=>{var p=SIM.players[i],label=document.createElement("span");label.textContent="#"+p.num+" "+(this.last.seats[i]||p.name);
        label.draggable=true;label.title="Przeciągnij na inne okno, aby zamienić miejsca. Dwuklik otwiera zawodnika.";
        label.ondragstart=ev=>ev.dataTransfer.setData("text/plain",String(i));label.ondragover=ev=>ev.preventDefault();
        label.ondrop=ev=>{ev.preventDefault();var from=order.indexOf(Number(ev.dataTransfer.getData("text/plain"))),to=order.indexOf(i);
          if(from>=0 && to>=0){[order[from],order[to]]=[order[to],order[from]];this.layoutKey="";}};
        label.ondblclick=()=>{this.el("lanTrack").value=i;this.el("lanGroup").value="one";this.layoutKey="";};
        box.appendChild(label);});
      this.layoutKey=id;this.tileCursor=0;
    }
    var cam=this.monitorCam||(this.monitorCam=new THREE.PerspectiveCamera(55,1,.15,350)),size=r.getSize(this.screenSize||(this.screenSize=new THREE.Vector2()));
    var scale=Math.min(1,1500/size.x,950/size.y),w=Math.max(1,Math.round(size.x*scale)),h=Math.max(1,Math.round(size.y*scale));
    if(!this.atlas || this.atlas.width!==w || this.atlas.height!==h){
      if(this.atlas)this.atlas.dispose();
      this.atlas=new THREE.WebGLRenderTarget(w,h,{minFilter:THREE.LinearFilter,magFilter:THREE.LinearFilter,generateMipmaps:false});
      this.atlas.texture.encoding=r.outputEncoding;layoutChanged=true;
    }
    if(!this.screenScene){
      this.screenScene=new THREE.Scene();this.screenCam=new THREE.OrthographicCamera(-1,1,1,-1,0,2);this.screenCam.position.z=1;
      this.screenMaterial=new THREE.MeshBasicMaterial({map:this.atlas.texture,depthTest:false,depthWrite:false,toneMapped:false});
      this.screenScene.add(new THREE.Mesh(new THREE.PlaneGeometry(2,2),this.screenMaterial));
    }
    this.screenMaterial.map=this.atlas.texture;
    var atlas=this.atlas,auto=r.shadowMap.autoUpdate;r.shadowMap.autoUpdate=false;
    try{
      if(layoutChanged){atlas.scissorTest=false;atlas.viewport.set(0,0,w,h);r.setRenderTarget(atlas);r.clear();}
      atlas.scissorTest=true;
      var batch=Math.min(indices.length,SET.q===0?3:5);
      for(var j=0;j<batch;j++){
        var n=this.tileCursor++%indices.length,i=indices[n],col=n%cols,row=Math.floor(n/cols);
        var x=Math.floor(col*w/cols),y=Math.floor((rows-row-1)*h/rows);
        var sw=Math.floor((col+1)*w/cols)-x,sh=Math.floor((rows-row)*h/rows)-y;
        this.playerCamera(cam,i,sw/sh);atlas.viewport.set(x,y,sw,sh);atlas.scissor.copy(atlas.viewport);r.setRenderTarget(atlas);r.render(WORLD.scene,cam);
      }
    }finally{r.setRenderTarget(null);r.setScissorTest(false);r.setViewport(0,0,size.x,size.y);r.shadowMap.autoUpdate=auto;}
    r.render(this.screenScene,this.screenCam);
  }
};
