/* ============================================================
   SUPER PILKA '98 · 06-sim.js — encje, fizyka piłki i zawodników
   ============================================================ */
var SIM = {
  players: [],
  ball: null,
  teams: [],
  events: [],          // zdarzenia dla modułu zasad
  G: 9.81, BR: 0.15,

  resetMatch: function(){
    /* POPRAWKA: usuń meshy zawodników z POPRZEDNIEGO meczu —
       inaczej 11 (lub 22) „duchów” zostaje na boisku obok nowej jedenastki */
    for(var r=0;r<this.players.length;r++){
      if(this.players[r] && this.players[r].mesh) WORLD.removePlayer(this.players[r].mesh);
    }
    this.players.length = 0;
    if(WORLD.gPlayers) WORLD.gPlayers.children.length = 0;   /* gwint bezpieczeństwa */
    this.teams = [
      { id:0, dir:1, score:0, user:null, stats:{shots:0,onT:0,corr:0,fouls:0,yel:0,red:0,pass:0,attempt:0,poss:0}, switchCd:0 },
      { id:1, dir:-1, score:0, user:null, stats:{shots:0,onT:0,corr:0,fouls:0,yel:0,red:0,pass:0,attempt:0,poss:0}, switchCd:0 }
    ];
    for(var t=0;t<2;t++){
      var roster=TEAMS.rosters(t);this.teams[t].bench=roster.slice(11);this.teams[t].changes=0;this.teams[t].departed=[];
      for(var i=0;i<11;i++){
        var form=LINEUP.formation(t), coord=LINEUP.forms[form][i];
        var f={role:LINEUP.roles[form][i],x:coord[0],z:coord[1]};
        var num=roster[i].num,name=TEAMS.label(roster[i]);
        var mesh=WORLD.makePlayer(t,i===0,num,null,null,name);
        var pace = (i===0 ? 6.3 : 6.8 + Math.random()*1.2);
        this.players.push({
          team:t, idx:i, role:f.role, num:num, mesh:mesh, name:name,fullName:roster[i].name,
          stridePhase:mesh.userData.phase, stamina:1, runT:0, challengeCd:0, turn:0, diveSide:1, trackingBall:false, challenge:null, foulCount:0, foulLoad:0,
          home:{ x:f.x, z:f.z },
          pos:{ x:f.x, z:f.z }, vel:{ x:0, z:0 }, face:0,
          pace:pace, action:"run", actionT:0,
          isUser:null, moveTarget:null,
          goals:0, yellows:0, off:false, aiTarget:null, decideCd:0, slideCd:0
        });
      }
    }
    this.ball = { x:0, y:this.BR, z:0, vx:0, vy:0, vz:0,
      owner:null, ownerAge:0,flightAge:0, cushion:null, settleT:0, lastTouchTeam:-1, lastKicker:null, curve:0, live:false, lock:0, receiver:null, route:null, flight:"", shotTeam:null };
    this.events.length = 0;
    this.syncMeshes(0);
  },

  control: function(team,player){
    var tm=this.teams[team];
    if(tm.user && tm.user!==player){tm.user.isUser=null;tm.user.moveTarget=null;}
    tm.user=player;
    if(player) player.isUser=team;
  },
  dirX: function(team){ return this.teams[team].dir; },

  /* pozycja domowa formacji dla kierunku ataku teamu */
  formPos: function(team, slotX, slotZ){
    var d = this.teams[team].dir;
    return { x: slotX * d, z: slotZ * d };
  },

  /* ================= FIZYKA ================= */
  step: function(dt){
    var b = this.ball;
    b.lock=Math.max(0,b.lock-dt);b.ownerAge=b.owner?b.ownerAge+dt:0;b.flightAge=b.owner?0:b.flightAge+dt;
    if(b.cushion){
      b.settleT-=dt;
      if(b.settleT<=0 || b.cushion.off || Math.hypot(b.x-b.cushion.pos.x,b.z-b.cushion.pos.z)>1.75){
        b.cushion=null;b.receiver=null;b.route=null;
      }
    }
    b.prevX=b.x;b.prevY=b.y;b.prevZ=b.z;
    /* --- piłka --- */
    if(!b.owner){
      b.vy -= this.G*dt;
      var airborne = b.y > this.BR + 0.02;
      var drag = airborne ? 0.13 : 0.72*CONDITIONS.drag();
      var f = Math.exp(-drag*dt);
      b.vx *= f; b.vz *= f;
      if(airborne && b.curve){
        /* lekki efekt Magnusa dla stałych fragmentów */
        var sp = Math.hypot(b.vx, b.vz);
        if(sp>0.5){
          var px = -b.vz/sp, pz = b.vx/sp;
          b.vx += px*b.curve*dt; b.vz += pz*b.curve*dt;
        }
      }
      b.x += b.vx*dt; b.y += b.vy*dt; b.z += b.vz*dt;
      if(b.y < this.BR){
        b.y = this.BR;
        if(!b.cushion && b.vy < -1.4){
          b.vy = -b.vy*CONDITIONS.bounce();
          AUDIO.bounce(Math.abs(b.vy));
          if(b.vy < 1.6) b.vy = 0;
        } else b.vy = 0;
      }
      this._postCollision(b);
    }
    /* --- zawodnicy --- */
    for(var i=0;i<this.players.length;i++){
      var pl = this.players[i];
      if(pl.off) continue;
      pl.prevX=pl.pos.x;pl.prevZ=pl.pos.z;
      RECEPTION.prepare(pl,b);
      this._stepPlayer(pl, dt);
    }
    if(RULES.state==="play" && (MATCHDAY.armContact(dt) || OFFICIAL.check(dt) && RULES.state!=="play"))return;
    this._separate();
    if(b.owner)this.carry(b.owner,dt);
    this._ballContacts(dt);
  },

  carry:function(p,dt){
    var b=this.ball,fx=Math.sin(p.face),fz=Math.cos(p.face);
    if(p.keeperHold){
      p.keeperHold=Math.abs(p.pos.x+this.dirX(p.team)*HL)<16.35 && Math.abs(p.pos.z)<20;
      if(p.keeperHold){
        b.x=p.pos.x+.37*fx;b.z=p.pos.z+.37*fz;b.y=1.15*p.mesh.scale.y;
        b.vx=p.vel.x;b.vz=p.vel.z;return;
      }
    }
    var speed=Math.hypot(p.vel.x,p.vel.z),tight=p.closeControl;
    var sprint=!tight && (p.moveTarget?.sprint || speed>7.5);
    // Po dotknięciu butem liczy się pęd piłki. Zmiana kierunku wymaga następnego kontaktu.
    if(speed>.7){fx=p.vel.x/speed;fz=p.vel.z/speed;}
    var dx=b.x-p.pos.x,dz=b.z-p.pos.z,dist=Math.hypot(dx,dz);
    b.nextTouch=Math.max(0,(b.nextTouch||0)-dt);
    p.dribbleAnim=Math.max(0,(p.dribbleAnim||0)-dt);
    var reach=tight?.72:.88;
    if(dist<=reach && b.release){
      var release=b.release;b.release=null;this[release.method].apply(this,release.args);return;
    }
    if(!b.release && dist<=reach && b.nextTouch<=0){
      var target=p.moveTarget,span=target?Math.hypot(target.x-p.pos.x,target.z-p.pos.z):0;
      var interval=span<.15 && speed<1?.24:tight?.31:sprint?.52+.24*Math.min(1,speed/7):.49;
      var cap=p.pace*(p.isUser===null?AI.profile(p.team).spd:1)*(target?.sprint?1.13+.24*p.stamina:1);
      var wanted=Math.min(span*4,cap*(tight?.56:1)*(target?.amount??1));
      var acceleration=tight?32:24,ramp=Math.min(interval,Math.abs(wanted-speed)/acceleration);
      var distance=speed*ramp+Math.sign(wanted-speed)*acceleration*ramp*ramp*.5+wanted*(interval-ramp);
      if(speed<.7 && span>.15){fx=(target.x-p.pos.x)/span;fz=(target.z-p.pos.z)/span;}
      var drag=(tight?2.65:sprint?2.30:2.10)*CONDITIONS.drag();
      var foot=p.dribbleFoot===0?1:0,side=foot?1:-1;
      var ahead=speed<1?.34:tight?.34:.46,across=side*(tight?.075:.12);
      var launch=drag/(1-Math.exp(-drag*interval));
      b.vx=((distance+ahead)*fx+across*fz-dx)*launch;
      b.vz=((distance+ahead)*fz-across*fx-dz)*launch;
      b.rollDrag=drag;b.nextTouch=interval*.72;p.dribbleFoot=foot;
      p.dribbleAnim=speed>1?.18:0;
    }
    var decay=Math.exp(-(b.rollDrag||2.1)*dt);
    var travel=(1-decay)/(b.rollDrag||2.1);
    b.x+=b.vx*travel;b.z+=b.vz*travel;b.vx*=decay;b.vz*=decay;b.y=this.BR;b.vy=0;
  },
  waitForTouch:function(pl,method,args){
    var b=this.ball;
    if(b.owner!==pl || pl.keeperHold || Math.hypot(b.x-pl.pos.x,b.z-pl.pos.z)<=.89)return false;
    if(!b.release)b.release={method:method,args:Array.prototype.slice.call(args)};
    return true;
  },
  shoot:function(pl,dx,dz,power,kind,curve){
    if(this.waitForTouch(pl,"shoot",arguments))return;
    this.kick(pl,dx,dz,power,kind);
    if(curve)this.ball.curve=curve;
    RULES.onShot(pl);
  },
  _stepPlayer: function(pl, dt){
    /* cel ruchu ustawiony przez AI (aiTarget) albo przez input człowieka (w module main) */
    var tgt = pl.moveTarget;    // {x, z, sprint}
    if(this.ball.owner===pl && this.ball.release){
      tgt={x:this.ball.x+this.ball.vx*.18,z:this.ball.z+this.ball.vz*.18,sprint:true};
    }
    var dvx=0,dvz=0,maxs=pl.pace*(pl.isUser===null?AI.profile(pl.team).spd:1);
    if(tgt){
      var dx = tgt.x - pl.pos.x, dz = tgt.z - pl.pos.z;
      var d = Math.hypot(dx, dz);
      if(d > 0.06){
        dvx = dx/d; dvz = dz/d;
        var boost=tgt.sprint?1.13+.24*pl.stamina:1;
        var want=Math.min(d*4,maxs*boost*(pl.closeControl ? 0.56:1)*(tgt.amount===undefined?1:tgt.amount));
        dvx *= want; dvz *= want;
      }
    }
    var moving=Math.hypot(pl.vel.x,pl.vel.z)>pl.pace*.76;
    var draining=tgt && tgt.sprint && moving;
    pl.stamina=Math.max(0,Math.min(1,pl.stamina+dt*(draining?-.058:moving ? 0.015 : 0.045)));
    pl.runT=Math.max(0,pl.runT-dt);pl.challengeCd=Math.max(0,pl.challengeCd-dt);
    if(pl.action==="fallen"){dvx=0;dvz=0;}
    if(pl.action==="slide" || pl.action==="dive"){dvx=pl.vel.x*.96;dvz=pl.vel.z*.96;}
    if(RECEPTION.clips[pl.action] && pl.actionT>.15){dvx*=.56;dvz*=.56;}
    var acc=pl.closeControl?32:24;
    pl.vel.x += Math.max(-acc*dt, Math.min(acc*dt, dvx - pl.vel.x));
    pl.vel.z += Math.max(-acc*dt, Math.min(acc*dt, dvz - pl.vel.z));
    var sp = Math.hypot(pl.vel.x, pl.vel.z);
    if(sp > maxs*1.36){ pl.vel.x *= maxs*1.36/sp; pl.vel.z *= maxs*1.36/sp; }
    pl.pos.x += pl.vel.x*dt; pl.pos.z += pl.vel.z*dt;
    pl.stridePhase=(pl.stridePhase+dt*MOTION.strideRate(sp))%1;

    var prevFace=pl.face,ball=this.ball,dxBall=ball.x-pl.pos.x,dzBall=ball.z-pl.pos.z;
    var ballDistance=Math.hypot(dxBall,dzBall);
    var facing=pl.face,turnRate=10;
    var travel=tgt && Math.hypot(tgt.x-pl.pos.x,tgt.z-pl.pos.z)>.24
      ?Math.atan2(tgt.x-pl.pos.x,tgt.z-pl.pos.z):sp>.35?Math.atan2(pl.vel.x,pl.vel.z):pl.face;
    pl.trackingBall=false;
    if(pl.challenge){
      facing=pl.challenge.face;
    }else if(pl.action==="fallen" || pl.action==="dive" || pl.action==="slide"){
      facing=pl.face;
    }else if(pl.readyAction || (RECEPTION.clips[pl.action] && pl.actionT>.15)){
      facing=pl.trapFace;turnRate=18;
    }else if(pl.kickFace!==undefined && pl.actionT>.08 && ["kick","passkick","crosskick","header"].includes(pl.action)){
      facing=pl.kickFace;turnRate=20;
    }else if(ball.owner!==pl && ballDistance>.09){
      var toBall=Math.atan2(dxBall,dzBall);
      var receiving=ball.receiver===pl || ball.cushion===pl;
      // A keeper, a waiting receiver and a retreating marker see the ball over their toes.
      // A distant runner opens the shoulder on the side of the pass.
      var open=pl.role==="GK" || sp<1 || pl.closeControl || receiving?0:
        pl.runT>0 && ballDistance>9?1.03:Math.min(.86,Math.max(0,ballDistance-4)*.05);
      facing=toBall+Math.max(-open,Math.min(open,this._angDelta(toBall,travel)));
      pl.trackingBall=true;turnRate=receiving || ballDistance<6?16:10;
    }else if(ball.owner===pl || sp>.45){facing=travel;}
    pl.face+=this._angDelta(pl.face,facing)*(1-Math.exp(-turnRate*dt));
    pl.turn+=(this._angDelta(prevFace,pl.face)/Math.max(dt,.001)*.18-pl.turn)*Math.min(1,dt*10);
    /* granice: lekko poza boisko dozwolone */
    pl.pos.x = Math.max(-HL-4, Math.min(HL+4, pl.pos.x));
    pl.pos.z = Math.max(-HW-4, Math.min(HW+4, pl.pos.z));

    if(pl.actionT > 0){
      pl.actionT -= dt;
      if(pl.actionT <= 0){ pl.action = "run"; }
    }
    if(pl.firstTouch && (pl.firstTouch.life-=dt)<=0)pl.firstTouch=null;
    if(pl.slideCd > 0) pl.slideCd -= dt;
    if(pl.decideCd > 0) pl.decideCd -= dt;
  },
  _angDelta: function(a, b){
    var d = (b - a) % (Math.PI*2);
    if(d > Math.PI) d -= Math.PI*2;
    if(d < -Math.PI) d += Math.PI*2;
    return d;
  },
  _separate: function(){
    var ps = this.players;
    for(var i=0;i<ps.length;i++){
      if(ps[i].off) continue;
      for(var j=i+1;j<ps.length;j++){
        if(ps[j].off) continue;
        var dx = ps[j].pos.x-ps[i].pos.x, dz = ps[j].pos.z-ps[i].pos.z;
        var d2 = dx*dx+dz*dz;
        if(d2 < 0.0001){
          var angle=(i*17+j*31)*2.39996;dx=Math.cos(angle)*.01;dz=Math.sin(angle)*.01;d2=.0001;
        }
        if(d2 < 0.72){
          var d = Math.sqrt(d2), push = (0.85-d)/d*0.5;
          var mi = ps[j].role==="GK"?0:1, mj = ps[i].role==="GK"?0:1;
          ps[i].pos.x -= dx*push*mi; ps[i].pos.z -= dz*push*mi;
          ps[j].pos.x += dx*push*mj; ps[j].pos.z += dz*push*mj;
        }
      }
    }
  },

  _postCollision: function(b){
    var posts = [ [HL,3.66],[HL,-3.66],[-HL,3.66],[-HL,-3.66] ];
    for(var i=0;i<4;i++){
      var dx = b.x-posts[i][0], dz = b.z-posts[i][1];
      var d = Math.hypot(dx,dz);
      if(d < this.BR+GK_R && b.y < GOAL_H+0.1){
        var nx = dx/(d||1), nz = dz/(d||1);
        var vn = b.vx*nx + b.vz*nz;
        if(vn < 0){
          b.vx -= 2*vn*nx; b.vz -= 2*vn*nz;
          b.vx *= 0.6; b.vz *= 0.6;
          AUDIO.bounce(8);
          this.events.push({ type:"post" });
        }
        b.x = posts[i][0] + nx*(this.BR+GK_R+0.01);
        b.z = posts[i][1] + nz*(this.BR+GK_R+0.01);
      }
    }
    /* poprzeczki: cylinder wzdłuż osi Z na (x=±52.5, y=2.44) */
    for(var s=-1; s<=1; s+=2){
      var dxb = b.x - s*HL, dyb = b.y - GOAL_H;
      var db = Math.hypot(dxb, dyb);
      if(db < this.BR+GK_R && Math.abs(b.z) < GOAL_W/2+0.3){
        var nx = dxb/(db||0.01), ny = dyb/(db||0.01);
        var vn = b.vx*nx + b.vy*ny;
        if(vn < 0){
          b.vx -= 2*vn*nx; b.vy -= 2*vn*ny;
          b.vx *= 0.55; b.vy *= 0.55;
          AUDIO.bounce(8);
          this.events.push({ type:"post" });
        }
        b.x = s*HL + nx*(this.BR+GK_R+0.01);
        b.y = GOAL_H + ny*(this.BR+GK_R+0.01);
      }
    }
  },

  _ballContacts: function(dt){
    var b = this.ball, ps = this.players;
    if(b.owner){
      var o = b.owner;
      var d2 = (b.x-o.pos.x)*(b.x-o.pos.x)+(b.z-o.pos.z)*(b.z-o.pos.z);
      if(o.keeperHold)return;
      if(d2>.78*.78){
        var rival=null,best=.55;
        for(var j=0;j<ps.length;j++){
          var q=ps[j];if(q.off || q.team===o.team || q.action==="fallen" || q.action==="slide" || q.action==="dive")continue;
          var gap=Math.hypot(b.x-q.pos.x,b.z-q.pos.z);
          if(gap<best && gap+.18<Math.sqrt(d2)){rival=q;best=gap;}
        }
        if(rival){this.takeBall(rival);return;}
      }
      if(d2>2.72*2.72){b.owner=null;b.release=null;b.flight="dribble";b.lock=.06;}
      return;
    }
    if(b.y>2.18 || Math.abs(b.x)>HL+this.BR || Math.abs(b.z)>HW+this.BR)return;
    var speed=Math.hypot(b.vx,b.vz),near=null,best=Infinity,method=null;
    var ground=b.y<=this.BR+.049,canCushion=!ground && RECEPTION.allowed(b);
    for(var i=0;i<ps.length;i++){
      var p=ps[i];
      if(p.off || p.action==="fallen" || p.action==="slide" || p.action==="dive" || (p.challenge && !p.challenge.won))continue;
      if(p===b.lastKicker && b.lock>0 && !(ground && p===b.cushion))continue;
      if(p.role==="GK" && b.shotTeam!==null)continue;
      var d=Math.hypot(b.x-p.pos.x,b.z-p.pos.z);
      if(d>1.0)continue;
      if(FIRST_TOUCH.try(p,b,speed))return;
      var action=null,radius;
      if(ground){radius=p===b.receiver?.94:speed<2?.84:.65;}
      else if(canCushion){
        if(p===b.cushion || (b.cushion && b.lock>0))continue;
        action=RECEPTION.type(b.y/p.mesh.scale.y);
        if(!action)continue;
        if(speed>1.2 && (b.x-p.pos.x)*(b.vx-p.vel.x)+(b.z-p.pos.z)*(b.vz-p.vel.z)>.25)continue;
        d=RECEPTION.distance(p,b,action);radius=RECEPTION.clips[action].reach*p.mesh.scale.y;
      }else{if(b.y>1.16)continue;radius=.43;}
      if(d<radius && d<best){near=p;best=d;method=action;}
    }
    if(!near)return;
    var pass=["pass","through","cross","throw","gklong","clear","headpass","headclear"].includes(b.flight);
    if((speed<10.4 || (pass && speed<(b.receiver===near?32:23))) && (ground || method)){
      if(method){
        if(method==="trapHead" && b.flight==="cross" && RULES.state==="play"){
          RULES.checkHeader();
          if(b.flight!=="cross" || RULES.state!=="play")return;
        }
        RECEPTION.touch(near,b,method);return;
      }
      if(!b.cushion && pass && speed>3 && near.action==="run"){
        near.trapLeg=RECEPTION.receivingLeg(near,b);
        near.action="trapFoot";near.actionT=RECEPTION.clips.trapFoot.follow;near.trapHeight=.19;
        near.trapFace=Math.atan2(b.x-near.pos.x,b.z-near.pos.z);near.readyAction=null;
      }
      this.takeBall(near);
    }else if(best<.43){
      var dx=b.x-near.pos.x,dz=b.z-near.pos.z,normalLength=Math.hypot(dx,dz);
      var nx=normalLength>.001?dx/normalLength:-b.vx/(speed||1);
      var nz=normalLength>.001?dz/normalLength:-b.vz/(speed||1);
      var vn=b.vx*nx+b.vz*nz;
      if(vn<0){b.vx=(b.vx-1.65*vn*nx)*.53;b.vz=(b.vz-1.65*vn*nz)*.53;
        this.events.push({type:"touch",player:near});b.lastTouchTeam=near.team;b.lastKicker=near;b.cushion=null;b.receiver=null;b.route=null;b.lock=.18;}
    }
  },
  takeBall: function(pl){
    var b=this.ball;
    if(MATCHDAY.lastArm?.p===pl)MATCHDAY.lastArm.direct=false;
    var counted=b.cushion===pl; b.cushion=null;
    if(b.owner)b.owner.keeperHold=false;
    b.lastShotBy=null; b.owner=pl;b.ownerAge=0;b.receiver=null;b.route=null;b.curve=0;b.vy=0;b.y=this.BR;b.flight="";b.shotTeam=null;
    b.lastTouchTeam=pl.team;b.lastKicker=pl;b.lock=.15;
    b.vx=pl.vel.x+(b.vx-pl.vel.x)*.18;b.vz=pl.vel.z+(b.vz-pl.vel.z)*.18;
    b.release=null;b.nextTouch=0;b.rollDrag=2.1;pl.dribbleAnim=0;
    pl.decideCd=Math.max(pl.decideCd,pl.role==="GK" ? .78 : pl.isUser===null?AI.profile(pl.team).react:.30);
    if(!counted)this.events.push({type:"touch",player:pl});
  },
  standingTackle: function(pl){
    if(pl.off || pl.challengeCd>0 || pl.challenge || pl.action==="fallen" || pl.action==="slide" || this.ball.owner?.team===pl.team)return false;
    if(!this.ball.owner && this.ball.y>.7 && this.ball.y<1.9){pl.action="armblock";pl.actionT=.32;pl.challengeCd=.8;return true;}
    OFFICIAL.start(pl,false);pl.challengeCd=.78;pl.action="standtackle";pl.actionT=.30;return true;
  },
  deliver: function(pl,mate,kind,power,aimX,aimZ,destination,spread){
    if(this.waitForTouch(pl,"deliver",arguments))return;
    var dir=this.dirX(pl.team), b=this.ball;
    var tx=b.x+aimX*18,tz=b.z+aimZ*18;
    if(mate){
      var lead=kind==="through" ? 0.46 : 0.20;
      tx=mate.pos.x+mate.vel.x*lead;tz=mate.pos.z+mate.vel.z*lead;
      if(kind==="through"){tx+=dir*(4.7+power*2.9);}
      if(kind==="cross"){tx+=dir*1.9;tz=mate.pos.z*.88;}
      tx=AI.clampX(tx);tz=AI.clampZ(tz);
    }
    if(destination){tx=destination.x;tz=destination.z;}
    if(spread){
      var ax=tx-b.x,az=tz-b.z,length=Math.hypot(ax,az)||1;
      var width=spread*Math.min(1.5,Math.max(.28,length/16));
      var across=(Math.random()*2-1)*width,along=(Math.random()*2-1)*width*.65;
      tx+=(along*ax-across*az)/length;tz+=(along*az+across*ax)/length;
    }
    var dx=tx-b.x,dz=tz-b.z,dist=Math.hypot(dx,dz)||1;
    this.kick(pl,dx,dz,power,kind);
    if(kind==="cross"){
      var flight=Math.max(.85,Math.min(1.9,dist/15));
      var sp=dist*.13/(1-Math.exp(-.13*flight));
      b.vx=dx/dist*sp;b.vz=dz/dist*sp;b.vy=.5*this.G*flight+(1.45-b.y)/flight;
      b.curve=0;
    }else{
      var speed=Math.min(35,(kind==="through"?7.9:5.7)+dist*.73+power*3.1);
      b.vx=dx/dist*speed;b.vz=dz/dist*speed;b.vy=.24;b.curve=0;
    }
    b.receiver=mate;b.route={x:tx,z:tz};RULES.onPass(pl,mate);
  },

  /* ================= UDERZENIA ================= */
  kick: function(pl, dx, dz, power, kind){
    if(this.waitForTouch(pl,"kick",arguments))return;
    var b = this.ball;b.release=null;if(MATCHDAY.lastArm?.p===pl)MATCHDAY.lastArm.direct=false;
    var d = Math.hypot(dx, dz) || 1;
    if(pl.keeperHold){pl.keeperHold=false;b.y=kind==="gklong" ? 0.65:this.BR;}
    dx/=d;dz/=d;pl.kickFace=Math.atan2(dx,dz);
    var sp = 0, vy = 0, curve = 0;
    kind = kind || "pass";
    if(kind==="pass"){    sp = 11 + 13*power; vy = 0.4 + 2.2*power; }
    if(kind==="through"){ sp = 14 + 14*power; vy = 0.8 + 1.6*power; }
    if(kind==="shot"){    sp = 17 + 17*power; vy = 1.2 + 5.2*power; }
    if(kind==="finesse"){sp=17+11*power;vy=2.6+2.5*power;}
    if(kind==="clear"){   sp = 16 + 10*power; vy = 5.5 + 2*power; }
    if(kind==="throw"){   sp = 7 + 6*power;  vy = 3.3; }
    if(kind==="cross"){   sp = 12 + 6*power; vy = 5.6; curve = (Math.random()<0.5?-1:1)*(1.4+power); }
    if(kind==="gklong"){  sp = 21 + 7*power; vy = 7.2; }
    if(kind==="penclear"){sp = 18 + 8*power; vy = 3.0; }
    if(kind==="header"){  sp = 10 + 9*power;  vy = 0.8 + 2.4*power; }
    if(kind==="knee"){    sp = 13 + 10*power; vy = 1.0 + 3.2*power; }
    if(kind==="volley"){  sp = 15 + 14*power; vy = 1.1 + 4.6*power; }
    if(kind==="headpass"){sp = 7 + 5*power;   vy = 1.2 + 1.4*power; }
    if(kind==="headclear"){sp = 14 + 8*power; vy = 5.5 + 1.5*power; }
    /* podkręcenie z dobiegu: uderzenie pod kątem do biegu zawodnika
       kręci piłkę (efekt Magnusa w locie) — jak strzał „za uchem” */
    if(!curve && pl && (pl.vel.x || pl.vel.z)){
      var rs = Math.hypot(pl.vel.x, pl.vel.z);
      if(rs > 2){
        var crs = (pl.vel.x/rs)*dz - (pl.vel.z/rs)*dx;
        var kf = kind==="shot" ? 2.8 : kind==="volley" ? 2.4 :
                 (kind==="clear" || kind==="headclear") ? 1.1 : 0.7;
        curve = crs * kf;
      }
    }
    b.owner = null;b.cushion=null;b.flightAge=0;
    b.vx = dx*sp; b.vz = dz*sp; b.vy = vy;
    b.curve = curve;
    b.lastTouchTeam = pl.team; b.lastKicker = pl;
    b.lock=.23;b.receiver=null;b.route=null;b.flight=kind;
    b.shotTeam=["shot","header","finesse","volley"].includes(kind)?pl.team:null;
    b.lastShotBy=b.shotTeam!==null?pl:null;
    pl.action=kind==="header"?"header":kind==="cross"?"crosskick":["through","pass"].includes(kind)?"passkick":"kick";
    pl.actionT=pl.action==="passkick" ? 0.30:pl.action==="header" ? 0.45 : 0.40;
    if(kind==="cross")RULES.headerDone=false;
    AUDIO.kick(power);
    return { speed: sp, kind: kind };
  },
  throwBall: function(pl, dx, dz, power){
    var b = this.ball;
    var d = Math.hypot(dx, dz) || 1;
    b.owner = null;b.cushion=null;b.flightAge=0;
    /* wyrzut oburącz znad głowy: piłka startuje spod rąk, nad głową */
    b.x = pl.pos.x + Math.sin(pl.face)*0.30;
    b.z = pl.pos.z + Math.cos(pl.face)*0.30;
    b.y = 2.15;
    b.vx = dx/d*(7+8*power); b.vz = dz/d*(7+8*power); b.vy = 2.6 + power*1.4;
    b.curve = 0;
    b.lastTouchTeam = pl.team; b.lastKicker = pl;
    b.lock=.26;b.receiver=null;b.route=null;b.flight="throw";b.shotTeam=null;b.lastShotBy=null;
    pl.action = "throw"; pl.actionT = 0.52;
    AUDIO.kick(0.25);
  },

  /* ================= WŚLIZGI ================= */
  startSlide: function(pl){
    if(pl.off || pl.challenge || pl.action==="slide" || pl.action==="fallen" || pl.slideCd>0)return false;
    OFFICIAL.start(pl,true);
    pl.action = "slide"; pl.actionT = 0.72; pl.slideCd = 1.4;
    pl.vel.x = Math.sin(pl.face)*8.6;
    pl.vel.z = Math.cos(pl.face)*8.6;
    return true;
  },

  /* ================= SYNCHRONIZACJA GRAFIKI ================= */
  syncMeshes: function(dt){
    var b = this.ball;
    WORLD.ball.position.set(b.x, b.y, b.z);
    if(!b.owner || !b.owner.keeperHold){
      var roll = Math.hypot(b.vx, b.vz);
      if(roll > 0.4){
        WORLD.ball.rotation.x += (b.vz/0.15)*dt;
        WORLD.ball.rotation.z -= (b.vx/0.15)*dt;
      }
    }
    WORLD.blob.position.set(b.x, 0.022, b.z);
    var bs = 0.7 + Math.max(0, b.y-0.15)*0.55;
    WORLD.blob.scale.set(bs, bs, 1);
    WORLD.blob.material.opacity = Math.max(0.12, 0.5 - (b.y-0.15)*0.22);

    for(var i=0;i<this.players.length;i++){
      var pl = this.players[i];
      if(pl.off || !pl.mesh){ if(pl.mesh) pl.mesh.visible = false; continue; }
      pl.mesh.visible = true;
      pl.mesh.position.set(pl.pos.x,0,pl.pos.z);
      pl.mesh.rotation.y = pl.face;
      var speed = Math.hypot(pl.vel.x, pl.vel.z);
      var action=this.visualAction(pl);
      var look=this._angDelta(pl.face,Math.atan2(b.x-pl.pos.x,b.z-pl.pos.z));
      if(RULES.state==="goal")look=pl.action==="run"?0:.14*Math.sin(RULES.stateT*2.1+pl.idx);
      if(RULES.state==="booking" && pl.action==="booked")look=0;
      var lateral=(pl.vel.x*Math.cos(pl.face)-pl.vel.z*Math.sin(pl.face))/(speed||1);
      var forward=(pl.vel.x*Math.sin(pl.face)+pl.vel.z*Math.cos(pl.face))/(speed||1);
      pl.mesh.userData.contactHeight=pl.trapHeight;pl.mesh.userData.receiveLeg=action==="dribble"?pl.dribbleFoot:pl.trapLeg;
      WORLD.animatePlayer(pl.mesh,speed,dt,action,this.visualTime(pl),pl.turn,look,pl.diveSide,lateral,forward,RULES.state==="play"?pl.stridePhase:undefined);
    }
    WORLD.playerShadows(this.players);
  },

  visualAction: function(pl){
    if(pl.action!=="run")return pl.action;
    if(pl.readyAction && !this.ball.owner && !this.ball.cushion)return pl.readyAction;
    if(pl.keeperHold && this.ball.owner===pl)return "keeperhold";
    if(this.ball.owner===pl && pl.dribbleAnim>0 && !pl.closeControl)return "dribble";
    if(pl.isUser!==null && MAIN.chargeS[pl.team]>.03 && this.ball.owner===pl)return "windup";
    if(pl.isUser!==null && MAIN.chargeP[pl.team]>.04 && this.ball.owner===pl)return "passload";
    var speed=Math.hypot(pl.vel.x,pl.vel.z);
    var strideFront=Math.sin(pl.face)*pl.vel.x+Math.cos(pl.face)*pl.vel.z;
    return pl.closeControl || (pl.trackingBall && speed>.37 && strideFront<speed*.77)?"jockey":"run";
  },

  visualTime:function(pl){if(pl.action==="run" && this.ball.owner===pl && pl.dribbleAnim>0)return pl.dribbleAnim;return pl.action==="run" && pl.readyAction?pl.readyT:pl.actionT;},

  nearestToBall: function(team, exclGK){
    var best = null, bd = 1e9, b = this.ball;
    for(var i=0;i<this.players.length;i++){
      var pl = this.players[i];
      if(pl.off || pl.team!==team) continue;
      if(exclGK && pl.role==="GK") continue;
      var d = (pl.pos.x-b.x)*(pl.pos.x-b.x)+(pl.pos.z-b.z)*(pl.pos.z-b.z);
      if(d < bd){ bd = d; best = pl; }
    }
    return best;
  },
  teamPlayers: function(team){
    var out = [];
    for(var i=0;i<this.players.length;i++)
      if(this.players[i].team===team && !this.players[i].off) out.push(this.players[i]);
    return out;
  },
  playersOf: function(team, role){
    var out = [];
    for(var i=0;i<this.players.length;i++)
      if(this.players[i].team===team && !this.players[i].off && (!role || this.players[i].role===role)) out.push(this.players[i]);
    return out;
  },

  /* pomocnik wyboru partnera do podania */
  pickPassTarget: function(team, mx, mz, through, self){
    var mates = this.teamPlayers(team), best = null, bs = -1e9;
    var ml = Math.hypot(mx, mz);
    if(ml < 0.25){ mx = Math.sin(self.face); mz = Math.cos(self.face); ml = 1; }
    mx /= ml; mz /= ml;
    var dirX = this.teams[team].dir;
    for(var i=0;i<mates.length;i++){
      var m = mates[i];
      if(m===self) continue;
      var dx = m.pos.x-self.pos.x, dz = m.pos.z-self.pos.z;
      var d = Math.hypot(dx, dz);
      if(d < 2 || d > 42) continue;
      var al = (dx*mx+dz*mz)/d;
      if(al < 0.05) continue;
      var prog = ((m.pos.x-self.pos.x)*dirX)/20;
      var s = al*3.2 + prog*0.6 - Math.abs(d-14)*0.05 - (m.role==="GK"?2.2:0);
      var lane=AI.laneOpenness(self,m,this.teamPlayers(1-team));
      s+=Math.min(4,lane)*.16;
      if(through)s+=prog*.85+(m.runT>0?1.9:0)+(m.role==="FW" ? 0.4:0);
      if(s > bs){ bs = s; best = m; }
    }
    return best;
  }
};
