# Super Piłka ’98

Samodzielna gra piłkarska 3D na komputer. Otwórz `super-pilka-98.html` w przeglądarce z obsługą WebGL. Gra działa z dysku, także offline. Przed meczem możesz ustawić tryb solo, dwóch graczy lokalnie lub mecz dwóch drużyn komputerowych.

## Gra przez LAN

Na komputerze gospodarza potrzebne są Python 3.9 lub nowszy i Node.js 18 lub nowszy. Rozpakuj archiwum i w katalogu z plikiem `serve.py` uruchom serwer.

```bash
python3 serve.py --port 8906
```

Na Windows możesz użyć `py -3 serve.py --port 8906`. Gospodarz otwiera `http://localhost:8906`. Pozostałe komputery w tej samej sieci otwierają adres IP gospodarza z portem 8906. Przykładowo dla komputera o adresie 192.168.1.20 będzie to `http://192.168.1.20:8906`. Na Linuksie adresy gospodarza pokaże `hostname -I`. Serwer ma obsługę logowania, symulacji i zapisu w SQLite. Każda przeglądarka samodzielnie rysuje stadion, piłkę i zawodników.

1. Przed wejściem do **LAN Party** ustaw drużyny, pogodę i długość połowy w menu głównym. Wybór **45 min** oznacza zegar 1:1 i dwie połowy po 45 minut czasu rzeczywistego, z doliczeniem przerw w grze.
2. W **Profil gracza** utwórz profil lub zaloguj się. W **Organizacja meczów, klanów i turniejów** utwórz mecz. Możesz zostawić obie drużyny otwarte albo wskazać klany. Do reprezentowania klanu służy przycisk **Dołącz**.
3. Każdy uczestnik wybiera ten sam mecz, pozycję i **Zagraj**. Organizator może też uruchomić spotkanie przed wejściem pierwszego gracza. W jednym meczu może grać do 22 osób, w tym obaj bramkarze. Jeden komputer steruje wybraną pozycją przyciskami gracza 1. AI prowadzi pozostałych zawodników. Po rozłączeniu klienta AI przejmuje pozycję po około sześciu sekundach. Gracz może ponownie się zalogować i zająć wolne miejsce.
4. Widz wybiera mecz i **Wejdź na trybuny** bez zakładania konta. Może wybrać sektor, rząd i miejsce, obrócić widok przeciągnięciem myszy i zmienić zbliżenie kółkiem. Kamera domyślnie śledzi piłkę.
5. **Reżyserka** jest dostępna dla organizatora danego meczu oraz administratora serwera. Obsługuje obie drużyny w 22 oknach, 11 zawodników jednej strony i pojedynczy numer. Liczbę kolumn można zmienić. Przeciągnięcie kafelka zamienia kolejność, a dwuklik wybiera pojedynczego zawodnika. Przycisk **Zmiana** zgłasza rezerwowego, a **Pauza / wznów** działa dla całego pokoju.

## Klany, turnieje i zapis

Turnieje klasowe i światowe obsługują od 2 do 16 klanów i terminarz każdy z każdym. Poszczególne mecze mogą trwać równocześnie. W panelu **Wyniki, statystyki i historia** wybierz klan, turniej albo jeden mecz. Dostępne są tabela punktowa, terminarz, bramki, próby i celność podań, kartki, faule oraz lista zdarzeń. Przy remisie w tabeli decydują różnica bramek i liczba strzelonych goli. Przy równych wszystkich trzech wartościach klany dzielą pierwsze miejsce.

Profile, przynależność do klanów, turnieje, historia i stan spotkań zapisują się obok serwera w `conf/liga.sqlite3`. Serwer utrwala mecz co dwie sekundy, przy zmianach fazy i podczas zamykania przez Ctrl+C. Ponowne uruchomienie z tym samym katalogiem wznawia aktywne pokoje i zachowuje pauzę. Po wejściu wybierz swój mecz i pozycję. Do kopii zapasowej zamknij serwer i skopiuj katalog `conf`. Własny katalog zapisu możesz wskazać przez `--data`. Klucz do administracji wszystkimi pokojami powstaje przy pierwszym uruchomieniu w `conf/admin.key`. Utworzenie meczu nadaje jego organizatorowi dostęp do reżyserki.

## Piłka, kamera i oprawa meczowa

W sprincie zawodnik wypuszcza piłkę przed siebie i dobiega na następne dotknięcie. Obrońca może przeciąć piłkę w tej przerwie. Przytrzymanie **E** skraca prowadzenie. Adresat podania biegnie do przewidywanego miejsca spotkania z toczącą się lub opadającą piłką. Naciśnij **K** tuż przed kontaktem, aby podać z pierwszej piłki, albo **L**, aby uderzyć. Kierunek oraz wysokość decydują o uderzeniu z półobrotu, woleju bądź główce. Kolega może ponownie odegrać głową, zanim piłka dotknie murawy.

Domyślna **Kamera inteligentna** uwzględnia tor piłki i kontrolowanych zawodników. W menu wybierzesz trzy stadiony, stroje podstawowe i wyjazdowe oraz trzy wersje piłki. Deszcz zmienia toczenie i odbicie, śnieg przykrywa murawę i spowalnia piłkę, a mgła ogranicza widoczność. Przed pierwszym gwizdkiem drużyny ustawiają się do prezentacji. Słychać krótkie fragmenty hymnów ze śpiewem syntetycznym. Po zwycięstwie kapitan odbiera puchar i ponownie rozbrzmiewa hymn zwycięzców. Klawisz **C** pomija ceremonię.

## Kadry i głosy PL / EN

Polska, Anglia, Francja i Niemcy mają kadry turniejowe z EURO 2024 wraz z rezerwowymi. W grze są też dwa własne kluby. W **Drużyny → Kadra i sztab** kliknij nazwisko, aby posłuchać jego wymowy w języku gry. Dane zawodników, trenerów i obsady sędziowskiej znajdują się w `source/data/teams.json`.

Oba banki komentarza w `source/audio` mają po 169 pozycji. Indeks określa początek i długość każdej frazy lub nazwiska. Osobne pliki 14 głównych komunikatów dla każdego języka znajdziesz w `source/audio/cues/pl` i `source/audio/cues/en`. Serwer syntetyzuje nicki również lokalnie i przechowuje WAV w `conf/voices`. Do gry wystarczają dołączone nagrania.

```bash
python3 tools/voice.py --lang pl -o moj-nick.wav "Tomek 98"
python3 tools/build_audio.py
python3 build.py
```

Pierwsze polecenie tworzy pojedynczy WAV. Drugie przebudowuje nagrania PL/EN i hymny przy użyciu FFmpeg. Generator wykorzystuje lokalny eSpeak NG lub eSpeak, jeśli jest zainstalowany. Ma również własny syntezator formantowy. Dla angielskiego potrafi skorzystać z głosu Flite w FFmpeg. Synteza działa bez pobierania modeli.

## Transmisja TV 2000

Kamera **TV 2000** prowadzi akcję wzdłuż linii bocznej. Przy rozpoczęciu obejmuje koło środkowe. Przy rzucie rożnym, karnym i wykopie ustawia się za wykonawcą. Klawiszami w lewo i prawo lub lewą gałką obracasz strzałkę. Przytrzymaj i puść strzał, żeby posłać piłkę we wskazanym kierunku. Przed uderzeniem zawodnik robi rozbieg. Krótkie rozegranie dobiera partnera po tej stronie.

Po golu strzelec biegnie przed kamerę, a najbliżsi koledzy ruszają za nim. Podczas napomnienia sędzia podnosi kartkę przed ukaranym zawodnikiem. Belka podaje numer, nazwisko, drużynę i minutę. **C** lub **Select** pomija aktualne ujęcie. Przy odpowiednio długiej akcji po golu następuje powtórka.

## Podgląd zawodników

W zakładce **Drużyny** kliknij **Obejrzyj model 3D**. Przeciągaj myszą, by obracać postać. Wybierz ruch i kadr. Parada bramkarza pokazuje zawodnika w rękawicach. Podczas meczu klawisz **C** przełącza pięć kamer, w tym kamerę zza zawodnika. Kółko i klawisze **+** oraz **−** zmieniają zbliżenie.

Wybierz **Mimika**, aby obejrzeć z bliska powieki i ruch ust. Przeciągnij model w bok, żeby obejrzeć skronie, uszy i kark. Wśród ruchów są także cztery przyjęcia z piłką. W meczu zawodnik dobiera kontakt głową, klatką, udem lub stopą do wysokości podania. Aby zgasić dośrodkowanie w polu karnym, przytrzymaj bliską kontrolę (**E** dla pierwszego gracza, **B** dla drugiego, **LT / L2** na padzie).

## Przeciwnik i ustawienie do piłki

W ustawieniach meczu wybierz **Początkujący**, **Łatwy**, **Normalny** lub **Trudny**. Nowa instalacja zaczyna na poziomie początkującym. Przy aktualizacji gra odczytuje wcześniejszy wybór. W grze solo poziom reguluje szybkość przeciwnika, czas na opanowanie podania przed pressingiem, rozrzut podań i strzałów oraz interwencje bramkarza. Na początkującym obrona czeka około 1,55 sekundy od przejęcia piłki przed aktywnym doskokiem. Na łatwym około 0,95 sekundy. Obrońca może w tym czasie zająć pozycję i przeciąć podanie. Zawodnik oczekujący na piłkę i bramkarz śledzą ją tułowiem i głową. Obrońca może biec bokiem lub cofać się twarzą do akcji.

## Decyzje sędziego

**L** wykonuje odbiór na stojąco, **J** wślizg. W grze na padzie są to **B / ◯** oraz **X / □**. Sędzia sprawdza kolejność kontaktu stopy z piłką i przeciwnikiem, prędkość wejścia, kierunek i możliwość zagrania piłki. Rozróżnia m.in. podstawienie nogi, spóźniony atak, wślizg w nogi, niedozwolone szarżowanie i atak na bramkarza trzymającego piłkę. Te reguły obejmują obie drużyny.

Nieostrożny kontakt zwykle kończy się rzutem wolnym lub karnym. Nierozważne wejście grozi żółtą kartką, a poważny, rażący faul bezpośrednią czerwoną. Przy ocenie pozbawienia realnej szansy na bramkę gra uwzględnia kierunek ataku, kontrolę piłki, odległość od bramki i asekurację. W polu karnym rozróżnia spóźnioną próbę zagrania piłki od szarży bez takiej próby. Przy drugiej żółtej sędzia najpierw pokazuje napomnienie, opuszcza rękę i podnosi czerwoną. Belka podaje nazwisko, minutę i powód. [Przepis 12 IFAB](https://www.theifab.com/laws/latest/fouls-and-misconduct/)

### Porównanie z rzeczywistym meczem

| Sytuacja | Stan w tej wersji |
|---|---|
| Faule kontaktowe, kartki i karne | Sędzia ocenia zarejestrowany kontakt. Zespół ukaranego czerwoną gra w osłabieniu. |
| Spalony | Gra wykrywa dotknięcie piłki przez gracza na spalonym i przyznaje wolny pośredni. Sędzia sygnalizuje go uniesioną ręką. Nie rozpoznaje zasłonięcia bramkarzowi widoku przez zawodnika bez kontaktu z piłką. |
| Korzyść | Sędzia może pozwolić na kontynuowanie ataku. Gdy korzyść znika, wraca do miejsca przewinienia. Odłożoną kartkę pokazuje przy przerwie w grze. |
| Ręka i gra bramkarza | Sędzia ocenia kontakt z ręką i jej ustawienie. Bramka zdobyta bezpośrednio ręką podlega anulowaniu. Bramkarz może łapać piłkę we własnym polu karnym. |
| Zmiany | W pauzie wybierasz schodzącego i rezerwowego. Sędzia dopuszcza zgłoszoną zmianę przy najbliższej przerwie w grze. Każda drużyna może wykonać do pięciu zmian. |
| Czas meczu | Zegar biegnie również podczas przerw w grze. Pod koniec każdej połowy pojawia się należny czas doliczony. Przyznany rzut karny może przedłużyć połowę do zakończenia strzału. |

Punktem odniesienia są przepisy IFAB dotyczące sędziego, spalonego, liczby zawodników i czasu gry. [Sędzia](https://www.theifab.com/laws/latest/the-referee/) · [Spalony](https://www.theifab.com/laws/latest/offside/) · [Zawodnicy](https://www.theifab.com/laws/latest/the-players/) · [Czas gry](https://www.theifab.com/laws/latest/the-duration-of-the-match/)

## Stadion i doping

W menu głównym lub podczas pauzy wybierz **Zwiedź stadion**. Widoki **Gospodarze** i **Goście** prowadzą do sektorów obu klubów. **Bęben** i **Trąbka** przybliżają muzyków wybranego sektora. **Z murawy** pokazuje zadaszenie oraz galerię nad trybuną główną z perspektywy boiska. Wybieraj ujęcia przyciskami albo strzałkami w lewo i w prawo. **Esc** przywraca poprzedni widok. Nazwy drużyn z menu pojawiają się na szalikach, transparentach i bandach LED. Doping korzysta z ustawienia głośności gry.

## Sterowanie

| Akcja | Gracz 1 | Gracz 2 | Pad Xbox / PlayStation |
|---|---|---|---|
| Ruch i celowanie | WASD | Strzałki | Lewa gałka lub krzyżak |
| Podanie / pressing | K | Przecinek | A / ✕ |
| Strzał / odbiór na stojąco | L | Kropka | B / ◯ |
| Dośrodkowanie / wślizg | J | Ukośnik | X / □ |
| Podanie prostopadłe | I | M | Y / △ |
| Sprint | Lewy Shift lub spacja | Prawy Shift | RT / R2 |
| Bliski drybling / obrona bokiem | E | B | LT / L2 |
| Strzał techniczny | Q + L | H + kropka | RB + B / R1 + ◯ |
| Podaj i wyjdź na pozycję | O + K | N + przecinek | LB + A / L1 + ✕ |
| Zmiana obrońcy | O | N | LB / L1 |
| Pauza | Esc | Esc | Start / Options |

Przytrzymaj podanie albo strzał, aby ustalić siłę, i puść przycisk. Przy kombinacjach trzymaj modyfikator podczas ładowania. Po zagraniu bez ruchu gałką lub klawiaturą adresat sam wybiega do podania. Przy wznowieniu od środka użyj podania.

## Zbudowanie pełnej gry ze źródeł

W rozpakowanym katalogu uruchom poniższe polecenie.

```bash
python3 build.py
```

Powstanie `super-pilka-98.html`. Skrypt korzysta ze standardowej biblioteki Pythona. Silnik Three.js jest dołączony w katalogu `source`.

Osiem twarzy jest zapisanych w teksturze `source/art/twarze.webp`. Podczas budowania obraz trafia do pliku HTML. Atlas zawiera skórę od kołnierza po czubek głowy oraz warianty powiek i ust. Siatkę głowy i materiał obsługuje `source/js/05-face.js`, a przyjęcia piłki `source/js/06-reception.js`. Po edycji ośmiu portretów w `tools/portrety.webp` można odtworzyć atlas poleceniem `python3 tools/bake_faces.py` (Pillow i NumPy). Modele i materiały znajdują się w `source/js/05-athletes.js`, animacje stawów w `source/js/05-motion.js`, a podgląd postaci w `source/js/10-showroom.js`.

Bryła stadionu i sektory są w `source/js/05-stadium.js`, modele i animacje kibiców w `source/js/05-supporters.js`, a murawa, piłka i siatki bramek w `source/js/05-pitch.js`.
