/* Sylwetka w metrach. Wspólna siatka z wagami, miednica, kręgosłup i łańcuchy kończyn.
   Współrzędne lokalne: +Z z przodu, +Y w górę. */
var ATHLETE = {
  shirtTexture: function(kit, number, name, team, keeper, staff){
    var cv=document.createElement("canvas");cv.width=512;cv.height=256;
    var g=cv.getContext("2d"), shirt=new THREE.Color(keeper?kit.gk:kit.shirt);
    g.fillStyle="#fff";g.fillRect(0,0,512,256);
    g.save();g.beginPath();g.rect(0,9,512,240);g.clip();
    g.fillStyle="#"+shirt.getHexString();g.fillRect(0,9,512,240);
    var ink=staff||keeper?"#172824":team===0?"#26352e":"#f2f8ff";
    var trim=staff?"#656c61":keeper?"#264536":team===0?"#bc3641":"#acd9fc";
    if(!staff){
      g.fillStyle=trim;
      if(keeper){for(var x=0;x<512;x+=22)g.fillRect(x,18,8,42);}
      else if(team===0){
        g.beginPath();g.moveTo(51,17);g.lineTo(80,17);g.lineTo(211,249);g.lineTo(178,249);g.fill();
      }else{g.fillRect(73,13,9,232);g.fillRect(86,13,3,232);}
      g.fillStyle="rgba(255,255,255,.10)";
      for(var y=19;y<247;y+=5)g.fillRect(0,y,512,.85);
      g.textAlign="center";g.fillStyle=ink;g.font="bold 85px Arial";g.fillText(number,384,177,105);
      g.font="bold 15px Arial";g.fillText((name||"").toUpperCase(),384,82,110);
      g.font="bold 41px Arial";g.fillText(number,128,154,54);
      g.fillStyle=trim;g.beginPath();g.moveTo(145,70);g.lineTo(160,70);g.lineTo(159,82);g.lineTo(152,87);g.lineTo(146,82);g.fill();
    }
    g.fillStyle="rgba(0,0,0,.13)";g.fillRect(0,239,512,5);g.restore();
    var texture=new THREE.CanvasTexture(cv);texture.encoding=THREE.sRGBEncoding;texture.anisotropy=4;return texture;
  },

  create: function(team, keeper, number, parent, customKit, name){
    var kit=customKit||WORLD.kit[team], staff=!!customKit, idx=number+team*17;
    var skins=[0xc78459,0xa56846,0xe0aa80,0x995d41,0xedbc96,0xc58c68,0x82523e];
    var hairs=[0x38281e,0x29221d,0x614631,0x231d1a,0x947450];
    var skin=skins[idx%skins.length], hair=hairs[idx%hairs.length];
    var shorts=keeper?kit.gkShorts:kit.shorts, sock=keeper?0x273e36:kit.socks, shirt=keeper?kit.gk:kit.shirt;
    var trim=staff?shirt:keeper?0x304437:team===0?0xb72b3b:0x98ccfa;
    var bootColors=[0x273139,0x222a2c,0x843d2e,0x23404c];
    var boot=bootColors[idx%4], sole=idx%3===0?0xbab599:0x41484a;
    var bootTrim=idx%2?0xe6c693:0xb4d4dd;
    var group=new THREE.Group(), bones=[], positions=[], indices=[], colors=[], uvs=[], jointIndex=[], weights=[];
    var absolute=[], colorCache={};
    function joint(label,parentBone,x,y,z){
      var b=new THREE.Bone();b.name=label;b.position.set(x,y,z);
      if(parentBone)parentBone.add(b);
      var off=parentBone?absolute[parentBone.userData.index]:[0,0,0];
      b.userData.index=bones.length;absolute.push([off[0]+x,off[1]+y,off[2]+z]);bones.push(b);return b;
    }
    var hips=joint("pelvis",null,0,.933,0);
    var spine=joint("spine",hips,0,.055,0),neck=joint("neck",spine,0,.54,.012);
    var head=joint("head",neck,0,.071,.004);
    function vertex(b,x,y,z,c,u,v,other,blend){
      var n=b.userData.index,o=absolute[n];positions.push(x+o[0],y+o[1],z+o[2]);
      var rgb=colorCache[c]||(colorCache[c]=new THREE.Color(c).convertSRGBToLinear());
      colors.push(rgb.r,rgb.g,rgb.b);uvs.push(u,v);
      jointIndex.push(n,other?other.userData.index:n,0,0);weights.push(1-(blend||0),blend||0,0,0);
    }
    // Każdy przekrój: wysokość, promienie, przesunięcie przód/tył i opcjonalna waga sąsiedniego stawu.
    function loft(b,rings,color,sides,cx,cz,cloth,other){
      var start=positions.length/3;
      rings.forEach(function(r,j){
        for(var i=0;i<=sides;i++){
          var u=i/sides,a=(u-.25)*Math.PI*2;
          vertex(b,(cx||0)+Math.sin(a)*r[1],r[0],(cz||0)+(r[3]||0)+Math.cos(a)*r[2],color,
            cloth?u : 0.007,cloth ? 0.045+.91*(r[0]-rings[0][0])/(rings[rings.length-1][0]-rings[0][0]) : 0.987,other,r[4]);
          if(j && i){var d=start+j*(sides+1)+i;indices.push(d-sides-2,d-sides-1,d,d-sides-2,d,d-1);}
        }
      });
    }
    function oval(b,x,y,z,rx,ry,rz,color,n){
      var rings=[];
      for(var k=0;k<=6;k++){var a=k*Math.PI/6;rings.push([y-Math.cos(a)*ry,Math.max(.001,Math.sin(a)*rx),Math.max(.001,Math.sin(a)*rz)]);}
      loft(b,rings,color,n||10,x,z);
    }
    loft(hips,[[-.12,.154,.105],[-.08,.177,.121],[.05,.167,.111],[.1,.152,.107]],shorts,16);
    loft(spine,[[-.018,.163,.111],[.035,.169,.112],[.14,.153,.103],[.26,.17,.115],[.37,.194,.127,.006],[.43,.209,.119],[.48,.196,.101],[.51,.129,.081],[.525,.075,.067]],0xffffff,24,0,0,true);
    loft(spine,[[.50,.101,.075],[.518,.084,.071],[.528,.072,.067]],trim,16);
    loft(neck,[[-.044,.067,.065],[.028,.064,.066],[.096,.076,.073]],skin,12);
    loft(head,[[-.026,.043,.053,.035],[-.006,.069,.082,.023],[.032,.089,.098,.015],[.081,.101,.107,.004],[.133,.106,.109],[.18,.103,.106,-.007],[.219,.086,.092,-.009],[.244,.044,.056,-.007],[.251,.009,.015]],skin,18);
    // Linia włosów schodzi ku karkowi i skroniom. Kilka cięć zmienia sylwetkę głowy.
    var hairStart=positions.length/3,hairSides=24,style=idx%3;
    for(var row=0;row<6;row++){
      for(var h=0;h<=hairSides;h++){
        var u=h/hairSides,a=(u-.25)*Math.PI*2,front=Math.cos(a),sw=Math.sin(a);
        var low=.102+.066*front-.032*Math.pow(Math.abs(sw),5)+.008*sw*style;
        var top=.269+.007*style, y=[low,low+.012,.193,.224,.250,top][row];
        var radius=[1,1.035,1.045,.96,.69,.045][row];
        if(row>=3)y+=.005*style*sw;
        vertex(head,sw*.109*radius+(row>3 ? 0.005*style:0),y,front*.115*radius-.004,hair,.007,.987);
        if(row && h){var d=hairStart+row*(hairSides+1)+h;indices.push(d-hairSides-2,d-hairSides-1,d,d-hairSides-2,d,d-1);}
      }
    }
    [-1,1].forEach(function(s){
      oval(head,s*.099,.092,-.008,.018,.03,.02,skin);
      oval(head,s*.044,.114,.101,.023,.009,.007,0xe0cdb7,8);
      oval(head,s*.044,.113,.107,.009,.008,.004,0x3d322a,8);
      oval(head,s*.046,.134,.102,.026,.006,.006,hair,8);
      oval(head,s*.106,.093,-.005,.010,.017,.012,0xa87557,8);
      oval(head,s*.047,.125,.102,.023,.004,.006,skin,8);
    });
    loft(head,[[.064,.017,.012,.106],[.075,.021,.018,.115],[.088,.014,.024,.111],[.121,.011,.012,.102]],skin,10);
    oval(head,0,.035,.105,.028,.009,.006,skin,10);
    oval(head,0,.042,.109,.031,.004,.004,0x96644f);
    var limbs=[];
    [-1,1].forEach(function(side){
      var suffix=side<0?"L":"R";
      var thigh=joint("hip"+suffix,hips,side*.105,-.005,.004);
      var knee=joint("knee"+suffix,thigh,0,-.426,0);
      var ankle=joint("ankle"+suffix,knee,0,-.417,0);
      var toe=joint("toes"+suffix,ankle,0,-.053,.107);
      var shoulder=joint("shoulder"+suffix,spine,side*.203,.435,0);
      var elbow=joint("elbow"+suffix,shoulder,side*.03,-.268,-.004);
      var wrist=joint("wrist"+suffix,elbow,side*.012,-.245,0);
      limbs.push({hip:thigh,knee:knee,ankle:ankle,toe:toe,arm:shoulder,elbow:elbow,hand:wrist,side:side});
      loft(thigh,[[-.45,.050,.052,.006,.78],[-.403,.061,.069,.009,.30],[-.33,.076,.078],[-.21,.085,.093],[-.1,.091,.099]],skin,12,0,0,false,knee);
      loft(thigh,[[-.215,.088,.095],[-.20,.094,.100],[-.09,.101,.116],[.015,.091,.111],[.055,.071,.085]],shorts,14);
      loft(knee,[[-.19,.056,.064,-.012],[-.13,.064,.076,-.013],[-.055,.056,.058],[.015,.058,.061,.007],[.045,.048,.049]],skin,12);
      oval(knee,0,-.009,.041,.046,.052,.029,skin);
      loft(knee,[[-.412,.040,.043],[-.32,.041,.051],[-.24,.051,.062,-.009],[-.15,.065,.077,-.014],[-.098,.064,.069,-.009]],sock,14);
      loft(knee,[[-.125,.066,.074,-.011],[-.11,.066,.073,-.01]],staff?sock:keeper?0xc6d094:team===0?0xf5eadb:0xb2d4f2,14);
      // Przekroje od zapiętka do czubka. Przód cholewki i podeszwy zgina się razem z palcami.
      function shoeLayer(sections,color){
        var first=positions.length/3,n=14;
        sections.forEach(function(section,j){
          var z=section[0],width=section[1],bottom=section[2],top=section[3];
          var blend=Math.max(0,Math.min(1,(z-.064)/.105));
          for(var k=0;k<=n;k++){
            var theta=k*2*Math.PI/n, x=Math.cos(theta)*width;
            var y=(top+bottom)/2+Math.sin(theta)*(top-bottom)/2;
            vertex(ankle,x,y,z,color,.007,.987,toe,blend);
            if(j && k){var d=first+j*(n+1)+k;indices.push(d-n-2,d-n-1,d,d-n-2,d,d-1);}
          }
        });
      }
      shoeLayer([[-.081,.009,-.058,-.035],[-.075,.045,-.062,.021],[-.036,.051,-.062,.057],
        [.012,.050,-.062,.056],[.053,.056,-.062,.040],[.098,.063,-.062,.015],[.151,.063,-.062,-.002],
        [.196,.050,-.056,-.013],[.226,.022,-.048,-.024],[.230,.003,-.036,-.033]],boot);
      shoeLayer([[-.083,.007,-.062,-.047],[-.071,.049,-.071,-.049],[.017,.052,-.073,-.05],
        [.112,.065,-.074,-.050],[.164,.064,-.070,-.049],[.201,.049,-.061,-.044],
        [.228,.019,-.050,-.037],[.231,.003,-.042,-.038]],sole);
      for(var lace=0;lace<4;lace++)oval(ankle,0,.054-lace*.007,.024+lace*.017,.033,.004,.005,0xe2e2d7,8);
      oval(ankle,side*.052,-.026,.037,.008,.008,.045,bootTrim,10);
      oval(ankle,0,-.002,-.072,.028,.020,.007,bootTrim,10);
      [-1,1].forEach(function(s){
        oval(ankle,s*.031,-.073,-.041,.012,.012,.014,0x383c39,8);
        oval(toe,s*.033,-.017,.049,.012,.013,.016,0x383c39,8);
      });
      loft(shoulder,[[-.286,.042,.044,0,.63],[-.248,.045,.048,0,.20],[-.185,.057,.060],[-.112,.060,.066],[-.04,.067,.074]],skin,12,side*.014,0,false,elbow);
      loft(shoulder,[[-.16,.064,.071],[-.146,.069,.077],[-.065,.075,.083],[.002,.071,.087],[.047,.044,.061],[.06,.019,.034]],shirt,14,side*.012,0);
      loft(shoulder,[[-.158,.066,.073],[-.145,.070,.078]],trim,12,side*.012,0);
      loft(elbow,[[-.248,.030,.031],[-.201,.034,.037],[-.126,.042,.050],[-.063,.051,.055],[.004,.045,.048],[.025,.038,.038]],skin,12);
      oval(elbow,0,0,-.006,.046,.047,.045,skin,12);
      var handColor=keeper?0xdceba8:skin;
      loft(wrist,[[-.045,.034,.024,.007],[.014,.030,.032]],handColor,10);
      oval(wrist,0,-.051,.009,.039,.057,.026,handColor);
      for(var f=0;f<4;f++){var fx=(f-1.5)*.016;oval(wrist,fx,-.092+(f===3 ? 0.009:0),.015,.009,.033-(f===3 ? 0.007:0),.010,handColor,8);}
      oval(wrist,-side*.035,-.044,.026,.016,.033,.018,handColor);
      if(keeper)loft(wrist,[[-.016,.042,.04],[.023,.039,.037]],0x293c39,12);
    });
    var geo=new THREE.BufferGeometry();
    geo.setIndex(indices);geo.setAttribute("position",new THREE.Float32BufferAttribute(positions,3));
    geo.setAttribute("color",new THREE.Float32BufferAttribute(colors,3));geo.setAttribute("uv",new THREE.Float32BufferAttribute(uvs,2));
    geo.setAttribute("skinIndex",new THREE.Uint16BufferAttribute(jointIndex,4));geo.setAttribute("skinWeight",new THREE.Float32BufferAttribute(weights,4));
    geo.computeVertexNormals();geo.boundingSphere=new THREE.Sphere(new THREE.Vector3(0,.83,0),1.9);
    var mat=new THREE.MeshLambertMaterial({vertexColors:true,map:this.shirtTexture(kit,number,name,team,keeper,staff)});
    if("skinning" in mat)mat.skinning=true;
    var model=new THREE.SkinnedMesh(geo,mat);model.add(hips);model.bind(new THREE.Skeleton(bones));
    model.castShadow=true;
    group.userData={model:model,hips:hips,spine:spine,neck:neck,head:head,limbs:limbs,
      legL:limbs[0].hip,legR:limbs[1].hip,armL:limbs[0].arm,armR:limbs[1].arm,
      phase:(idx*.37)%1,poseT:0,kickLeg:idx%4===0?0:1};
    group.add(model);
    var height=.97+(idx%7)*.012;
    group.scale.set(height*(.95+.021*(idx%5)),height,height);
    if(parent)parent.add(group);
    return group;
  },

  dispose: function(group){
    if(group.parent)group.parent.remove(group);
    var m=group.userData.model;
    if(m.skeleton.dispose)m.skeleton.dispose();
    m.geometry.dispose();m.material.map.dispose();m.material.dispose();
  }
};
