/* Odwrotna kinematyka nogi w płaszczyźnie strzałkowej i płynne przejścia między pozami. */
var MOTION = {
  clamp: function(x,a,b){return Math.min(b,Math.max(a,x));},
  animate: function(group,speed,dt,action,time,turn,look,diveSide,sideSpeed,forwardSpeed){
    var u=group.userData, clamp=this.clamp, tau=Math.PI*2;
    var stride=clamp(speed/7.7,0,1.25), sprint=clamp((speed-5)/4,0,1);
    var freq=1.10+Math.min(10,speed)*.131;
    u.phase=(u.phase+dt*(speed>.18?freq : 0.28))%1;u.poseT+=dt;
    var breath=Math.sin(u.poseT*2.9),cycle=Math.sin(u.phase*tau), gait=clamp(speed*1.6,0,1);
    var x=0,y=.925+.006*breath+(.012+.024*sprint)*Math.cos(u.phase*tau*2)*gait,z=0;
    var tilt=.025+stride*.135,twist=-cycle*.13*stride,roll=0,bank=clamp(turn||0,-1,1)*.105;
    var rootPitch=0,rootRoll=0;
    var ease=dt>0?1-Math.exp(-dt*24):1;
    if(u.motionMode!==action){u.motionMode=action;u.transition=0;}
    u.transition+=dt;
    var plantedEase=(action==="run" || action==="jockey") && u.transition>.15?1:ease;
    var pace=speed/freq, stance=clamp(.97/Math.max(.05,pace),.27,.62);
    var reach=Math.min(.52,pace*stance/2);
    if(action==="jockey"){y-=.105;tilt+=.075;}
    var direction=u.kickLeg===0?-1:1;
    if(action==="windup" || action==="passload"){twist=-direction*.25;tilt=.12;y-=.025;}
    if(["kick","crosskick","passkick"].includes(action)){twist=direction*.29;tilt=.105;bank+=direction*.055;}
    if(action==="slide"){y=.33;z=-.08;rootPitch=-.68;tilt=.04;}
    if(action==="fallen"){y=.17;rootPitch=1.33;rootRoll=.24;}
    if(action==="dive"){
      var flight=clamp((.65-time)/.65,0,1),side=diveSide||1;
      rootRoll=-side*Math.sin(Math.min(1,flight*2)*1.61);
      y=.58+.51*Math.sin(Math.PI*flight);tilt=.07;twist=.12*side;
    }
    if(action==="header"){y+=.41*Math.sin(Math.PI*clamp(1-time/.45,0,1));tilt=.23*Math.cos(time*10);}
    if(action==="throw"){tilt=-.25+.65*clamp(1-time/.52,0,1);}
    if(action==="celebrate"){y+=Math.abs(Math.sin(u.poseT*5))*.075;tilt=-.045;}
    u.hips.position.set(x+.024*cycle*gait,y,z);
    u.hips.rotation.x+=(rootPitch-u.hips.rotation.x)*ease;u.hips.rotation.z+=(rootRoll-bank-u.hips.rotation.z)*ease;
    u.hips.rotation.y+=(cycle*.06*stride-u.hips.rotation.y)*ease;
    u.spine.rotation.x+=(tilt-u.spine.rotation.x)*ease;
    u.spine.rotation.y+=(twist-u.spine.rotation.y)*ease;
    u.spine.rotation.z+=(roll+.025*cycle*gait-u.spine.rotation.z)*ease;
    u.head.rotation.y+=(clamp(look||0,-.64,.64)-twist*.65-u.head.rotation.y)*ease;
    u.neck.rotation.x+=(-tilt*.72-.025-u.neck.rotation.x)*ease;
    u.limbs.forEach(function(l,i){
      var phase=(u.phase+i*.5)%1,swing=clamp((phase-stance)/(1-stance),0,1);
      var swingBlend=swing*swing*(3-2*swing);
      var footZ=phase<stance?reach*(1-2*phase/stance):reach*(2*swingBlend-1);
      var lift=phase<stance?0:Math.sin(Math.PI*swing)*(.065+.30*stride)*gait;
      var lateral=0;
      if(action==="jockey"){
        lateral=(sideSpeed===undefined ? 0.85:sideSpeed)*footZ;
        footZ*=forwardSpeed===undefined ? 0.35:forwardSpeed;
      }
      var flat=phase<stance?(phase/stance>.67 ? 0.34*(phase/stance-.67)/.33:-.14*Math.max(0,1-phase/stance*4)) : 0.38*Math.sin(swing*tau)*stride;
      var down=y-.005-.084-lift-Math.max(0,Math.sin(flat)*.17);
      var dist=clamp(Math.hypot(down,footZ,lateral),.16,.8429);
      var a=.426,b=.417;
      var thigh=-(Math.atan2(footZ,down)+Math.acos(clamp((a*a+dist*dist-b*b)/(2*a*dist),-1,1)));
      var knee=Math.PI-Math.acos(clamp((a*a+b*b-dist*dist)/(2*a*b),-1,1));
      var ankle=-thigh-knee+flat*gait, toe=-Math.max(0,flat)*gait;
      var arm=Math.cos(phase*tau)*(.33+.45*sprint)*gait-.11;
      var elbow=-.22-(.46+.45*sprint)*gait-.23*gait*Math.cos(phase*tau);
      var spread=l.side*(.12+.045*stride), hipSide=0, hipYaw=0, palm=l.side*.10;
      if(action==="jockey"){spread=l.side*.40;elbow=-.70;hipSide=l.side*.12+Math.atan2(lateral,down);}
      if(action==="windup" || action==="passload" || action==="kick" || action==="passkick" || action==="crosskick"){
        var hard=action!=="passkick" && action!=="passload";
        var loading=action==="windup" || action==="passload";
        var follow=loading?0 : 0.77+.23*clamp((1-time/(hard ? 0.40 : 0.30))/.23,0,1);
        var settle=loading?0:clamp((.15-time)/.15,0,1);
        if(i===u.kickLeg){
          thigh=((hard ? 0.46 : 0.19)-(hard?1.64:1.15)*follow)*(1-settle);
          knee=((hard?1.43 : 0.84)*(1-follow))*(1-settle)+.13;
          ankle=-.18+follow*.28;hipYaw=(hard?-.13:-.62)*direction;
        }else{thigh=-.27;knee=.39;ankle=-.12;hipSide=.08;}
        spread=l.side*(.51+(1-follow)*.24);arm=i!==u.kickLeg?-.43 : 0.34;elbow=-.51;
      }else if(action==="slide" || action==="fallen"){
        thigh=i===1?-1.24:-.78;knee=i===1 ? 0.12:1.32;ankle=-.1;
        spread=l.side*(action==="slide" ? 0.84:1.12);arm=-.32;elbow=-.44;
      }else if(action==="standtackle"){
        thigh=i===1?-.90:-.31;knee=i===1 ? 0.25 : 0.64;ankle=-.09;spread=l.side*.56;
      }else if(action==="throw"){
        arm=-2.86+clamp(1-time/.52,0,1)*1.50;elbow=-.78+clamp(1-time/.52,0,1)*.60;
        spread=l.side*.15;thigh=i===1?-.26 : 0.06;knee=.30;ankle=-.21;
      }else if(action==="keeperhold"){arm=-.64;elbow=-1.03;spread=-l.side*.13;palm=-l.side*.27;}
      else if(action==="header"){spread=l.side*.78;arm=-.57;elbow=-.87;knee=.57;ankle=-.3;}
      else if(action==="dive"){arm=-2.45;spread=l.side*.24;elbow=-.15;thigh=i===1?-.34 : 0.26;knee=i===1 ? 0.58 : 0.32;ankle=-.23;}
      else if(action==="celebrate"){spread=l.side*(2.06+.12*breath);arm=-.16;elbow=-.31;thigh=-.19;knee=.33;ankle=-.14;}
      l.hip.rotation.x+=(thigh-l.hip.rotation.x)*plantedEase;l.hip.rotation.z+=(hipSide-l.hip.rotation.z)*plantedEase;
      l.hip.rotation.y+=(hipYaw-l.hip.rotation.y)*ease;l.knee.rotation.x+=(knee-l.knee.rotation.x)*plantedEase;
      l.ankle.rotation.x+=(ankle-l.ankle.rotation.x)*plantedEase;l.toe.rotation.x+=(toe-l.toe.rotation.x)*plantedEase;
      l.arm.rotation.x+=(arm-l.arm.rotation.x)*ease;l.arm.rotation.z+=(spread-l.arm.rotation.z)*ease;
      l.elbow.rotation.x+=(elbow-l.elbow.rotation.x)*ease;l.hand.rotation.z+=(palm-l.hand.rotation.z)*ease;
      var wristCurl=action==="dive"?-.20 : 0.12+.11*gait;
      l.hand.rotation.x+=(wristCurl-l.hand.rotation.x)*ease;
    });
  },
  sit: function(group){
    var u=group.userData;u.hips.position.y=.67;u.spine.rotation.x=.09;
    u.limbs.forEach(function(l){l.hip.rotation.x=-1.50;l.knee.rotation.x=1.49;l.arm.rotation.x=-.32;l.elbow.rotation.x=-.91;});
  }
};
