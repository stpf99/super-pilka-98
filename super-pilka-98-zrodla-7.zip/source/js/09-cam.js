/* ============================================================
   SUPER POLKA '98 · 09-cam.js — kamery, reżyser, powtórki
   0: TV boczna · 1: Góra '98 · 2: Za piłką
   • TV: adaptacyjny kadr — prowadzenie piłki z wyprzedzeniem,
     auto-cofnięcie i uniesienie przy autowej bandzie (piłka zawsze
     widoczna także przy wrzucie z autu), najazd przy polu karnym.
   • Cięcia reżysera: kick-off (intro zza wykonawcy), gol (zbliżenie
     z najazdem), karny (najazd podczas celowania), rożny (kąt z rogu).
   • POWTÓRKA: REC buforuje ~6 s gry (16 Hz), po golu REPLAY odtwarza
     akcję w zwolnionym tempie kinową kamerą (plan z trybuny + plan
     zza akcji z najazdem na bramkę), letterbox + znacznik w HUD.
   ============================================================ */
var CAM = {
  pos: { x:0, y:30, z:52 },
  look: { x:0, y:0, z:0 },
  fov: 38,
  menuAngle: 0,
  modeNames: ["TV", "TOP", "BEHIND","PLAYER"],
  _last: null,

  /* interaktywne zbliżenie: 1 = Neutralne; <1 najazd, >1 odjazd.
     Kółko myszy / klawisze + − (patrz INPUT + MAIN); zastosowane w trybach
     TV / Góra / Za piłką — kadry reżysera (gol, karny, rożny, intro) bez zmian. */
  zoom: 1, zoomT: 1,
  zoomBy: function(f){
    this.zoomT = Math.max(0.5, Math.min(2.4, this.zoomT + f));
  },

  setMode: function(m){ SET.cam = ((m%4)+4)%4; },

  update: function(dt, state){
    if(state === "replay") return;            /* kadr prowadzi REPLAY */
    var b = SIM.ball;
    var des = { x:0, y:30, z:52 }, look = { x:0, y:0, z:0 }, fov = 38;
    var m = SET.cam|0;
    var snap = false;
    var zoomable = false;          /* true tylko w trybach gracza (TV/TOP/BEHIND) */
    if(this._last !== state){
      /* twarde cięcie tylko w kluczowych momentach transmisji */
      snap = state==="kickoff" || state==="goal" || state==="penalty" ||
             (state==="play" && this._last==="kickoff");
      this._last = state;
    }

    if(state==="goal"){
      /* zbliżenie na strzelca + powolny najazd */
      var scorer = null;
      for(var i=0;i<SIM.players.length;i++)
        if(SIM.players[i].action==="celebrate"){ scorer = SIM.players[i]; break; }
      if(scorer){
        des = { x: scorer.pos.x - SIM.teams[scorer.team].dir*7, y: 4.5, z: scorer.pos.z + 9 };
        look = { x: scorer.pos.x, y: 1.2, z: scorer.pos.z };
        var el = Math.max(0, 3.4 - (RULES.celebT||0));
        fov = 45 - Math.min(10, el*4.2);
      } else { des = { x:0, y:22, z:44 }; look = { x:0, y:0.5, z:0 }; fov = 38; }
    }
    else if(state==="kickoff"){
      /* intro zza wykonawcy — jak w '98 */
      var tk = RULES.taker;
      if(tk){
        var dir = SIM.teams[RULES.restartTeam].dir;
        des = { x: tk.pos.x - dir*7.5, y: 5.2, z: tk.pos.z*0.6 + 3.6 };
        look = { x: tk.pos.x + dir*14, y: 0.9, z: tk.pos.z*0.5 };
        fov = 47;
      }
    }
    else if(state==="menu"){
      this.menuAngle += dt*.055;
      des={x:18+Math.sin(this.menuAngle)*12,y:15,z:35+Math.cos(this.menuAngle)*4};
      look={x:-8,y:4,z:-17};
      fov = 42;
    }
    else if(m===0){ /* TV boczna — kadr jak transmisja: prowadzenie z wyprzedzeniem,
                       piłka przy dowolnej bandzie zawsze w kadrze */
      zoomable = true;
      var lx=Math.max(-48,Math.min(48,b.x+b.vx*.26));
      var lz=Math.max(-32,Math.min(32,b.z+b.vz*.16));
      var wide=Math.abs(b.y)>2?Math.min(b.y*.42,3.1):0;
      var box=Math.min(1,Math.max(0,(Math.abs(b.x)-28)/24));
      des={x:lx*.88,y:27+Math.max(0,b.z-8)*.43+wide,z:42+b.z*.66};
      look={x:lx,y : 0.4+Math.min(2,b.y*.19),z:lz};
      fov=44-box*3+wide;
    }
    else if(m===1){ /* Góra '98 */
      zoomable = true;
      des = { x: Math.max(-14, Math.min(14, b.x*0.28)), y: 94, z: Math.max(-8, Math.min(8, b.z*0.24)) + 12 };
      look = { x: Math.max(-26, Math.min(26, b.x*0.5)), y: 0, z: Math.max(-16, Math.min(16, b.z*0.42)) };
      fov = 45;
    }
    else if(m===2){ /* Za piłką */
      zoomable = true;
      var d = SIM.teams[0].dir;
      des = { x: b.x - d*11, y: 7.5 + Math.max(0, b.z)*0.16, z: Math.max(-33, Math.min(33, b.z*0.8)) };
      look = { x: b.x + d*15, y: 0.8, z: Math.max(-32, Math.min(32, b.z*0.9)) };
      var gpush = Math.max(0, (Math.abs(b.x) - 30) / 22);
      fov = 52 - gpush*6;
    }
    else { // Niski kadr zza barku pozwala oglądać pracę nóg w trakcie gry.
      zoomable=true;
      var tracked=SIM.teams[0].user || b.owner || SIM.nearestToBall(b.lastTouchTeam===1?1:0,true);
      var dir=SIM.dirX(tracked.team),px=tracked.pos.x,pz=tracked.pos.z;
      des={x:px-dir*5.6,y:2.45,z:pz+dir*1.25};
      look={x:px+dir*4.6,y : 0.92,z:pz+Math.max(-2,Math.min(2,(b.z-pz)*.22))};
      fov=55;
    }
    if(state==="penalty"){
      zoomable=false;des = { x: b.x - SIM.teams[RULES.restartTeam].dir*10, y: 6.5, z: 4 };
      look = { x: b.x + SIM.teams[RULES.restartTeam].dir*8, y: 1, z: 0 };
      fov = 46 - Math.min(7, RULES.stateT*2.0);   /* najazd podczas celowania */
    }
    else if(state==="corner" && Math.abs(RULES.restartPos.x) > 40){
      zoomable=false;var c = RULES.restartPos;                   /* kadr z rogu — jak przed rożnym */
      des = { x: Math.max(-46, Math.min(46, c.x*0.9)), y: 24, z: 42 + Math.abs(c.z)*0.4 };
      look = { x: c.x*0.8, y: 0.8, z: c.z*0.7 };
      fov = 41;
    }

    /* zoom interaktywny — skala odległości kamera→punkt celowania
       (tylko tryby TV/TOP/BEHIND; kadry reżysera zostają bez zmian) */
    this.zoom += (this.zoomT - this.zoom) * Math.min(1, dt*7);
    if(zoomable){
      des.x = look.x + (des.x - look.x)*this.zoom;
      des.y = look.y + (des.y - look.y)*this.zoom;
      des.z = look.z + (des.z - look.z)*this.zoom;
    }

    if(snap){
      this.pos.x=des.x; this.pos.y=des.y; this.pos.z=des.z;
      this.look.x=look.x; this.look.y=look.y; this.look.z=look.z;
      this.fov=fov;
    } else {
      var kp = Math.min(1, dt*3.4), kl = Math.min(1, dt*5.2), kf = Math.min(1, dt*3);
      this.pos.x += (des.x-this.pos.x)*kp;
      this.pos.y += (des.y-this.pos.y)*kp;
      this.pos.z += (des.z-this.pos.z)*kp;
      this.look.x += (look.x-this.look.x)*kl;
      this.look.y += (look.y-this.look.y)*kl;
      this.look.z += (look.z-this.look.z)*kl;
      this.fov += (fov-this.fov)*kf;
    }

    WORLD.cam.position.set(this.pos.x, this.pos.y, this.pos.z);
    WORLD.cam.lookAt(this.look.x, this.look.y, this.look.z);
    if(Math.abs(WORLD.cam.fov - this.fov) > 0.05){
      WORLD.cam.fov = this.fov;
      WORLD.cam.updateProjectionMatrix();
    }
  }
};

/* ============ NAGRYWANIE AKCJI — bufor kołowy ~16 Hz ============ */
var REC = {
  buf: [], acc: 0, span: 0,
  stride:8, actions:["run","slide","kick","fallen","celebrate","throw","standtackle","dive","header","passkick","crosskick","jockey","windup","keeperhold","passload"],
  STEP: 0.062,             /* ~16 klatek nagrania na sekundę */
  MAX: 7.0,                /* ile sekund wstecz trzymać */

  reset: function(){ this.buf.length = 0; this.acc = 0; this.span = 0; },

  push: function(dt){
    this.acc += dt;
    if(this.acc < this.STEP) return;
    this.acc -= this.STEP;
    var ps = SIM.players, n = ps.length;
    var p=new Float32Array(n*this.stride);
    for(var i=0;i<n;i++){
      var pl=ps[i],o=i*this.stride;
      p[o]=pl.pos.x;p[o+1]=pl.pos.z;p[o+2]=pl.face;p[o+3]=Math.max(0,this.actions.indexOf(SIM.visualAction(pl)));
      p[o+4]=pl.actionT;p[o+5]=Math.hypot(pl.vel.x,pl.vel.z);p[o+6]=pl.mesh?pl.mesh.userData.phase:0;p[o+7]=pl.diveSide;
    }
    var b = SIM.ball;
    this.span += this.STEP;
    this.buf.push({ t: this.span, bx: b.x, by: b.y, bz: b.z, bvx: b.vx, bvz: b.vz, p: p });
    while(this.buf.length > 2 && this.buf[this.buf.length-1].t - this.buf[0].t > this.MAX)
      this.buf.shift();
  },

  canReplay: function(){
    if(this.buf.length < 20) return false;
    var t1 = this.buf[this.buf.length-1].t;
    for(var i=0;i<this.buf.length;i++)
      if(t1 - this.buf[i].t >= 3.4) return true;    /* minimum ~3,5 s materiału */
    return false;
  },

  frames: function(){
    var t1 = this.buf[this.buf.length-1].t, out = [];
    for(var i=0;i<this.buf.length;i++)
      if(t1 - this.buf[i].t <= 6.0) out.push(this.buf[i]);
    return out;
  }
};

/* ============ POWTÓRKA — kinowa reżyseria po golu ============ */
var REPLAY = {
  active: false, t: 0, dur: 5, fr: null, f0: 0,
  goalDir: 1, side: 1, _prev: null, _dt: 0.016,

  SPEED: 0.8,              /* tempo odtwarzania (0.8 = lekkie zwolnienie) */

  begin: function(){
    var fr = REC.frames();
    if(!fr || fr.length < 14){ this.active = false; return false; }
    this.fr = fr;
    this.f0 = fr[0].t;
    var span = fr[fr.length-1].t - fr[0].t;
    this.dur = span / this.SPEED;
    this.t = 0;
    this.goalDir = fr[fr.length-1].bx > 0 ? 1 : -1;   /* do której bramki wpadła */
    this.side = fr[fr.length-1].bz >= 0 ? 1 : -1;     /* kamera z drugiej połowy szerokości */
    this._prev = null;
    this.active = true;
    HUD.replayUI(true);
    HUD.commentary(tPick("c_rep"));
    WORLD.crowdPulse = 0.35;
    AUDIO.excitementSet(0.5);
    this._apply(this.f0);
    return true;
  },

  /* zwraca true, gdy powtórka się skończyła */
  update: function(dt){
    if(!this.active) return true;
    if(INPUT.slots[0].camP || INPUT.slots[1].camP){ this.finish(); return true; }
    this._dt = Math.min(0.05, dt);
    this.t += dt;
    var ft = this.f0 + this.t*this.SPEED;
    if(ft >= this.fr[this.fr.length-1].t){ this.finish(); return true; }
    this._apply(ft);
    this._cam();
    return false;
  },

  finish: function(){
    this.active = false;
    HUD.replayUI(false);
    SIM.syncMeshes(0);            /* natychmiastowy powrót do realnych pozycji */
  },

  _actStr: ["run","slide","kick","fallen","celebrate"],

  _apply: function(ft){
    var fr = this.fr, i = 0;
    while(i < fr.length-1 && fr[i+1].t < ft) i++;
    var a = fr[i], b2 = fr[Math.min(fr.length-1, i+1)];
    var k = (ft - a.t) / ((b2.t - a.t) || 1);
    var bx = a.bx + (b2.bx-a.bx)*k, by = a.by + (b2.by-a.by)*k, bz = a.bz + (b2.bz-a.bz)*k;
    WORLD.ball.position.set(bx, by, bz);
    WORLD.blob.position.set(bx, 0.022, bz);
    var bs = 0.7 + Math.max(0, by-0.15)*0.55;
    WORLD.blob.scale.set(bs, bs, 1);
    WORLD.blob.material.opacity = Math.max(0.12, 0.5 - (by-0.15)*0.22);
    for(var pi=0; pi<SIM.players.length; pi++){
      var pl = SIM.players[pi];
      if(pl.off || !pl.mesh){ if(pl.mesh) pl.mesh.visible = false; continue; }
      pl.mesh.visible = true;
      var o = pi*REC.stride;
      var x = a.p[o] + (b2.p[o]-a.p[o])*k;
      var z = a.p[o+1] + (b2.p[o+1]-a.p[o+1])*k;
      var face = a.p[o+2] + SIM._angDelta(a.p[o+2], b2.p[o+2])*k;
      var frame=k<.5?a:b2,act=frame.p[o+3]|0;
      pl.mesh.position.set(x, 0, z);
      pl.mesh.rotation.y = face;
      var phase=a.p[o+6]+((b2.p[o+6]-a.p[o+6]+1)%1)*k;
      pl.mesh.userData.phase=phase%1;
      WORLD.animatePlayer(pl.mesh,a.p[o+5]+(b2.p[o+5]-a.p[o+5])*k,0,REC.actions[act],frame.p[o+4],0,0,frame.p[o+7]);
    }
    WORLD.playerShadows(SIM.players);
    this._prev = { bx: bx, bz: bz };
  },

  _cam: function(){
    var bp = WORLD.ball.position;
    var k = Math.min(1, this.t / this.dur);
    var d = this.goalDir;
    if(k < 0.42){
      /* PLAN A: niska kamera od strony bocznej — prowadzi piłkę jak operator */
      var cz = -this.side * 19;
      WORLD.cam.position.set(
        Math.max(-42, Math.min(42, bp.x*0.9)),
        2.6 + k*1.4,
        cz - this.side * Math.max(0, Math.abs(bp.z)-8)*0.35 );
      WORLD.cam.lookAt(bp.x, Math.max(0.6, bp.y), bp.z);
      WORLD.cam.fov = 34 - k*5;
    } else {
      /* PLAN B: zza akcji — najazd na bramkę wraz z dobiegiem piłki */
      var kk = (k - 0.42) / 0.58;
      var dist = 15 - kk*7;
      WORLD.cam.position.set(
        bp.x - d*dist,
        5.6 - kk*2.6,
        Math.max(-30, Math.min(30, bp.z*0.8)) );
      WORLD.cam.lookAt(d*HL, 1.5, bp.z*0.4);
      WORLD.cam.fov = 40 - kk*14;
    }
    WORLD.cam.updateProjectionMatrix();
  }
};
