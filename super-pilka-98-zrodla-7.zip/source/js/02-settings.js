/* ============================================================
   SUPER PILKA '98 · 02-settings.js — ustawienia zapisywane lokalnie
   ============================================================ */
var SET = {
  mode: 0,        // 0 = 1 gracz vs komputer, 1 = 2 graczy, 2 = oglądaj (AI vs AI)
  half: 120,      // sekundy na połowę: 60/120/180/300
  diff: 1,        // 0 łatwy, 1 normalny, 2 trudny
  ref:  1,        // 0 łagodny, 1 normalny, 2 surowy
  cam:  0,        // 0 TV, 1 góra, 2 za piłką, 3 za graczem
  night: 1,       // 1 = noc pod reflektorami, 0 = dzień
  q:    1,        // 0 niska, 1 średnia, 2 wysoka
  snd:  0.6,      // głośność 0..1
  lang:"pl",
  home:"KS SOKÓŁ", away:"TS ORZEŁ",
  formH:"4-3-3", formA:"4-4-2", tacticH:"balanced", tacticA:"balanced"
};
var SET_KEY = "sp98_v1";
try{
  var _saved = JSON.parse(localStorage.getItem(SET_KEY) || "{}");
  var choices = {mode:[0,1,2],half:[60,120,180,300],diff:[0,1,2],ref:[0,1,2],cam:[0,1,2,3],
    night:[0,1],q:[0,1,2],snd:[0,0.6,1],lang:["pl","en"],formH:Object.keys(LINEUP.forms),
    formA:Object.keys(LINEUP.forms),tacticH:["balanced","press","counter"],tacticA:["balanced","press","counter"]};
  Object.keys(SET).forEach(function(key){
    if(key==="home" || key==="away"){
      if(typeof _saved[key]==="string" && _saved[key].trim()) SET[key]=_saved[key].trim().slice(0,14);
    } else if(choices[key].includes(_saved[key])) SET[key]=_saved[key];
  });
}catch(e){ /* file:// bez localStorage — ignoruj */ }

function SET_save(){
  try{ localStorage.setItem(SET_KEY, JSON.stringify(SET)); }catch(e){}
}
function SET_applyLang(){ I18N_cur = SET.lang; applyI18n(); }

/* segment menu: klik + odczyt wartości */
function SET_bindSeg(id, key, parse, after){
  var seg = document.getElementById(id);
  function sync(){
    seg.querySelectorAll("button").forEach(function(b){
      var on = String(b.dataset.v) === String(SET[key]);
      b.classList.toggle("on", on); b.setAttribute("aria-pressed", String(on));
    });
  }
  seg.addEventListener("click", function(e){
    var b = e.target.closest("button"); if(!b) return;
    SET[key] = parse ? parse(b.dataset.v) : b.dataset.v;
    SET_save(); sync(); UI_click();
    if(after) after();
    DESK.refresh();
  });
  sync();
  return sync;
}
function SET_updateModeUI(){
  var tg = document.getElementById("tagAway");
  if(tg) tg.textContent = SET.mode===1 ? "P2" : "CPU";
  document.getElementById("tagHome").textContent = SET.mode===2 ? "CPU" : "P1";
}
var syncCameraMenu;
function SET_bindAll(){
  SET_bindSeg("segMode","mode", Number, function(){ SET_updateModeUI(); });
  SET_bindSeg("segHalf","half", Number);
  SET_bindSeg("segDiff","diff", Number);
  SET_bindSeg("segRef","ref", Number);
  syncCameraMenu = SET_bindSeg("segCam","cam", Number);
  SET_bindSeg("segNight","night", Number, function(){ if(WORLD.setNight) WORLD.setNight(SET.night===1); });
  SET_bindSeg("segQ","q", Number, function(){ WORLD.quality(); });
  SET_bindSeg("segSnd","snd", Number, function(){ AUDIO.setVolume(); });
  SET_bindSeg("segLang","lang", String, function(){
    SET_applyLang(); UI_click();
  });
  ["H","A"].forEach(function(side, team){
    SET_bindSeg("form"+side,"form"+side,String,function(){ if(SIM.teams.length) LINEUP.apply(team); });
    SET_bindSeg("tactic"+side,"tactic"+side,String);
  });
  var ih = document.getElementById("inHome"), ia = document.getElementById("inAway");
  ih.value = SET.home; ia.value = SET.away;
  ih.addEventListener("change", function(){ SET.home = ih.value.trim() || "KS SOKÓŁ"; ih.value=SET.home; SET_save(); DESK.refresh(); });
  ia.addEventListener("change", function(){ SET.away = ia.value.trim() || "TS ORZEŁ"; ia.value=SET.away; SET_save(); DESK.refresh(); });
  SET_updateModeUI();
}

/* parametry rozgrywki wynikające z ustawień */
var DIFF = [
  { react:0.50, passErr:2.3, shotErr:1.7, spd:0.93, press:15, mark:3.2, gk:0.55, aiIQ:0.55 },
  { react:0.34, passErr:1.4, shotErr:1.0, spd:1.00, press:20, mark:2.1, gk:0.70, aiIQ:0.75 },
  { react:0.21, passErr:0.8, shotErr:0.6, spd:1.06, press:25, mark:1.3, gk:0.82, aiIQ:0.92 }
];
var REFSTRICT = [0.7, 1.0, 1.45];
