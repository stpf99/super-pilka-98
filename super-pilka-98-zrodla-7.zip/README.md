# Super Piłka ’98

Samodzielna gra piłkarska 3D na komputer. Otwórz `super-pilka-98.html` w przeglądarce z obsługą WebGL. Gra działa z dysku, także offline. Przed meczem możesz ustawić tryb solo, dwóch graczy lokalnie lub mecz dwóch drużyn komputerowych.

## Podgląd zawodników

W zakładce **Drużyny** kliknij **Obejrzyj model 3D**. Przeciągaj myszą, by obracać postać. Wybierz ruch i kadr. Parada bramkarza pokazuje zawodnika w rękawicach. Podczas meczu klawisz **C** przełącza cztery kamery, w tym kamerę zza zawodnika. Kółko i klawisze **+** oraz **−** zmieniają zbliżenie.

## Sterowanie

| Akcja | Gracz 1 | Gracz 2 | Pad Xbox / PlayStation |
|---|---|---|---|
| Ruch i celowanie | WASD | Strzałki | Lewa gałka lub krzyżak |
| Podanie / pressing | K | Przecinek | A / ✕ |
| Strzał / odbiór na stojąco | L | Kropka | B / ◯ |
| Dośrodkowanie / wślizg | J | Ukośnik | X / □ |
| Podanie prostopadłe | I | M | Y / △ |
| Sprint | Lewy Shift lub spacja | Prawy Shift | RT / R2 |
| Bliski drybling / obrona bokiem | E | B | LT / L2 |
| Strzał techniczny | Q + L | H + kropka | RB + B / R1 + ◯ |
| Podaj i wyjdź na pozycję | O + K | N + przecinek | LB + A / L1 + ✕ |
| Zmiana obrońcy | O | N | LB / L1 |
| Pauza | Esc | Esc | Start / Options |

Przytrzymaj podanie albo strzał, aby ustalić siłę, i puść przycisk. Przy kombinacjach trzymaj modyfikator podczas ładowania. Po zagraniu bez ruchu gałką lub klawiaturą adresat sam wybiega do podania. Przy wznowieniu od środka użyj podania.

## Zbudowanie pełnej gry ze źródeł

W rozpakowanym katalogu uruchom:

```bash
python3 build.py
```

Powstanie `super-pilka-98.html`. Skrypt korzysta ze standardowej biblioteki Pythona. Silnik Three.js jest dołączony w katalogu `source`.

Modele i materiały znajdują się w `source/js/05-athletes.js`, animacje stawów w `source/js/05-motion.js`, a podgląd postaci w `source/js/10-showroom.js`.
