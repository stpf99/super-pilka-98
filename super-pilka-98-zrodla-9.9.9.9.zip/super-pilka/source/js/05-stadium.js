// Osiem połączonych odcinków. Narożniki szerokich pierścieni spotykają się na dwusiecznych.
var STADIUM={
  time:{value:0},roars:[{value:0},{value:0}],goalTeam:-1,goalLeft:0,lastBeat:-1,
  /* fala meksykańska (poz. 7): waveU — kąt frontu, waveA — głośność; steruje nimi tick */
  waveU:{value:-100},waveA:{value:0},waveT:-1,waveCd:24,
  corners:[[-46,43],[46,43],[61,28],[61,-28],[46,-43],[-46,-43],[-61,-28],[-61,28]],
  sides:[],batches:[],anchors:[{},{}],cloth:[],names:[],rows:14,
  row:function(r){return {d:.32+r*1.11+(r>=7?1.85:0),y:1.23+r*.65+(r>=7?1.18:0)};},
  init:function(world){
    var self=this,group=this.group=new THREE.Group();group.name="Stadion Miejski";world.scene.add(group);
    var sides=this.sides=this.corners.map(function(a,i){
      var b=self.corners[(i+1)%8],dx=b[0]-a[0],dz=b[1]-a[1],len=Math.hypot(dx,dz);
      return {a:a,b:b,len:len,nx:-dz/len,nz:dx/len,team:[1,1,1,0,0,0,0,1][i],bays:[7,2,4,2,7,2,4,2][i]};
    });
    function joint(a,b){var k=1+a.nx*b.nx+a.nz*b.nz;return [(a.nx+b.nx)/k,(a.nz+b.nz)/k];}
    sides.forEach(function(s,i){
      var u=joint(sides[(i+7)%8],s),v=joint(s,sides[(i+1)%8]);s.yaw=Math.atan2(-s.nx,-s.nz);
      s.at=function(t,d,y){return [(1-t)*(s.a[0]+d*u[0])+t*(s.b[0]+d*v[0]),y,(1-t)*(s.a[1]+d*u[1])+t*(s.b[1]+d*v[1])];};
    });
    this.cloth=[arenaTexture(512,128),arenaTexture(512,128)];
    this.setNames(SET.home,SET.away);
    var surface=new ArenaGeometry(),metal=new ArenaGeometry(),lights=new ArenaGeometry();
    var glassItems=[],nameplates=[];
    var seatItems=[],banks=new Map(),scarves=[[],[]],flags=[[],[]],fabricPanels=[[],[]],seatColors=[
      [0x742b42,0xa1374b,0xb94a58,0xede2d2],[0x253e62,0x2a5991,0x3978b2,0xd4e2e5]];
    var seed=981998;
    function random(){seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;}
    function addFan(s,side,t,r,pose,style,featured,detailed){
      var row=self.row(r),p=s.at(t,row.d+.45,row.y+.018),height=featured?1.035:.88+random()*.22;
      var yaw=s.yaw+(random()-.5)*(featured?.16:.44);
      var matrix=arenaMatrix(p[0],p[1],p[2],yaw,height*(.89+random()*.20),height,height);
      var tone=.79+.23*random(),warm=(style%3-1)*.017;
      var item={matrix:matrix,rank:featured?-2-random():random(),color:new THREE.Color(tone+warm,tone,tone-warm)};
      var real=detailed||pose==="brass"||pose==="drum",key=[s.team,style,pose,+real].join("-");
      if(!banks.has(key))banks.set(key,{team:s.team,style:style,pose:pose,real:real,items:[]});
      banks.get(key).items.push(item);if(pose==="scarf")scarves[s.team].push(item);
      if(featured&&(pose==="drum"||pose==="brass"||pose==="scarf")&&!self.anchors[s.team][pose])self.anchors[s.team][pose]={p:p,side:side};
    }
    sides.forEach(function(s,side){
      function at(t,d,y){return s.at(t,d,y);}
      function band(d0,y0,d1,y1,color,t0,t1){
        t0=t0===undefined?0:t0;t1=t1===undefined?1:t1;
        if(side===4&&Math.max(d0,d1)<5.9&&t0<.524&&t1>.476){
          if(t0<.476)band(d0,y0,d1,y1,color,t0,.476);
          if(t1>.524)band(d0,y0,d1,y1,color,.524,t1);
          return;
        }
        var a=at(t0,d0,y0),b=at(t1,d0,y0),k=surface.uv.length;
        surface.quad(a,b,at(t1,d1,y1),at(t0,d1,y1),color);
        var across=Math.hypot(b[0]-a[0],b[2]-a[2])/2,back=Math.hypot(d1-d0,y1-y0)/2;
        surface.uv[k+2]=surface.uv[k+4]=across;surface.uv[k+5]=surface.uv[k+7]=back;
      }
      function beam(t0,d0,y0,t1,d1,y1,rad,col){metal.rod(at(t0,d0,y0),at(t1,d1,y1),rad,rad,col,6);}
      var pal=SUPPORTERS.teams[s.team],isLong=side===0||side===4;
      band(-.33,.02,-.33,1.21,0x526269);
      band(-.37,1.15,-.37,1.25,0xc8c6b3);band(-.33,1.23,.34,1.23,0x9b9c92);
      // Dwa poziomy betonowych stopni, promenada i odsłonięte schody przy granicach sektorów.
      for(var rowNum=0;rowNum<self.rows;rowNum++){
        var row=self.row(rowNum),next=self.row(rowNum+1);
        band(row.d,row.y,next.d,row.y,rowNum%2?0x798488:0x828b8a);
        band(next.d,row.y,next.d,next.y,rowNum===6?0x32404c:0x59656c);
        if(rowNum===6){band(next.d-.035,row.y+.86,next.d-.035,row.y+1.03,pal[0]);}
        var cols=Math.floor(s.len/.86);
        for(var col=0;col<cols;col++){
          var t=(col+.5)/cols,across=t*s.bays,local=(across%1)*s.len/s.bays;
          if(Math.min(local,s.len/s.bays-local)<.67)continue;
          if(side===4&&rowNum<=4&&Math.abs(t-.5)*s.len<2.28)continue;
          var chair=at(t,row.d+.60,row.y);
          var cidx=(Math.floor(across)+Math.floor(rowNum/3))%5===0?3:(col+rowNum)%3;
          seatItems.push({matrix:arenaMatrix(chair[0],chair[1],chair[2],s.yaw,1,1,1),color:new THREE.Color(seatColors[s.team][cidx]).convertSRGBToLinear()});
          var rel=col-Math.floor(cols*.32);
          var featured=isLong&&rowNum===0&&rel>=-2&&rel<=2;
          var close=isLong&&rowNum<5&&Math.abs(rel)<=6;
          if(!featured&&random()<.054)continue;
          var draw=random(),pose=draw<.29?"seat":draw<.48?"clap":draw<.64?"scarf":draw<.77?"wave":"idle";
          var style=Math.floor(random()*8);
          if(featured){
            pose=["wave","drum","scarf","brass","clap"][rel+2];style=[2,1,4,3,6][rel+2];
          }else if(rowNum===2&&col===Math.floor(cols*.69)){pose=side%2?"brass":"drum";}
          addFan(s,side,t,rowNum,pose,style,featured,close);
        }
        for(var aisle=0;aisle<=s.bays;aisle++){
          var v=aisle/s.bays,lo=Math.max(0,v-.57/s.len),hi=Math.min(1,v+.57/s.len);
          band(row.d+.003,row.y+.01,row.d+.08,row.y+.01,0xd8c38a,lo,hi);
          if(rowNum%4===0&&aisle>0&&aisle<s.bays){
            var end=self.row(Math.min(rowNum+3,self.rows-1));
            beam(v,row.d,row.y,v,row.d,row.y+.82,.031,0xadb7b6);
            beam(v,row.d,row.y+.82,v,end.d+.5,end.y+.82,.038,0xaeb9b9);
          }
        }
      }
      // Balustrady, flagi sektorowe, numeracja, zadaszenie z widocznymi dźwigarami i świetlikami.
      var roofPanels=s.bays*4,low=6.85,high=19.8;
      for(var k=0;k<roofPanels;k++){
        var l=k/roofPanels,h=(k+1)/roofPanels,roofColor=k%4===1?0xa9babf:k%2?0x768b97:0x8a9da6;
        band(low,14.55,high,16.7,roofColor,l,h);
        band(low-.01,14.52,low,14.12,0x263741,l,h);
        band(low-.015,14.18,low-.015,14.26,pal[0],l,h);
        if(k%2===0){
          beam(l,low,14.50,l,high,16.63,.083,0xb9c3c3);
          beam(l,low,14.04,l,high,15.02,.089,0x71848d);
          for(var r=0;r<4;r++){
            var d0=low+(high-low)*r/4,d1=low+(high-low)*(r+1)/4;
            beam(l,d0,14.04+.98*r/4,l,d1,14.50+2.13*(r+1)/4,.050,0x8f9d9f);
          }
        }
        if(k%4===0){
          beam(l,high,1,l,high,16.61,.22,0x5c717c);beam(l,high,10.1,l,high-3.2,15.68,.11,0x85959a);
        }
        var a=at(l+.14/roofPanels,low+.18,14.02),b=at(h-.12/roofPanels,low+.18,14.02);
        lights.rod(a,b,.045,.045,0xffedc1,5);
      }
      band(high,16.68,high,10.05,0x45555d);band(high-.08,10.15,high-.08,11.5,0x61757b);
      // Przeszklona galeria prasowa nad ostatnim rzędem. Światło wnętrza zmienia się po zmroku.
      var panes=s.bays*4;
      for(var pane=0;pane<panes;pane++){
        if(pane%12===0)continue;
        var midPane=(pane+.5)/panes,gl=at(midPane,19.68,13.34);
        var pl=at(pane/panes,19.68,13.34),pr=at((pane+1)/panes,19.68,13.34);
        glassItems.push({matrix:arenaMatrix(gl[0],gl[1],gl[2],s.yaw,Math.hypot(pr[0]-pl[0],pr[2]-pl[2])-.12,1.72,1)});
        beam(pane/panes,19.66,12.39,pane/panes,19.66,14.26,.049,0x788a90);
      }
      band(19.6,12.40,19.6,12.48,0x9eaaa7);band(19.6,14.20,19.6,14.32,0x647780);
      if(isLong){var np=at(.5,6.78,14.25);nameplates.push({matrix:arenaMatrix(np[0],np[1],np[2],s.yaw,13.0,.80,1)});}
      for(var bay=0;bay<s.bays;bay++){
        var mid=(bay+.5)/s.bays,span=s.len/s.bays;
        var p=at(mid,-.39,.70);
        if(!(side===4&&Math.abs(mid-.5)*s.len<3))
          fabricPanels[s.team].push({matrix:arenaMatrix(p[0],p[1],p[2],s.yaw,Math.min(6.9,span*.60),.80,1)});
        // Pomiędzy piętrami biegnie drugi poziom klubowych flag, z przerwą na numer sektora.
        if(isLong || bay%2===0){
          var railFlag=at(mid+.24/s.bays,9.88,6.10);
          fabricPanels[s.team].push({matrix:arenaMatrix(railFlag[0],railFlag[1],railFlag[2],s.yaw,span*.39,.55,1)});
        }
        var rail0=bay/s.bays+.9/s.len,rail1=(bay+1)/s.bays-.9/s.len;
        beam(rail0,-.10,1.97,rail1,-.10,1.97,.035,0xb4c1c0);
        for(var j=0;j<=4;j++){var rail=rail0+(rail1-rail0)*j/4;beam(rail,-.10,1.23,rail,-.10,1.97,.025,0xa1b0b1);}
        var sign=at(mid,9.91,6.37);self.sectorSign(group,sign,s.yaw,String.fromCharCode(65+side)+(bay+1));
        if(bay%2===0){
          var f=at(mid-.026,4.62,3.90);
          metal.rod(f,[f[0],f[1]+2.82,f[2]],.024,.024,0xb6c0bb,6);
          flags[s.team].push({matrix:arenaMatrix(f[0],f[1]+2.78,f[2],s.yaw,1,1,1)});
        }
      }
    });
    var structural=new THREE.MeshLambertMaterial({vertexColors:true,side:THREE.DoubleSide});
    var aggregate=arenaTexture(128,128,function(g){
      g.fillStyle="#efefeb";g.fillRect(0,0,128,128);
      for(var i=0;i<1950;i++){g.fillStyle=i%3?"rgba(79,76,72,.11)":"rgba(255,255,255,.42)";
        g.fillRect(random()*128,random()*128,.6+random()*1.5,.6+random()*1.4);}
      g.fillStyle="rgba(88,96,99,.095)";g.fillRect(0,0,1,128);
    });aggregate.wrapS=aggregate.wrapT=THREE.RepeatWrapping;
    this.frames=structural;this.masonry=new THREE.MeshLambertMaterial({vertexColors:true,map:aggregate,side:THREE.DoubleSide});group.add(new THREE.Mesh(surface.build(false),this.masonry),new THREE.Mesh(metal.build(false),structural));
    this.eaves=new THREE.MeshBasicMaterial({vertexColors:true});group.add(new THREE.Mesh(lights.build(false),this.eaves));
    this.glassMaps=[this.glassTexture(false),this.glassTexture(true)];
    this.glassMat=new THREE.MeshBasicMaterial({map:this.glassMaps[0]});
    arenaInstances(new THREE.PlaneGeometry(1,1),this.glassMat,glassItems,group);
    var plaque=arenaTexture(512,64,function(g){
      g.fillStyle="#23373a";g.fillRect(0,0,512,64);g.fillStyle="#e6d79b";g.fillRect(0,4,512,3);
      g.font="bold 39px Arial";g.textAlign="center";g.textBaseline="middle";g.fillText("STADION MIEJSKI",256,34,448);
    });
    this.plaque=plaque;arenaInstances(new THREE.PlaneGeometry(1,1),new THREE.MeshLambertMaterial({map:plaque}),nameplates,group);
    var seats=arenaInstances(this.chairGeometry(),new THREE.MeshLambertMaterial({vertexColors:true,side:THREE.DoubleSide}),seatItems,group);
    seats.name="Krzesełka";this.seats=seats;
    var faces=SUPPORTERS.faceAtlas();
    var solid=[SUPPORTERS.material(0,faces),SUPPORTERS.material(1,faces)];
    solid.forEach(function(m){m.side=THREE.FrontSide;});
    var atlas=[0,1].map(function(i){var m=SUPPORTERS.material(i,SUPPORTERS.atlas(i));m.alphaTest=.40;return m;});
    var flagsGeo=this.flagGeometry();
    this.batches=[];
    function batch(geo,mat,items,label){
      if(!items.length)return null;
      items.sort(function(a,b){return a.rank-b.rank;});
      var m=arenaInstances(geo,mat,items,group);m.name=label;
      var levels=[.52,.80,1].map(function(cut){return items.filter(function(x){return x.rank<cut;}).length;});
      self.batches.push({m:m,n:items.length,levels:levels});return m;
    }
    banks.forEach(function(bank){
      var g=bank.real?SUPPORTERS.person(bank.team,bank.style,bank.pose,true):SUPPORTERS.card(bank.style,bank.pose);
      batch(g,bank.real?solid[bank.team]:atlas[bank.team],bank.items,"Kibice "+bank.pose);
    });
    [0,1].forEach(function(team){
      var cloth=SUPPORTERS.material(team,self.cloth[team]);
      var m=batch(SUPPORTERS.scarf(),cloth,scarves[team],"Szaliki "+team);
      // Liczba szalików i ich właścicieli zależy od identycznego progu losowania.
      if(m)m.userData.scarves=true;
      var panel=new THREE.MeshLambertMaterial({map:self.cloth[team],side:THREE.DoubleSide});
      arenaInstances(new THREE.PlaneGeometry(1,1),panel,fabricPanels[team],group);
      var flag=arenaInstances(flagsGeo,self.flagMaterial(team),flags[team],group);flag.name="Flagi "+team;
    });
    /* Tifo (poz. 7): wielkie mozaiki na półkach długich trybun,
       rozwijane z góry podczas prezentacji i chowane przy wznowieniu gry. */
    this.tifos=[0,1].map(function(team){
      var side=sides[team===0?4:0],tex=arenaTexture(1024,192);
      var paint=function(){self.paintTifo(tex,self.names[team],team);};paint();
      var w=24,h=4.35,geo=new THREE.PlaneGeometry(w,h,12,3);geo.translate(0,-h/2,0);
      var mesh=new THREE.Mesh(geo,new THREE.MeshLambertMaterial({map:tex,side:THREE.DoubleSide}));
      var p=side.at(.5,.24,5.15);
      mesh.position.set(p[0],p[1],p[2]);mesh.rotation.y=side.yaw;
      mesh.scale.y=.045;mesh.visible=false;group.add(mesh);
      return {mesh:mesh,paint:paint};
    });
    this.technical(group);this.quality(SET.q);
  },
  /* Barwy klubu, rombowe kafle mozaiki i nazwa drużyny na wielkim płótnie (poz. 7). */
  paintTifo:function(tex,name,team){
    var g=tex.image.getContext("2d"),w=tex.image.width,h=tex.image.height;
    var pal=SUPPORTERS.teams[team];
    var hex=function(c){return "#"+c.toString(16).padStart(6,"0");};
    g.fillStyle=hex(pal[0]);g.fillRect(0,0,w,h);
    var cell=32;
    for(var y=0;y<Math.ceil(h/cell);y++)for(var x=0;x<Math.ceil(w/cell);x++){
      var cx=x*cell+cell/2,cy=y*cell+cell/2;
      if((x+y)%2===0){g.fillStyle="rgba(0,0,0,.16)";g.save();g.translate(cx,cy);g.rotate(Math.PI/4);
        g.fillRect(-cell*.30,-cell*.30,cell*.60,cell*.60);g.restore();}
      else{g.fillStyle=hex(pal[1]);g.fillRect(x*cell+1,y*cell+1,cell-2,cell-2);}
    }
    g.fillStyle="rgba(8,10,16,.34)";g.fillRect(0,h*.30,w,h*.44);
    g.fillStyle=hex(pal[2]);g.fillRect(0,h*.30,w,4);g.fillRect(0,h*.74-4,w,4);
    g.textAlign="center";g.textBaseline="middle";g.font="bold 74px Arial,sans-serif";
    var label=((name||"").toUpperCase().slice(0,16))||"SUPER PIŁKA";
    g.fillStyle="rgba(12,14,20,.85)";g.fillText(label,w/2+3,h*.52+3,w-60);
    g.fillStyle="#fff3d9";g.fillText(label,w/2,h*.52,w-60);
    g.font="bold 26px Arial,sans-serif";g.fillStyle="rgba(255,243,217,.78)";
    g.fillText("SUPER PIŁKA ’98",w/2,h*.13,w-40);
    g.fillStyle="rgba(0,0,0,.18)";for(var yy=0;yy<h;yy+=4)g.fillRect(0,yy,w,1);
    tex.needsUpdate=true;
  },
  glassTexture:function(night){
    return arenaTexture(128,64,function(g){
      var grad=g.createLinearGradient(0,0,0,64);
      grad.addColorStop(0,night?"#5d655f":"#85979b");grad.addColorStop(.48,night?"#8d7d60":"#596e78");grad.addColorStop(1,night?"#473f34":"#334853");
      g.fillStyle=grad;g.fillRect(0,0,128,64);
      g.fillStyle=night?"#ebd4a0":"#bbc6bc";g.fillRect(8,9,40,2);g.fillRect(72,9,45,2);
      g.fillStyle=night?"#354143":"#46545c";g.fillRect(9,38,24,12);g.fillRect(76,40,28,12);
      g.fillStyle=night?"#829588":"#809096";g.fillRect(11,40,19,7);g.fillRect(79,42,22,7);
      g.fillStyle="rgba(208,231,228,.12)";g.beginPath();g.moveTo(36,0);g.lineTo(59,0);g.lineTo(26,64);g.lineTo(8,64);g.fill();
      g.fillStyle="#34454c";g.fillRect(0,48,128,3);g.fillRect(60,0,3,64);
    });
  },
  sectorSign:function(group,p,yaw,text){
    if(!this.signData){
      this.signData=arenaTexture(1024,512,function(g){
        for(var i=0;i<8;i++)for(var j=0;j<8;j++){
          var x=j*128,y=i*64;g.fillStyle="#23333d";g.fillRect(x,y,128,64);
          g.fillStyle="#e6e4c8";g.fillRect(x+5,y+8,3,48);g.font="bold 44px Arial";
          g.textBaseline="middle";g.textAlign="center";g.fillText(String.fromCharCode(65+i)+(j+1),x+67,y+34);
        }
      });this.signMat=new THREE.MeshBasicMaterial({map:this.signData});
    }
    var g=new THREE.PlaneGeometry(1.46,.70),uv=g.attributes.uv,col=Number(text.slice(1))-1,row=text.charCodeAt(0)-65;
    for(var k=0;k<uv.count;k++)uv.setXY(k,(col+.02+.96*uv.getX(k))/8,1-(row+.98-.96*uv.getY(k))/8);
    var sign=new THREE.Mesh(g,this.signMat);sign.rotation.y=yaw;sign.position.set(p[0],p[1],p[2]);group.add(sign);
  },
  flagGeometry:function(){
    var g=new THREE.PlaneGeometry(1.43,.87,9,3);g.translate(.715,-.435,0);return g;
  },
  flagMaterial:function(team){
    var tex=arenaTexture(128,64,function(g){
      g.fillStyle=team?"#24588c":"#a8334b";g.fillRect(0,0,128,64);g.fillStyle="#efe4cd";g.fillRect(0,17,128,6);g.fillRect(0,39,128,6);
      g.save();g.translate(36,32);g.rotate(Math.PI/4);g.fillRect(-12,-12,24,24);g.restore();
      g.fillStyle=team?"#20375d":"#85253a";g.fillRect(33,24,6,16);
    });
    var m=new THREE.MeshLambertMaterial({map:tex,side:THREE.DoubleSide});
    m.onBeforeCompile=function(s){s.uniforms.flagTime=STADIUM.time;s.vertexShader="uniform float flagTime;\n"+s.vertexShader.replace("#include <begin_vertex>",
      "#include <begin_vertex>\nfloat wav=sin(position.x*5.8-flagTime*3.8+instanceMatrix[3].x*.27);transformed.z+=position.x*(.12+.15*wav);transformed.y+=position.x*.057*wav;");};return m;
  },
  setNames:function(home,away){
    var self=this;[home,away].forEach(function(n,i){if(n!==self.names[i]){SUPPORTERS.paintScarf(self.cloth[i],n,i);self.names[i]=n;}});
    if(this.tifos)this.tifos.forEach(function(T){T.paint();});
  },
  quality:function(q){
    this.batches.forEach(function(b){b.m.count=b.levels[q]||0;});
  },
  technical:function(group){
    var g=new ArenaGeometry(),m=new THREE.MeshLambertMaterial({vertexColors:true,side:THREE.DoubleSide});
    // Tunel na wysokości linii środkowej, z rozsuwanym harmonijkowym zadaszeniem.
    g.quad([-2.13,0,-42.8],[-2.13,0,-47.8],[-2.13,2.80,-47.8],[-2.13,2.80,-42.8],0x384851);
    g.quad([2.13,0,-47.8],[2.13,0,-42.8],[2.13,2.80,-42.8],[2.13,2.80,-47.8],0x384851);
    g.quad([-2.13,2.80,-42.8],[2.13,2.80,-42.8],[2.13,2.80,-47.8],[-2.13,2.80,-47.8],0x667781);
    g.quad([-2.1,.04,-43.15],[2.1,.04,-43.15],[2.1,2.77,-43.15],[-2.1,2.77,-43.15],0x18242a);
    for(var z=-42.77;z>=-47.8;z-=.61){
      g.rod([-2.14,0,z],[-2.14,2.82,z],.044,.044,0xa9b8b9);g.rod([-2.14,2.82,z],[2.14,2.82,z],.055,.055,0xb0bcbc);
      g.rod([2.14,2.82,z],[2.14,0,z],.044,.044,0xa9b8b9);
    }
    [-16,16].forEach(function(x,team){
      var accent=SUPPORTERS.teams[team][0];
      g.rod([x-6.57,2.31,-37.98],[x+6.57,2.31,-37.98],.066,.066,accent,8);
      for(var j=0;j<5;j++){
        var bx=x-4.5+j*.19;
        g.loft(bx,-39.05,[[.06,.062,.062],[.24,.065,.065],[.285,.034,.034],[.31,.030,.030]],8,j%2?0x6fafa8:0xd4dbca);
        g.loft(bx,-39.05,[[.30,.035,.035],[.333,.035,.035]],8,accent);
      }
      for(var px=-6;px<7;px+=3)g.rod([x+px,1.4,-41.57],[x+px,2.27,-38.10],.036,.036,0x8d9ea3,6);
    });group.add(new THREE.Mesh(g.build(false),m));
  },
  goal:function(team){this.goalTeam=team;this.goalLeft=4.6;},
  tick:function(dt,withSound){
    this.time.value+=dt;this.goalLeft=Math.max(0,this.goalLeft-dt);
    for(var i=0;i<2;i++){
      var replayCheer=MAIN.state==="match"&&!MAIN.paused?WORLD.crowdPulse:0;
      var target=this.goalLeft>0?(i===this.goalTeam?1:.17):.05+replayCheer*(i===this.goalTeam?.48:.10);
      this.roars[i].value+=(target-this.roars[i].value)*Math.min(1,dt*3.8);}
    var beat=Math.floor(this.time.value/.56);
    if(beat!==this.lastBeat){
      this.lastBeat=beat;var tour=typeof STADIUM_TOUR!=="undefined"&&STADIUM_TOUR.active;
      if(withSound&&AUDIO.ok&&SET.snd>0)AUDIO.standBeat(beat,tour,this.goalLeft>0);
    }
    /* fala meksykańska (poz. 7): startuje co ~30 s gry przy cichej widowni,
       obiega stadion ~13 s; front i zanik rytmu steruje shader kibiców */
    var tourNow=typeof STADIUM_TOUR!=="undefined"&&STADIUM_TOUR.active;
    var calm=(MAIN.state==="match"&&!MAIN.paused)||tourNow;
    if(calm&&typeof RULES!=="undefined"&&["opening","closing","fulltime","halftime","substitution","replay","menu"].indexOf(RULES.state)>=0)calm=false;
    if(this.waveT>=0){
      this.waveT+=dt*.483;
      if(this.waveT>6.75){this.waveT=-1;this.waveCd=26+Math.random()*24;}
    }else if(calm&&this.goalLeft<=0&&this.roars[0].value<.30&&this.roars[1].value<.30){
      this.waveCd-=dt;
      if(this.waveCd<=0)this.waveT=0;
    }
    if(this.waveT<0)this.waveU.value-=dt*.483;
    else this.waveU.value=this.waveT-.36;
    this.waveA.value=Math.max(0,Math.min(1,this.waveA.value+(this.waveT>=0?dt*2.6:-dt*1.6)));
    /* tifo (poz. 7): rozwija się w pierwszych sekundach prezentacji */
    if(this.tifos){
      var show=(typeof RULES!=="undefined")&&RULES.state==="opening"&&MAIN.state==="match";
      for(var f=0;f<this.tifos.length;f++){
        var T=this.tifos[f];T.mesh.visible=show;
        if(show){
          var pr=Math.max(0,Math.min(1,(RULES.stateT-.55)/2.7));
          T.mesh.scale.y=Math.max(.045,1-Math.pow(1-pr,2.5));
        }
      }
    }
  }
};

STADIUM.chairGeometry=function(){
  var b=new ArenaGeometry(),shell=0xf2f2ee;
  // Wyprofilowane siedzisko i odchylone oparcie stanowią jeden odlew.
  var profile=[[.212,.440,.251],[.230,.419,.244],[.240,.403,.188],[.244,.403,-.002],
    [.239,.420,-.134],[.229,.467,-.192],[.221,.571,-.218],[.210,.725,-.250],[.180,.787,-.257]];
  var n=7;
  profile.forEach(function(r,j){
    for(var k=0;k<n;k++){
      var u=k/(n-1)*2-1,edge=u*u,back=Math.max(0,(r[1]-.45)*2.8);
      var idx=b.vertex([u*r[0],r[1]+edge*.023*(1-back),r[2]+edge*.053*back],shell);
      if(j&&k)b.face(idx-n-1,idx-n,idx,idx-1);
    }
  });
  b.rod([-.159,.16,-.065],[-.159,.385,-.026],.026,.028,0x424f53,6);
  b.rod([.159,.16,-.065],[.159,.385,-.026],.026,.028,0x424f53,6);
  b.rod([-.19,.152,-.07],[.19,.152,-.07],.031,.031,0x586166,6);
  b.rod([0,.025,-.073],[0,.156,-.068],.041,.037,0x4d5356,6);
  return b.build(false);
};
