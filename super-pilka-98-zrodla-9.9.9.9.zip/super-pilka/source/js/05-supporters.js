var SUPPORTERS={
  teams:[[0xa32742,0xd34953,0xf4ead9,0x562539],[0x245491,0x347cbd,0xe3f2f7,0x172e52]],
  skin:[0xc58e68,0x8e6049,0xecbb98,0x784c39,0xdbaa82,0xd99e76,0xa67355,0xefc39e],
  hair:[0x34241e,0x282127,0x7a5035,0x292526,0x996d4b,0x422c23,0x777674,0x573c2f],
  outer:[0x364650,0x3e5149,0x89573a,0x494758,0x626e4e,0x594636,0x364250,0x9a9c92],
  material:function(team,map){
    var mat=new THREE.MeshLambertMaterial({vertexColors:true,map:map||null,side:map?THREE.DoubleSide:THREE.FrontSide});
    mat.onBeforeCompile=function(shader){
      shader.uniforms.standTime=STADIUM.time;shader.uniforms.standRoar=STADIUM.roars[team];
      shader.uniforms.standWave=STADIUM.waveU;shader.uniforms.standWaveAmp=STADIUM.waveA;
      shader.vertexShader="uniform float standTime, standRoar, standWave, standWaveAmp;\nattribute vec2 fanMotion;\n"+shader.vertexShader.replace("#include <begin_vertex>",
        "#include <begin_vertex>\n"+[
        "vec3 seat=instanceMatrix[3].xyz;",
        "float phase=fract(sin(dot(seat.xz,vec2(.713,.371)))*1573.23)*6.283;",
        "float sway=sin(standTime*1.75+phase), beat=standTime*6.283/0.56;",
        "float mass=smoothstep(.02,.94,position.y);",
        "transformed.x+=mass*(.017+.037*standRoar)*sway;",
        "transformed.y+=mass*(.008+.13*standRoar)*(.5+.5*sin(standTime*(3.1+.17*phase)+phase));",
        "float w=fanMotion.x, act=fanMotion.y;",
        "if(act>.5 && act<1.5){transformed.x-=w*.078*(.5+.5*cos(beat+phase));transformed.y+=abs(w)*.037*sin(beat+phase);}",
        "else if(act>1.5 && act<2.5){transformed.x+=abs(w)*.063*sin(standTime*2.45+phase);transformed.y+=abs(w)*.077*sin(standTime*2.45+phase)+w*.034*cos(standTime*2.45+phase);}",
        "else if(act>2.5 && act<3.5){float lift=.5-.5*cos(beat*.5+(w<0.0?0.0:3.14159));transformed.y+=abs(w)*.20*lift;transformed.z-=abs(w)*.06*lift;}",
        "else if(act>3.5 && act<4.5){transformed.y+=abs(w)*.012*sin(beat*.5);}",
        "else if(act>4.5){transformed.x+=w*.09*sway;transformed.y+=abs(w)*.067*sin(standTime*3.2+phase);}",
        /* fala meksykańska (poz. 7): front biegnie dookoła widowni po kącie siedzenia */
        "float wAng=atan(seat.z,seat.x);",
        "float wD=abs(atan(sin(wAng-standWave),cos(wAng-standWave)));",
        "float wl=(1.0-smoothstep(.15,.42,wD))*standWaveAmp;",
        "transformed.y+=mass*wl*(.45+.055*sin(standTime*8.4+phase));",
        "transformed.x+=mass*wl*.05*sin(standTime*8.4+phase);"].join("\n"));
    };return mat;
  },
  paintScarf:function(tex,name,team){
    var g=tex.image.getContext("2d"),w=tex.image.width,h=tex.image.height,ink="#fff5df";
    g.fillStyle="#"+WORLD.kit[team].tag.toString(16).padStart(6,"0");g.fillRect(0,0,w,h);
    g.fillStyle="rgba(255,255,255,.085)";g.fillRect(0,8,w,h-16);
    g.fillStyle=ink;g.fillRect(0,7,w,4);g.fillRect(0,h-11,w,4);
    [0,1].forEach(function(end){g.save();if(end){g.translate(w,0);g.scale(-1,1);}
      g.fillRect(3,0,12,h);g.fillRect(24,0,8,h);g.fillRect(40,0,4,h);g.restore();});
    g.textAlign="center";g.textBaseline="middle";g.font="bold 82px Arial, sans-serif";
    g.fillStyle=team?"#132f56":"#69172d";g.fillText(name,w/2+2,h*.52+3,w-120);
    g.fillStyle=ink;g.fillText(name,w/2,h*.52,w-120);
    g.fillStyle="rgba(16,20,28,.09)";for(var y=1;y<h;y+=4)g.fillRect(0,y,w,1);
    tex.needsUpdate=true;
  },
  scarf:function(){
    var b=new ArenaGeometry();
    for(var i=0;i<=18;i++){
      var u=i/18,sw=2*u-1,x=sw*.535,y=1.907-.064*(1-sw*sw)-Math.max(0,Math.abs(x)-.426),z=.131+.017*Math.sin(u*Math.PI*3);
      var k=b.vertex([x,y,z],0xffffff,u,0,sw,2);b.vertex([x,y+.153,z-.009],0xffffff,u,1,sw,2);
      if(i)b.face(k-2,k,k+1,k-1);
    }return b.build(true);
  },
  person:function(team,style,pose,detail){
    var b=new ArenaGeometry(),pal=this.teams[team],skin=this.skin[style],hair=this.hair[style];
    var variant=(style+this.poses.indexOf(pose)+7)%9;
    var neutrals=[0x42594e,0xb38146,0x667f91,0xe8dfc6,0x845049,0x374555,0x9c927a,0x648688,0x858398];
    var top=variant<4?neutrals[(style+variant)%neutrals.length]:[1,4,6].includes(style)?this.outer[style]:pal[style%3];
    var trim=style%3===2?pal[0]:pal[2];
    var pants=[0x2b3c4b,0x39444c,0x34443a,0x404451][style%4],shoe=style%3===1?0xbfc4be:0x272e36;
    var seated=pose==="seat",hip=seated?.57:.90,drop=hip-.90,n=detail?9:5,r=detail?12:7;
    function limb(a,c,x,y,col,wa,wb,kind){b.rod(a,c,x,y,col,n,wa,wb,kind);}
    [-1,1].forEach(function(s){
      var x=s*.128,ankle=[x,.113,seated?.19:.047],knee=[s*.143,seated?.51:.49,seated?.306:.063];
      limb([s*.101,hip+.008,-.012],knee,.105,.079,pants);limb(knee,ankle,.079,.054,pants);
      b.loft(x,ankle[2]+.041,[[.023,.064,.128],[.061,.070,.134],[.131,.056,.082,-.024]],n,shoe);
      if(detail)b.loft(x,ankle[2]+.045,[[.020,.067,.125],[.039,.070,.135]],n,0xbabbb1);
    });
    b.loft(0,0,[[hip-.063,.155,.111],[hip+.044,.192,.131],[1.16+drop,.184,.128],[1.326+drop,.235,.140],[1.40+drop,.207,.12],[1.457+drop,.097,.077]],r,top);
    b.loft(0,.002,[[1.409+drop,.078,.072],[1.527+drop,.072,.067]],n,skin);
    if(style%3!==0){
      b.loft(0,.003,[[1.38+drop,.143,.118],[1.423+drop,.115,.105],[1.456+drop,.085,.09]],n,trim);
      var xs=style%2===0?-.10:.10;
      b.quad([xs-.039,1.12+drop,.143],[xs+.039,1.12+drop,.143],[xs+.033,1.405+drop,.117],[xs-.037,1.406+drop,.117],trim);
      if(detail)for(var l=0;l<3;l++)b.quad([xs-.039,1.13+drop+l*.043,.145],[xs+.038,1.13+drop+l*.043,.145],[xs+.038,1.144+drop+l*.043,.145],[xs-.039,1.144+drop+l*.043,.145],pal[0]);
    }
    var fy=1.562+drop;
    var faceRange;
    if(detail)faceRange=this.head(b,style,fy);
    else b.loft(0,.006,[[fy-.079,.052,.060,.024],[fy-.034,.086,.091,.014],[fy+.052,.101,.103],[fy+.126,.098,.100,-.003],[fy+.177,.069,.073]],r,skin);
    if(!detail&&(style===2||style===5))b.oval(0,fy+.05,-.075,.109,.143,.066,hair,n);
    if(detail)this.haircut(b,style,fy,hair);
    else b.loft(0,-.009,[[fy+.099,.105,.099],[fy+.156,.107,.105],[fy+.194,.078,.079],[fy+.212,.030,.035]],r,hair);
    if(style===0||style===4||style===7){
      b.loft(0,-.007,[[fy+.115,.111,.108],[fy+.158,.111,.110],[fy+.212,.076,.077],[fy+.231,.026,.032]],r,pal[style===7?3:0]);
      b.loft(0,-.005,[[fy+.113,.112,.111],[fy+.134,.114,.113]],r,trim);
      if(style===4)b.oval(0,fy+.247,-.012,.034,.030,.035,trim,n);
      else b.oval(0,fy+.131,.098,.091,.009,.060,pal[3],n);
    }
    if(detail){
      [-1,1].forEach(function(s){
        b.oval(s*.098,fy+.036,-.002,.016,.029,.018,skin,7);
        b.oval(s*.104,fy+.036,.002,.010,.015,.010,0xad795c,8);
      });
      // Nasada, grzbiet i skrzydełka nosa mają odrębne przekroje.
      b.loft(0,0,[[fy+.001,.011,.008,.108],[fy+.009,.016,.012,.113],[fy+.020,.017,.016,.117],
        [fy+.034,.011,.014,.111],[fy+.062,.009,.007,.107]],12,skin);
      [-1,1].forEach(function(s){b.oval(s*.013,fy+.011,.112,.009,.007,.008,skin,8);});
      if(style===1||style===4||style===6){
        b.quad([-.006,hip+.02,.134],[.007,hip+.02,.134],[.006,1.41+drop,.130],[-.006,1.41+drop,.130],0x677378);
        [-1,1].forEach(function(s){b.rod([s*.16,1.084+drop,.079],[s*.098,1.016+drop,.125],.006,.006,0x626d68,5);});
      }
    }
    var kind={clap:1,scarf:2,drum:3,brass:4,wave:5}[pose]||0;
    [-1,1].forEach(function(s){
      var sh=[s*.202,1.346+drop,-.002],elbow,hand;
      if(pose==="scarf"){elbow=[s*.393,1.605,.061];hand=[s*.429,1.922,.131];}
      else if(pose==="drum"){elbow=[s*.306,1.114,.117];hand=[s*.174,1.205,.331];}
      else if(pose==="brass"){elbow=[s*.303,1.249,.118];hand=[s*.055+.035,1.507,s<0?.361:.284];}
      else if(pose==="wave"&&s>0){elbow=[.319,1.547,.045];hand=[.358,1.824,.103];}
      else if(pose==="clap"){elbow=[s*.28,1.151,.108];hand=[s*.107,1.366,.305];}
      else{elbow=[s*.257,sh[1]-.231,.044];hand=[s*(seated?.151:.245),seated?.616:1.00,seated?.28:.144];}
      var act=pose==="wave"&&s<0?0:kind,mid=sh.map(function(v,j){return v+(elbow[j]-v)*.73;});
      limb(sh,mid,.084,.066,top,0,s*.34,act);limb(mid,elbow,.064,.051,style%3===1?top:skin,s*.34,s*.51,act);
      limb(elbow,hand,.052,.031,style%3===1?top:skin,s*.51,s,act);
      if(detail){
        var hx=hand[0],hy=hand[1],hz=hand[2],raised=pose==="wave"||pose==="scarf";
        b.oval(hx,hy,hz,.036,.046,.023,skin,10,s,act);
        for(var f=0;f<4;f++){
          var fx=hx+(f-1.5)*.014,spread=raised&&pose!=="scarf"?(f-1.5)*.008:0;
          var l=raised?.049:.037,dy=raised?1:-1;
          b.rod([fx,hy+dy*.019,hz+.008],[fx+spread,hy+dy*(l-(f===3?.008:0)),hz+.026],.0085,.0065,skin,7,s,s,act);
        }
        b.oval(hx-s*.030,hy+.002,hz+.014,.014,.022,.012,skin,9,s,act);
      }else b.oval(hand[0],hand[1],hand[2],.043,.050,.038,skin,n,s,act);
      if(pose==="drum"){
        b.rod([hand[0]+s*.03,hand[1]+.046,.286],[s*.105,1.083,.493],.010,.012,0xe3c99d,8,s,s,3);
        b.oval(s*.105,1.083,.493,.025,.025,.025,0xf2e3c8,8,s,3);
      }
      if(pose==="scarf"&&detail)for(var i=0;i<5;i++){
        var x=s*(.487+i*.011),y=1.91-(Math.abs(x)-.426)-.064*(1-(x/.535)*(x/.535));
        b.rod([x,y,.133],[x+s*.003,y-.045+(i%2)*.008,.134],.003,.0025,pal[2],4,s,s,2);
      }
    });
    if(pose==="drum")this.drum(b,pal);
    if(pose==="brass")this.trumpet(b);
    var geo=b.build(true);
    if(faceRange){
      var uv=geo.attributes.uv;
      for(var j=0;j<uv.count;j++)if(j<faceRange[0]||j>=faceRange[1])uv.setXY(j,1018/1024,6/512);
    }
    return geo;
  },
  drum:function(b,pal){
    var z=.425,r=.245;
    b.loft(0,z,[[.727,r,r],[1.055,r,r]],20,pal[0]);
    [.740,1.046].forEach(function(y){b.loft(0,z,[[y-.012,r+.014,r+.014],[y+.013,r+.014,r+.014]],20,0xd4d9d2);});
    b.loft(0,z,[[1.058,r-.003,r-.003],[1.066,r-.003,r-.003]],20,0xe4d7b9);
    for(var i=0;i<10;i++){var a=i*Math.PI*.2,x=(r+.004)*Math.sin(a),zz=z+(r+.004)*Math.cos(a);b.rod([x,.758,zz],[x,1.034,zz],.010,.010,0xc1c8c9,5);}
    [.767,1.021].forEach(function(y){b.loft(0,z,[[y-.006,r+.002,r+.002],[y+.006,r+.002,r+.002]],20,pal[2]);});
    // Medalion na froncie korpusu oraz podwójna warstwa w miejscu uderzania.
    b.oval(0,.891,z+r,.060,.073,.007,pal[2],12);
    b.oval(0,.89,z+r+.007,.043,.056,.005,pal[0],12);
    b.rod([-.022,.887,z+r+.012],[-.004,.865,z+r+.012],.006,.006,pal[2],5);
    b.rod([-.004,.865,z+r+.012],[.024,.919,z+r+.012],.006,.006,pal[2],5);
    b.loft(0,z,[[1.0665,.076,.076],[1.067,.076,.076]],22,0xd5c8ab);
    b.rod([-.172,1.396,.062],[.179,.98,.273],.029,.030,0x34343b,6);
    b.rod([.170,1.386,.063],[-.176,.98,.274],.022,.024,0x675747,6);
  },
  trumpet:function(b){
    var gold=0xdba845,light=0xffdf8e;
    var path=[[0,1.545,.108],[.064,1.534,.342],[.021,1.452,.431],[-.028,1.434,.448],[-.063,1.426,.422],[-.078,1.446,.260],[-.066,1.461,.225],[-.038,1.485,.210],[-.012,1.504,.245],[.018,1.517,.357],[.067,1.523,.452],[.125,1.532,.544]];
    for(var i=1;i<path.length;i++)b.rod(path[i-1],path[i],.014,.016,gold,10,1,1,4);
    for(var j=0;j<3;j++){
      var z=.286+j*.044;b.rod([.007,1.467,z],[.007,1.552,z],.018,.017,gold,8,1,1,4);
      b.rod([.007,1.550,z],[.007,1.578,z],.007,.007,light,7,1,1,4);b.oval(.007,1.581,z,.017,.006,.015,0xeaebd4,8,1,4);
    }
    var axis=new THREE.Vector3(.55,.13,.83).normalize(),right=new THREE.Vector3(0,1,0).cross(axis).normalize(),up=axis.clone().cross(right);
    var first=b.p.length/3,n=20,profile=[[0,.019,gold],[.069,.028,gold],[.127,.048,gold],[.167,.076,light],[.188,.108,light],[.185,.100,light],[.150,.059,0xb38231],[.091,.023,0x785324],[.073,.002,0x4e3620]];
    profile.forEach(function(p,k){for(var s=0;s<n;s++){
      var a=s*2*Math.PI/n,cs=p[1]*Math.cos(a),sn=p[1]*Math.sin(a);
      b.vertex([.125+p[0]*axis.x+cs*right.x+sn*up.x,1.532+p[0]*axis.y+cs*right.y+sn*up.y,
        .544+p[0]*axis.z+cs*right.z+sn*up.z],p[2],0,0,1,4);
      if(k){var lo=first+(k-1)*n+s,nx=first+(k-1)*n+(s+1)%n;b.face(lo,nx,nx+n,lo+n);}
    }});
  }
};

// Atlas odległych rzędów powstaje z tych samych modeli. Z-bufor nie jest potrzebny dla rozłącznych kafli.
SUPPORTERS.poses=["seat","idle","clap","wave","scarf"];
SUPPORTERS.atlas=function(team){
  var self=this;
  return arenaTexture(1024,1024,function(ctx,w,h){
    var cellW=w/8,cellH=h/8;
    self.poses.forEach(function(pose,row){
      for(var style=0;style<8;style++){
        var geo=self.person(team,style,pose,false),p=geo.attributes.position,c=geo.attributes.color,indices=geo.index.array;
        var faces=[],xx=[],yy=[],zz=[];
        for(var j=0;j<p.count;j++){
          xx.push(style*cellW+(p.getX(j)+.62)*cellW/1.24);
          yy.push(row*cellH+cellH*(1-(p.getY(j)+.08-p.getZ(j)*.13)/2.24));
          zz.push(p.getZ(j)+.13*p.getY(j));
        }
        for(var i=0;i<indices.length;i+=3){
          var a=indices[i],b=indices[i+1],d=indices[i+2];
          if((xx[b]-xx[a])*(yy[d]-yy[a])-(yy[b]-yy[a])*(xx[d]-xx[a])>=0)continue;
          var normal=new THREE.Vector3().fromBufferAttribute(geo.attributes.normal,a);
          var f=.78+.23*Math.max(0,normal.y)+.15*Math.max(0,normal.x*.50+normal.z*.77);
          var col=new THREE.Color(c.getX(a)*f,c.getY(a)*f,c.getZ(a)*f).convertLinearToSRGB();
          faces.push([zz[a]+zz[b]+zz[d],a,b,d,"#"+col.getHexString()]);
        }
        faces.sort(function(a,b){return a[0]-b[0];});
        faces.forEach(function(f){ctx.fillStyle=f[4];ctx.strokeStyle=f[4];ctx.lineWidth=.60;
          ctx.beginPath();ctx.moveTo(xx[f[1]],yy[f[1]]);ctx.lineTo(xx[f[2]],yy[f[2]]);ctx.lineTo(xx[f[3]],yy[f[3]]);ctx.closePath();ctx.fill();ctx.stroke();});
        geo.dispose();
      }
    });
  });
};
SUPPORTERS.card=function(style,pose){
  var b=new ArenaGeometry(),row=this.poses.indexOf(pose),part={clap:1,scarf:2,wave:5}[pose]||0;
  var cols=6,levels=[-.08,.42,.9,1.27,1.55,1.86,2.16];
  levels.forEach(function(y,j){
    for(var i=0;i<=cols;i++){
      var u=i/cols,x=(u-.5)*1.24;
      var w=Math.min(1,Math.abs(x)/.43)*Math.sign(x)*Math.min(1,Math.max(0,(y-1.20)/.45));
      if(pose==="wave"&&x<0)w=0;
      var k=b.vertex([x,y,-.020],0xffffff,(style+u)/8,1-(row+1-(y+.08)/2.24)/8,w,part);
      if(i&&j)b.face(k-cols-2,k-cols-1,k,k-1);
    }
  });return b.build(true);
};

// Jedna tekstura dla zbliżeń. Twarze rozwijają się cylindrycznie ze szwem ukrytym przy karku.
SUPPORTERS.paintFace=function(g,style,skin,hair){
    function oval(x,y,rx,ry,color){
      g.save();g.translate(x,y);g.scale(rx,ry);g.fillStyle=color;g.beginPath();g.arc(0,0,1,0,Math.PI*2);g.fill();g.restore();
    }
    function line(x0,y0,cx,cy,x1,y1,width,color){
      g.strokeStyle=color;g.lineWidth=width;g.beginPath();g.moveTo(x0,y0);g.quadraticCurveTo(cx,cy,x1,y1);g.stroke();
    }
      g.fillStyle=skin;g.fillRect(0,0,256,256);
      var shade=g.createLinearGradient(0,0,0,256);shade.addColorStop(0,"rgba(64,32,27,.15)");shade.addColorStop(.42,"rgba(233,182,137,.06)");shade.addColorStop(.75,"rgba(116,53,42,.06)");shade.addColorStop(1,"rgba(69,41,36,.26)");
      g.fillStyle=shade;g.fillRect(0,0,256,256);
      for(var s=-1;s<=1;s+=2){
        var x=128+s*(17.5+style%3),y=132+(style%3-1)*2.2;
        var blush=g.createRadialGradient(x+s*8,162,2,x+s*8,162,20);
        blush.addColorStop(0,"rgba(173,78,63,.17)");blush.addColorStop(1,"rgba(173,78,63,0)");
        g.fillStyle=blush;g.fillRect(x-33,141,66,42);
        oval(x,y+1,10,5.2,"rgba(97,54,45,.36)");
        g.fillStyle="#d9c6ae";g.beginPath();g.moveTo(x-8.4,y);g.quadraticCurveTo(x-1,y-5.7,x+8.7,y-.55);
        g.quadraticCurveTo(x+.3,y+3.75,x-8.4,y);g.fill();
        oval(x+.55,y-.48,3.4,3.15,style%3===0?"#585346":"#514133");
        oval(x+.45,y-.47,1.66,2.1,"#302c29");oval(x-.40,y-1.49,.86,.85,"#e2d7c7");
        line(x-8.5,y,x-.1,y-5.7,x+8.7,y-.55,1.13,"#67473b");
        line(x-8.1,y+6,x,y+8,x+7,y+4.1,1,"rgba(89,54,46,.26)");
        g.fillStyle=hair;g.beginPath();g.moveTo(x-9.1,y-10+s*.86);g.quadraticCurveTo(x-1,y-16-(style%2)*2,x+8.8,y-10.5-s);
        g.lineTo(x+8.2,y-8.5-s);g.quadraticCurveTo(x-1,y-11.5,x-9.1,y-8.1+s);g.fill();
      }
      if(style===1||style===6){
        var beard=g.createLinearGradient(0,167,0,249);beard.addColorStop(0,"rgba(64,45,37,0)");beard.addColorStop(1,"rgba(52,39,36,.61)");
        g.fillStyle=beard;g.beginPath();g.moveTo(74,153);g.quadraticCurveTo(85,196,111,201);g.quadraticCurveTo(126,188,142,201);
        g.quadraticCurveTo(168,194,183,151);g.lineTo(181,254);g.lineTo(72,254);g.closePath();g.fill();
        for(var j=0;j<210;j++){var x=79+(j*41%98),y=210+(j*59%43);g.fillStyle="rgba(50,40,34,.17)";g.fillRect(x,y,1.2,2);}
      }
      oval(128,207,10.6,3.75,"rgba(153,91,76,.57)");
      line(116.4,204,127,201+(style%3),139.5,203,1.8,"#845445");
      line(121,208,128,210,135,207,1,"rgba(241,190,154,.59)");

};
SUPPORTERS.faceAtlas=function(){
  var self=this;
  return arenaTexture(1024,512,function(g,w,h){
    for(var style=0;style<8;style++){
      g.save();g.translate((style%4)*256,Math.floor(style/4)*256);
      self.paintFace(g,style,"#"+self.skin[style].toString(16).padStart(6,"0"),"#"+self.hair[style].toString(16).padStart(6,"0"));
      g.restore();
    }
    g.fillStyle="white";g.fillRect(w-12,h-12,12,12);
  });
};
SUPPORTERS.head=function(b,style,fy){
  var bands=[[-.082,.034,.047,.026],[-.068,.058,.069,.024],[-.041,.079,.084,.018],[-.019,.090,.093,.011],
    [.012,.098,.098,.007],[.045,.106,.102,.002],[.077,.108,.105,0],[.103,.108,.105,-.003],[.138,.102,.104,-.004],[.171,.088,.093,-.006],[.197,.058,.072,-.008],[.211,.025,.040,-.010]];
  var start=b.p.length/3,n=26;
  bands.forEach(function(band,j){
    for(var k=0;k<=n;k++){
      var u=k/n,a=(u-.5)*2*Math.PI,cs=Math.cos(a),sn=Math.sin(a);
      var p=[sn*band[1],fy+band[0],.005+band[3]+cs*band[2]];
      var rise=Math.min(1,(band[0]+.082)/.279);
      var id=b.vertex(p,0xffffff,((style%4)+.012+.976*u)/4,1-(Math.floor(style/4)+.986-.972*rise)/2);
      if(j&&k)b.face(id-n-2,id-n-1,id,id-1);
    }
  });
  return [start,b.p.length/3];
};
SUPPORTERS.haircut=function(b,style,fy,hair){
  var n=20,start=b.p.length/3,long=style===2||style===5;
  for(var j=0;j<6;j++)for(var k=0;k<n;k++){
    var a=k/n*2*Math.PI,cs=Math.cos(a),sn=Math.sin(a);
    var edge=.077+.079*cs-.038*Math.pow(Math.abs(sn),6)-(long?.041:0)*(1-Math.max(0,cs))
      +.009*sn*Math.max(0,cs)+.006*Math.sin(3*a+style);
    var capped=style===0||style===4||style===7,top=(capped?.193:.221)+.005*(style%3),y=[edge,edge+.012,.155,capped?.175:.192,top-.009,top][j];
    var rad=[1.0,1.029,1.019,.90,.54,.18][j]*(capped?.91:1);
    var id=b.vertex([sn*.107*rad,fy+y,-.008+cs*.111*rad],hair);
    if(j){var lo=start+(j-1)*n+k,nx=start+(j-1)*n+(k+1)%n;b.face(lo,nx,nx+n,lo+n);}
  }
  if(long)b.oval(.043,fy-.008,-.119,.057,.105,.045,hair,12);
};
