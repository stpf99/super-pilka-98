#!/usr/bin/env python3
"""Test oprawy kibicowskiej (poz. 7: widzowie, grafika) — wersja oszczędna (SwiftShader).
Weryfikuje: tifo przed meczem, falę meksykańską (shader), dym ultrasów i stroboskop
przy golu oraz fajerwerki podczas ceremonii zakończenia. Zegar ceremonii jest
wstrzykiwany (RULES.stateT), bo pod SwiftShader pełna scena renderuje wolno."""
from playwright.sync_api import sync_playwright
from pathlib import Path

GAME = Path(__file__).resolve().parent.parent / "super-pilka-98.html"
errs, ok = [], []

with sync_playwright() as pw:
    browser = pw.chromium.launch(args=["--use-gl=swiftshader", "--enable-unsafe-swiftshader"])
    page = browser.new_page(viewport={"width": 480, "height": 320})
    page.on("pageerror", lambda e: errs.append(str(e)[:300]))
    page.set_default_timeout(30000)
    page.goto(GAME.as_uri())
    page.wait_for_timeout(6000)

    st = page.evaluate("""() => ({
        tifos: STADIUM.tifos ? STADIUM.tifos.length : 0,
        tifoHidden: STADIUM.tifos ? STADIUM.tifos.every(T => !T.mesh.visible) : false,
        waveU: typeof STADIUM.waveU === 'object',
        softPool: WORLD.fxSoft ? WORLD.fxSoft.g.attributes.position.count : 0,
        menu: !document.getElementById('ovMenu').classList.contains('hide')
    })""")
    ok.append(("menu po starcie", st["menu"]))
    ok.append(("tifo utworzone (2 płótna)", st["tifos"] == 2))
    ok.append(("tifo schowane w menu", st["tifoHidden"]))
    ok.append(("uniform fali zdefiniowany", st["waveU"]))
    ok.append(("pula cząstek 460", st["softPool"] == 460))
    print("stan menu:", st, flush=True)

    page.evaluate("() => { SET.q = 0; WORLD.quality(); }")
    page.evaluate("() => document.getElementById('btnPlay').click()")
    page.wait_for_function("() => RULES.state === 'opening'", timeout=120000)
    # tifo rozwija się wg stateT — wstrzyknij zegar, jedna klatka przelicza skalę
    page.evaluate("() => { RULES.stateT = 3.6; }")
    page.wait_for_function("() => STADIUM.tifos[0].mesh.scale.y > 0.6", timeout=60000)
    op = page.evaluate("""() => ({
        state: RULES.state,
        tifoVisible: STADIUM.tifos.map(T => T.mesh.visible),
        tifoScale: STADIUM.tifos.map(T => +T.mesh.scale.y.toFixed(3))
    })""")
    ok.append(("stan otwarcia", op["state"] == "opening"))
    ok.append(("tifo rozwinięte podczas otwarcia", all(op["tifoVisible"]) and all(s > 0.6 for s in op["tifoScale"])))
    print("otwarcie:", op, flush=True)

    # fala: wymuś start i poczekaj na narastanie amplitudy
    page.evaluate("() => { STADIUM.waveT = 0; STADIUM.waveCd = 0; }")
    page.wait_for_function("() => STADIUM.waveA.value > 0.2", timeout=60000)
    wv = page.evaluate("() => ({amp: +STADIUM.waveA.value.toFixed(3), t: +STADIUM.waveT.toFixed(2)})")
    ok.append(("fala zyskuje amplitudę", wv["amp"] > 0.2 and wv["t"] > 0))
    print("fala:", wv, flush=True)

    # szpieg na fxPush — łapie krótkie błyski zanim wygasną przy wolnych klatkach
    page.evaluate("""() => {
        window.__flashes = 0;
        const orig = WORLD.fxPush.bind(WORLD);
        WORLD.fxPush = function(pool, p) {
            if (pool === WORLD.fxSoft && p.kind === 'flat' && p.s0 === .34) window.__flashes++;
            return orig(pool, p);
        };
    }""")

    # gol: dym ultrasów + ryk trybuny gospodarzy (stateT=0 i celebT=3.9 — jak w
    # RULES._goal, inaczej zerowy celebT zamyka celebrację w pierwszej klatce)
    page.evaluate("() => { RULES.state = 'goal'; RULES.stateT = 0; RULES.celebT = 3.9; STADIUM.goal(0); SIM.ball.x = 30; SIM.ball.z = 0; }")
    page.wait_for_function("() => WORLD.fxSoft.list.length > 10", timeout=60000)
    gl = page.evaluate("() => ({soft: WORLD.fxSoft.list.length, roar: +STADIUM.roars[0].value.toFixed(2)})")
    ok.append(("dym ultrasów po golu", gl["soft"] > 10))
    page.wait_for_function("() => STADIUM.roars[0].value > 0.6", timeout=60000)
    ok.append(("dopingo ryk gospodarzy", True))
    print("gol:", gl, flush=True)

    # stroboskop: wymuś akumulator błysków i sprawdź, czy fxFlashes tworzy cząstki
    page.evaluate("() => { WORLD._flashAcc = 1; }")
    page.wait_for_function("() => window.__flashes > 0", timeout=60000)
    fl = page.evaluate("() => window.__flashes")
    ok.append(("stroboskop trybun", fl > 0))
    print("błyski:", fl, flush=True)

    # koniec ceremonii — fajerwerki (akumulator tuż pod progiem .5 s)
    page.evaluate("() => { RULES.state = 'closing'; RULES.stateT = 0; WORLD._fwAcc = 0.49; }")
    page.wait_for_function("() => WORLD._fwT !== undefined && WORLD.fxSoft.list.length > 5", timeout=90000)
    cl = page.evaluate("() => ({soft: WORLD.fxSoft.list.length, conf: WORLD.fxConf.list.length, fwT: +WORLD._fwT.toFixed(1)})")
    ok.append(("konfetti zakończenia", cl["conf"] > 40))
    ok.append(("fajerwerki w puli", cl["soft"] > 5))
    print("zakończenie:", cl, flush=True)

    page.evaluate("() => { RULES.state = 'menu'; delete window.__flashes; }")
    page.wait_for_timeout(600)
    ok.append(("brak błędów strony", not errs))
    if errs: print("BŁĘDY:", errs[:3], flush=True)
    browser.close()

fails = [n for n, v in ok if not v]
for n, v in ok: print(("OK   " if v else "BRAK ") + n)
print("WYNIK:", "OK" if not fails else "PORAŻKA: " + ", ".join(fails))
