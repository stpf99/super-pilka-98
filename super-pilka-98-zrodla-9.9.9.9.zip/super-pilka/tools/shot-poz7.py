#!/usr/bin/env python3
"""Zrzuty kontrolne poz. 7: tifo podczas otwarcia i efekty gola nocą."""
from playwright.sync_api import sync_playwright
from pathlib import Path

GAME = Path(__file__).resolve().parent.parent / "super-pilka-98.html"
OUT = Path("/tmp/render"); OUT.mkdir(exist_ok=True)
with sync_playwright() as pw:
    browser = pw.chromium.launch(args=["--use-gl=swiftshader", "--enable-unsafe-swiftshader"])
    page = browser.new_page(viewport={"width": 800, "height": 450})
    page.set_default_timeout(30000)
    page.goto(GAME.as_uri())
    page.wait_for_timeout(6000)
    page.evaluate("() => { SET.q = 1; WORLD.quality(); }")
    page.evaluate("() => document.getElementById('btnPlay').click()")
    page.wait_for_function("() => RULES.state === 'opening'", timeout=120000)
    page.evaluate("() => { RULES.stateT = 4.2; }")
    page.wait_for_function("() => STADIUM.tifos[0].mesh.scale.y > .9", timeout=60000)
    # szeroki widok na trybunę z tifo (kamera ręczna nad boiskiem)
    page.evaluate("""() => {
        const t = STADIUM.tifos[1].mesh.position;
        WORLD.cam.position.set(t.x*0.72, 16.5, 26);
        WORLD.cam.lookAt(t.x*0.8, 3.2, t.z);
    }""")
    page.wait_for_timeout(2000)
    page.screenshot(path=str(OUT / "tifo.png"), timeout=150000)
    # gol nocą: dym + błyski + ryk
    page.evaluate("""() => { RULES.state='goal'; RULES.stateT=0; RULES.celebT=3.9;
        STADIUM.goal(0); SIM.ball.x=30; SIM.ball.z=0; WORLD.setNight(true); WORLD._flashAcc=1; }""")
    page.wait_for_function("() => WORLD.fxSoft.list.length > 15", timeout=60000)
    page.evaluate("""() => {
        window.__camUpd = CAM.update;
        CAM.update = function(){};               /* zamroź reżysera kamery */
        WORLD.setNight(true);
        const t = STADIUM.anchors[0].drum.p;
        WORLD.cam.position.set(t[0]*0.72, t[1]+6.5, t[2]*0.62);
        WORLD.cam.lookAt(t[0], t[1]+2.0, t[2]);
        WORLD.cam.fov = 46; WORLD.cam.updateProjectionMatrix();
    }""")
    page.wait_for_timeout(1800)
    page.screenshot(path=str(OUT / "gol-noc.png"), timeout=150000)
    browser.close()
print("zrzuty zapisane")
